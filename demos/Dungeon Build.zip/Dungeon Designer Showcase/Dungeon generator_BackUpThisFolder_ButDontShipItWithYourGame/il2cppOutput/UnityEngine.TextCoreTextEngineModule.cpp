﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>



// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.TextCore.Text.FontAsset>
struct Dictionary_2_tC20B3D6AE4370C892734F670EF4D1FB9CE91F371;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32>
struct Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.Character>
struct Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph>
struct Dictionary_2_tC61348D10610A6B3D7B65102D82AC3467D59EAA7;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0;
// System.Collections.Generic.Dictionary`2<System.UInt32,System.Int32>
struct Dictionary_2_t1A4804CA9724B6CE01D6ECABE81CE0848CBA80B4;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteCharacter>
struct Dictionary_2_tD4154357CA320908C5A7A35ED81FA2A9856C28D9;
// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteGlyph>
struct Dictionary_2_tDC0461D8CBB2E6B52DD2C421114EDE7C1C70DE73;
// System.Collections.Generic.HashSet`1<System.Int32>
struct HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2;
// System.Collections.Generic.HashSet`1<System.UInt32>
struct HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A;
// System.Collections.Generic.IEqualityComparer`1<System.UInt32>
struct IEqualityComparer_1_t0BB8211419723EB61BF19007AC9D62365E50500E;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct KeyCollection_tF62DA58D084558E31E5A09537D460287D59B1A89;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character>
struct List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset>
struct List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>
struct List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C;
// System.Collections.Generic.List`1<UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct List_1_t3CA8EA3609B406A4099002CBD02BB599F3B1D5DB;
// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>
struct List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset>
struct List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter>
struct List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteGlyph>
struct List_1_t063B87D3CFDC3AEE80E33EFBDA1410C697D71AD6;
// System.Collections.Generic.List`1<UnityEngine.Texture2D>
struct List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4;
// System.Collections.Generic.List`1<System.UInt32>
struct List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A;
// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.TextSettings/FontReferenceMap>
struct List_1_tA1547550E5FBA50050B20DA74245C38434654EE8;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct ValueCollection_tB99ECE94AB57EE9AB1FAC3276CC7108B468367C9;
// System.Collections.Generic.Dictionary`2/Entry<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>[]
struct EntryU5BU5D_t68A3C3C2FF61504922EC13C363BED0E17D474FA8;
// System.Collections.Generic.HashSet`1/Slot<System.UInt32>[]
struct SlotU5BU5D_tBF418274114DA8D3D070D784415BF0500C1960C6;
// System.Byte[]
struct ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031;
// System.Char[]
struct CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB;
// UnityEngine.Color32[]
struct Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259;
// UnityEngine.TextCore.Text.FontWeightPair[]
struct FontWeightPairU5BU5D_t76E8DB55C81EEBEFA2E6D1D3E3B3EA1FB4C4954F;
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
// System.Int32Enum[]
struct Int32EnumU5BU5D_t87B7DB802810C38016332669039EF42C487A081F;
// UnityEngine.TextCore.Text.LineInfo[]
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D;
// UnityEngine.TextCore.Text.LinkInfo[]
struct LinkInfoU5BU5D_tB7EB23E47AF29CCBEC884F9D0DB95BC97F62AE51;
// UnityEngine.TextCore.Text.MaterialReference[]
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E;
// UnityEngine.TextCore.Text.MeshInfo[]
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6;
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
// UnityEngine.TextCore.Text.PageInfo[]
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4;
// UnityEngine.TextCore.Text.RichTextTagAttribute[]
struct RichTextTagAttributeU5BU5D_tEE9D071B3246F23742DBF4226567620BCBB24A14;
// System.Single[]
struct SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C;
// UnityEngine.TextCore.Text.TextAlignment[]
struct TextAlignmentU5BU5D_t756DC2D672145699CB9718DDBA5982ED51A95F49;
// UnityEngine.TextCore.Text.TextColorGradient[]
struct TextColorGradientU5BU5D_tA27A5E49640CF01334A10DBDBC959903AFBD941A;
// UnityEngine.TextCore.Text.TextElementInfo[]
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E;
// UnityEngine.TextCore.Text.TextFontWeight[]
struct TextFontWeightU5BU5D_t3DE32809AEE657255C8333897D61F2EA5279D43F;
// UnityEngine.Texture2D[]
struct Texture2DU5BU5D_t05332F1E3F7D4493E304C702201F9BE4F9236191;
// System.UInt32[]
struct UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
// UnityEngine.TextCore.Text.WordInfo[]
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B;
// UnityEngine.TextCore.Text.XmlTagAttribute[]
struct XmlTagAttributeU5BU5D_tEDFE75BDDC81D11CEA2F2A12583516D3BFB309B2;
// UnityEngine.TextCore.Text.Character
struct Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC;
// UnityEngine.Font
struct Font_tC95270EA3198038970422D78B74A7F2E218A96B6;
// UnityEngine.TextCore.Text.FontAsset
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958;
// UnityEngine.TextCore.Text.FontFeatureTable
struct FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7;
// UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F;
// UnityEngine.Material
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3;
// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t3C47F63E24BEB9FCE2DC6309E027F238DC5C5E37;
// UnityEngine.Shader
struct Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692;
// UnityEngine.TextCore.Text.SpriteAsset
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313;
// System.String
struct String_t;
// UnityEngine.TextAsset
struct TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69;
// UnityEngine.TextCore.Text.TextAsset
struct TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8;
// UnityEngine.TextCore.Text.TextColorGradient
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70;
// UnityEngine.TextCore.Text.TextElement
struct TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA;
// UnityEngine.TextCore.Text.TextGenerationSettings
struct TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2;
// UnityEngine.TextCore.Text.TextGenerator
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366;
// UnityEngine.TextCore.Text.TextInfo
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09;
// UnityEngine.TextCore.Text.TextSettings
struct TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64;
// UnityEngine.TextCore.Text.TextStyleSheet
struct TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E;
// UnityEngine.Texture
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700;
// UnityEngine.Texture2D
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
// UnityEngine.TextCore.Text.UnicodeLineBreakingRules
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;

IL2CPP_EXTERN_C RuntimeClass* Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E;
IL2CPP_EXTERN_C String_t* _stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D;
IL2CPP_EXTERN_C String_t* _stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var;
struct Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B;
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7;
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2;

struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D;
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E;
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6;
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4;
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E;
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C;
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>
struct Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0  : public RuntimeObject
{
	// System.Int32[] System.Collections.Generic.Dictionary`2::_buckets
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets_0;
	// System.Collections.Generic.Dictionary`2/Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::_entries
	EntryU5BU5D_t68A3C3C2FF61504922EC13C363BED0E17D474FA8* ____entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::_count
	int32_t ____count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::_freeList
	int32_t ____freeList_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::_freeCount
	int32_t ____freeCount_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::_version
	int32_t ____version_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::_comparer
	RuntimeObject* ____comparer_6;
	// System.Collections.Generic.Dictionary`2/KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::_keys
	KeyCollection_tF62DA58D084558E31E5A09537D460287D59B1A89* ____keys_7;
	// System.Collections.Generic.Dictionary`2/ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::_values
	ValueCollection_tB99ECE94AB57EE9AB1FAC3276CC7108B468367C9* ____values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject* ____syncRoot_9;
};

// System.Collections.Generic.HashSet`1<System.UInt32>
struct HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A  : public RuntimeObject
{
	// System.Int32[] System.Collections.Generic.HashSet`1::_buckets
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets_7;
	// System.Collections.Generic.HashSet`1/Slot<T>[] System.Collections.Generic.HashSet`1::_slots
	SlotU5BU5D_tBF418274114DA8D3D070D784415BF0500C1960C6* ____slots_8;
	// System.Int32 System.Collections.Generic.HashSet`1::_count
	int32_t ____count_9;
	// System.Int32 System.Collections.Generic.HashSet`1::_lastIndex
	int32_t ____lastIndex_10;
	// System.Int32 System.Collections.Generic.HashSet`1::_freeList
	int32_t ____freeList_11;
	// System.Collections.Generic.IEqualityComparer`1<T> System.Collections.Generic.HashSet`1::_comparer
	RuntimeObject* ____comparer_12;
	// System.Int32 System.Collections.Generic.HashSet`1::_version
	int32_t ____version_13;
	// System.Runtime.Serialization.SerializationInfo System.Collections.Generic.HashSet`1::_siInfo
	SerializationInfo_t3C47F63E24BEB9FCE2DC6309E027F238DC5C5E37* ____siInfo_14;
};

// UnityEngine.TextCore.Text.FontFeatureTable
struct FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7  : public RuntimeObject
{
	// System.Collections.Generic.List`1<UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord> UnityEngine.TextCore.Text.FontFeatureTable::m_GlyphPairAdjustmentRecords
	List_1_t3CA8EA3609B406A4099002CBD02BB599F3B1D5DB* ___m_GlyphPairAdjustmentRecords_0;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord> UnityEngine.TextCore.Text.FontFeatureTable::m_GlyphPairAdjustmentRecordLookup
	Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* ___m_GlyphPairAdjustmentRecordLookup_1;
};

// System.String
struct String_t  : public RuntimeObject
{
	// System.Int32 System.String::_stringLength
	int32_t ____stringLength_4;
	// System.Char System.String::_firstChar
	Il2CppChar ____firstChar_5;
};

// UnityEngine.TextCore.Text.TextGeneratorUtilities
struct TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53  : public RuntimeObject
{
};

// UnityEngine.TextCore.Text.TextInfo
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09  : public RuntimeObject
{
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::characterCount
	int32_t ___characterCount_2;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::spriteCount
	int32_t ___spriteCount_3;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::spaceCount
	int32_t ___spaceCount_4;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::wordCount
	int32_t ___wordCount_5;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::linkCount
	int32_t ___linkCount_6;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::lineCount
	int32_t ___lineCount_7;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::pageCount
	int32_t ___pageCount_8;
	// System.Int32 UnityEngine.TextCore.Text.TextInfo::materialCount
	int32_t ___materialCount_9;
	// UnityEngine.TextCore.Text.TextElementInfo[] UnityEngine.TextCore.Text.TextInfo::textElementInfo
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* ___textElementInfo_10;
	// UnityEngine.TextCore.Text.WordInfo[] UnityEngine.TextCore.Text.TextInfo::wordInfo
	WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* ___wordInfo_11;
	// UnityEngine.TextCore.Text.LinkInfo[] UnityEngine.TextCore.Text.TextInfo::linkInfo
	LinkInfoU5BU5D_tB7EB23E47AF29CCBEC884F9D0DB95BC97F62AE51* ___linkInfo_12;
	// UnityEngine.TextCore.Text.LineInfo[] UnityEngine.TextCore.Text.TextInfo::lineInfo
	LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* ___lineInfo_13;
	// UnityEngine.TextCore.Text.PageInfo[] UnityEngine.TextCore.Text.TextInfo::pageInfo
	PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* ___pageInfo_14;
	// UnityEngine.TextCore.Text.MeshInfo[] UnityEngine.TextCore.Text.TextInfo::meshInfo
	MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* ___meshInfo_15;
	// System.Boolean UnityEngine.TextCore.Text.TextInfo::isDirty
	bool ___isDirty_16;
};

// UnityEngine.TextCore.Text.TextShaderUtilities
struct TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692  : public RuntimeObject
{
};

// UnityEngine.TextCore.Text.UnicodeLineBreakingRules
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E  : public RuntimeObject
{
	// UnityEngine.TextAsset UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_UnicodeLineBreakingRules
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_UnicodeLineBreakingRules_1;
	// UnityEngine.TextAsset UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_LeadingCharacters
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_LeadingCharacters_2;
	// UnityEngine.TextAsset UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_FollowingCharacters
	TextAsset_t2C64E93DA366D9DE5A8209E1802FA4884AC1BD69* ___m_FollowingCharacters_3;
	// System.Boolean UnityEngine.TextCore.Text.UnicodeLineBreakingRules::m_UseModernHangulLineBreakingRules
	bool ___m_UseModernHangulLineBreakingRules_4;
};

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>
struct TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Object>
struct TextProcessingStack_1_t5EA97AAC21CEE068194F77E59929440F85AD3991 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	RuntimeObject* ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>
struct TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	SingleU5BU5D_t89DEFE97BCEDB5857010E79ECE0F52CF6E93B87C* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	float ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient>
struct TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	TextColorGradientU5BU5D_tA27A5E49640CF01334A10DBDBC959903AFBD941A* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;
};

// System.Byte
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3 
{
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;
};

// System.Char
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17 
{
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;
};

// UnityEngine.Color
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;
};

// UnityEngine.Color32
struct Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B 
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Int32 UnityEngine.Color32::rgba
			int32_t ___rgba_0;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___rgba_0_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			// System.Byte UnityEngine.Color32::r
			uint8_t ___r_1;
		};
		#pragma pack(pop, tp)
		struct
		{
			uint8_t ___r_1_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___g_2_OffsetPadding[1];
			// System.Byte UnityEngine.Color32::g
			uint8_t ___g_2;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___g_2_OffsetPadding_forAlignmentOnly[1];
			uint8_t ___g_2_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___b_3_OffsetPadding[2];
			// System.Byte UnityEngine.Color32::b
			uint8_t ___b_3;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___b_3_OffsetPadding_forAlignmentOnly[2];
			uint8_t ___b_3_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			char ___a_4_OffsetPadding[3];
			// System.Byte UnityEngine.Color32::a
			uint8_t ___a_4;
		};
		#pragma pack(pop, tp)
		struct
		{
			char ___a_4_OffsetPadding_forAlignmentOnly[3];
			uint8_t ___a_4_forAlignmentOnly;
		};
	};
};

// System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2  : public ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F
{
};
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_com
{
};

// UnityEngine.TextCore.FaceInfo
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 
{
	// System.Int32 UnityEngine.TextCore.FaceInfo::m_FaceIndex
	int32_t ___m_FaceIndex_0;
	// System.String UnityEngine.TextCore.FaceInfo::m_FamilyName
	String_t* ___m_FamilyName_1;
	// System.String UnityEngine.TextCore.FaceInfo::m_StyleName
	String_t* ___m_StyleName_2;
	// System.Int32 UnityEngine.TextCore.FaceInfo::m_PointSize
	int32_t ___m_PointSize_3;
	// System.Single UnityEngine.TextCore.FaceInfo::m_Scale
	float ___m_Scale_4;
	// System.Int32 UnityEngine.TextCore.FaceInfo::m_UnitsPerEM
	int32_t ___m_UnitsPerEM_5;
	// System.Single UnityEngine.TextCore.FaceInfo::m_LineHeight
	float ___m_LineHeight_6;
	// System.Single UnityEngine.TextCore.FaceInfo::m_AscentLine
	float ___m_AscentLine_7;
	// System.Single UnityEngine.TextCore.FaceInfo::m_CapLine
	float ___m_CapLine_8;
	// System.Single UnityEngine.TextCore.FaceInfo::m_MeanLine
	float ___m_MeanLine_9;
	// System.Single UnityEngine.TextCore.FaceInfo::m_Baseline
	float ___m_Baseline_10;
	// System.Single UnityEngine.TextCore.FaceInfo::m_DescentLine
	float ___m_DescentLine_11;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SuperscriptOffset
	float ___m_SuperscriptOffset_12;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SuperscriptSize
	float ___m_SuperscriptSize_13;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SubscriptOffset
	float ___m_SubscriptOffset_14;
	// System.Single UnityEngine.TextCore.FaceInfo::m_SubscriptSize
	float ___m_SubscriptSize_15;
	// System.Single UnityEngine.TextCore.FaceInfo::m_UnderlineOffset
	float ___m_UnderlineOffset_16;
	// System.Single UnityEngine.TextCore.FaceInfo::m_UnderlineThickness
	float ___m_UnderlineThickness_17;
	// System.Single UnityEngine.TextCore.FaceInfo::m_StrikethroughOffset
	float ___m_StrikethroughOffset_18;
	// System.Single UnityEngine.TextCore.FaceInfo::m_StrikethroughThickness
	float ___m_StrikethroughThickness_19;
	// System.Single UnityEngine.TextCore.FaceInfo::m_TabWidth
	float ___m_TabWidth_20;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.FaceInfo
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756_marshaled_pinvoke
{
	int32_t ___m_FaceIndex_0;
	char* ___m_FamilyName_1;
	char* ___m_StyleName_2;
	int32_t ___m_PointSize_3;
	float ___m_Scale_4;
	int32_t ___m_UnitsPerEM_5;
	float ___m_LineHeight_6;
	float ___m_AscentLine_7;
	float ___m_CapLine_8;
	float ___m_MeanLine_9;
	float ___m_Baseline_10;
	float ___m_DescentLine_11;
	float ___m_SuperscriptOffset_12;
	float ___m_SuperscriptSize_13;
	float ___m_SubscriptOffset_14;
	float ___m_SubscriptSize_15;
	float ___m_UnderlineOffset_16;
	float ___m_UnderlineThickness_17;
	float ___m_StrikethroughOffset_18;
	float ___m_StrikethroughThickness_19;
	float ___m_TabWidth_20;
};
// Native definition for COM marshalling of UnityEngine.TextCore.FaceInfo
struct FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756_marshaled_com
{
	int32_t ___m_FaceIndex_0;
	Il2CppChar* ___m_FamilyName_1;
	Il2CppChar* ___m_StyleName_2;
	int32_t ___m_PointSize_3;
	float ___m_Scale_4;
	int32_t ___m_UnitsPerEM_5;
	float ___m_LineHeight_6;
	float ___m_AscentLine_7;
	float ___m_CapLine_8;
	float ___m_MeanLine_9;
	float ___m_Baseline_10;
	float ___m_DescentLine_11;
	float ___m_SuperscriptOffset_12;
	float ___m_SuperscriptSize_13;
	float ___m_SubscriptOffset_14;
	float ___m_SubscriptSize_15;
	float ___m_UnderlineOffset_16;
	float ___m_UnderlineThickness_17;
	float ___m_StrikethroughOffset_18;
	float ___m_StrikethroughThickness_19;
	float ___m_TabWidth_20;
};

// UnityEngine.TextCore.Text.FontAssetCreationEditorSettings
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52 
{
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::sourceFontFileGUID
	String_t* ___sourceFontFileGUID_0;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::faceIndex
	int32_t ___faceIndex_1;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::pointSizeSamplingMode
	int32_t ___pointSizeSamplingMode_2;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::pointSize
	int32_t ___pointSize_3;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::padding
	int32_t ___padding_4;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::packingMode
	int32_t ___packingMode_5;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::atlasWidth
	int32_t ___atlasWidth_6;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::atlasHeight
	int32_t ___atlasHeight_7;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::characterSetSelectionMode
	int32_t ___characterSetSelectionMode_8;
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::characterSequence
	String_t* ___characterSequence_9;
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::referencedFontAssetGUID
	String_t* ___referencedFontAssetGUID_10;
	// System.String UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::referencedTextAssetGUID
	String_t* ___referencedTextAssetGUID_11;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::fontStyle
	int32_t ___fontStyle_12;
	// System.Single UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::fontStyleModifier
	float ___fontStyleModifier_13;
	// System.Int32 UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::renderMode
	int32_t ___renderMode_14;
	// System.Boolean UnityEngine.TextCore.Text.FontAssetCreationEditorSettings::includeFontFeatures
	bool ___includeFontFeatures_15;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.FontAssetCreationEditorSettings
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52_marshaled_pinvoke
{
	char* ___sourceFontFileGUID_0;
	int32_t ___faceIndex_1;
	int32_t ___pointSizeSamplingMode_2;
	int32_t ___pointSize_3;
	int32_t ___padding_4;
	int32_t ___packingMode_5;
	int32_t ___atlasWidth_6;
	int32_t ___atlasHeight_7;
	int32_t ___characterSetSelectionMode_8;
	char* ___characterSequence_9;
	char* ___referencedFontAssetGUID_10;
	char* ___referencedTextAssetGUID_11;
	int32_t ___fontStyle_12;
	float ___fontStyleModifier_13;
	int32_t ___renderMode_14;
	int32_t ___includeFontFeatures_15;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.FontAssetCreationEditorSettings
struct FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52_marshaled_com
{
	Il2CppChar* ___sourceFontFileGUID_0;
	int32_t ___faceIndex_1;
	int32_t ___pointSizeSamplingMode_2;
	int32_t ___pointSize_3;
	int32_t ___padding_4;
	int32_t ___packingMode_5;
	int32_t ___atlasWidth_6;
	int32_t ___atlasHeight_7;
	int32_t ___characterSetSelectionMode_8;
	Il2CppChar* ___characterSequence_9;
	Il2CppChar* ___referencedFontAssetGUID_10;
	Il2CppChar* ___referencedTextAssetGUID_11;
	int32_t ___fontStyle_12;
	float ___fontStyleModifier_13;
	int32_t ___renderMode_14;
	int32_t ___includeFontFeatures_15;
};

// UnityEngine.TextCore.Text.FontStyleStack
struct FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 
{
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::bold
	uint8_t ___bold_0;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::italic
	uint8_t ___italic_1;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::underline
	uint8_t ___underline_2;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::strikethrough
	uint8_t ___strikethrough_3;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::highlight
	uint8_t ___highlight_4;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::superscript
	uint8_t ___superscript_5;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::subscript
	uint8_t ___subscript_6;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::uppercase
	uint8_t ___uppercase_7;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::lowercase
	uint8_t ___lowercase_8;
	// System.Byte UnityEngine.TextCore.Text.FontStyleStack::smallcaps
	uint8_t ___smallcaps_9;
};

// UnityEngine.TextCore.GlyphMetrics
struct GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A 
{
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_Width
	float ___m_Width_0;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_Height
	float ___m_Height_1;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalBearingX
	float ___m_HorizontalBearingX_2;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalBearingY
	float ___m_HorizontalBearingY_3;
	// System.Single UnityEngine.TextCore.GlyphMetrics::m_HorizontalAdvance
	float ___m_HorizontalAdvance_4;
};

// UnityEngine.TextCore.GlyphRect
struct GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D 
{
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Y
	int32_t ___m_Y_1;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Width
	int32_t ___m_Width_2;
	// System.Int32 UnityEngine.TextCore.GlyphRect::m_Height
	int32_t ___m_Height_3;
};

// UnityEngine.TextCore.LowLevel.GlyphValueRecord
struct GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E 
{
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_XPlacement
	float ___m_XPlacement_0;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_YPlacement
	float ___m_YPlacement_1;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_XAdvance
	float ___m_XAdvance_2;
	// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::m_YAdvance
	float ___m_YAdvance_3;
};

// System.Int32
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

// UnityEngine.TextCore.Text.MaterialReference
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 
{
	// System.Int32 UnityEngine.TextCore.Text.MaterialReference::index
	int32_t ___index_0;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.MaterialReference::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.MaterialReference::spriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_2;
	// UnityEngine.Material UnityEngine.TextCore.Text.MaterialReference::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_3;
	// System.Boolean UnityEngine.TextCore.Text.MaterialReference::isDefaultMaterial
	bool ___isDefaultMaterial_4;
	// System.Boolean UnityEngine.TextCore.Text.MaterialReference::isFallbackMaterial
	bool ___isFallbackMaterial_5;
	// UnityEngine.Material UnityEngine.TextCore.Text.MaterialReference::fallbackMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial_6;
	// System.Single UnityEngine.TextCore.Text.MaterialReference::padding
	float ___padding_7;
	// System.Int32 UnityEngine.TextCore.Text.MaterialReference::referenceCount
	int32_t ___referenceCount_8;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.MaterialReference
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26_marshaled_pinvoke
{
	int32_t ___index_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_2;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_3;
	int32_t ___isDefaultMaterial_4;
	int32_t ___isFallbackMaterial_5;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial_6;
	float ___padding_7;
	int32_t ___referenceCount_8;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.MaterialReference
struct MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26_marshaled_com
{
	int32_t ___index_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_2;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_3;
	int32_t ___isDefaultMaterial_4;
	int32_t ___isFallbackMaterial_5;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___fallbackMaterial_6;
	float ___padding_7;
	int32_t ___referenceCount_8;
};

// UnityEngine.Matrix4x4
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 
{
	// System.Single UnityEngine.Matrix4x4::m00
	float ___m00_0;
	// System.Single UnityEngine.Matrix4x4::m10
	float ___m10_1;
	// System.Single UnityEngine.Matrix4x4::m20
	float ___m20_2;
	// System.Single UnityEngine.Matrix4x4::m30
	float ___m30_3;
	// System.Single UnityEngine.Matrix4x4::m01
	float ___m01_4;
	// System.Single UnityEngine.Matrix4x4::m11
	float ___m11_5;
	// System.Single UnityEngine.Matrix4x4::m21
	float ___m21_6;
	// System.Single UnityEngine.Matrix4x4::m31
	float ___m31_7;
	// System.Single UnityEngine.Matrix4x4::m02
	float ___m02_8;
	// System.Single UnityEngine.Matrix4x4::m12
	float ___m12_9;
	// System.Single UnityEngine.Matrix4x4::m22
	float ___m22_10;
	// System.Single UnityEngine.Matrix4x4::m32
	float ___m32_11;
	// System.Single UnityEngine.Matrix4x4::m03
	float ___m03_12;
	// System.Single UnityEngine.Matrix4x4::m13
	float ___m13_13;
	// System.Single UnityEngine.Matrix4x4::m23
	float ___m23_14;
	// System.Single UnityEngine.Matrix4x4::m33
	float ___m33_15;
};

// UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F 
{
	// System.Int32 UnityEngine.TextCore.Text.MeshInfo::vertexCount
	int32_t ___vertexCount_1;
	// UnityEngine.Vector3[] UnityEngine.TextCore.Text.MeshInfo::vertices
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___vertices_2;
	// UnityEngine.Vector2[] UnityEngine.TextCore.Text.MeshInfo::uvs0
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___uvs0_3;
	// UnityEngine.Vector2[] UnityEngine.TextCore.Text.MeshInfo::uvs2
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___uvs2_4;
	// UnityEngine.Color32[] UnityEngine.TextCore.Text.MeshInfo::colors32
	Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259* ___colors32_5;
	// System.Int32[] UnityEngine.TextCore.Text.MeshInfo::triangles
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___triangles_6;
	// UnityEngine.Material UnityEngine.TextCore.Text.MeshInfo::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_marshaled_pinvoke
{
	int32_t ___vertexCount_1;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___vertices_2;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs0_3;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs2_4;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* ___colors32_5;
	Il2CppSafeArray/*NONE*/* ___triangles_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_marshaled_com
{
	int32_t ___vertexCount_1;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* ___vertices_2;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs0_3;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* ___uvs2_4;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* ___colors32_5;
	Il2CppSafeArray/*NONE*/* ___triangles_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
};

// UnityEngine.TextCore.Text.PageInfo
struct PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 
{
	// System.Int32 UnityEngine.TextCore.Text.PageInfo::firstCharacterIndex
	int32_t ___firstCharacterIndex_0;
	// System.Int32 UnityEngine.TextCore.Text.PageInfo::lastCharacterIndex
	int32_t ___lastCharacterIndex_1;
	// System.Single UnityEngine.TextCore.Text.PageInfo::ascender
	float ___ascender_2;
	// System.Single UnityEngine.TextCore.Text.PageInfo::baseLine
	float ___baseLine_3;
	// System.Single UnityEngine.TextCore.Text.PageInfo::descender
	float ___descender_4;
};

// UnityEngine.Rect
struct Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D 
{
	// System.Single UnityEngine.Rect::m_XMin
	float ___m_XMin_0;
	// System.Single UnityEngine.Rect::m_YMin
	float ___m_YMin_1;
	// System.Single UnityEngine.Rect::m_Width
	float ___m_Width_2;
	// System.Single UnityEngine.Rect::m_Height
	float ___m_Height_3;
};

// System.Single
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	// System.Single System.Single::m_value
	float ___m_value_0;
};

// System.UInt32
struct UInt32_t1833D51FFA667B18A5AA4B8D34DE284F8495D29B 
{
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;
};

// UnityEngine.Vector2
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;
};

// UnityEngine.Vector3
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;
};

// UnityEngine.Vector4
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 
{
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;
};

// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};

// UnityEngine.TextCore.Text.WordInfo
struct WordInfo_tA466206097891A5A2590896EE164AFC406EB060D 
{
	// System.Int32 UnityEngine.TextCore.Text.WordInfo::firstCharacterIndex
	int32_t ___firstCharacterIndex_0;
	// System.Int32 UnityEngine.TextCore.Text.WordInfo::lastCharacterIndex
	int32_t ___lastCharacterIndex_1;
	// System.Int32 UnityEngine.TextCore.Text.WordInfo::characterCount
	int32_t ___characterCount_2;
};

// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD 
{
	// UnityEngine.TextCore.Text.Character UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::character
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character_0;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_2;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter::materialIndex
	int32_t ___materialIndex_3;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD_marshaled_pinvoke
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_2;
	int32_t ___materialIndex_3;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter
struct SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD_marshaled_com
{
	Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* ___character_0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_1;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_2;
	int32_t ___materialIndex_3;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>
struct TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	Color32U5BU5D_t38116C3E91765C4C5726CE12C77FAD7F9F737259* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>
struct TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.AtlasPopulationMode
struct AtlasPopulationMode_tD12439CB3789E0F868A2A2AC7D623C9B835E1B79 
{
	// System.Int32 UnityEngine.TextCore.Text.AtlasPopulationMode::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.ColorGradientMode
struct ColorGradientMode_t36364E6ABCEC0A0DBE9BAFF9F40DA5FFDCD969D0 
{
	// System.Int32 UnityEngine.TextCore.Text.ColorGradientMode::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.Extents
struct Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 
{
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.Extents::min
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___min_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.Extents::max
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___max_1;
};

// UnityEngine.TextCore.LowLevel.FontFeatureLookupFlags
struct FontFeatureLookupFlags_t2000121BA341A3CAE5E0D4FAC6AA4378FE14AE1B 
{
	// System.Int32 UnityEngine.TextCore.LowLevel.FontFeatureLookupFlags::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.FontStyles
struct FontStyles_t284AF8C10031F4774DF8BC8DE6DF9EC11EE14668 
{
	// System.Int32 UnityEngine.TextCore.Text.FontStyles::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord
struct GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 
{
	// System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::m_GlyphIndex
	uint32_t ___m_GlyphIndex_0;
	// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::m_GlyphValueRecord
	GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___m_GlyphValueRecord_1;
};

// UnityEngine.TextCore.GlyphClassDefinitionType
struct GlyphClassDefinitionType_t9C21A3848A07B17C2690F285B5FA60A2E246FBA2 
{
	// System.Int32 UnityEngine.TextCore.GlyphClassDefinitionType::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.LowLevel.GlyphRenderMode
struct GlyphRenderMode_tE7FB60827750662A45E89D168932FE2D8AEB5281 
{
	// System.Int32 UnityEngine.TextCore.LowLevel.GlyphRenderMode::value__
	int32_t ___value___2;
};

// System.Int32Enum
struct Int32Enum_tCBAC8BA2BFF3A845FA599F303093BBBA374B6F0C 
{
	// System.Int32 System.Int32Enum::value__
	int32_t ___value___2;
};

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// Unity.Profiling.ProfilerMarker
struct ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD 
{
	// System.IntPtr Unity.Profiling.ProfilerMarker::m_Ptr
	intptr_t ___m_Ptr_0;
};

// UnityEngine.TextCore.Text.TextAlignment
struct TextAlignment_tD681BE7D2451C44115A90D2D8AA7D91C78A5A070 
{
	// System.Int32 UnityEngine.TextCore.Text.TextAlignment::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.TextElementType
struct TextElementType_tEBCF09EEF888E8B1F62D3DD66AF21890D12545EB 
{
	// System.Byte UnityEngine.TextCore.Text.TextElementType::value__
	uint8_t ___value___2;
};

// UnityEngine.TextCore.Text.TextFontWeight
struct TextFontWeight_t789E26840C291C6C1270D4434CE007ACDFA40350 
{
	// System.Int32 UnityEngine.TextCore.Text.TextFontWeight::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.TextOverflowMode
struct TextOverflowMode_tB7F9FB28B889C1F21B14D3DAC32980D71D9D7F50 
{
	// System.Int32 UnityEngine.TextCore.Text.TextOverflowMode::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.TextVertex
struct TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 
{
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextVertex::position
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___position_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextVertex::uv
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv_1;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextVertex::uv2
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv2_2;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextVertex::uv4
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___uv4_3;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextVertex::color
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_4;
};

// UnityEngine.TextCore.Text.TextureMapping
struct TextureMapping_t14CF4FEE624B1D968B076DAE56E67AA4756B653A 
{
	// System.Int32 UnityEngine.TextCore.Text.TextureMapping::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.VertexSortingOrder
struct VertexSortingOrder_tEA3D744EB3D7C496D69F756B98344FDA38432EB9 
{
	// System.Int32 UnityEngine.TextCore.Text.VertexSortingOrder::value__
	int32_t ___value___2;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32Enum>
struct TextProcessingStack_1_t9C24840D494C4878BD8680855123926D6243C90D 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	Int32EnumU5BU5D_t87B7DB802810C38016332669039EF42C487A081F* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment>
struct TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	TextAlignmentU5BU5D_t756DC2D672145699CB9718DDBA5982ED51A95F49* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight>
struct TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 
{
	// T[] UnityEngine.TextCore.Text.TextProcessingStack`1::itemStack
	TextFontWeightU5BU5D_t3DE32809AEE657255C8333897D61F2EA5279D43F* ___itemStack_0;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::index
	int32_t ___index_1;
	// T UnityEngine.TextCore.Text.TextProcessingStack`1::m_DefaultItem
	int32_t ___m_DefaultItem_2;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Capacity
	int32_t ___m_Capacity_3;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_RolloverSize
	int32_t ___m_RolloverSize_4;
	// System.Int32 UnityEngine.TextCore.Text.TextProcessingStack`1::m_Count
	int32_t ___m_Count_5;
};

// UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F  : public RuntimeObject
{
	// System.UInt32 UnityEngine.TextCore.Glyph::m_Index
	uint32_t ___m_Index_0;
	// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::m_Metrics
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics_1;
	// UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::m_GlyphRect
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect_2;
	// System.Single UnityEngine.TextCore.Glyph::m_Scale
	float ___m_Scale_3;
	// System.Int32 UnityEngine.TextCore.Glyph::m_AtlasIndex
	int32_t ___m_AtlasIndex_4;
	// UnityEngine.TextCore.GlyphClassDefinitionType UnityEngine.TextCore.Glyph::m_ClassDefinitionType
	int32_t ___m_ClassDefinitionType_5;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_pinvoke
{
	uint32_t ___m_Index_0;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics_1;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect_2;
	float ___m_Scale_3;
	int32_t ___m_AtlasIndex_4;
	int32_t ___m_ClassDefinitionType_5;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Glyph
struct Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F_marshaled_com
{
	uint32_t ___m_Index_0;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A ___m_Metrics_1;
	GlyphRect_tB6D225B9318A527A1CBC1B4078EB923398EB808D ___m_GlyphRect_2;
	float ___m_Scale_3;
	int32_t ___m_AtlasIndex_4;
	int32_t ___m_ClassDefinitionType_5;
};

// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord
struct GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E 
{
	// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_FirstAdjustmentRecord
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 ___m_FirstAdjustmentRecord_0;
	// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_SecondAdjustmentRecord
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 ___m_SecondAdjustmentRecord_1;
	// UnityEngine.TextCore.LowLevel.FontFeatureLookupFlags UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::m_FeatureLookupFlags
	int32_t ___m_FeatureLookupFlags_2;
};

// UnityEngine.TextCore.Text.LineInfo
struct LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 
{
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::controlCharacterCount
	int32_t ___controlCharacterCount_0;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::characterCount
	int32_t ___characterCount_1;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::visibleCharacterCount
	int32_t ___visibleCharacterCount_2;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::spaceCount
	int32_t ___spaceCount_3;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::visibleSpaceCount
	int32_t ___visibleSpaceCount_4;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::wordCount
	int32_t ___wordCount_5;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::firstCharacterIndex
	int32_t ___firstCharacterIndex_6;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::firstVisibleCharacterIndex
	int32_t ___firstVisibleCharacterIndex_7;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::lastCharacterIndex
	int32_t ___lastCharacterIndex_8;
	// System.Int32 UnityEngine.TextCore.Text.LineInfo::lastVisibleCharacterIndex
	int32_t ___lastVisibleCharacterIndex_9;
	// System.Single UnityEngine.TextCore.Text.LineInfo::length
	float ___length_10;
	// System.Single UnityEngine.TextCore.Text.LineInfo::lineHeight
	float ___lineHeight_11;
	// System.Single UnityEngine.TextCore.Text.LineInfo::ascender
	float ___ascender_12;
	// System.Single UnityEngine.TextCore.Text.LineInfo::baseline
	float ___baseline_13;
	// System.Single UnityEngine.TextCore.Text.LineInfo::descender
	float ___descender_14;
	// System.Single UnityEngine.TextCore.Text.LineInfo::maxAdvance
	float ___maxAdvance_15;
	// System.Single UnityEngine.TextCore.Text.LineInfo::width
	float ___width_16;
	// System.Single UnityEngine.TextCore.Text.LineInfo::marginLeft
	float ___marginLeft_17;
	// System.Single UnityEngine.TextCore.Text.LineInfo::marginRight
	float ___marginRight_18;
	// UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.LineInfo::alignment
	int32_t ___alignment_19;
	// UnityEngine.TextCore.Text.Extents UnityEngine.TextCore.Text.LineInfo::lineExtents
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___lineExtents_20;
};

// UnityEngine.Material
struct Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// UnityEngine.ScriptableObject
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_pinvoke : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A_marshaled_com : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
};

// UnityEngine.TextCore.Text.TextElement
struct TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA  : public RuntimeObject
{
	// UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextElement::m_ElementType
	uint8_t ___m_ElementType_0;
	// System.UInt32 UnityEngine.TextCore.Text.TextElement::m_Unicode
	uint32_t ___m_Unicode_1;
	// UnityEngine.TextCore.Text.TextAsset UnityEngine.TextCore.Text.TextElement::m_TextAsset
	TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* ___m_TextAsset_2;
	// UnityEngine.TextCore.Glyph UnityEngine.TextCore.Text.TextElement::m_Glyph
	Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* ___m_Glyph_3;
	// System.UInt32 UnityEngine.TextCore.Text.TextElement::m_GlyphIndex
	uint32_t ___m_GlyphIndex_4;
	// System.Single UnityEngine.TextCore.Text.TextElement::m_Scale
	float ___m_Scale_5;
};

// UnityEngine.TextCore.Text.TextElementInfo
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 
{
	// System.Char UnityEngine.TextCore.Text.TextElementInfo::character
	Il2CppChar ___character_0;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::index
	int32_t ___index_1;
	// UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextElementInfo::elementType
	uint8_t ___elementType_2;
	// UnityEngine.TextCore.Text.TextElement UnityEngine.TextCore.Text.TextElementInfo::textElement
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement_3;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextElementInfo::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextElementInfo::spriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_5;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::spriteIndex
	int32_t ___spriteIndex_6;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextElementInfo::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::materialReferenceIndex
	int32_t ___materialReferenceIndex_8;
	// System.Boolean UnityEngine.TextCore.Text.TextElementInfo::isUsingAlternateTypeface
	bool ___isUsingAlternateTypeface_9;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::pointSize
	float ___pointSize_10;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::lineNumber
	int32_t ___lineNumber_11;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::pageNumber
	int32_t ___pageNumber_12;
	// System.Int32 UnityEngine.TextCore.Text.TextElementInfo::vertexIndex
	int32_t ___vertexIndex_13;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexTopLeft
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft_14;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexBottomLeft
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft_15;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexTopRight
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight_16;
	// UnityEngine.TextCore.Text.TextVertex UnityEngine.TextCore.Text.TextElementInfo::vertexBottomRight
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight_17;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::topLeft
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft_18;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::bottomLeft
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft_19;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::topRight
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight_20;
	// UnityEngine.Vector3 UnityEngine.TextCore.Text.TextElementInfo::bottomRight
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight_21;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::origin
	float ___origin_22;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::ascender
	float ___ascender_23;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::baseLine
	float ___baseLine_24;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::descender
	float ___descender_25;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::xAdvance
	float ___xAdvance_26;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::aspectRatio
	float ___aspectRatio_27;
	// System.Single UnityEngine.TextCore.Text.TextElementInfo::scale
	float ___scale_28;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::color
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_29;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::underlineColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::strikethroughColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextElementInfo::highlightColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextElementInfo::style
	int32_t ___style_33;
	// System.Boolean UnityEngine.TextCore.Text.TextElementInfo::isVisible
	bool ___isVisible_34;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.TextElementInfo
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976_marshaled_pinvoke
{
	uint8_t ___character_0;
	int32_t ___index_1;
	uint8_t ___elementType_2;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement_3;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_5;
	int32_t ___spriteIndex_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
	int32_t ___materialReferenceIndex_8;
	int32_t ___isUsingAlternateTypeface_9;
	float ___pointSize_10;
	int32_t ___lineNumber_11;
	int32_t ___pageNumber_12;
	int32_t ___vertexIndex_13;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft_14;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft_15;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight_16;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight_17;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft_18;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft_19;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight_20;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight_21;
	float ___origin_22;
	float ___ascender_23;
	float ___baseLine_24;
	float ___descender_25;
	float ___xAdvance_26;
	float ___aspectRatio_27;
	float ___scale_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	int32_t ___style_33;
	int32_t ___isVisible_34;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.TextElementInfo
struct TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976_marshaled_com
{
	uint8_t ___character_0;
	int32_t ___index_1;
	uint8_t ___elementType_2;
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___textElement_3;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_5;
	int32_t ___spriteIndex_6;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_7;
	int32_t ___materialReferenceIndex_8;
	int32_t ___isUsingAlternateTypeface_9;
	float ___pointSize_10;
	int32_t ___lineNumber_11;
	int32_t ___pageNumber_12;
	int32_t ___vertexIndex_13;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopLeft_14;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomLeft_15;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexTopRight_16;
	TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9 ___vertexBottomRight_17;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topLeft_18;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomLeft_19;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___topRight_20;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___bottomRight_21;
	float ___origin_22;
	float ___ascender_23;
	float ___baseLine_24;
	float ___descender_25;
	float ___xAdvance_26;
	float ___aspectRatio_27;
	float ___scale_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___color_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	int32_t ___style_33;
	int32_t ___isVisible_34;
};

// UnityEngine.TextCore.Text.TextGenerationSettings
struct TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2  : public RuntimeObject
{
	// System.String UnityEngine.TextCore.Text.TextGenerationSettings::text
	String_t* ___text_0;
	// UnityEngine.Rect UnityEngine.TextCore.Text.TextGenerationSettings::screenRect
	Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D ___screenRect_1;
	// UnityEngine.Vector4 UnityEngine.TextCore.Text.TextGenerationSettings::margins
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___margins_2;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::scale
	float ___scale_3;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextGenerationSettings::fontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___fontAsset_4;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextGenerationSettings::material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___material_5;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextGenerationSettings::spriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___spriteAsset_6;
	// UnityEngine.TextCore.Text.TextStyleSheet UnityEngine.TextCore.Text.TextGenerationSettings::styleSheet
	TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E* ___styleSheet_7;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextGenerationSettings::fontStyle
	int32_t ___fontStyle_8;
	// UnityEngine.TextCore.Text.TextSettings UnityEngine.TextCore.Text.TextGenerationSettings::textSettings
	TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* ___textSettings_9;
	// UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.TextGenerationSettings::textAlignment
	int32_t ___textAlignment_10;
	// UnityEngine.TextCore.Text.TextOverflowMode UnityEngine.TextCore.Text.TextGenerationSettings::overflowMode
	int32_t ___overflowMode_11;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::wordWrap
	bool ___wordWrap_12;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::wordWrappingRatio
	float ___wordWrappingRatio_13;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextGenerationSettings::color
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___color_14;
	// UnityEngine.TextCore.Text.TextColorGradient UnityEngine.TextCore.Text.TextGenerationSettings::fontColorGradient
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___fontColorGradient_15;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::tintSprites
	bool ___tintSprites_16;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::overrideRichTextColors
	bool ___overrideRichTextColors_17;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::fontSize
	float ___fontSize_18;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::autoSize
	bool ___autoSize_19;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::fontSizeMin
	float ___fontSizeMin_20;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::fontSizeMax
	float ___fontSizeMax_21;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::enableKerning
	bool ___enableKerning_22;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::richText
	bool ___richText_23;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::isRightToLeft
	bool ___isRightToLeft_24;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::extraPadding
	bool ___extraPadding_25;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::parseControlCharacters
	bool ___parseControlCharacters_26;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::characterSpacing
	float ___characterSpacing_27;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::wordSpacing
	float ___wordSpacing_28;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::lineSpacing
	float ___lineSpacing_29;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::paragraphSpacing
	float ___paragraphSpacing_30;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::lineSpacingMax
	float ___lineSpacingMax_31;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::maxVisibleCharacters
	int32_t ___maxVisibleCharacters_32;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::maxVisibleWords
	int32_t ___maxVisibleWords_33;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::maxVisibleLines
	int32_t ___maxVisibleLines_34;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::firstVisibleCharacter
	int32_t ___firstVisibleCharacter_35;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::useMaxVisibleDescender
	bool ___useMaxVisibleDescender_36;
	// UnityEngine.TextCore.Text.TextFontWeight UnityEngine.TextCore.Text.TextGenerationSettings::fontWeight
	int32_t ___fontWeight_37;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerationSettings::pageToDisplay
	int32_t ___pageToDisplay_38;
	// UnityEngine.TextCore.Text.TextureMapping UnityEngine.TextCore.Text.TextGenerationSettings::horizontalMapping
	int32_t ___horizontalMapping_39;
	// UnityEngine.TextCore.Text.TextureMapping UnityEngine.TextCore.Text.TextGenerationSettings::verticalMapping
	int32_t ___verticalMapping_40;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::uvLineOffset
	float ___uvLineOffset_41;
	// UnityEngine.TextCore.Text.VertexSortingOrder UnityEngine.TextCore.Text.TextGenerationSettings::geometrySortingOrder
	int32_t ___geometrySortingOrder_42;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerationSettings::inverseYAxis
	bool ___inverseYAxis_43;
	// System.Single UnityEngine.TextCore.Text.TextGenerationSettings::charWidthMaxAdj
	float ___charWidthMaxAdj_44;
};

// UnityEngine.TextCore.Text.Character
struct Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC  : public TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA
{
};

// UnityEngine.TextCore.Text.SpriteCharacter
struct SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5  : public TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA
{
	// System.String UnityEngine.TextCore.Text.SpriteCharacter::m_Name
	String_t* ___m_Name_6;
	// System.Int32 UnityEngine.TextCore.Text.SpriteCharacter::m_HashCode
	int32_t ___m_HashCode_7;
};

// UnityEngine.TextCore.Text.TextAsset
struct TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	// System.String UnityEngine.TextCore.Text.TextAsset::m_Version
	String_t* ___m_Version_4;
	// System.Int32 UnityEngine.TextCore.Text.TextAsset::m_InstanceID
	int32_t ___m_InstanceID_5;
	// System.Int32 UnityEngine.TextCore.Text.TextAsset::m_HashCode
	int32_t ___m_HashCode_6;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextAsset::m_Material
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_Material_7;
	// System.Int32 UnityEngine.TextCore.Text.TextAsset::m_MaterialHashCode
	int32_t ___m_MaterialHashCode_8;
};

// UnityEngine.TextCore.Text.TextColorGradient
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	// UnityEngine.TextCore.Text.ColorGradientMode UnityEngine.TextCore.Text.TextColorGradient::colorMode
	int32_t ___colorMode_4;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::topLeft
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___topLeft_5;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::topRight
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___topRight_6;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::bottomLeft
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___bottomLeft_7;
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::bottomRight
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___bottomRight_8;
};

// UnityEngine.TextCore.Text.TextSettings
struct TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64  : public ScriptableObject_tB3BFDB921A1B1795B38A5417D3B97A89A140436A
{
	// System.String UnityEngine.TextCore.Text.TextSettings::m_Version
	String_t* ___m_Version_4;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextSettings::m_DefaultFontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___m_DefaultFontAsset_5;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_DefaultFontAssetPath
	String_t* ___m_DefaultFontAssetPath_6;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.TextSettings::m_FallbackFontAssets
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___m_FallbackFontAssets_7;
	// System.Boolean UnityEngine.TextCore.Text.TextSettings::m_MatchMaterialPreset
	bool ___m_MatchMaterialPreset_8;
	// System.Int32 UnityEngine.TextCore.Text.TextSettings::m_MissingCharacterUnicode
	int32_t ___m_MissingCharacterUnicode_9;
	// System.Boolean UnityEngine.TextCore.Text.TextSettings::m_ClearDynamicDataOnBuild
	bool ___m_ClearDynamicDataOnBuild_10;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextSettings::m_DefaultSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_DefaultSpriteAsset_11;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_DefaultSpriteAssetPath
	String_t* ___m_DefaultSpriteAssetPath_12;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset> UnityEngine.TextCore.Text.TextSettings::m_FallbackSpriteAssets
	List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320* ___m_FallbackSpriteAssets_13;
	// System.UInt32 UnityEngine.TextCore.Text.TextSettings::m_MissingSpriteCharacterUnicode
	uint32_t ___m_MissingSpriteCharacterUnicode_14;
	// UnityEngine.TextCore.Text.TextStyleSheet UnityEngine.TextCore.Text.TextSettings::m_DefaultStyleSheet
	TextStyleSheet_t86A0FA5523897465F371A2ABC17DFA3558C8D15E* ___m_DefaultStyleSheet_15;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_StyleSheetsResourcePath
	String_t* ___m_StyleSheetsResourcePath_16;
	// System.String UnityEngine.TextCore.Text.TextSettings::m_DefaultColorGradientPresetsPath
	String_t* ___m_DefaultColorGradientPresetsPath_17;
	// UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.TextSettings::m_UnicodeLineBreakingRules
	UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* ___m_UnicodeLineBreakingRules_18;
	// System.Boolean UnityEngine.TextCore.Text.TextSettings::m_DisplayWarnings
	bool ___m_DisplayWarnings_19;
	// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.TextSettings::m_FontLookup
	Dictionary_2_tC20B3D6AE4370C892734F670EF4D1FB9CE91F371* ___m_FontLookup_20;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.TextSettings/FontReferenceMap> UnityEngine.TextCore.Text.TextSettings::m_FontReferences
	List_1_tA1547550E5FBA50050B20DA74245C38434654EE8* ___m_FontReferences_21;
};

// UnityEngine.TextCore.Text.WordWrapState
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 
{
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::previousWordBreak
	int32_t ___previousWordBreak_0;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::totalCharacterCount
	int32_t ___totalCharacterCount_1;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::visibleCharacterCount
	int32_t ___visibleCharacterCount_2;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::visibleSpriteCount
	int32_t ___visibleSpriteCount_3;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::visibleLinkCount
	int32_t ___visibleLinkCount_4;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::firstCharacterIndex
	int32_t ___firstCharacterIndex_5;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::firstVisibleCharacterIndex
	int32_t ___firstVisibleCharacterIndex_6;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::lastCharacterIndex
	int32_t ___lastCharacterIndex_7;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::lastVisibleCharIndex
	int32_t ___lastVisibleCharIndex_8;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::lineNumber
	int32_t ___lineNumber_9;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxCapHeight
	float ___maxCapHeight_10;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxAscender
	float ___maxAscender_11;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxDescender
	float ___maxDescender_12;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxLineAscender
	float ___maxLineAscender_13;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::maxLineDescender
	float ___maxLineDescender_14;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::previousLineAscender
	float ___previousLineAscender_15;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::xAdvance
	float ___xAdvance_16;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::preferredWidth
	float ___preferredWidth_17;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::preferredHeight
	float ___preferredHeight_18;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::previousLineScale
	float ___previousLineScale_19;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::wordCount
	int32_t ___wordCount_20;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.WordWrapState::fontStyle
	int32_t ___fontStyle_21;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::fontScale
	float ___fontScale_22;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::fontScaleMultiplier
	float ___fontScaleMultiplier_23;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::currentFontSize
	float ___currentFontSize_24;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::baselineOffset
	float ___baselineOffset_25;
	// System.Single UnityEngine.TextCore.Text.WordWrapState::lineOffset
	float ___lineOffset_26;
	// UnityEngine.TextCore.Text.TextInfo UnityEngine.TextCore.Text.WordWrapState::textInfo
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo_27;
	// UnityEngine.TextCore.Text.LineInfo UnityEngine.TextCore.Text.WordWrapState::lineInfo
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo_28;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::vertexColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor_29;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::underlineColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::strikethroughColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.WordWrapState::highlightColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	// UnityEngine.TextCore.Text.FontStyleStack UnityEngine.TextCore.Text.WordWrapState::basicStyleStack
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack_33;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::colorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack_34;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::underlineColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack_35;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::strikethroughColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack_36;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.WordWrapState::highlightColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack_37;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient> UnityEngine.TextCore.Text.WordWrapState::colorGradientStack
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack_38;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.WordWrapState::sizeStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack_39;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.WordWrapState::indentStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack_40;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight> UnityEngine.TextCore.Text.WordWrapState::fontWeightStack
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack_41;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.WordWrapState::styleStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack_42;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.WordWrapState::baselineStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack_43;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.WordWrapState::actionStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack_44;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference> UnityEngine.TextCore.Text.WordWrapState::materialReferenceStack
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack_45;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment> UnityEngine.TextCore.Text.WordWrapState::lineJustificationStack
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack_46;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::spriteAnimationId
	int32_t ___spriteAnimationId_47;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.WordWrapState::currentFontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset_48;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.WordWrapState::currentSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset_49;
	// UnityEngine.Material UnityEngine.TextCore.Text.WordWrapState::currentMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial_50;
	// System.Int32 UnityEngine.TextCore.Text.WordWrapState::currentMaterialIndex
	int32_t ___currentMaterialIndex_51;
	// UnityEngine.TextCore.Text.Extents UnityEngine.TextCore.Text.WordWrapState::meshExtents
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents_52;
	// System.Boolean UnityEngine.TextCore.Text.WordWrapState::tagNoParsing
	bool ___tagNoParsing_53;
	// System.Boolean UnityEngine.TextCore.Text.WordWrapState::isNonBreakingSpace
	bool ___isNonBreakingSpace_54;
};
// Native definition for P/Invoke marshalling of UnityEngine.TextCore.Text.WordWrapState
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123_marshaled_pinvoke
{
	int32_t ___previousWordBreak_0;
	int32_t ___totalCharacterCount_1;
	int32_t ___visibleCharacterCount_2;
	int32_t ___visibleSpriteCount_3;
	int32_t ___visibleLinkCount_4;
	int32_t ___firstCharacterIndex_5;
	int32_t ___firstVisibleCharacterIndex_6;
	int32_t ___lastCharacterIndex_7;
	int32_t ___lastVisibleCharIndex_8;
	int32_t ___lineNumber_9;
	float ___maxCapHeight_10;
	float ___maxAscender_11;
	float ___maxDescender_12;
	float ___maxLineAscender_13;
	float ___maxLineDescender_14;
	float ___previousLineAscender_15;
	float ___xAdvance_16;
	float ___preferredWidth_17;
	float ___preferredHeight_18;
	float ___previousLineScale_19;
	int32_t ___wordCount_20;
	int32_t ___fontStyle_21;
	float ___fontScale_22;
	float ___fontScaleMultiplier_23;
	float ___currentFontSize_24;
	float ___baselineOffset_25;
	float ___lineOffset_26;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo_27;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack_33;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack_34;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack_35;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack_36;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack_37;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack_38;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack_39;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack_40;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack_41;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack_42;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack_43;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack_44;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack_45;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack_46;
	int32_t ___spriteAnimationId_47;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset_48;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset_49;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial_50;
	int32_t ___currentMaterialIndex_51;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents_52;
	int32_t ___tagNoParsing_53;
	int32_t ___isNonBreakingSpace_54;
};
// Native definition for COM marshalling of UnityEngine.TextCore.Text.WordWrapState
struct WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123_marshaled_com
{
	int32_t ___previousWordBreak_0;
	int32_t ___totalCharacterCount_1;
	int32_t ___visibleCharacterCount_2;
	int32_t ___visibleSpriteCount_3;
	int32_t ___visibleLinkCount_4;
	int32_t ___firstCharacterIndex_5;
	int32_t ___firstVisibleCharacterIndex_6;
	int32_t ___lastCharacterIndex_7;
	int32_t ___lastVisibleCharIndex_8;
	int32_t ___lineNumber_9;
	float ___maxCapHeight_10;
	float ___maxAscender_11;
	float ___maxDescender_12;
	float ___maxLineAscender_13;
	float ___maxLineDescender_14;
	float ___previousLineAscender_15;
	float ___xAdvance_16;
	float ___preferredWidth_17;
	float ___preferredHeight_18;
	float ___previousLineScale_19;
	int32_t ___wordCount_20;
	int32_t ___fontStyle_21;
	float ___fontScale_22;
	float ___fontScaleMultiplier_23;
	float ___currentFontSize_24;
	float ___baselineOffset_25;
	float ___lineOffset_26;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___textInfo_27;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 ___lineInfo_28;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___vertexColor_29;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___underlineColor_30;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___strikethroughColor_31;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___highlightColor_32;
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___basicStyleStack_33;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___colorStack_34;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___underlineColorStack_35;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___strikethroughColorStack_36;
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___highlightColorStack_37;
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___colorGradientStack_38;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___sizeStack_39;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___indentStack_40;
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___fontWeightStack_41;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___styleStack_42;
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___baselineStack_43;
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___actionStack_44;
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___materialReferenceStack_45;
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___lineJustificationStack_46;
	int32_t ___spriteAnimationId_47;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___currentFontAsset_48;
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___currentSpriteAsset_49;
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___currentMaterial_50;
	int32_t ___currentMaterialIndex_51;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___meshExtents_52;
	int32_t ___tagNoParsing_53;
	int32_t ___isNonBreakingSpace_54;
};

// UnityEngine.TextCore.Text.FontAsset
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958  : public TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8
{
	// System.String UnityEngine.TextCore.Text.FontAsset::m_SourceFontFileGUID
	String_t* ___m_SourceFontFileGUID_9;
	// UnityEngine.Font UnityEngine.TextCore.Text.FontAsset::m_SourceFontFile
	Font_tC95270EA3198038970422D78B74A7F2E218A96B6* ___m_SourceFontFile_10;
	// UnityEngine.TextCore.Text.AtlasPopulationMode UnityEngine.TextCore.Text.FontAsset::m_AtlasPopulationMode
	int32_t ___m_AtlasPopulationMode_11;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::InternalDynamicOS
	bool ___InternalDynamicOS_12;
	// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.FontAsset::m_FaceInfo
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 ___m_FaceInfo_13;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_FamilyNameHashCode
	int32_t ___m_FamilyNameHashCode_14;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_StyleNameHashCode
	int32_t ___m_StyleNameHashCode_15;
	// UnityEngine.TextCore.Text.FontWeightPair[] UnityEngine.TextCore.Text.FontAsset::m_FontWeightTable
	FontWeightPairU5BU5D_t76E8DB55C81EEBEFA2E6D1D3E3B3EA1FB4C4954F* ___m_FontWeightTable_16;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphTable
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphTable_17;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphLookupDictionary
	Dictionary_2_tC61348D10610A6B3D7B65102D82AC3467D59EAA7* ___m_GlyphLookupDictionary_18;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::m_CharacterTable
	List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317* ___m_CharacterTable_19;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::m_CharacterLookupDictionary
	Dictionary_2_t93CDF0F4011A5A3024EB73A492F9512E3046EACB* ___m_CharacterLookupDictionary_20;
	// UnityEngine.Texture2D UnityEngine.TextCore.Text.FontAsset::m_AtlasTexture
	Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___m_AtlasTexture_21;
	// UnityEngine.Texture2D[] UnityEngine.TextCore.Text.FontAsset::m_AtlasTextures
	Texture2DU5BU5D_t05332F1E3F7D4493E304C702201F9BE4F9236191* ___m_AtlasTextures_22;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasTextureIndex
	int32_t ___m_AtlasTextureIndex_23;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::m_IsMultiAtlasTexturesEnabled
	bool ___m_IsMultiAtlasTexturesEnabled_24;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::m_ClearDynamicDataOnBuild
	bool ___m_ClearDynamicDataOnBuild_25;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasWidth
	int32_t ___m_AtlasWidth_26;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasHeight
	int32_t ___m_AtlasHeight_27;
	// System.Int32 UnityEngine.TextCore.Text.FontAsset::m_AtlasPadding
	int32_t ___m_AtlasPadding_28;
	// UnityEngine.TextCore.LowLevel.GlyphRenderMode UnityEngine.TextCore.Text.FontAsset::m_AtlasRenderMode
	int32_t ___m_AtlasRenderMode_29;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect> UnityEngine.TextCore.Text.FontAsset::m_UsedGlyphRects
	List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B* ___m_UsedGlyphRects_30;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect> UnityEngine.TextCore.Text.FontAsset::m_FreeGlyphRects
	List_1_t425D3A455811E316D2DF73E46CF9CD90A4341C1B* ___m_FreeGlyphRects_31;
	// UnityEngine.TextCore.Text.FontFeatureTable UnityEngine.TextCore.Text.FontAsset::m_FontFeatureTable
	FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* ___m_FontFeatureTable_32;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.FontAsset::m_FallbackFontAssetTable
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___m_FallbackFontAssetTable_33;
	// UnityEngine.TextCore.Text.FontAssetCreationEditorSettings UnityEngine.TextCore.Text.FontAsset::m_fontAssetCreationEditorSettings
	FontAssetCreationEditorSettings_t0FF28D2E78F090105C63C81F9E438A7B09E3EA52 ___m_fontAssetCreationEditorSettings_34;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_RegularStyleWeight
	float ___m_RegularStyleWeight_35;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_RegularStyleSpacing
	float ___m_RegularStyleSpacing_36;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_BoldStyleWeight
	float ___m_BoldStyleWeight_37;
	// System.Single UnityEngine.TextCore.Text.FontAsset::m_BoldStyleSpacing
	float ___m_BoldStyleSpacing_38;
	// System.Byte UnityEngine.TextCore.Text.FontAsset::m_ItalicStyleSlant
	uint8_t ___m_ItalicStyleSlant_39;
	// System.Byte UnityEngine.TextCore.Text.FontAsset::m_TabMultiple
	uint8_t ___m_TabMultiple_40;
	// System.Boolean UnityEngine.TextCore.Text.FontAsset::IsFontAssetLookupTablesDirty
	bool ___IsFontAssetLookupTablesDirty_41;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphsToRender
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphsToRender_55;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph> UnityEngine.TextCore.Text.FontAsset::m_GlyphsRendered
	List_1_t95DB74B8EE315F8F92B7B96D93C901C8C3F6FE2C* ___m_GlyphsRendered_56;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphIndexList
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphIndexList_57;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphIndexListNewlyAdded
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphIndexListNewlyAdded_58;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphsToAdd
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___m_GlyphsToAdd_59;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_GlyphsToAddLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_GlyphsToAddLookup_60;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.Character> UnityEngine.TextCore.Text.FontAsset::m_CharactersToAdd
	List_1_tFED0F30EE65D995591571D3CD2C10F22439CB317* ___m_CharactersToAdd_61;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_CharactersToAddLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_CharactersToAddLookup_62;
	// System.Collections.Generic.List`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::s_MissingCharacterList
	List_1_t9B68833848E4C4D7F623C05F6B77F0449396354A* ___s_MissingCharacterList_63;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.FontAsset::m_MissingUnicodesFromFontFile
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___m_MissingUnicodesFromFontFile_64;
};

// UnityEngine.TextCore.Text.SpriteAsset
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313  : public TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8
{
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> UnityEngine.TextCore.Text.SpriteAsset::m_NameLookup
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___m_NameLookup_9;
	// System.Collections.Generic.Dictionary`2<System.UInt32,System.Int32> UnityEngine.TextCore.Text.SpriteAsset::m_GlyphIndexLookup
	Dictionary_2_t1A4804CA9724B6CE01D6ECABE81CE0848CBA80B4* ___m_GlyphIndexLookup_10;
	// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.SpriteAsset::m_FaceInfo
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 ___m_FaceInfo_11;
	// UnityEngine.Texture UnityEngine.TextCore.Text.SpriteAsset::m_SpriteAtlasTexture
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_SpriteAtlasTexture_12;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteCharacterTable
	List_1_t7DA088250C54C07AF1211AE132355AD2D343EE51* ___m_SpriteCharacterTable_13;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteCharacter> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteCharacterLookup
	Dictionary_2_tD4154357CA320908C5A7A35ED81FA2A9856C28D9* ___m_SpriteCharacterLookup_14;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteGlyph> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteGlyphTable
	List_1_t063B87D3CFDC3AEE80E33EFBDA1410C697D71AD6* ___m_SpriteGlyphTable_15;
	// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.Text.SpriteGlyph> UnityEngine.TextCore.Text.SpriteAsset::m_SpriteGlyphLookup
	Dictionary_2_tDC0461D8CBB2E6B52DD2C421114EDE7C1C70DE73* ___m_SpriteGlyphLookup_16;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.SpriteAsset> UnityEngine.TextCore.Text.SpriteAsset::fallbackSpriteAssets
	List_1_t3EE59C28A34FCD5060EF6B6BAFA85F2C9D01D320* ___fallbackSpriteAssets_17;
	// System.Boolean UnityEngine.TextCore.Text.SpriteAsset::m_IsSpriteAssetLookupTablesDirty
	bool ___m_IsSpriteAssetLookupTablesDirty_18;
};

// UnityEngine.TextCore.Text.TextGenerator
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366  : public RuntimeObject
{
	// UnityEngine.Vector3[] UnityEngine.TextCore.Text.TextGenerator::m_RectTransformCorners
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* ___m_RectTransformCorners_1;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginWidth
	float ___m_MarginWidth_2;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginHeight
	float ___m_MarginHeight_3;
	// System.Int32[] UnityEngine.TextCore.Text.TextGenerator::m_CharBuffer
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___m_CharBuffer_4;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_PreferredWidth
	float ___m_PreferredWidth_5;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_PreferredHeight
	float ___m_PreferredHeight_6;
	// UnityEngine.TextCore.Text.FontAsset UnityEngine.TextCore.Text.TextGenerator::m_CurrentFontAsset
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___m_CurrentFontAsset_7;
	// UnityEngine.Material UnityEngine.TextCore.Text.TextGenerator::m_CurrentMaterial
	Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___m_CurrentMaterial_8;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_CurrentMaterialIndex
	int32_t ___m_CurrentMaterialIndex_9;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference> UnityEngine.TextCore.Text.TextGenerator::m_MaterialReferenceStack
	TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA ___m_MaterialReferenceStack_10;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_Padding
	float ___m_Padding_11;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextGenerator::m_CurrentSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_CurrentSpriteAsset_12;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_TotalCharacterCount
	int32_t ___m_TotalCharacterCount_13;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_FontScale
	float ___m_FontScale_14;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_FontSize
	float ___m_FontSize_15;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_FontScaleMultiplier
	float ___m_FontScaleMultiplier_16;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_CurrentFontSize
	float ___m_CurrentFontSize_17;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.TextGenerator::m_SizeStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_SizeStack_18;
	// UnityEngine.TextCore.Text.FontStyles UnityEngine.TextCore.Text.TextGenerator::m_FontStyleInternal
	int32_t ___m_FontStyleInternal_19;
	// UnityEngine.TextCore.Text.FontStyleStack UnityEngine.TextCore.Text.TextGenerator::m_FontStyleStack
	FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7 ___m_FontStyleStack_20;
	// UnityEngine.TextCore.Text.TextFontWeight UnityEngine.TextCore.Text.TextGenerator::m_FontWeightInternal
	int32_t ___m_FontWeightInternal_21;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight> UnityEngine.TextCore.Text.TextGenerator::m_FontWeightStack
	TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790 ___m_FontWeightStack_22;
	// UnityEngine.TextCore.Text.TextAlignment UnityEngine.TextCore.Text.TextGenerator::m_LineJustification
	int32_t ___m_LineJustification_23;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment> UnityEngine.TextCore.Text.TextGenerator::m_LineJustificationStack
	TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F ___m_LineJustificationStack_24;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_BaselineOffset
	float ___m_BaselineOffset_25;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.TextGenerator::m_BaselineOffsetStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_BaselineOffsetStack_26;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_FontColor32
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_FontColor32_27;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_HtmlColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_HtmlColor_28;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_UnderlineColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_UnderlineColor_29;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_StrikethroughColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_StrikethroughColor_30;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_ColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_ColorStack_31;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_UnderlineColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_UnderlineColorStack_32;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_StrikethroughColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_StrikethroughColorStack_33;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32> UnityEngine.TextCore.Text.TextGenerator::m_HighlightColorStack
	TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63 ___m_HighlightColorStack_34;
	// UnityEngine.TextCore.Text.TextColorGradient UnityEngine.TextCore.Text.TextGenerator::m_ColorGradientPreset
	TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___m_ColorGradientPreset_35;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient> UnityEngine.TextCore.Text.TextGenerator::m_ColorGradientStack
	TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E ___m_ColorGradientStack_36;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.TextGenerator::m_ActionStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_ActionStack_37;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsFxMatrixSet
	bool ___m_IsFxMatrixSet_38;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_LineOffset
	float ___m_LineOffset_39;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_LineHeight
	float ___m_LineHeight_40;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_CSpacing
	float ___m_CSpacing_41;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MonoSpacing
	float ___m_MonoSpacing_42;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_XAdvance
	float ___m_XAdvance_43;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_TagLineIndent
	float ___m_TagLineIndent_44;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_TagIndent
	float ___m_TagIndent_45;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single> UnityEngine.TextCore.Text.TextGenerator::m_IndentStack
	TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555 ___m_IndentStack_46;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_TagNoParsing
	bool ___m_TagNoParsing_47;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_CharacterCount
	int32_t ___m_CharacterCount_48;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_FirstCharacterOfLine
	int32_t ___m_FirstCharacterOfLine_49;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LastCharacterOfLine
	int32_t ___m_LastCharacterOfLine_50;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_FirstVisibleCharacterOfLine
	int32_t ___m_FirstVisibleCharacterOfLine_51;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LastVisibleCharacterOfLine
	int32_t ___m_LastVisibleCharacterOfLine_52;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxLineAscender
	float ___m_MaxLineAscender_53;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxLineDescender
	float ___m_MaxLineDescender_54;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LineNumber
	int32_t ___m_LineNumber_55;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LineVisibleCharacterCount
	int32_t ___m_LineVisibleCharacterCount_56;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_FirstOverflowCharacterIndex
	int32_t ___m_FirstOverflowCharacterIndex_57;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_PageNumber
	int32_t ___m_PageNumber_58;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginLeft
	float ___m_MarginLeft_59;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MarginRight
	float ___m_MarginRight_60;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_Width
	float ___m_Width_61;
	// UnityEngine.TextCore.Text.Extents UnityEngine.TextCore.Text.TextGenerator::m_MeshExtents
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 ___m_MeshExtents_62;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxCapHeight
	float ___m_MaxCapHeight_63;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxAscender
	float ___m_MaxAscender_64;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxDescender
	float ___m_MaxDescender_65;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsNewPage
	bool ___m_IsNewPage_66;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsNonBreakingSpace
	bool ___m_IsNonBreakingSpace_67;
	// UnityEngine.TextCore.Text.WordWrapState UnityEngine.TextCore.Text.TextGenerator::m_SavedWordWrapState
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedWordWrapState_68;
	// UnityEngine.TextCore.Text.WordWrapState UnityEngine.TextCore.Text.TextGenerator::m_SavedLineState
	WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123 ___m_SavedLineState_69;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_LoopCountA
	int32_t ___m_LoopCountA_70;
	// UnityEngine.TextCore.Text.TextElementType UnityEngine.TextCore.Text.TextGenerator::m_TextElementType
	uint8_t ___m_TextElementType_71;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsParsingText
	bool ___m_IsParsingText_72;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteIndex
	int32_t ___m_SpriteIndex_73;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_SpriteColor_74;
	// UnityEngine.TextCore.Text.TextElement UnityEngine.TextCore.Text.TextGenerator::m_CachedTextElement
	TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* ___m_CachedTextElement_75;
	// UnityEngine.Color32 UnityEngine.TextCore.Text.TextGenerator::m_HighlightColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___m_HighlightColor_76;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_CharWidthAdjDelta
	float ___m_CharWidthAdjDelta_77;
	// UnityEngine.Matrix4x4 UnityEngine.TextCore.Text.TextGenerator::m_FxMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_FxMatrix_78;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MaxFontSize
	float ___m_MaxFontSize_79;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_MinFontSize
	float ___m_MinFontSize_80;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsCharacterWrappingEnabled
	bool ___m_IsCharacterWrappingEnabled_81;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_StartOfLineAscender
	float ___m_StartOfLineAscender_82;
	// System.Single UnityEngine.TextCore.Text.TextGenerator::m_LineSpacingDelta
	float ___m_LineSpacingDelta_83;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsMaskingEnabled
	bool ___m_IsMaskingEnabled_84;
	// UnityEngine.TextCore.Text.MaterialReference[] UnityEngine.TextCore.Text.TextGenerator::m_MaterialReferences
	MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* ___m_MaterialReferences_85;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteCount
	int32_t ___m_SpriteCount_86;
	// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32> UnityEngine.TextCore.Text.TextGenerator::m_StyleStack
	TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8 ___m_StyleStack_87;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_SpriteAnimationId
	int32_t ___m_SpriteAnimationId_88;
	// System.UInt32[] UnityEngine.TextCore.Text.TextGenerator::m_InternalTextParsingBuffer
	UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA* ___m_InternalTextParsingBuffer_89;
	// UnityEngine.TextCore.Text.RichTextTagAttribute[] UnityEngine.TextCore.Text.TextGenerator::m_Attributes
	RichTextTagAttributeU5BU5D_tEE9D071B3246F23742DBF4226567620BCBB24A14* ___m_Attributes_90;
	// UnityEngine.TextCore.Text.XmlTagAttribute[] UnityEngine.TextCore.Text.TextGenerator::m_XmlAttribute
	XmlTagAttributeU5BU5D_tEDFE75BDDC81D11CEA2F2A12583516D3BFB309B2* ___m_XmlAttribute_91;
	// System.Char[] UnityEngine.TextCore.Text.TextGenerator::m_RichTextTag
	CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB* ___m_RichTextTag_92;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Int32> UnityEngine.TextCore.Text.TextGenerator::m_MaterialReferenceIndexLookup
	Dictionary_2_tABE19B9C5C52F1DE14F0D3287B2696E7D7419180* ___m_MaterialReferenceIndexLookup_93;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsCalculatingPreferredValues
	bool ___m_IsCalculatingPreferredValues_94;
	// UnityEngine.TextCore.Text.SpriteAsset UnityEngine.TextCore.Text.TextGenerator::m_DefaultSpriteAsset
	SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___m_DefaultSpriteAsset_95;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_TintSprite
	bool ___m_TintSprite_96;
	// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter UnityEngine.TextCore.Text.TextGenerator::m_Ellipsis
	SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD ___m_Ellipsis_97;
	// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter UnityEngine.TextCore.Text.TextGenerator::m_Underline
	SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD ___m_Underline_98;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsUsingBold
	bool ___m_IsUsingBold_99;
	// System.Boolean UnityEngine.TextCore.Text.TextGenerator::m_IsSdfShader
	bool ___m_IsSdfShader_100;
	// UnityEngine.TextCore.Text.TextElementInfo[] UnityEngine.TextCore.Text.TextGenerator::m_InternalTextElementInfo
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* ___m_InternalTextElementInfo_101;
	// System.Int32 UnityEngine.TextCore.Text.TextGenerator::m_RecursiveCount
	int32_t ___m_RecursiveCount_102;
};

// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>

// System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>

// System.Collections.Generic.HashSet`1<System.UInt32>

// System.Collections.Generic.HashSet`1<System.UInt32>

// UnityEngine.TextCore.Text.FontFeatureTable

// UnityEngine.TextCore.Text.FontFeatureTable

// System.String
struct String_t_StaticFields
{
	// System.String System.String::Empty
	String_t* ___Empty_6;
};

// System.String

// UnityEngine.TextCore.Text.TextGeneratorUtilities
struct TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGeneratorUtilities::largePositiveVector2
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___largePositiveVector2_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextGeneratorUtilities::largeNegativeVector2
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___largeNegativeVector2_1;
};

// UnityEngine.TextCore.Text.TextGeneratorUtilities

// UnityEngine.TextCore.Text.TextInfo
struct TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextInfo::s_InfinityVectorPositive
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___s_InfinityVectorPositive_0;
	// UnityEngine.Vector2 UnityEngine.TextCore.Text.TextInfo::s_InfinityVectorNegative
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___s_InfinityVectorNegative_1;
};

// UnityEngine.TextCore.Text.TextInfo

// UnityEngine.TextCore.Text.TextShaderUtilities
struct TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields
{
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MainTex
	int32_t ___ID_MainTex_0;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_FaceTex
	int32_t ___ID_FaceTex_1;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_FaceColor
	int32_t ___ID_FaceColor_2;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_FaceDilate
	int32_t ___ID_FaceDilate_3;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Shininess
	int32_t ___ID_Shininess_4;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayColor
	int32_t ___ID_UnderlayColor_5;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayOffsetX
	int32_t ___ID_UnderlayOffsetX_6;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayOffsetY
	int32_t ___ID_UnderlayOffsetY_7;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlayDilate
	int32_t ___ID_UnderlayDilate_8;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UnderlaySoftness
	int32_t ___ID_UnderlaySoftness_9;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_WeightNormal
	int32_t ___ID_WeightNormal_10;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_WeightBold
	int32_t ___ID_WeightBold_11;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineTex
	int32_t ___ID_OutlineTex_12;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineWidth
	int32_t ___ID_OutlineWidth_13;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineSoftness
	int32_t ___ID_OutlineSoftness_14;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_OutlineColor
	int32_t ___ID_OutlineColor_15;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Outline2Color
	int32_t ___ID_Outline2Color_16;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Outline2Width
	int32_t ___ID_Outline2Width_17;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Padding
	int32_t ___ID_Padding_18;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GradientScale
	int32_t ___ID_GradientScale_19;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleX
	int32_t ___ID_ScaleX_20;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleY
	int32_t ___ID_ScaleY_21;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_PerspectiveFilter
	int32_t ___ID_PerspectiveFilter_22;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_Sharpness
	int32_t ___ID_Sharpness_23;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_TextureWidth
	int32_t ___ID_TextureWidth_24;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_TextureHeight
	int32_t ___ID_TextureHeight_25;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_BevelAmount
	int32_t ___ID_BevelAmount_26;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowColor
	int32_t ___ID_GlowColor_27;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowOffset
	int32_t ___ID_GlowOffset_28;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowPower
	int32_t ___ID_GlowPower_29;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowOuter
	int32_t ___ID_GlowOuter_30;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_GlowInner
	int32_t ___ID_GlowInner_31;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_LightAngle
	int32_t ___ID_LightAngle_32;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_EnvMap
	int32_t ___ID_EnvMap_33;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_EnvMatrix
	int32_t ___ID_EnvMatrix_34;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_EnvMatrixRotation
	int32_t ___ID_EnvMatrixRotation_35;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MaskCoord
	int32_t ___ID_MaskCoord_36;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ClipRect
	int32_t ___ID_ClipRect_37;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MaskSoftnessX
	int32_t ___ID_MaskSoftnessX_38;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_MaskSoftnessY
	int32_t ___ID_MaskSoftnessY_39;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_VertexOffsetX
	int32_t ___ID_VertexOffsetX_40;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_VertexOffsetY
	int32_t ___ID_VertexOffsetY_41;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_UseClipRect
	int32_t ___ID_UseClipRect_42;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilID
	int32_t ___ID_StencilID_43;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilOp
	int32_t ___ID_StencilOp_44;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilComp
	int32_t ___ID_StencilComp_45;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilReadMask
	int32_t ___ID_StencilReadMask_46;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_StencilWriteMask
	int32_t ___ID_StencilWriteMask_47;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ShaderFlags
	int32_t ___ID_ShaderFlags_48;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleRatio_A
	int32_t ___ID_ScaleRatio_A_49;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleRatio_B
	int32_t ___ID_ScaleRatio_B_50;
	// System.Int32 UnityEngine.TextCore.Text.TextShaderUtilities::ID_ScaleRatio_C
	int32_t ___ID_ScaleRatio_C_51;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Bevel
	String_t* ___Keyword_Bevel_52;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Glow
	String_t* ___Keyword_Glow_53;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Underlay
	String_t* ___Keyword_Underlay_54;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Ratios
	String_t* ___Keyword_Ratios_55;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_MASK_SOFT
	String_t* ___Keyword_MASK_SOFT_56;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_MASK_HARD
	String_t* ___Keyword_MASK_HARD_57;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_MASK_TEX
	String_t* ___Keyword_MASK_TEX_58;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::Keyword_Outline
	String_t* ___Keyword_Outline_59;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::ShaderTag_ZTestMode
	String_t* ___ShaderTag_ZTestMode_60;
	// System.String UnityEngine.TextCore.Text.TextShaderUtilities::ShaderTag_CullMode
	String_t* ___ShaderTag_CullMode_61;
	// System.Single UnityEngine.TextCore.Text.TextShaderUtilities::m_clamp
	float ___m_clamp_62;
	// System.Boolean UnityEngine.TextCore.Text.TextShaderUtilities::isInitialized
	bool ___isInitialized_63;
	// UnityEngine.Shader UnityEngine.TextCore.Text.TextShaderUtilities::k_ShaderRef_MobileSDF
	Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692* ___k_ShaderRef_MobileSDF_64;
	// UnityEngine.Shader UnityEngine.TextCore.Text.TextShaderUtilities::k_ShaderRef_MobileBitmap
	Shader_tADC867D36B7876EE22427FAA2CE485105F4EE692* ___k_ShaderRef_MobileBitmap_65;
};

// UnityEngine.TextCore.Text.TextShaderUtilities

// UnityEngine.TextCore.Text.UnicodeLineBreakingRules
struct UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E_StaticFields
{
	// UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.UnicodeLineBreakingRules::s_Instance
	UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* ___s_Instance_0;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::s_LeadingCharactersLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___s_LeadingCharactersLookup_5;
	// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::s_FollowingCharactersLookup
	HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* ___s_FollowingCharactersLookup_6;
};

// UnityEngine.TextCore.Text.UnicodeLineBreakingRules

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Object>

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Object>

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient>

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;
};

// System.Boolean

// System.Byte

// System.Byte

// System.Char
struct Char_t521A6F19B456D956AF452D926C32709DC03D6B17_StaticFields
{
	// System.Byte[] System.Char::s_categoryForLatin1
	ByteU5BU5D_tA6237BF417AE52AD70CFB4EF24A7A82613DF9031* ___s_categoryForLatin1_3;
};

// System.Char

// UnityEngine.Color

// UnityEngine.Color

// UnityEngine.Color32

// UnityEngine.Color32

// UnityEngine.TextCore.FaceInfo

// UnityEngine.TextCore.FaceInfo

// UnityEngine.TextCore.Text.FontStyleStack

// UnityEngine.TextCore.Text.FontStyleStack

// UnityEngine.TextCore.GlyphMetrics

// UnityEngine.TextCore.GlyphMetrics

// UnityEngine.TextCore.LowLevel.GlyphValueRecord

// UnityEngine.TextCore.LowLevel.GlyphValueRecord

// System.Int32

// System.Int32

// UnityEngine.TextCore.Text.MaterialReference

// UnityEngine.TextCore.Text.MaterialReference

// UnityEngine.Matrix4x4
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6_StaticFields
{
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::zeroMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___zeroMatrix_16;
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::identityMatrix
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___identityMatrix_17;
};

// UnityEngine.Matrix4x4

// UnityEngine.TextCore.Text.MeshInfo
struct MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_StaticFields
{
	// UnityEngine.Color32 UnityEngine.TextCore.Text.MeshInfo::k_DefaultColor
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___k_DefaultColor_0;
};

// UnityEngine.TextCore.Text.MeshInfo

// UnityEngine.TextCore.Text.PageInfo

// UnityEngine.TextCore.Text.PageInfo

// System.Single

// System.Single

// System.UInt32

// System.UInt32

// UnityEngine.Vector2
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___negativeInfinityVector_9;
};

// UnityEngine.Vector2

// UnityEngine.Vector3
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields
{
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___negativeInfinityVector_14;
};

// UnityEngine.Vector3

// UnityEngine.Vector4
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3_StaticFields
{
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___negativeInfinityVector_8;
};

// UnityEngine.Vector4

// System.Void

// System.Void

// UnityEngine.TextCore.Text.WordInfo

// UnityEngine.TextCore.Text.WordInfo

// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter

// UnityEngine.TextCore.Text.TextGenerator/SpecialCharacter

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>

// UnityEngine.TextCore.Text.Extents

// UnityEngine.TextCore.Text.Extents

// UnityEngine.TextCore.Text.FontStyles

// UnityEngine.TextCore.Text.FontStyles

// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord

// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord

// System.Int32Enum

// System.Int32Enum

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;
};

// UnityEngine.Object

// UnityEngine.TextCore.Text.TextAlignment

// UnityEngine.TextCore.Text.TextAlignment

// UnityEngine.TextCore.Text.TextElementType

// UnityEngine.TextCore.Text.TextElementType

// UnityEngine.TextCore.Text.TextFontWeight

// UnityEngine.TextCore.Text.TextFontWeight

// UnityEngine.TextCore.Text.TextOverflowMode

// UnityEngine.TextCore.Text.TextOverflowMode

// UnityEngine.TextCore.Text.TextVertex

// UnityEngine.TextCore.Text.TextVertex

// UnityEngine.TextCore.Text.TextureMapping

// UnityEngine.TextCore.Text.TextureMapping

// UnityEngine.TextCore.Text.VertexSortingOrder

// UnityEngine.TextCore.Text.VertexSortingOrder

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32Enum>

// UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32Enum>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight>

// UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight>

// UnityEngine.TextCore.Glyph

// UnityEngine.TextCore.Glyph

// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord

// UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord

// UnityEngine.TextCore.Text.LineInfo

// UnityEngine.TextCore.Text.LineInfo

// UnityEngine.Material

// UnityEngine.Material

// UnityEngine.TextCore.Text.TextElement

// UnityEngine.TextCore.Text.TextElement

// UnityEngine.TextCore.Text.TextElementInfo

// UnityEngine.TextCore.Text.TextElementInfo

// UnityEngine.TextCore.Text.TextGenerationSettings

// UnityEngine.TextCore.Text.TextGenerationSettings

// UnityEngine.TextCore.Text.Character

// UnityEngine.TextCore.Text.Character

// UnityEngine.TextCore.Text.SpriteCharacter

// UnityEngine.TextCore.Text.SpriteCharacter

// UnityEngine.TextCore.Text.TextAsset

// UnityEngine.TextCore.Text.TextAsset

// UnityEngine.TextCore.Text.TextColorGradient
struct TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70_StaticFields
{
	// UnityEngine.Color UnityEngine.TextCore.Text.TextColorGradient::k_DefaultColor
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___k_DefaultColor_10;
};

// UnityEngine.TextCore.Text.TextColorGradient

// UnityEngine.TextCore.Text.TextSettings

// UnityEngine.TextCore.Text.TextSettings

// UnityEngine.TextCore.Text.WordWrapState

// UnityEngine.TextCore.Text.WordWrapState

// UnityEngine.TextCore.Text.FontAsset
struct FontAsset_t61A6446D934E582651044E33D250EA8D306AB958_StaticFields
{
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_ReadFontAssetDefinitionMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_ReadFontAssetDefinitionMarker_42;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_AddSynthesizedCharactersMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_AddSynthesizedCharactersMarker_43;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_TryAddCharacterMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddCharacterMarker_44;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_TryAddCharactersMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_TryAddCharactersMarker_45;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_UpdateGlyphAdjustmentRecordsMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateGlyphAdjustmentRecordsMarker_46;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_ClearFontAssetDataMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_ClearFontAssetDataMarker_47;
	// Unity.Profiling.ProfilerMarker UnityEngine.TextCore.Text.FontAsset::k_UpdateFontAssetDataMarker
	ProfilerMarker_tA256E18DA86EDBC5528CE066FC91C96EE86501AD ___k_UpdateFontAssetDataMarker_48;
	// System.String UnityEngine.TextCore.Text.FontAsset::s_DefaultMaterialSuffix
	String_t* ___s_DefaultMaterialSuffix_49;
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.FontAsset::k_SearchedFontAssetLookup
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_SearchedFontAssetLookup_50;
	// System.Collections.Generic.List`1<UnityEngine.TextCore.Text.FontAsset> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_FontFeaturesUpdateQueue
	List_1_t55B85B981AC5FD6A5358491F90FE354F78BB97DE* ___k_FontAssets_FontFeaturesUpdateQueue_51;
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_FontFeaturesUpdateQueueLookup
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_FontAssets_FontFeaturesUpdateQueueLookup_52;
	// System.Collections.Generic.List`1<UnityEngine.Texture2D> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_AtlasTexturesUpdateQueue
	List_1_t0F231C3F13EBA1FF9081BD61489D01AA3CBE59D4* ___k_FontAssets_AtlasTexturesUpdateQueue_53;
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.FontAsset::k_FontAssets_AtlasTexturesUpdateQueueLookup
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_FontAssets_AtlasTexturesUpdateQueueLookup_54;
	// System.UInt32[] UnityEngine.TextCore.Text.FontAsset::k_GlyphIndexArray
	UInt32U5BU5D_t02FBD658AD156A17574ECE6106CF1FBFCC9807FA* ___k_GlyphIndexArray_65;
};

// UnityEngine.TextCore.Text.FontAsset

// UnityEngine.TextCore.Text.SpriteAsset
struct SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_StaticFields
{
	// System.Collections.Generic.HashSet`1<System.Int32> UnityEngine.TextCore.Text.SpriteAsset::k_searchedSpriteAssets
	HashSet_1_t4A2F2B74276D0AD3ED0F873045BD61E9504ECAE2* ___k_searchedSpriteAssets_19;
};

// UnityEngine.TextCore.Text.SpriteAsset

// UnityEngine.TextCore.Text.TextGenerator
struct TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366_StaticFields
{
	// UnityEngine.TextCore.Text.TextGenerator UnityEngine.TextCore.Text.TextGenerator::s_TextGenerator
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* ___s_TextGenerator_0;
};

// UnityEngine.TextCore.Text.TextGenerator
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C  : public RuntimeArray
{
	ALIGN_FIELD (8) Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 m_Items[1];

	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.TextElementInfo[]
struct TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E  : public RuntimeArray
{
	ALIGN_FIELD (8) TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 m_Items[1];

	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___textElement_3), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, TextElementInfo_tDD7A12E319505510E0B350E342BD55F32AB5F976 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___textElement_3), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
};
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C  : public RuntimeArray
{
	ALIGN_FIELD (8) int32_t m_Items[1];

	inline int32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int32_t value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.PageInfo[]
struct PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4  : public RuntimeArray
{
	ALIGN_FIELD (8) PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 m_Items[1];

	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909 value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.LineInfo[]
struct LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D  : public RuntimeArray
{
	ALIGN_FIELD (8) LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 m_Items[1];

	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 value)
	{
		m_Items[index] = value;
	}
};
// UnityEngine.TextCore.Text.MaterialReference[]
struct MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E  : public RuntimeArray
{
	ALIGN_FIELD (8) MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 m_Items[1];

	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fallbackMaterial_6), (void*)NULL);
		#endif
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fontAsset_1), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___spriteAsset_2), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___fallbackMaterial_6), (void*)NULL);
		#endif
	}
};
// UnityEngine.TextCore.Text.MeshInfo[]
struct MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6  : public RuntimeArray
{
	ALIGN_FIELD (8) MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F m_Items[1];

	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___vertices_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs0_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs2_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___colors32_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___triangles_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___vertices_2), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs0_3), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___uvs2_4), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___colors32_5), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___triangles_6), (void*)NULL);
		#endif
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___material_7), (void*)NULL);
		#endif
	}
};
// UnityEngine.TextCore.Text.WordInfo[]
struct WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B  : public RuntimeArray
{
	ALIGN_FIELD (8) WordInfo_tA466206097891A5A2590896EE164AFC406EB060D m_Items[1];

	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, WordInfo_tA466206097891A5A2590896EE164AFC406EB060D value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline WordInfo_tA466206097891A5A2590896EE164AFC406EB060D* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, WordInfo_tA466206097891A5A2590896EE164AFC406EB060D value)
	{
		m_Items[index] = value;
	}
};


// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_gshared (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* __this, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___0_item, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_gshared (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, float ___0_item, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32Enum>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared (TextProcessingStack_1_t9C24840D494C4878BD8680855123926D6243C90D* __this, int32_t ___0_item, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_gshared (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_gshared (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_item, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Object>::SetDefault(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_SetDefault_m2748811181AC3D93A43815FE1FAC09A7E569806E_gshared (TextProcessingStack_1_t5EA97AAC21CEE068194F77E59929440F85AD3991* __this, RuntimeObject* ___0_item, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_gshared (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>::TryGetValue(TKey,TValue&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_gshared (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* __this, uint32_t ___0_key, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* ___1_value, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.PageInfo>(T[]&,System.Int32,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_gshared (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** ___0_array, int32_t ___1_size, bool ___2_isBlockAllocated, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.HashSet`1<System.UInt32>::Contains(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_gshared (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* __this, uint32_t ___0_item, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.WordInfo>(T[]&,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_gshared (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** ___0_array, int32_t ___1_size, const RuntimeMethod* method) ;

// System.Void UnityEngine.TextCore.Text.TextInfo::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::ClearMesh(System.Boolean,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83 (bool ___0_updateMesh, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MaterialReference::.ctor(System.Int32,UnityEngine.TextCore.Text.FontAsset,UnityEngine.TextCore.Text.SpriteAsset,UnityEngine.Material,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A (MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26* __this, int32_t ___0_index, FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* ___1_fontAsset, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* ___2_spriteAsset, Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___3_material, float ___4_padding, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.MaterialReference>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* __this, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA*, MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_gshared)(__this, ___0_item, method);
}
// UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.Text.FontAsset::get_faceInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9 (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, float ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*, float, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_gshared)(__this, ___0_item, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextFontWeight>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79 (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790* __this, int32_t ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared)(__this, ___0_item, method);
}
// System.Void UnityEngine.TextCore.Text.FontStyleStack::Clear()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0 (FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextAlignment>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230 (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F* __this, int32_t ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F*, int32_t, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m8D8C14A7EA75EBF60C7DDD5F4C8A81209E37751D_gshared)(__this, ___0_item, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Single>::Clear()
inline void TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3 (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*, const RuntimeMethod*))TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_gshared)(__this, method);
}
// UnityEngine.Vector3 UnityEngine.Vector3::get_zero()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) ;
// UnityEngine.Color32 UnityEngine.Color32::op_Implicit(UnityEngine.Color)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___0_c, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.Color32>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54 (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B, const RuntimeMethod*))TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_gshared)(__this, ___0_item, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<UnityEngine.TextCore.Text.TextColorGradient>::SetDefault(T)
inline void TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9 (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E* __this, TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70* ___0_item, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E*, TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*, const RuntimeMethod*))TextProcessingStack_1_SetDefault_m2748811181AC3D93A43815FE1FAC09A7E569806E_gshared)(__this, ___0_item, method);
}
// System.Void UnityEngine.TextCore.Text.TextProcessingStack`1<System.Int32>::Clear()
inline void TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* __this, const RuntimeMethod* method)
{
	((  void (*) (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*, const RuntimeMethod*))TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_gshared)(__this, method);
}
// System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_lineHeight_m528B4A822181FCECF3D4FF1045DF288E5872AB9D (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Mathf::Clamp(System.Int32,System.Int32,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline (int32_t ___0_value, int32_t ___1_min, int32_t ___2_max, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::ClearLineInfo()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7 (TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::SaveWordWrappingState(UnityEngine.TextCore.Text.WordWrapState&,System.Int32,System.Int32,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* ___0_state, int32_t ___1_index, int32_t ___2_count, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___3_textInfo, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.TextCore.Text.TextGenerator::ValidateHtmlTag(System.Int32[],System.Int32,System.Int32&,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGenerator_ValidateHtmlTag_m9C85462F15A6165B10E4C4EE93620AC1021BE5CD (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ___0_chars, int32_t ___1_startIndex, int32_t* ___2_endIndex, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___3_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___4_textInfo, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsLower(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Char System.Char::ToUpper(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsUpper(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsUpper_mF150C44B70F522A14B2A8DF71DE0ADE52F9A3392 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Char System.Char::ToLower(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Il2CppChar Char_ToLower_m238489988C62CB10C7C7CAAEF8F3B2D1C5B5E056 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// UnityEngine.TextCore.Text.TextAsset UnityEngine.TextCore.Text.TextElement::get_textAsset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* TextElement_get_textAsset_m52383A3758AABF5BEA013155765BD1141479685A (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// System.UInt32 UnityEngine.TextCore.Text.TextElement::get_glyphIndex()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint32_t TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// UnityEngine.Color UnityEngine.Color::get_white()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline (const RuntimeMethod* method) ;
// UnityEngine.TextCore.Glyph UnityEngine.TextCore.Text.TextElement::get_glyph()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA (Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.TextElement::get_scale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6 (TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.TextGenerator::GetPaddingForMaterial(UnityEngine.Material,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float TextGenerator_GetPaddingForMaterial_mE5A4DEF3F64851861C092F7A4FC58C902F775C74 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* ___0_material, bool ___1_extraPadding, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.Dictionary`2<System.UInt32,UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord>::TryGetValue(TKey,TValue&)
inline bool Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* __this, uint32_t ___0_key, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* ___1_value, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0*, uint32_t, GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E*, const RuntimeMethod*))Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_gshared)(__this, ___0_key, ___1_value, method);
}
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m867469548F17B298F893B78EE2F93D34E4A6C39C (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7 (GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_mFDFECB1F7A38E22BD2388FFE9C71E732F6B44D91 (GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E* __this, const RuntimeMethod* method) ;
// UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphValueRecord::op_Addition(UnityEngine.TextCore.LowLevel.GlyphValueRecord,UnityEngine.TextCore.LowLevel.GlyphValueRecord)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E GlyphValueRecord_op_Addition_mF26165B4CE61A5409AEFF24B0D1727804E13602B (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___0_a, GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E ___1_b, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_regularStyleSpacing()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsWhiteSpace(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Material::HasProperty(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222 (Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* __this, int32_t ___0_nameID, const RuntimeMethod* method) ;
// System.Single UnityEngine.Material::GetFloat(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932 (Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* __this, int32_t ___0_nameID, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_boldStyleWeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_boldStyleSpacing()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0 (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.Text.FontAsset::get_regularStyleWeight()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FontAsset_get_regularStyleWeight_m6C4B4D4CAD36800E6E686A05A5DB8D4475F2707F (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8 (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223 (GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
// System.Byte UnityEngine.TextCore.Text.FontAsset::get_italicStyleSlant()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Addition(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Division(UnityEngine.Vector3,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Subtraction(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Matrix4x4::MultiplyPoint3x4(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814 (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_point, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_subscriptSize_mF6264BFB215FDE6C94A45D2F8FC946ADFCDD2E31 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Max(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Min(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::GenerateTextMesh(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___0_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.TextCore.Text.TextGenerator::RestoreWordWrappingState(UnityEngine.TextCore.Text.WordWrapState&,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* ___0_state, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.TextCore.Text.TextGeneratorUtilities::Approximately(System.Single,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D (float ___0_a, float ___1_b, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::AdjustLineOffset(System.Int32,System.Int32,System.Single,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123 (int32_t ___0_startIndex, int32_t ___1_endIndex, float ___2_offset, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___3_textInfo, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector2::.ctor(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::ResizeLineExtents(System.Int32,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85 (int32_t ___0_size, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::DisableMasking()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, const RuntimeMethod* method) ;
// System.String UnityEngine.Object::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// System.String System.String::Concat(System.String,System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B (String_t* ___0_str0, String_t* ___1_str1, String_t* ___2_str2, const RuntimeMethod* method) ;
// System.Void UnityEngine.Debug::LogWarning(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9 (RuntimeObject* ___0_message, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::EnableMasking()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::SaveGlyphVertexInfo(System.Single,System.Single,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, float ___0_padding, float ___1_stylePadding, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___2_vertexColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___3_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___4_textInfo, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::SaveSpriteVertexInfo(UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_vertexColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___1_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___2_textInfo, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsSeparator(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_tabWidth_mC6D9F42C40EDD767DE22050E4FBE3878AC96B161 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Byte UnityEngine.TextCore.Text.FontAsset::get_tabMultiple()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR uint8_t FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE (FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E (GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.PageInfo>(T[]&,System.Int32,System.Boolean)
inline void TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8 (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** ___0_array, int32_t ___1_size, bool ___2_isBlockAllocated, const RuntimeMethod* method)
{
	((  void (*) (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4**, int32_t, bool, const RuntimeMethod*))TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_gshared)(___0_array, ___1_size, ___2_isBlockAllocated, method);
}
// UnityEngine.TextCore.Text.UnicodeLineBreakingRules UnityEngine.TextCore.Text.TextSettings::get_lineBreakingRules()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04 (TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* __this, const RuntimeMethod* method) ;
// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::get_leadingCharactersLookup()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.HashSet`1<System.UInt32>::Contains(T)
inline bool HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9 (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* __this, uint32_t ___0_item, const RuntimeMethod* method)
{
	return ((  bool (*) (HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A*, uint32_t, const RuntimeMethod*))HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_gshared)(__this, ___0_item, method);
}
// System.Collections.Generic.HashSet`1<System.UInt32> UnityEngine.TextCore.Text.UnicodeLineBreakingRules::get_followingCharactersLookup()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B (UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MeshInfo::Clear(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, bool ___0_uploadChanges, const RuntimeMethod* method) ;
// System.Void UnityEngine.Color32::.ctor(System.Byte,System.Byte,System.Byte,System.Byte)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* __this, uint8_t ___0_r, uint8_t ___1_g, uint8_t ___2_b, uint8_t ___3_a, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsControl(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsControl_m133C10360BE82B7580E4D3ECE3C881A6C82B3F7F (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Void UnityEngine.Debug::Log(System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB (RuntimeObject* ___0_message, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::FillCharacterVertexBuffers(System.Int32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_FillCharacterVertexBuffers_m54CA97C6C26BA84BC949845B20E9DADF2F0C19CA (int32_t ___0_i, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___1_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___2_textInfo, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGeneratorUtilities::FillSpriteVertexBuffers(System.Int32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGeneratorUtilities_FillSpriteVertexBuffers_m4305B80FA32FE21A59AF68A5501226E5A4203CC3 (int32_t ___0_i, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___1_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___2_textInfo, const RuntimeMethod* method) ;
// System.Boolean System.Char::IsLetterOrDigit(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextInfo::Resize<UnityEngine.TextCore.Text.WordInfo>(T[]&,System.Int32)
inline void TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** ___0_array, int32_t ___1_size, const RuntimeMethod* method)
{
	((  void (*) (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**, int32_t, const RuntimeMethod*))TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_gshared)(___0_array, ___1_size, method);
}
// System.Boolean System.Char::IsPunctuation(System.Char)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Char_IsPunctuation_m619E42D942E22C9BA1DDB8E704BECA546C376473 (Il2CppChar ___0_c, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_underlineOffset_mB1CBB29ECFFE69047F35E654E7F90755F95DD251 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::DrawUnderlineMesh(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32&,System.Single,System.Single,System.Single,System.Single,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_start, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_end, int32_t* ___2_index, float ___3_startScale, float ___4_endScale, float ___5_maxScale, float ___6_sdfScale, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___7_underlineColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___8_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___9_textInfo, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.TextCore.Text.ColorUtilities::CompareColors(UnityEngine.Color32,UnityEngine.Color32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875 (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___0_a, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___1_b, const RuntimeMethod* method) ;
// System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float FaceInfo_get_strikethroughOffset_m7997E4A1512FE358331B3A6543C62C92A0AA5CA5 (FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Object::GetInstanceID()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector2::op_Implicit(UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_v, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.TextGenerator::DrawTextHighlight(UnityEngine.Vector3,UnityEngine.Vector3,System.Int32&,UnityEngine.Color32,UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_start, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_end, int32_t* ___2_index, Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B ___3_highlightColor, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___4_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___5_textInfo, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MeshInfo::SortGeometry(UnityEngine.TextCore.Text.VertexSortingOrder)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, int32_t ___0_order, const RuntimeMethod* method) ;
// System.Void UnityEngine.TextCore.Text.MeshInfo::ClearUnusedVertices()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830 (MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Clamp01(System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline (float ___0_value, const RuntimeMethod* method) ;
// System.Void UnityEngine.Color::.ctor(System.Single,System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F* __this, float ___0_r, float ___1_g, float ___2_b, float ___3_a, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void UnityEngine.TextCore.Text.TextGenerator::GenerateTextMesh(UnityEngine.TextCore.Text.TextGenerationSettings,UnityEngine.TextCore.Text.TextInfo)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831 (TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* __this, TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* ___0_generationSettings, TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* ___1_textInfo, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	float V_4 = 0.0f;
	bool V_5 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_6;
	memset((&V_6), 0, sizeof(V_6));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_7;
	memset((&V_7), 0, sizeof(V_7));
	bool V_8 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_9;
	memset((&V_9), 0, sizeof(V_9));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_10;
	memset((&V_10), 0, sizeof(V_10));
	bool V_11 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_12;
	memset((&V_12), 0, sizeof(V_12));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_13;
	memset((&V_13), 0, sizeof(V_13));
	float V_14 = 0.0f;
	bool V_15 = false;
	int32_t V_16 = 0;
	int32_t V_17 = 0;
	int32_t V_18 = 0;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 V_19;
	memset((&V_19), 0, sizeof(V_19));
	float V_20 = 0.0f;
	float V_21 = 0.0f;
	float V_22 = 0.0f;
	TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* V_23 = NULL;
	float V_24 = 0.0f;
	float V_25 = 0.0f;
	bool V_26 = false;
	bool V_27 = false;
	bool V_28 = false;
	bool V_29 = false;
	int32_t V_30 = 0;
	int32_t V_31 = 0;
	float V_32 = 0.0f;
	int32_t V_33 = 0;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_34;
	memset((&V_34), 0, sizeof(V_34));
	Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* V_35 = NULL;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_36;
	memset((&V_36), 0, sizeof(V_36));
	int32_t V_37 = 0;
	int32_t V_38 = 0;
	int32_t V_39 = 0;
	bool V_40 = false;
	bool V_41 = false;
	int32_t V_42 = 0;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_43;
	memset((&V_43), 0, sizeof(V_43));
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_44;
	memset((&V_44), 0, sizeof(V_44));
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_45;
	memset((&V_45), 0, sizeof(V_45));
	float V_46 = 0.0f;
	float V_47 = 0.0f;
	float V_48 = 0.0f;
	float V_49 = 0.0f;
	int32_t V_50 = 0;
	float V_51 = 0.0f;
	float V_52 = 0.0f;
	float V_53 = 0.0f;
	TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* V_54 = NULL;
	bool V_55 = false;
	bool V_56 = false;
	FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 V_57;
	memset((&V_57), 0, sizeof(V_57));
	float V_58 = 0.0f;
	int32_t V_59 = 0;
	int32_t V_60 = 0;
	int32_t V_61 = 0;
	bool V_62 = false;
	float V_63 = 0.0f;
	float V_64 = 0.0f;
	GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E V_65;
	memset((&V_65), 0, sizeof(V_65));
	float V_66 = 0.0f;
	float V_67 = 0.0f;
	float V_68 = 0.0f;
	float V_69 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_70;
	memset((&V_70), 0, sizeof(V_70));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_71;
	memset((&V_71), 0, sizeof(V_71));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_72;
	memset((&V_72), 0, sizeof(V_72));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_73;
	memset((&V_73), 0, sizeof(V_73));
	float V_74 = 0.0f;
	float V_75 = 0.0f;
	float V_76 = 0.0f;
	float V_77 = 0.0f;
	bool V_78 = false;
	bool V_79 = false;
	bool V_80 = false;
	bool V_81 = false;
	bool V_82 = false;
	bool V_83 = false;
	bool V_84 = false;
	bool V_85 = false;
	bool V_86 = false;
	bool V_87 = false;
	bool V_88 = false;
	bool V_89 = false;
	SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* V_90 = NULL;
	float V_91 = 0.0f;
	bool V_92 = false;
	bool V_93 = false;
	GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A V_94;
	memset((&V_94), 0, sizeof(V_94));
	bool V_95 = false;
	bool V_96 = false;
	bool V_97 = false;
	bool V_98 = false;
	GlyphPairAdjustmentRecord_t6E4295094D349DBF22BC59116FBC8F22EA55420E V_99;
	memset((&V_99), 0, sizeof(V_99));
	uint32_t V_100 = 0;
	bool V_101 = false;
	uint32_t V_102 = 0;
	uint32_t V_103 = 0;
	bool V_104 = false;
	GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 V_105;
	memset((&V_105), 0, sizeof(V_105));
	bool V_106 = false;
	uint32_t V_107 = 0;
	uint32_t V_108 = 0;
	bool V_109 = false;
	bool V_110 = false;
	bool V_111 = false;
	bool V_112 = false;
	bool V_113 = false;
	bool V_114 = false;
	float V_115 = 0.0f;
	bool V_116 = false;
	bool V_117 = false;
	float V_118 = 0.0f;
	bool V_119 = false;
	bool V_120 = false;
	float V_121 = 0.0f;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_122;
	memset((&V_122), 0, sizeof(V_122));
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_123;
	memset((&V_123), 0, sizeof(V_123));
	bool V_124 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_125;
	memset((&V_125), 0, sizeof(V_125));
	bool V_126 = false;
	float V_127 = 0.0f;
	float V_128 = 0.0f;
	bool V_129 = false;
	bool V_130 = false;
	bool V_131 = false;
	bool V_132 = false;
	float V_133 = 0.0f;
	bool V_134 = false;
	bool V_135 = false;
	float V_136 = 0.0f;
	float V_137 = 0.0f;
	bool V_138 = false;
	bool V_139 = false;
	bool V_140 = false;
	bool V_141 = false;
	bool V_142 = false;
	bool V_143 = false;
	bool V_144 = false;
	bool V_145 = false;
	float V_146 = 0.0f;
	bool V_147 = false;
	bool V_148 = false;
	int32_t V_149 = 0;
	bool V_150 = false;
	bool V_151 = false;
	float V_152 = 0.0f;
	bool V_153 = false;
	bool V_154 = false;
	bool V_155 = false;
	int32_t V_156 = 0;
	int32_t V_157 = 0;
	bool V_158 = false;
	bool V_159 = false;
	bool V_160 = false;
	bool V_161 = false;
	bool V_162 = false;
	bool V_163 = false;
	bool V_164 = false;
	bool V_165 = false;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* V_166 = NULL;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_167;
	memset((&V_167), 0, sizeof(V_167));
	bool V_168 = false;
	bool V_169 = false;
	bool V_170 = false;
	bool V_171 = false;
	bool V_172 = false;
	bool V_173 = false;
	bool V_174 = false;
	bool V_175 = false;
	float V_176 = 0.0f;
	bool V_177 = false;
	bool V_178 = false;
	bool V_179 = false;
	bool V_180 = false;
	bool V_181 = false;
	bool V_182 = false;
	int32_t V_183 = 0;
	int32_t V_184 = 0;
	bool V_185 = false;
	bool V_186 = false;
	bool V_187 = false;
	bool V_188 = false;
	bool V_189 = false;
	bool V_190 = false;
	bool V_191 = false;
	bool V_192 = false;
	bool V_193 = false;
	bool V_194 = false;
	bool V_195 = false;
	bool V_196 = false;
	bool V_197 = false;
	bool V_198 = false;
	float V_199 = 0.0f;
	float V_200 = 0.0f;
	bool V_201 = false;
	bool V_202 = false;
	bool V_203 = false;
	float V_204 = 0.0f;
	bool V_205 = false;
	bool V_206 = false;
	bool V_207 = false;
	bool V_208 = false;
	float V_209 = 0.0f;
	float V_210 = 0.0f;
	bool V_211 = false;
	float V_212 = 0.0f;
	bool V_213 = false;
	bool V_214 = false;
	bool V_215 = false;
	bool V_216 = false;
	bool V_217 = false;
	bool V_218 = false;
	bool V_219 = false;
	bool V_220 = false;
	bool V_221 = false;
	bool V_222 = false;
	bool V_223 = false;
	bool V_224 = false;
	bool V_225 = false;
	bool V_226 = false;
	bool V_227 = false;
	bool V_228 = false;
	bool V_229 = false;
	bool V_230 = false;
	bool V_231 = false;
	bool V_232 = false;
	bool V_233 = false;
	bool V_234 = false;
	int32_t V_235 = 0;
	int32_t V_236 = 0;
	bool V_237 = false;
	bool V_238 = false;
	bool V_239 = false;
	int32_t V_240 = 0;
	FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* V_241 = NULL;
	Il2CppChar V_242 = 0x0;
	int32_t V_243 = 0;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 V_244;
	memset((&V_244), 0, sizeof(V_244));
	int32_t V_245 = 0;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_246;
	memset((&V_246), 0, sizeof(V_246));
	bool V_247 = false;
	int32_t V_248 = 0;
	bool V_249 = false;
	float V_250 = 0.0f;
	bool V_251 = false;
	float V_252 = 0.0f;
	bool V_253 = false;
	Il2CppChar V_254 = 0x0;
	bool V_255 = false;
	int32_t V_256 = 0;
	int32_t V_257 = 0;
	bool V_258 = false;
	bool V_259 = false;
	bool V_260 = false;
	bool V_261 = false;
	bool V_262 = false;
	bool V_263 = false;
	bool V_264 = false;
	float V_265 = 0.0f;
	int32_t V_266 = 0;
	int32_t V_267 = 0;
	float V_268 = 0.0f;
	bool V_269 = false;
	bool V_270 = false;
	bool V_271 = false;
	bool V_272 = false;
	bool V_273 = false;
	bool V_274 = false;
	bool V_275 = false;
	uint8_t V_276 = 0;
	Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 V_277;
	memset((&V_277), 0, sizeof(V_277));
	float V_278 = 0.0f;
	uint8_t V_279 = 0;
	uint8_t V_280 = 0;
	float V_281 = 0.0f;
	int32_t V_282 = 0;
	int32_t V_283 = 0;
	bool V_284 = false;
	int32_t V_285 = 0;
	int32_t V_286 = 0;
	float V_287 = 0.0f;
	int32_t V_288 = 0;
	int32_t V_289 = 0;
	bool V_290 = false;
	bool V_291 = false;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* V_292 = NULL;
	bool V_293 = false;
	bool V_294 = false;
	bool V_295 = false;
	bool V_296 = false;
	bool V_297 = false;
	bool V_298 = false;
	bool V_299 = false;
	bool V_300 = false;
	bool V_301 = false;
	int32_t V_302 = 0;
	int32_t V_303 = 0;
	bool V_304 = false;
	bool V_305 = false;
	bool V_306 = false;
	int32_t V_307 = 0;
	int32_t V_308 = 0;
	bool V_309 = false;
	int32_t* V_310 = NULL;
	bool V_311 = false;
	bool V_312 = false;
	int32_t V_313 = 0;
	bool V_314 = false;
	bool V_315 = false;
	bool V_316 = false;
	bool V_317 = false;
	bool V_318 = false;
	bool V_319 = false;
	bool V_320 = false;
	bool V_321 = false;
	int32_t V_322 = 0;
	bool V_323 = false;
	bool V_324 = false;
	bool V_325 = false;
	bool V_326 = false;
	bool V_327 = false;
	bool V_328 = false;
	bool V_329 = false;
	bool V_330 = false;
	bool V_331 = false;
	bool V_332 = false;
	int32_t V_333 = 0;
	bool V_334 = false;
	int32_t V_335 = 0;
	bool V_336 = false;
	bool V_337 = false;
	bool V_338 = false;
	bool V_339 = false;
	bool V_340 = false;
	bool V_341 = false;
	int32_t V_342 = 0;
	bool V_343 = false;
	bool V_344 = false;
	bool V_345 = false;
	bool V_346 = false;
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_347;
	memset((&V_347), 0, sizeof(V_347));
	bool V_348 = false;
	bool V_349 = false;
	bool V_350 = false;
	bool V_351 = false;
	bool V_352 = false;
	bool V_353 = false;
	bool V_354 = false;
	bool V_355 = false;
	bool V_356 = false;
	int32_t V_357 = 0;
	bool V_358 = false;
	bool V_359 = false;
	int32_t G_B6_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B10_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B9_0 = NULL;
	int32_t G_B11_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B11_1 = NULL;
	int32_t G_B15_0 = 0;
	float G_B51_0 = 0.0f;
	int32_t G_B68_0 = 0;
	int32_t G_B77_0 = 0;
	int32_t G_B94_0 = 0;
	float G_B100_0 = 0.0f;
	float G_B99_0 = 0.0f;
	float G_B101_0 = 0.0f;
	float G_B101_1 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B103_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B102_0 = NULL;
	float G_B104_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B104_1 = NULL;
	float G_B106_0 = 0.0f;
	float G_B105_0 = 0.0f;
	float G_B107_0 = 0.0f;
	float G_B107_1 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B109_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B108_0 = NULL;
	float G_B110_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B110_1 = NULL;
	int32_t G_B113_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B116_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B115_0 = NULL;
	float G_B117_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B117_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B119_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B118_0 = NULL;
	float G_B120_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B120_1 = NULL;
	int32_t G_B124_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B127_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B126_0 = NULL;
	float G_B128_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B128_1 = NULL;
	float G_B133_0 = 0.0f;
	int32_t G_B141_0 = 0;
	float G_B145_0 = 0.0f;
	int32_t G_B148_0 = 0;
	float G_B150_0 = 0.0f;
	float G_B149_0 = 0.0f;
	float G_B151_0 = 0.0f;
	float G_B151_1 = 0.0f;
	float G_B153_0 = 0.0f;
	float G_B153_1 = 0.0f;
	float G_B152_0 = 0.0f;
	float G_B152_1 = 0.0f;
	float G_B154_0 = 0.0f;
	float G_B154_1 = 0.0f;
	float G_B154_2 = 0.0f;
	float G_B156_0 = 0.0f;
	float G_B156_1 = 0.0f;
	float G_B155_0 = 0.0f;
	float G_B155_1 = 0.0f;
	float G_B157_0 = 0.0f;
	float G_B157_1 = 0.0f;
	float G_B157_2 = 0.0f;
	int32_t G_B161_0 = 0;
	int32_t G_B166_0 = 0;
	int32_t G_B186_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B190_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B189_0 = NULL;
	float G_B191_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B191_1 = NULL;
	int32_t G_B197_0 = 0;
	int32_t G_B199_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B203_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B203_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B202_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B202_1 = NULL;
	int32_t G_B204_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B204_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B204_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B206_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B206_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B205_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B205_1 = NULL;
	int32_t G_B207_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B207_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B207_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B209_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B209_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B208_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B208_1 = NULL;
	int32_t G_B210_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B210_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B210_2 = NULL;
	int32_t G_B219_0 = 0;
	int32_t G_B253_0 = 0;
	int32_t G_B266_0 = 0;
	int32_t G_B277_0 = 0;
	int32_t G_B287_0 = 0;
	int32_t G_B294_0 = 0;
	int32_t G_B301_0 = 0;
	int32_t G_B306_0 = 0;
	int32_t G_B341_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B355_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B354_0 = NULL;
	float G_B356_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B356_1 = NULL;
	int32_t G_B361_0 = 0;
	int32_t G_B370_0 = 0;
	int32_t G_B379_0 = 0;
	int32_t G_B385_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B389_0 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B388_0 = NULL;
	float G_B390_0 = 0.0f;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B390_1 = NULL;
	int32_t G_B396_0 = 0;
	int32_t G_B398_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B402_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B402_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B401_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B401_1 = NULL;
	int32_t G_B403_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B403_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B403_2 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B405_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B405_1 = NULL;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B404_0 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B404_1 = NULL;
	int32_t G_B406_0 = 0;
	TextGenerator_t6B84DC798596D3A9944DC346DD453C075EE62366* G_B406_1 = NULL;
	LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5* G_B406_2 = NULL;
	int32_t G_B425_0 = 0;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B430_0 = NULL;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B429_0 = NULL;
	float G_B431_0 = 0.0f;
	PageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909* G_B431_1 = NULL;
	int32_t G_B434_0 = 0;
	int32_t G_B439_0 = 0;
	int32_t G_B448_0 = 0;
	int32_t G_B460_0 = 0;
	int32_t G_B478_0 = 0;
	int32_t G_B484_0 = 0;
	int32_t G_B486_0 = 0;
	int32_t G_B488_0 = 0;
	int32_t G_B494_0 = 0;
	int32_t G_B502_0 = 0;
	int32_t G_B508_0 = 0;
	int32_t G_B672_0 = 0;
	int32_t G_B677_0 = 0;
	int32_t G_B680_0 = 0;
	int32_t G_B685_0 = 0;
	float G_B696_0 = 0.0f;
	int32_t G_B699_0 = 0;
	float G_B704_0 = 0.0f;
	int32_t G_B710_0 = 0;
	int32_t G_B712_0 = 0;
	int32_t G_B756_0 = 0;
	int32_t G_B765_0 = 0;
	int32_t G_B773_0 = 0;
	int32_t G_B784_0 = 0;
	int32_t G_B796_0 = 0;
	int32_t G_B802_0 = 0;
	int32_t G_B814_0 = 0;
	int32_t G_B816_0 = 0;
	int32_t G_B818_0 = 0;
	int32_t G_B827_0 = 0;
	int32_t G_B832_0 = 0;
	int32_t G_B842_0 = 0;
	int32_t G_B844_0 = 0;
	int32_t G_B849_0 = 0;
	float G_B853_0 = 0.0f;
	int32_t G_B859_0 = 0;
	int32_t G_B863_0 = 0;
	int32_t G_B871_0 = 0;
	int32_t G_B877_0 = 0;
	int32_t G_B879_0 = 0;
	int32_t G_B883_0 = 0;
	int32_t G_B890_0 = 0;
	int32_t G_B896_0 = 0;
	int32_t G_B908_0 = 0;
	int32_t G_B910_0 = 0;
	int32_t G_B915_0 = 0;
	int32_t G_B919_0 = 0;
	int32_t G_B925_0 = 0;
	int32_t G_B930_0 = 0;
	int32_t G_B934_0 = 0;
	int32_t G_B943_0 = 0;
	int32_t G_B945_0 = 0;
	int32_t G_B954_0 = 0;
	int32_t G_B959_0 = 0;
	int32_t G_B971_0 = 0;
	int32_t G_B973_0 = 0;
	int32_t G_B980_0 = 0;
	int32_t G_B984_0 = 0;
	int32_t G_B996_0 = 0;
	int32_t G_B1002_0 = 0;
	int32_t G_B1004_0 = 0;
	int32_t G_B1009_0 = 0;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1019_0 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1018_0 = NULL;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1020_0 = NULL;
	int32_t G_B1021_0 = 0;
	TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* G_B1021_1 = NULL;
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_0 = ___1_textInfo;
		V_55 = (bool)((((RuntimeObject*)(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09*)L_0) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_1 = V_55;
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		goto IL_6c59;
	}

IL_0010:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2 = ___1_textInfo;
		NullCheck(L_2);
		TextInfo_Clear_m60412774208F9D920707448E71E89C99233D9128(L_2, NULL);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = __this->___m_CharBuffer_4;
		if (!L_3)
		{
			goto IL_0035;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_4 = __this->___m_CharBuffer_4;
		NullCheck(L_4);
		if (!(((RuntimeArray*)L_4)->max_length))
		{
			goto IL_0035;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_5 = __this->___m_CharBuffer_4;
		NullCheck(L_5);
		int32_t L_6 = 0;
		int32_t L_7 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		G_B6_0 = ((((int32_t)L_7) == ((int32_t)0))? 1 : 0);
		goto IL_0036;
	}

IL_0035:
	{
		G_B6_0 = 1;
	}

IL_0036:
	{
		V_56 = (bool)G_B6_0;
		bool L_8 = V_56;
		if (!L_8)
		{
			goto IL_0060;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_9 = ___1_textInfo;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_9, NULL);
		__this->___m_PreferredWidth_5 = (0.0f);
		__this->___m_PreferredHeight_6 = (0.0f);
		goto IL_6c59;
	}

IL_0060:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_10 = ___0_generationSettings;
		NullCheck(L_10);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_11 = L_10->___fontAsset_4;
		__this->___m_CurrentFontAsset_7 = L_11;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset_7), (void*)L_11);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_12 = ___0_generationSettings;
		NullCheck(L_12);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_13 = L_12->___material_5;
		__this->___m_CurrentMaterial_8 = L_13;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentMaterial_8), (void*)L_13);
		__this->___m_CurrentMaterialIndex_9 = 0;
		TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA* L_14 = (TextProcessingStack_1_t0C74606C1B6C7817CA95F0DCA46B219CF6FB35CA*)(&__this->___m_MaterialReferenceStack_10);
		int32_t L_15 = __this->___m_CurrentMaterialIndex_9;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_16 = __this->___m_CurrentFontAsset_7;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_17 = __this->___m_CurrentMaterial_8;
		float L_18 = __this->___m_Padding_11;
		MaterialReference_t86DB0799D5C82869D4FF0A4F59624AED6910FD26 L_19;
		memset((&L_19), 0, sizeof(L_19));
		MaterialReference__ctor_m044AAA2C1079EB25A5534A6E0FA2314F033DB15A((&L_19), L_15, L_16, (SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)NULL, L_17, L_18, /*hidden argument*/NULL);
		TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C(L_14, L_19, TextProcessingStack_1_SetDefault_mDAFD4911B5A8BEE57351A37415ADF348F0A6B54C_RuntimeMethod_var);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_20 = ___0_generationSettings;
		NullCheck(L_20);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_21 = L_20->___spriteAsset_6;
		__this->___m_CurrentSpriteAsset_12 = L_21;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentSpriteAsset_12), (void*)L_21);
		int32_t L_22 = __this->___m_TotalCharacterCount_13;
		V_0 = L_22;
		float L_23 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_24 = ___0_generationSettings;
		NullCheck(L_24);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_25 = L_24->___fontAsset_4;
		NullCheck(L_25);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_26;
		L_26 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_25, NULL);
		V_57 = L_26;
		int32_t L_27;
		L_27 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_57), NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_28 = ___0_generationSettings;
		NullCheck(L_28);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_29 = L_28->___fontAsset_4;
		NullCheck(L_29);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_30;
		L_30 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_29, NULL);
		V_57 = L_30;
		float L_31;
		L_31 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		float L_32 = ((float)il2cpp_codegen_multiply(((float)(L_23/((float)L_27))), L_31));
		V_58 = L_32;
		__this->___m_FontScale_14 = L_32;
		float L_33 = V_58;
		V_1 = L_33;
		float L_34 = V_1;
		V_2 = L_34;
		__this->___m_FontScaleMultiplier_16 = (1.0f);
		float L_35 = __this->___m_FontSize_15;
		__this->___m_CurrentFontSize_17 = L_35;
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_36 = (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*)(&__this->___m_SizeStack_18);
		float L_37 = __this->___m_CurrentFontSize_17;
		TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9(L_36, L_37, TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_38 = ___0_generationSettings;
		NullCheck(L_38);
		int32_t L_39 = L_38->___fontStyle_8;
		__this->___m_FontStyleInternal_19 = L_39;
		int32_t L_40 = __this->___m_FontStyleInternal_19;
		G_B9_0 = __this;
		if ((((int32_t)((int32_t)((int32_t)L_40&1))) == ((int32_t)1)))
		{
			G_B10_0 = __this;
			goto IL_0144;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_41 = ___0_generationSettings;
		NullCheck(L_41);
		int32_t L_42 = L_41->___fontWeight_37;
		G_B11_0 = ((int32_t)(L_42));
		G_B11_1 = G_B9_0;
		goto IL_0149;
	}

IL_0144:
	{
		G_B11_0 = ((int32_t)700);
		G_B11_1 = G_B10_0;
	}

IL_0149:
	{
		NullCheck(G_B11_1);
		G_B11_1->___m_FontWeightInternal_21 = G_B11_0;
		TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790* L_43 = (TextProcessingStack_1_t698B87CDD968C2046F57134BB3AB807EBFFD7790*)(&__this->___m_FontWeightStack_22);
		int32_t L_44 = __this->___m_FontWeightInternal_21;
		TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79(L_43, L_44, TextProcessingStack_1_SetDefault_mDF71503A7E4F1891305CDCC7AE245CA66A713E79_RuntimeMethod_var);
		FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7* L_45 = (FontStyleStack_t63C77495F068E6DF762D6AF063A817E3709659A7*)(&__this->___m_FontStyleStack_20);
		FontStyleStack_Clear_m989659363648B27540168E46F23E1EF9877C06E0(L_45, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_46 = ___0_generationSettings;
		NullCheck(L_46);
		int32_t L_47 = L_46->___textAlignment_10;
		__this->___m_LineJustification_23 = L_47;
		TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F* L_48 = (TextProcessingStack_1_tE63296B08A4C34E38D7EF3FFFA3470076B9E3A0F*)(&__this->___m_LineJustificationStack_24);
		int32_t L_49 = __this->___m_LineJustification_23;
		TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230(L_48, L_49, TextProcessingStack_1_SetDefault_m2DBB41C08A4CB7F71156ED5965850C2A0570F230_RuntimeMethod_var);
		V_3 = (0.0f);
		V_4 = (1.0f);
		__this->___m_BaselineOffset_25 = (0.0f);
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_50 = (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*)(&__this->___m_BaselineOffsetStack_26);
		TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3(L_50, TextProcessingStack_1_Clear_m857C80F9AFD9507FE4784DB5DE79109E16C8EAA3_RuntimeMethod_var);
		V_5 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_51;
		L_51 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_6 = L_51;
		V_8 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_52;
		L_52 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_9 = L_52;
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_53;
		L_53 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_12 = L_53;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_54;
		L_54 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_13 = L_54;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_55 = ___0_generationSettings;
		NullCheck(L_55);
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_56 = L_55->___color_14;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_57;
		L_57 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_56, NULL);
		__this->___m_FontColor32_27 = L_57;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_58 = __this->___m_FontColor32_27;
		__this->___m_HtmlColor_28 = L_58;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_59 = __this->___m_HtmlColor_28;
		__this->___m_UnderlineColor_29 = L_59;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_60 = __this->___m_HtmlColor_28;
		__this->___m_StrikethroughColor_30 = L_60;
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_61 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_ColorStack_31);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_62 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_61, L_62, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_63 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_UnderlineColorStack_32);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_64 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_63, L_64, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_65 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_StrikethroughColorStack_33);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_66 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_65, L_66, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63* L_67 = (TextProcessingStack_1_t7868E818AC1E1B5FED21B76D5C309C9A04380B63*)(&__this->___m_HighlightColorStack_34);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_68 = __this->___m_HtmlColor_28;
		TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54(L_67, L_68, TextProcessingStack_1_SetDefault_mE01C025EC63ACC956213DF8794365033E48A0C54_RuntimeMethod_var);
		__this->___m_ColorGradientPreset_35 = (TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_ColorGradientPreset_35), (void*)(TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL);
		TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E* L_69 = (TextProcessingStack_1_t0F39F088E8F8F6E18C3C463B2998ADC5B7A0513E*)(&__this->___m_ColorGradientStack_36);
		TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9(L_69, (TextColorGradient_t22D94E441E8E8CD772B966C167E5C0AEB0919D70*)NULL, TextProcessingStack_1_SetDefault_mDD0BF36ABFBF0DBA2D289C08F9862374CE18A0F9_RuntimeMethod_var);
		TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8* L_70 = (TextProcessingStack_1_t27834AAB14D26DC6519558C4C2574BA9C190D8E8*)(&__this->___m_ActionStack_37);
		TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD(L_70, TextProcessingStack_1_Clear_m3684329CF566CB94C981B1EAB3F1F3C74D42D0CD_RuntimeMethod_var);
		__this->___m_IsFxMatrixSet_38 = (bool)0;
		__this->___m_LineOffset_39 = (0.0f);
		__this->___m_LineHeight_40 = (-32767.0f);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_71 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_71);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_72;
		L_72 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_71, NULL);
		V_57 = L_72;
		float L_73;
		L_73 = FaceInfo_get_lineHeight_m528B4A822181FCECF3D4FF1045DF288E5872AB9D((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_74 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_74);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_75;
		L_75 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_74, NULL);
		V_57 = L_75;
		float L_76;
		L_76 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_77 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_77);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_78;
		L_78 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_77, NULL);
		V_57 = L_78;
		float L_79;
		L_79 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3((&V_57), NULL);
		V_14 = ((float)il2cpp_codegen_subtract(L_73, ((float)il2cpp_codegen_subtract(L_76, L_79))));
		__this->___m_CSpacing_41 = (0.0f);
		__this->___m_MonoSpacing_42 = (0.0f);
		__this->___m_XAdvance_43 = (0.0f);
		__this->___m_TagLineIndent_44 = (0.0f);
		__this->___m_TagIndent_45 = (0.0f);
		TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555* L_80 = (TextProcessingStack_1_t9FC06E35259ADD291ED640FE7554D8C03EA5F555*)(&__this->___m_IndentStack_46);
		TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9(L_80, (0.0f), TextProcessingStack_1_SetDefault_mA28AEF460395ECD6CBF6A469575571F64F6836B9_RuntimeMethod_var);
		__this->___m_TagNoParsing_47 = (bool)0;
		__this->___m_CharacterCount_48 = 0;
		__this->___m_FirstCharacterOfLine_49 = 0;
		__this->___m_LastCharacterOfLine_50 = 0;
		__this->___m_FirstVisibleCharacterOfLine_51 = 0;
		__this->___m_LastVisibleCharacterOfLine_52 = 0;
		__this->___m_MaxLineAscender_53 = (-32767.0f);
		__this->___m_MaxLineDescender_54 = (32767.0f);
		__this->___m_LineNumber_55 = 0;
		__this->___m_LineVisibleCharacterCount_56 = 0;
		V_15 = (bool)1;
		__this->___m_FirstOverflowCharacterIndex_57 = (-1);
		__this->___m_PageNumber_58 = 0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_81 = ___0_generationSettings;
		NullCheck(L_81);
		int32_t L_82 = L_81->___pageToDisplay_38;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_83 = ___1_textInfo;
		NullCheck(L_83);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_84 = L_83->___pageInfo_14;
		NullCheck(L_84);
		int32_t L_85;
		L_85 = Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline(((int32_t)il2cpp_codegen_subtract(L_82, 1)), 0, ((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_84)->max_length)), 1)), NULL);
		V_16 = L_85;
		V_17 = 0;
		V_18 = 0;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_86 = ___0_generationSettings;
		NullCheck(L_86);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_87 = L_86->___margins_2;
		V_19 = L_87;
		float L_88 = __this->___m_MarginWidth_2;
		V_20 = L_88;
		float L_89 = __this->___m_MarginHeight_3;
		V_21 = L_89;
		__this->___m_MarginLeft_59 = (0.0f);
		__this->___m_MarginRight_60 = (0.0f);
		__this->___m_Width_61 = (-1.0f);
		float L_90 = V_20;
		float L_91 = __this->___m_MarginLeft_59;
		float L_92 = __this->___m_MarginRight_60;
		V_22 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_90, (9.99999975E-05f))), L_91)), L_92));
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_93 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_94 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largePositiveVector2_0;
		L_93->___min_0 = L_94;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_95 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_96 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largeNegativeVector2_1;
		L_95->___max_1 = L_96;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_97 = ___0_generationSettings;
		NullCheck(L_97);
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_98 = L_97->___textSettings_9;
		V_23 = L_98;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_99 = ___1_textInfo;
		NullCheck(L_99);
		TextInfo_ClearLineInfo_m986C886D34A324C8C4D30F9D8EF24AC242A10AD7(L_99, NULL);
		__this->___m_MaxCapHeight_63 = (0.0f);
		__this->___m_MaxAscender_64 = (0.0f);
		__this->___m_MaxDescender_65 = (0.0f);
		V_24 = (0.0f);
		V_25 = (0.0f);
		V_26 = (bool)0;
		__this->___m_IsNewPage_66 = (bool)0;
		V_27 = (bool)1;
		__this->___m_IsNonBreakingSpace_67 = (bool)0;
		V_28 = (bool)0;
		V_29 = (bool)0;
		V_30 = 0;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_100 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_101 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_100, (-1), (-1), L_101, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_102 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState_69);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_103 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_102, (-1), (-1), L_103, NULL);
		int32_t L_104 = __this->___m_LoopCountA_70;
		__this->___m_LoopCountA_70 = ((int32_t)il2cpp_codegen_add(L_104, 1));
		V_59 = 0;
		goto IL_3293;
	}

IL_0496:
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_105 = __this->___m_CharBuffer_4;
		int32_t L_106 = V_59;
		NullCheck(L_105);
		int32_t L_107 = L_106;
		int32_t L_108 = (L_105)->GetAt(static_cast<il2cpp_array_size_t>(L_107));
		V_60 = L_108;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_109 = ___0_generationSettings;
		NullCheck(L_109);
		bool L_110 = L_109->___richText_23;
		if (!L_110)
		{
			goto IL_04b2;
		}
	}
	{
		int32_t L_111 = V_60;
		G_B15_0 = ((((int32_t)L_111) == ((int32_t)((int32_t)60)))? 1 : 0);
		goto IL_04b3;
	}

IL_04b2:
	{
		G_B15_0 = 0;
	}

IL_04b3:
	{
		V_78 = (bool)G_B15_0;
		bool L_112 = V_78;
		if (!L_112)
		{
			goto IL_04ff;
		}
	}
	{
		__this->___m_IsParsingText_72 = (bool)1;
		__this->___m_TextElementType_71 = 1;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_113 = __this->___m_CharBuffer_4;
		int32_t L_114 = V_59;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_115 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_116 = ___1_textInfo;
		bool L_117;
		L_117 = TextGenerator_ValidateHtmlTag_m9C85462F15A6165B10E4C4EE93620AC1021BE5CD(__this, L_113, ((int32_t)il2cpp_codegen_add(L_114, 1)), (&V_31), L_115, L_116, NULL);
		V_79 = L_117;
		bool L_118 = V_79;
		if (!L_118)
		{
			goto IL_04fc;
		}
	}
	{
		int32_t L_119 = V_31;
		V_59 = L_119;
		uint8_t L_120 = __this->___m_TextElementType_71;
		V_80 = (bool)((((int32_t)L_120) == ((int32_t)1))? 1 : 0);
		bool L_121 = V_80;
		if (!L_121)
		{
			goto IL_04fb;
		}
	}
	{
		goto IL_3289;
	}

IL_04fb:
	{
	}

IL_04fc:
	{
		goto IL_0555;
	}

IL_04ff:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_122 = ___1_textInfo;
		NullCheck(L_122);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_123 = L_122->___textElementInfo_10;
		int32_t L_124 = __this->___m_CharacterCount_48;
		NullCheck(L_123);
		uint8_t L_125 = ((L_123)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_124)))->___elementType_2;
		__this->___m_TextElementType_71 = L_125;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_126 = ___1_textInfo;
		NullCheck(L_126);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_127 = L_126->___textElementInfo_10;
		int32_t L_128 = __this->___m_CharacterCount_48;
		NullCheck(L_127);
		int32_t L_129 = ((L_127)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_128)))->___materialReferenceIndex_8;
		__this->___m_CurrentMaterialIndex_9 = L_129;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_130 = ___1_textInfo;
		NullCheck(L_130);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_131 = L_130->___textElementInfo_10;
		int32_t L_132 = __this->___m_CharacterCount_48;
		NullCheck(L_131);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_133 = ((L_131)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_132)))->___fontAsset_4;
		__this->___m_CurrentFontAsset_7 = L_133;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset_7), (void*)L_133);
	}

IL_0555:
	{
		int32_t L_134 = __this->___m_CurrentMaterialIndex_9;
		V_61 = L_134;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_135 = ___1_textInfo;
		NullCheck(L_135);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_136 = L_135->___textElementInfo_10;
		int32_t L_137 = __this->___m_CharacterCount_48;
		NullCheck(L_136);
		bool L_138 = ((L_136)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_137)))->___isUsingAlternateTypeface_9;
		V_62 = L_138;
		__this->___m_IsParsingText_72 = (bool)0;
		int32_t L_139 = __this->___m_CharacterCount_48;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_140 = ___0_generationSettings;
		NullCheck(L_140);
		int32_t L_141 = L_140->___firstVisibleCharacter_35;
		V_81 = (bool)((((int32_t)L_139) < ((int32_t)L_141))? 1 : 0);
		bool L_142 = V_81;
		if (!L_142)
		{
			goto IL_05d6;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_143 = ___1_textInfo;
		NullCheck(L_143);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_144 = L_143->___textElementInfo_10;
		int32_t L_145 = __this->___m_CharacterCount_48;
		NullCheck(L_144);
		((L_144)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_145)))->___isVisible_34 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_146 = ___1_textInfo;
		NullCheck(L_146);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_147 = L_146->___textElementInfo_10;
		int32_t L_148 = __this->___m_CharacterCount_48;
		NullCheck(L_147);
		((L_147)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_148)))->___character_0 = ((int32_t)8203);
		int32_t L_149 = __this->___m_CharacterCount_48;
		__this->___m_CharacterCount_48 = ((int32_t)il2cpp_codegen_add(L_149, 1));
		goto IL_3289;
	}

IL_05d6:
	{
		V_63 = (1.0f);
		uint8_t L_150 = __this->___m_TextElementType_71;
		V_82 = (bool)((((int32_t)L_150) == ((int32_t)1))? 1 : 0);
		bool L_151 = V_82;
		if (!L_151)
		{
			goto IL_0683;
		}
	}
	{
		int32_t L_152 = __this->___m_FontStyleInternal_19;
		V_83 = (bool)((((int32_t)((int32_t)((int32_t)L_152&((int32_t)16)))) == ((int32_t)((int32_t)16)))? 1 : 0);
		bool L_153 = V_83;
		if (!L_153)
		{
			goto IL_061f;
		}
	}
	{
		int32_t L_154 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_155;
		L_155 = Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE(((int32_t)(uint16_t)L_154), NULL);
		V_84 = L_155;
		bool L_156 = V_84;
		if (!L_156)
		{
			goto IL_061c;
		}
	}
	{
		int32_t L_157 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_158;
		L_158 = Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2(((int32_t)(uint16_t)L_157), NULL);
		V_60 = L_158;
	}

IL_061c:
	{
		goto IL_0682;
	}

IL_061f:
	{
		int32_t L_159 = __this->___m_FontStyleInternal_19;
		V_85 = (bool)((((int32_t)((int32_t)((int32_t)L_159&8))) == ((int32_t)8))? 1 : 0);
		bool L_160 = V_85;
		if (!L_160)
		{
			goto IL_064c;
		}
	}
	{
		int32_t L_161 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_162;
		L_162 = Char_IsUpper_mF150C44B70F522A14B2A8DF71DE0ADE52F9A3392(((int32_t)(uint16_t)L_161), NULL);
		V_86 = L_162;
		bool L_163 = V_86;
		if (!L_163)
		{
			goto IL_0649;
		}
	}
	{
		int32_t L_164 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_165;
		L_165 = Char_ToLower_m238489988C62CB10C7C7CAAEF8F3B2D1C5B5E056(((int32_t)(uint16_t)L_164), NULL);
		V_60 = L_165;
	}

IL_0649:
	{
		goto IL_0682;
	}

IL_064c:
	{
		int32_t L_166 = __this->___m_FontStyleInternal_19;
		V_87 = (bool)((((int32_t)((int32_t)((int32_t)L_166&((int32_t)32)))) == ((int32_t)((int32_t)32)))? 1 : 0);
		bool L_167 = V_87;
		if (!L_167)
		{
			goto IL_0682;
		}
	}
	{
		int32_t L_168 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_169;
		L_169 = Char_IsLower_m9DDB41367F97CFFE6C46A3B5EDE7D11180B5F1AE(((int32_t)(uint16_t)L_168), NULL);
		V_88 = L_169;
		bool L_170 = V_88;
		if (!L_170)
		{
			goto IL_0681;
		}
	}
	{
		V_63 = (0.800000012f);
		int32_t L_171 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		Il2CppChar L_172;
		L_172 = Char_ToUpper_m7DB51DD07EE52F4CA897807281880930F5CBD2D2(((int32_t)(uint16_t)L_171), NULL);
		V_60 = L_172;
	}

IL_0681:
	{
	}

IL_0682:
	{
	}

IL_0683:
	{
		uint8_t L_173 = __this->___m_TextElementType_71;
		V_89 = (bool)((((int32_t)L_173) == ((int32_t)2))? 1 : 0);
		bool L_174 = V_89;
		if (!L_174)
		{
			goto IL_081d;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_175 = ___1_textInfo;
		NullCheck(L_175);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_176 = L_175->___textElementInfo_10;
		int32_t L_177 = __this->___m_CharacterCount_48;
		NullCheck(L_176);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_178 = ((L_176)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_177)))->___textElement_3;
		V_90 = ((SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5*)CastclassClass((RuntimeObject*)L_178, SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5_il2cpp_TypeInfo_var));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_179 = V_90;
		NullCheck(L_179);
		TextAsset_tB28F1843A877CCA74B89DC4F63EA532618B049B8* L_180;
		L_180 = TextElement_get_textAsset_m52383A3758AABF5BEA013155765BD1141479685A(L_179, NULL);
		__this->___m_CurrentSpriteAsset_12 = ((SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)IsInstClass((RuntimeObject*)L_180, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var));
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentSpriteAsset_12), (void*)((SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313*)IsInstClass((RuntimeObject*)L_180, SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313_il2cpp_TypeInfo_var)));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_181 = V_90;
		NullCheck(L_181);
		uint32_t L_182;
		L_182 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_181, NULL);
		__this->___m_SpriteIndex_73 = L_182;
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_183 = V_90;
		V_92 = (bool)((((RuntimeObject*)(SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5*)L_183) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_184 = V_92;
		if (!L_184)
		{
			goto IL_06e2;
		}
	}
	{
		goto IL_3289;
	}

IL_06e2:
	{
		int32_t L_185 = V_60;
		V_93 = (bool)((((int32_t)L_185) == ((int32_t)((int32_t)60)))? 1 : 0);
		bool L_186 = V_93;
		if (!L_186)
		{
			goto IL_06fe;
		}
	}
	{
		int32_t L_187 = __this->___m_SpriteIndex_73;
		V_60 = ((int32_t)il2cpp_codegen_add(((int32_t)57344), L_187));
		goto IL_070e;
	}

IL_06fe:
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_188;
		L_188 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_189;
		L_189 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_188, NULL);
		__this->___m_SpriteColor_74 = L_189;
	}

IL_070e:
	{
		float L_190 = __this->___m_CurrentFontSize_17;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_191 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_191);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_192;
		L_192 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_191, NULL);
		V_57 = L_192;
		int32_t L_193;
		L_193 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_194 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_194);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_195;
		L_195 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_194, NULL);
		V_57 = L_195;
		float L_196;
		L_196 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		V_91 = ((float)il2cpp_codegen_multiply(((float)(L_190/((float)L_193))), L_196));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_197 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_197);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_198;
		L_198 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_197, NULL);
		V_57 = L_198;
		float L_199;
		L_199 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD((&V_57), NULL);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_200 = V_90;
		NullCheck(L_200);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_201;
		L_201 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_200, NULL);
		NullCheck(L_201);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_202;
		L_202 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_201, NULL);
		V_94 = L_202;
		float L_203;
		L_203 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_94), NULL);
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_204 = V_90;
		NullCheck(L_204);
		float L_205;
		L_205 = TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6(L_204, NULL);
		float L_206 = V_91;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_207 = ___0_generationSettings;
		NullCheck(L_207);
		float L_208 = L_207->___scale_3;
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_199/L_203)), L_205)), L_206)), L_208));
		SpriteCharacter_tB3516A25DBFA0AD68DD8E1432752D503FD1F40F5* L_209 = V_90;
		__this->___m_CachedTextElement_75 = L_209;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CachedTextElement_75), (void*)L_209);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_210 = ___1_textInfo;
		NullCheck(L_210);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_211 = L_210->___textElementInfo_10;
		int32_t L_212 = __this->___m_CharacterCount_48;
		NullCheck(L_211);
		((L_211)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_212)))->___elementType_2 = 2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_213 = ___1_textInfo;
		NullCheck(L_213);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_214 = L_213->___textElementInfo_10;
		int32_t L_215 = __this->___m_CharacterCount_48;
		NullCheck(L_214);
		float L_216 = V_91;
		((L_214)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_215)))->___scale_28 = L_216;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_217 = ___1_textInfo;
		NullCheck(L_217);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_218 = L_217->___textElementInfo_10;
		int32_t L_219 = __this->___m_CharacterCount_48;
		NullCheck(L_218);
		SpriteAsset_t1D3CF1D9DC350A4690CB09DE228A8B59F2F02313* L_220 = __this->___m_CurrentSpriteAsset_12;
		((L_218)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_219)))->___spriteAsset_5 = L_220;
		Il2CppCodeGenWriteBarrier((void**)(&((L_218)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_219)))->___spriteAsset_5), (void*)L_220);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_221 = ___1_textInfo;
		NullCheck(L_221);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_222 = L_221->___textElementInfo_10;
		int32_t L_223 = __this->___m_CharacterCount_48;
		NullCheck(L_222);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_224 = __this->___m_CurrentFontAsset_7;
		((L_222)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_223)))->___fontAsset_4 = L_224;
		Il2CppCodeGenWriteBarrier((void**)(&((L_222)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_223)))->___fontAsset_4), (void*)L_224);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_225 = ___1_textInfo;
		NullCheck(L_225);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_226 = L_225->___textElementInfo_10;
		int32_t L_227 = __this->___m_CharacterCount_48;
		NullCheck(L_226);
		int32_t L_228 = __this->___m_CurrentMaterialIndex_9;
		((L_226)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_227)))->___materialReferenceIndex_8 = L_228;
		int32_t L_229 = V_61;
		__this->___m_CurrentMaterialIndex_9 = L_229;
		V_3 = (0.0f);
		goto IL_0961;
	}

IL_081d:
	{
		uint8_t L_230 = __this->___m_TextElementType_71;
		V_95 = (bool)((((int32_t)L_230) == ((int32_t)1))? 1 : 0);
		bool L_231 = V_95;
		if (!L_231)
		{
			goto IL_0961;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_232 = ___1_textInfo;
		NullCheck(L_232);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_233 = L_232->___textElementInfo_10;
		int32_t L_234 = __this->___m_CharacterCount_48;
		NullCheck(L_233);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_235 = ((L_233)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_234)))->___textElement_3;
		__this->___m_CachedTextElement_75 = L_235;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CachedTextElement_75), (void*)L_235);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_236 = __this->___m_CachedTextElement_75;
		V_96 = (bool)((((RuntimeObject*)(TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA*)L_236) == ((RuntimeObject*)(RuntimeObject*)NULL))? 1 : 0);
		bool L_237 = V_96;
		if (!L_237)
		{
			goto IL_0860;
		}
	}
	{
		goto IL_3289;
	}

IL_0860:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_238 = ___1_textInfo;
		NullCheck(L_238);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_239 = L_238->___textElementInfo_10;
		int32_t L_240 = __this->___m_CharacterCount_48;
		NullCheck(L_239);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_241 = ((L_239)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_240)))->___fontAsset_4;
		__this->___m_CurrentFontAsset_7 = L_241;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentFontAsset_7), (void*)L_241);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_242 = ___1_textInfo;
		NullCheck(L_242);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_243 = L_242->___textElementInfo_10;
		int32_t L_244 = __this->___m_CharacterCount_48;
		NullCheck(L_243);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_245 = ((L_243)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_244)))->___material_7;
		__this->___m_CurrentMaterial_8 = L_245;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___m_CurrentMaterial_8), (void*)L_245);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_246 = ___1_textInfo;
		NullCheck(L_246);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_247 = L_246->___textElementInfo_10;
		int32_t L_248 = __this->___m_CharacterCount_48;
		NullCheck(L_247);
		int32_t L_249 = ((L_247)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_248)))->___materialReferenceIndex_8;
		__this->___m_CurrentMaterialIndex_9 = L_249;
		float L_250 = __this->___m_CurrentFontSize_17;
		float L_251 = V_63;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_252 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_252);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_253;
		L_253 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_252, NULL);
		V_57 = L_253;
		int32_t L_254;
		L_254 = FaceInfo_get_pointSize_m7EF7429A4725AB715931A220F6BB498C3D6BF7CB((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_255 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_255);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_256;
		L_256 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_255, NULL);
		V_57 = L_256;
		float L_257;
		L_257 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		__this->___m_FontScale_14 = ((float)il2cpp_codegen_multiply(((float)(((float)il2cpp_codegen_multiply(L_250, L_251))/((float)L_254))), L_257));
		float L_258 = __this->___m_FontScale_14;
		float L_259 = __this->___m_FontScaleMultiplier_16;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_260 = __this->___m_CachedTextElement_75;
		NullCheck(L_260);
		float L_261;
		L_261 = TextElement_get_scale_mD16946900449FEE9E2F86B2C4C71E26F4491A0E6(L_260, NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_262 = ___0_generationSettings;
		NullCheck(L_262);
		float L_263 = L_262->___scale_3;
		V_2 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_258, L_259)), L_261)), L_263));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_264 = ___1_textInfo;
		NullCheck(L_264);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_265 = L_264->___textElementInfo_10;
		int32_t L_266 = __this->___m_CharacterCount_48;
		NullCheck(L_265);
		((L_265)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_266)))->___elementType_2 = 1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_267 = ___1_textInfo;
		NullCheck(L_267);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_268 = L_267->___textElementInfo_10;
		int32_t L_269 = __this->___m_CharacterCount_48;
		NullCheck(L_268);
		float L_270 = V_2;
		((L_268)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_269)))->___scale_28 = L_270;
		int32_t L_271 = __this->___m_CurrentMaterialIndex_9;
		if (!L_271)
		{
			goto IL_0959;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_272 = __this->___m_CurrentMaterial_8;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_273 = ___0_generationSettings;
		NullCheck(L_273);
		bool L_274 = L_273->___extraPadding_25;
		float L_275;
		L_275 = TextGenerator_GetPaddingForMaterial_mE5A4DEF3F64851861C092F7A4FC58C902F775C74(__this, L_272, L_274, NULL);
		G_B51_0 = L_275;
		goto IL_095f;
	}

IL_0959:
	{
		float L_276 = __this->___m_Padding_11;
		G_B51_0 = L_276;
	}

IL_095f:
	{
		V_3 = G_B51_0;
	}

IL_0961:
	{
		float L_277 = V_2;
		V_64 = L_277;
		int32_t L_278 = V_60;
		V_97 = (bool)((((int32_t)L_278) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_279 = V_97;
		if (!L_279)
		{
			goto IL_097b;
		}
	}
	{
		V_2 = (0.0f);
	}

IL_097b:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_280 = ___1_textInfo;
		NullCheck(L_280);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_281 = L_280->___textElementInfo_10;
		int32_t L_282 = __this->___m_CharacterCount_48;
		NullCheck(L_281);
		int32_t L_283 = V_60;
		((L_281)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_282)))->___character_0 = ((int32_t)(uint16_t)L_283);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_284 = ___1_textInfo;
		NullCheck(L_284);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_285 = L_284->___textElementInfo_10;
		int32_t L_286 = __this->___m_CharacterCount_48;
		NullCheck(L_285);
		float L_287 = __this->___m_CurrentFontSize_17;
		((L_285)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_286)))->___pointSize_10 = L_287;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_288 = ___1_textInfo;
		NullCheck(L_288);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_289 = L_288->___textElementInfo_10;
		int32_t L_290 = __this->___m_CharacterCount_48;
		NullCheck(L_289);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_291 = __this->___m_HtmlColor_28;
		((L_289)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_290)))->___color_29 = L_291;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_292 = ___1_textInfo;
		NullCheck(L_292);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_293 = L_292->___textElementInfo_10;
		int32_t L_294 = __this->___m_CharacterCount_48;
		NullCheck(L_293);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_295 = __this->___m_UnderlineColor_29;
		((L_293)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_294)))->___underlineColor_30 = L_295;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_296 = ___1_textInfo;
		NullCheck(L_296);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_297 = L_296->___textElementInfo_10;
		int32_t L_298 = __this->___m_CharacterCount_48;
		NullCheck(L_297);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_299 = __this->___m_StrikethroughColor_30;
		((L_297)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_298)))->___strikethroughColor_31 = L_299;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_300 = ___1_textInfo;
		NullCheck(L_300);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_301 = L_300->___textElementInfo_10;
		int32_t L_302 = __this->___m_CharacterCount_48;
		NullCheck(L_301);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_303 = __this->___m_HighlightColor_76;
		((L_301)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_302)))->___highlightColor_32 = L_303;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_304 = ___1_textInfo;
		NullCheck(L_304);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_305 = L_304->___textElementInfo_10;
		int32_t L_306 = __this->___m_CharacterCount_48;
		NullCheck(L_305);
		int32_t L_307 = __this->___m_FontStyleInternal_19;
		((L_305)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_306)))->___style_33 = L_307;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_308 = ___1_textInfo;
		NullCheck(L_308);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_309 = L_308->___textElementInfo_10;
		int32_t L_310 = __this->___m_CharacterCount_48;
		NullCheck(L_309);
		int32_t L_311 = V_59;
		((L_309)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_310)))->___index_1 = L_311;
		il2cpp_codegen_initobj((&V_65), sizeof(GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_312 = ___0_generationSettings;
		NullCheck(L_312);
		float L_313 = L_312->___characterSpacing_27;
		V_66 = L_313;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_314 = ___0_generationSettings;
		NullCheck(L_314);
		bool L_315 = L_314->___enableKerning_22;
		V_98 = L_315;
		bool L_316 = V_98;
		if (!L_316)
		{
			goto IL_0b68;
		}
	}
	{
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_317 = __this->___m_CachedTextElement_75;
		NullCheck(L_317);
		uint32_t L_318;
		L_318 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_317, NULL);
		V_100 = L_318;
		int32_t L_319 = __this->___m_CharacterCount_48;
		int32_t L_320 = V_0;
		V_101 = (bool)((((int32_t)L_319) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_320, 1))))? 1 : 0);
		bool L_321 = V_101;
		if (!L_321)
		{
			goto IL_0af0;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_322 = ___1_textInfo;
		NullCheck(L_322);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_323 = L_322->___textElementInfo_10;
		int32_t L_324 = __this->___m_CharacterCount_48;
		NullCheck(L_323);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_325 = ((L_323)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_324, 1)))))->___textElement_3;
		NullCheck(L_325);
		uint32_t L_326;
		L_326 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_325, NULL);
		V_102 = L_326;
		uint32_t L_327 = V_102;
		uint32_t L_328 = V_100;
		V_103 = ((int32_t)(((int32_t)((int32_t)L_327<<((int32_t)16)))|(int32_t)L_328));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_329 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_329);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_330 = L_329->___m_FontFeatureTable_32;
		NullCheck(L_330);
		Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* L_331 = L_330->___m_GlyphPairAdjustmentRecordLookup_1;
		uint32_t L_332 = V_103;
		NullCheck(L_331);
		bool L_333;
		L_333 = Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA(L_331, L_332, (&V_99), Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		V_104 = L_333;
		bool L_334 = V_104;
		if (!L_334)
		{
			goto IL_0aef;
		}
	}
	{
		GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 L_335;
		L_335 = GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_m867469548F17B298F893B78EE2F93D34E4A6C39C((&V_99), NULL);
		V_105 = L_335;
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_336;
		L_336 = GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7((&V_105), NULL);
		V_65 = L_336;
	}

IL_0aef:
	{
	}

IL_0af0:
	{
		int32_t L_337 = __this->___m_CharacterCount_48;
		V_106 = (bool)((((int32_t)((((int32_t)L_337) < ((int32_t)1))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_338 = V_106;
		if (!L_338)
		{
			goto IL_0b67;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_339 = ___1_textInfo;
		NullCheck(L_339);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_340 = L_339->___textElementInfo_10;
		int32_t L_341 = __this->___m_CharacterCount_48;
		NullCheck(L_340);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_342 = ((L_340)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_341, 1)))))->___textElement_3;
		NullCheck(L_342);
		uint32_t L_343;
		L_343 = TextElement_get_glyphIndex_m43F82F2F998D640DEDBE6860EBE7B171DDF4FE56(L_342, NULL);
		V_107 = L_343;
		uint32_t L_344 = V_100;
		uint32_t L_345 = V_107;
		V_108 = ((int32_t)(((int32_t)((int32_t)L_344<<((int32_t)16)))|(int32_t)L_345));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_346 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_346);
		FontFeatureTable_t992E0493CD7E9D7834DF204E0198237F0D25B3B7* L_347 = L_346->___m_FontFeatureTable_32;
		NullCheck(L_347);
		Dictionary_2_tDD72F78A572F94ECEDBDA75C3D17C3ED05C167E0* L_348 = L_347->___m_GlyphPairAdjustmentRecordLookup_1;
		uint32_t L_349 = V_108;
		NullCheck(L_348);
		bool L_350;
		L_350 = Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA(L_348, L_349, (&V_99), Dictionary_2_TryGetValue_m45061EA2C8BF9DD9DC9DA92DAB968171136507DA_RuntimeMethod_var);
		V_109 = L_350;
		bool L_351 = V_109;
		if (!L_351)
		{
			goto IL_0b66;
		}
	}
	{
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_352 = V_65;
		GlyphAdjustmentRecord_tC7A1B2E0AC7C4ED9CDB8E95E48790A46B6F315F7 L_353;
		L_353 = GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_mFDFECB1F7A38E22BD2388FFE9C71E732F6B44D91((&V_99), NULL);
		V_105 = L_353;
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_354;
		L_354 = GlyphAdjustmentRecord_get_glyphValueRecord_m83866DCE07A22F903D4BA417476E64114625BDD7((&V_105), NULL);
		GlyphValueRecord_t780927A39D46924E0D546A2AE5DDF1BB2B5A9C8E L_355;
		L_355 = GlyphValueRecord_op_Addition_mF26165B4CE61A5409AEFF24B0D1727804E13602B(L_352, L_354, NULL);
		V_65 = L_355;
	}

IL_0b66:
	{
	}

IL_0b67:
	{
	}

IL_0b68:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_356 = ___0_generationSettings;
		NullCheck(L_356);
		bool L_357 = L_356->___isRightToLeft_24;
		V_110 = L_357;
		bool L_358 = V_110;
		if (!L_358)
		{
			goto IL_0c03;
		}
	}
	{
		float L_359 = __this->___m_XAdvance_43;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_360 = __this->___m_CachedTextElement_75;
		NullCheck(L_360);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_361;
		L_361 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_360, NULL);
		NullCheck(L_361);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_362;
		L_362 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_361, NULL);
		V_94 = L_362;
		float L_363;
		L_363 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_94), NULL);
		float L_364 = V_4;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_365 = ___0_generationSettings;
		NullCheck(L_365);
		float L_366 = L_365->___characterSpacing_27;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_367 = ___0_generationSettings;
		NullCheck(L_367);
		float L_368 = L_367->___wordSpacing_28;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_369 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_369);
		float L_370;
		L_370 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_369, NULL);
		float L_371 = V_2;
		float L_372 = __this->___m_CSpacing_41;
		float L_373 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_subtract(L_359, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_363, L_364)), L_366)), L_368)), L_370)), L_371)), L_372)), ((float)il2cpp_codegen_subtract((1.0f), L_373))))));
		int32_t L_374 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_375;
		L_375 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_374), NULL);
		if (L_375)
		{
			goto IL_0be6;
		}
	}
	{
		int32_t L_376 = V_60;
		G_B68_0 = ((((int32_t)L_376) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_0be7;
	}

IL_0be6:
	{
		G_B68_0 = 1;
	}

IL_0be7:
	{
		V_111 = (bool)G_B68_0;
		bool L_377 = V_111;
		if (!L_377)
		{
			goto IL_0c02;
		}
	}
	{
		float L_378 = __this->___m_XAdvance_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_379 = ___0_generationSettings;
		NullCheck(L_379);
		float L_380 = L_379->___wordSpacing_28;
		float L_381 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_subtract(L_378, ((float)il2cpp_codegen_multiply(L_380, L_381))));
	}

IL_0c02:
	{
	}

IL_0c03:
	{
		V_67 = (0.0f);
		float L_382 = __this->___m_MonoSpacing_42;
		V_112 = (bool)((((int32_t)((((float)L_382) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_383 = V_112;
		if (!L_383)
		{
			goto IL_0c88;
		}
	}
	{
		float L_384 = __this->___m_MonoSpacing_42;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_385 = __this->___m_CachedTextElement_75;
		NullCheck(L_385);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_386;
		L_386 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_385, NULL);
		NullCheck(L_386);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_387;
		L_387 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_386, NULL);
		V_94 = L_387;
		float L_388;
		L_388 = GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13((&V_94), NULL);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_389 = __this->___m_CachedTextElement_75;
		NullCheck(L_389);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_390;
		L_390 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_389, NULL);
		NullCheck(L_390);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_391;
		L_391 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_390, NULL);
		V_94 = L_391;
		float L_392;
		L_392 = GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F((&V_94), NULL);
		float L_393 = V_2;
		float L_394 = __this->___m_CharWidthAdjDelta_77;
		V_67 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)(L_384/(2.0f))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)(L_388/(2.0f))), L_392)), L_393)))), ((float)il2cpp_codegen_subtract((1.0f), L_394))));
		float L_395 = __this->___m_XAdvance_43;
		float L_396 = V_67;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_395, L_396));
	}

IL_0c88:
	{
		uint8_t L_397 = __this->___m_TextElementType_71;
		if ((!(((uint32_t)L_397) == ((uint32_t)1))))
		{
			goto IL_0ca2;
		}
	}
	{
		bool L_398 = V_62;
		if (L_398)
		{
			goto IL_0ca2;
		}
	}
	{
		int32_t L_399 = __this->___m_FontStyleInternal_19;
		G_B77_0 = ((((int32_t)((int32_t)((int32_t)L_399&1))) == ((int32_t)1))? 1 : 0);
		goto IL_0ca3;
	}

IL_0ca2:
	{
		G_B77_0 = 0;
	}

IL_0ca3:
	{
		V_113 = (bool)G_B77_0;
		bool L_400 = V_113;
		if (!L_400)
		{
			goto IL_0d37;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_401 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_402 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_401);
		bool L_403;
		L_403 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_401, L_402, NULL);
		V_114 = L_403;
		bool L_404 = V_114;
		if (!L_404)
		{
			goto IL_0d14;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_405 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_406 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_405);
		float L_407;
		L_407 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_405, L_406, NULL);
		V_115 = L_407;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_408 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_408);
		float L_409;
		L_409 = FontAsset_get_boldStyleWeight_m804ACC85DD80DC72DB4BCC83C3FB866411F8EFCA(L_408, NULL);
		float L_410 = V_115;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_411 = __this->___m_CurrentMaterial_8;
		int32_t L_412 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A_49;
		NullCheck(L_411);
		float L_413;
		L_413 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_411, L_412, NULL);
		V_68 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_409/(4.0f))), L_410)), L_413));
		float L_414 = V_68;
		float L_415 = V_3;
		float L_416 = V_115;
		V_116 = (bool)((((float)((float)il2cpp_codegen_add(L_414, L_415))) > ((float)L_416))? 1 : 0);
		bool L_417 = V_116;
		if (!L_417)
		{
			goto IL_0d11;
		}
	}
	{
		float L_418 = V_115;
		float L_419 = V_68;
		V_3 = ((float)il2cpp_codegen_subtract(L_418, L_419));
	}

IL_0d11:
	{
		goto IL_0d1b;
	}

IL_0d14:
	{
		V_68 = (0.0f);
	}

IL_0d1b:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_420 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_420);
		float L_421;
		L_421 = FontAsset_get_boldStyleSpacing_mB8CF4F4880B110E41D566648FF1D995010CF1FF0(L_420, NULL);
		V_4 = ((float)il2cpp_codegen_add((1.0f), ((float)il2cpp_codegen_multiply(L_421, (0.00999999978f)))));
		goto IL_0dae;
	}

IL_0d37:
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_422 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_423 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_422);
		bool L_424;
		L_424 = Material_HasProperty_m52E2D3BC3049B8B228149E023CD73C34B05A5222(L_422, L_423, NULL);
		V_117 = L_424;
		bool L_425 = V_117;
		if (!L_425)
		{
			goto IL_0d9f;
		}
	}
	{
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_426 = __this->___m_CurrentMaterial_8;
		il2cpp_codegen_runtime_class_init_inline(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var);
		int32_t L_427 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_GradientScale_19;
		NullCheck(L_426);
		float L_428;
		L_428 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_426, L_427, NULL);
		V_118 = L_428;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_429 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_429);
		float L_430;
		L_430 = FontAsset_get_regularStyleWeight_m6C4B4D4CAD36800E6E686A05A5DB8D4475F2707F(L_429, NULL);
		float L_431 = V_118;
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_432 = __this->___m_CurrentMaterial_8;
		int32_t L_433 = ((TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_StaticFields*)il2cpp_codegen_static_fields_for(TextShaderUtilities_t47B400695C5D96E7B04FEF9D132468B3A1799692_il2cpp_TypeInfo_var))->___ID_ScaleRatio_A_49;
		NullCheck(L_432);
		float L_434;
		L_434 = Material_GetFloat_m52462F4AEDE20758BFB592B11DE83A79D2774932(L_432, L_433, NULL);
		V_68 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)(L_430/(4.0f))), L_431)), L_434));
		float L_435 = V_68;
		float L_436 = V_3;
		float L_437 = V_118;
		V_119 = (bool)((((float)((float)il2cpp_codegen_add(L_435, L_436))) > ((float)L_437))? 1 : 0);
		bool L_438 = V_119;
		if (!L_438)
		{
			goto IL_0d9c;
		}
	}
	{
		float L_439 = V_118;
		float L_440 = V_68;
		V_3 = ((float)il2cpp_codegen_subtract(L_439, L_440));
	}

IL_0d9c:
	{
		goto IL_0da6;
	}

IL_0d9f:
	{
		V_68 = (0.0f);
	}

IL_0da6:
	{
		V_4 = (1.0f);
	}

IL_0dae:
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_441 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_441);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_442;
		L_442 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_441, NULL);
		V_57 = L_442;
		float L_443;
		L_443 = FaceInfo_get_baseline_m934B597D3E0080FEF98CBDD091C457B497179C3A((&V_57), NULL);
		float L_444 = __this->___m_FontScale_14;
		float L_445 = __this->___m_FontScaleMultiplier_16;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_446 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_446);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_447;
		L_447 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_446, NULL);
		V_57 = L_447;
		float L_448;
		L_448 = FaceInfo_get_scale_mC475A572AD4956B47D8B9F8D90DC69BBBB102FCD((&V_57), NULL);
		V_69 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_443, L_444)), L_445)), L_448));
		float L_449 = __this->___m_XAdvance_43;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_450 = __this->___m_CachedTextElement_75;
		NullCheck(L_450);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_451;
		L_451 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_450, NULL);
		NullCheck(L_451);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_452;
		L_452 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_451, NULL);
		V_94 = L_452;
		float L_453;
		L_453 = GlyphMetrics_get_horizontalBearingX_m9C39B5E6D27FF34B706649AE47EE9390B5D76D6F((&V_94), NULL);
		float L_454 = V_3;
		float L_455 = V_68;
		float L_456;
		L_456 = GlyphValueRecord_get_xPlacement_m5E2B8B05A5DF57B2DC4B3795E71330CDDE1761C8((&V_65), NULL);
		float L_457 = V_2;
		float L_458 = __this->___m_CharWidthAdjDelta_77;
		(&V_70)->___x_2 = ((float)il2cpp_codegen_add(L_449, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_453, L_454)), L_455)), L_456)), L_457)), ((float)il2cpp_codegen_subtract((1.0f), L_458))))));
		float L_459 = V_69;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_460 = __this->___m_CachedTextElement_75;
		NullCheck(L_460);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_461;
		L_461 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_460, NULL);
		NullCheck(L_461);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_462;
		L_462 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_461, NULL);
		V_94 = L_462;
		float L_463;
		L_463 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_94), NULL);
		float L_464 = V_3;
		float L_465;
		L_465 = GlyphValueRecord_get_yPlacement_mB6303F8800305F6F96ECCD0CD9AA70A1A30A15DA((&V_65), NULL);
		float L_466 = V_2;
		float L_467 = __this->___m_LineOffset_39;
		float L_468 = __this->___m_BaselineOffset_25;
		(&V_70)->___y_3 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_459, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_463, L_464)), L_465)), L_466)))), L_467)), L_468));
		(&V_70)->___z_4 = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_469 = V_70;
		float L_470 = L_469.___x_2;
		(&V_71)->___x_2 = L_470;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_471 = V_70;
		float L_472 = L_471.___y_3;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_473 = __this->___m_CachedTextElement_75;
		NullCheck(L_473);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_474;
		L_474 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_473, NULL);
		NullCheck(L_474);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_475;
		L_475 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_474, NULL);
		V_94 = L_475;
		float L_476;
		L_476 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_94), NULL);
		float L_477 = V_3;
		float L_478 = V_2;
		(&V_71)->___y_3 = ((float)il2cpp_codegen_subtract(L_472, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_476, ((float)il2cpp_codegen_multiply(L_477, (2.0f))))), L_478))));
		(&V_71)->___z_4 = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_479 = V_71;
		float L_480 = L_479.___x_2;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_481 = __this->___m_CachedTextElement_75;
		NullCheck(L_481);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_482;
		L_482 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_481, NULL);
		NullCheck(L_482);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_483;
		L_483 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_482, NULL);
		V_94 = L_483;
		float L_484;
		L_484 = GlyphMetrics_get_width_m0F9F391E3A98984167E8001D4101BE1CE9354D13((&V_94), NULL);
		float L_485 = V_3;
		float L_486 = V_68;
		float L_487 = V_2;
		float L_488 = __this->___m_CharWidthAdjDelta_77;
		(&V_72)->___x_2 = ((float)il2cpp_codegen_add(L_480, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_484, ((float)il2cpp_codegen_multiply(L_485, (2.0f))))), ((float)il2cpp_codegen_multiply(L_486, (2.0f))))), L_487)), ((float)il2cpp_codegen_subtract((1.0f), L_488))))));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_489 = V_70;
		float L_490 = L_489.___y_3;
		(&V_72)->___y_3 = L_490;
		(&V_72)->___z_4 = (0.0f);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_491 = V_72;
		float L_492 = L_491.___x_2;
		(&V_73)->___x_2 = L_492;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_493 = V_71;
		float L_494 = L_493.___y_3;
		(&V_73)->___y_3 = L_494;
		(&V_73)->___z_4 = (0.0f);
		uint8_t L_495 = __this->___m_TextElementType_71;
		if ((!(((uint32_t)L_495) == ((uint32_t)1))))
		{
			goto IL_0f63;
		}
	}
	{
		bool L_496 = V_62;
		if (L_496)
		{
			goto IL_0f63;
		}
	}
	{
		int32_t L_497 = __this->___m_FontStyleInternal_19;
		G_B94_0 = ((((int32_t)((int32_t)((int32_t)L_497&2))) == ((int32_t)2))? 1 : 0);
		goto IL_0f64;
	}

IL_0f63:
	{
		G_B94_0 = 0;
	}

IL_0f64:
	{
		V_120 = (bool)G_B94_0;
		bool L_498 = V_120;
		if (!L_498)
		{
			goto IL_1031;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_499 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_499);
		uint8_t L_500;
		L_500 = FontAsset_get_italicStyleSlant_m69E70060C6E7940B4ACE61F2B7CB8965F86DA96B(L_499, NULL);
		V_121 = ((float)il2cpp_codegen_multiply(((float)L_500), (0.00999999978f)));
		float L_501 = V_121;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_502 = __this->___m_CachedTextElement_75;
		NullCheck(L_502);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_503;
		L_503 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_502, NULL);
		NullCheck(L_503);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_504;
		L_504 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_503, NULL);
		V_94 = L_504;
		float L_505;
		L_505 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_94), NULL);
		float L_506 = V_3;
		float L_507 = V_68;
		float L_508 = V_2;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_122), ((float)il2cpp_codegen_multiply(L_501, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_505, L_506)), L_507)), L_508)))), (0.0f), (0.0f), NULL);
		float L_509 = V_121;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_510 = __this->___m_CachedTextElement_75;
		NullCheck(L_510);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_511;
		L_511 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_510, NULL);
		NullCheck(L_511);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_512;
		L_512 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_511, NULL);
		V_94 = L_512;
		float L_513;
		L_513 = GlyphMetrics_get_horizontalBearingY_mD316BDD38A32258256994D6A2BCF0FC051D9B223((&V_94), NULL);
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_514 = __this->___m_CachedTextElement_75;
		NullCheck(L_514);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_515;
		L_515 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_514, NULL);
		NullCheck(L_515);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_516;
		L_516 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_515, NULL);
		V_94 = L_516;
		float L_517;
		L_517 = GlyphMetrics_get_height_mE0872B23CE1A20BF78DEACDBD53BAF789D84AD5C((&V_94), NULL);
		float L_518 = V_3;
		float L_519 = V_68;
		float L_520 = V_2;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_123), ((float)il2cpp_codegen_multiply(L_509, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_513, L_517)), L_518)), L_519)), L_520)))), (0.0f), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_521 = V_70;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_522 = V_122;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_523;
		L_523 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_521, L_522, NULL);
		V_70 = L_523;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_524 = V_71;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_525 = V_123;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_526;
		L_526 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_524, L_525, NULL);
		V_71 = L_526;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_527 = V_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_528 = V_122;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_529;
		L_529 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_527, L_528, NULL);
		V_72 = L_529;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_530 = V_73;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_531 = V_123;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_532;
		L_532 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_530, L_531, NULL);
		V_73 = L_532;
	}

IL_1031:
	{
		bool L_533 = __this->___m_IsFxMatrixSet_38;
		V_124 = L_533;
		bool L_534 = V_124;
		if (!L_534)
		{
			goto IL_10cb;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_535 = V_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_536 = V_71;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_537;
		L_537 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_535, L_536, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_538;
		L_538 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_537, (2.0f), NULL);
		V_125 = L_538;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_539 = (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6*)(&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_540 = V_70;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_541 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_542;
		L_542 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_540, L_541, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_543;
		L_543 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_539, L_542, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_544 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_545;
		L_545 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_543, L_544, NULL);
		V_70 = L_545;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_546 = (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6*)(&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_547 = V_71;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_548 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_549;
		L_549 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_547, L_548, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_550;
		L_550 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_546, L_549, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_551 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_552;
		L_552 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_550, L_551, NULL);
		V_71 = L_552;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_553 = (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6*)(&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_554 = V_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_555 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_556;
		L_556 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_554, L_555, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_557;
		L_557 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_553, L_556, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_558 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_559;
		L_559 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_557, L_558, NULL);
		V_72 = L_559;
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_560 = (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6*)(&__this->___m_FxMatrix_78);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_561 = V_73;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_562 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_563;
		L_563 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_561, L_562, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_564;
		L_564 = Matrix4x4_MultiplyPoint3x4_mACCBD70AFA82C63DA88555780B7B6B01281AB814(L_560, L_563, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_565 = V_125;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_566;
		L_566 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_564, L_565, NULL);
		V_73 = L_566;
	}

IL_10cb:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_567 = ___1_textInfo;
		NullCheck(L_567);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_568 = L_567->___textElementInfo_10;
		int32_t L_569 = __this->___m_CharacterCount_48;
		NullCheck(L_568);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_570 = V_71;
		((L_568)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_569)))->___bottomLeft_19 = L_570;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_571 = ___1_textInfo;
		NullCheck(L_571);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_572 = L_571->___textElementInfo_10;
		int32_t L_573 = __this->___m_CharacterCount_48;
		NullCheck(L_572);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_574 = V_70;
		((L_572)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_573)))->___topLeft_18 = L_574;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_575 = ___1_textInfo;
		NullCheck(L_575);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_576 = L_575->___textElementInfo_10;
		int32_t L_577 = __this->___m_CharacterCount_48;
		NullCheck(L_576);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_578 = V_72;
		((L_576)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_577)))->___topRight_20 = L_578;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_579 = ___1_textInfo;
		NullCheck(L_579);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_580 = L_579->___textElementInfo_10;
		int32_t L_581 = __this->___m_CharacterCount_48;
		NullCheck(L_580);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_582 = V_73;
		((L_580)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_581)))->___bottomRight_21 = L_582;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_583 = ___1_textInfo;
		NullCheck(L_583);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_584 = L_583->___textElementInfo_10;
		int32_t L_585 = __this->___m_CharacterCount_48;
		NullCheck(L_584);
		float L_586 = __this->___m_XAdvance_43;
		((L_584)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_585)))->___origin_22 = L_586;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_587 = ___1_textInfo;
		NullCheck(L_587);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_588 = L_587->___textElementInfo_10;
		int32_t L_589 = __this->___m_CharacterCount_48;
		NullCheck(L_588);
		float L_590 = V_69;
		float L_591 = __this->___m_LineOffset_39;
		float L_592 = __this->___m_BaselineOffset_25;
		((L_588)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_589)))->___baseLine_24 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_590, L_591)), L_592));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_593 = ___1_textInfo;
		NullCheck(L_593);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_594 = L_593->___textElementInfo_10;
		int32_t L_595 = __this->___m_CharacterCount_48;
		NullCheck(L_594);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_596 = V_72;
		float L_597 = L_596.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_598 = V_71;
		float L_599 = L_598.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_600 = V_70;
		float L_601 = L_600.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_602 = V_71;
		float L_603 = L_602.___y_3;
		((L_594)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_595)))->___aspectRatio_27 = ((float)(((float)il2cpp_codegen_subtract(L_597, L_599))/((float)il2cpp_codegen_subtract(L_601, L_603))));
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_604 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_604);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_605;
		L_605 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_604, NULL);
		V_57 = L_605;
		float L_606;
		L_606 = FaceInfo_get_ascentLine_m193755D649428EC24A7E433A1728F11DA7547ABD((&V_57), NULL);
		uint8_t L_607 = __this->___m_TextElementType_71;
		G_B99_0 = L_606;
		if ((((int32_t)L_607) == ((int32_t)1)))
		{
			G_B100_0 = L_606;
			goto IL_11d7;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_608 = ___1_textInfo;
		NullCheck(L_608);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_609 = L_608->___textElementInfo_10;
		int32_t L_610 = __this->___m_CharacterCount_48;
		NullCheck(L_609);
		float L_611 = ((L_609)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_610)))->___scale_28;
		G_B101_0 = L_611;
		G_B101_1 = G_B99_0;
		goto IL_11db;
	}

IL_11d7:
	{
		float L_612 = V_2;
		float L_613 = V_63;
		G_B101_0 = ((float)(L_612/L_613));
		G_B101_1 = G_B100_0;
	}

IL_11db:
	{
		float L_614 = __this->___m_BaselineOffset_25;
		V_74 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(G_B101_1, G_B101_0)), L_614));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_615 = ___1_textInfo;
		NullCheck(L_615);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_616 = L_615->___textElementInfo_10;
		int32_t L_617 = __this->___m_CharacterCount_48;
		NullCheck(L_616);
		float L_618 = V_74;
		float L_619 = __this->___m_LineOffset_39;
		((L_616)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_617)))->___ascender_23 = ((float)il2cpp_codegen_subtract(L_618, L_619));
		float L_620 = V_74;
		float L_621 = __this->___m_MaxLineAscender_53;
		G_B102_0 = __this;
		if ((((float)L_620) > ((float)L_621)))
		{
			G_B103_0 = __this;
			goto IL_1217;
		}
	}
	{
		float L_622 = __this->___m_MaxLineAscender_53;
		G_B104_0 = L_622;
		G_B104_1 = G_B102_0;
		goto IL_1219;
	}

IL_1217:
	{
		float L_623 = V_74;
		G_B104_0 = L_623;
		G_B104_1 = G_B103_0;
	}

IL_1219:
	{
		NullCheck(G_B104_1);
		G_B104_1->___m_MaxLineAscender_53 = G_B104_0;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_624 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_624);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_625;
		L_625 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_624, NULL);
		V_57 = L_625;
		float L_626;
		L_626 = FaceInfo_get_descentLine_m811A243C9B328B0C546BF9927A010A05DF172BD3((&V_57), NULL);
		uint8_t L_627 = __this->___m_TextElementType_71;
		G_B105_0 = L_626;
		if ((((int32_t)L_627) == ((int32_t)1)))
		{
			G_B106_0 = L_626;
			goto IL_1253;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_628 = ___1_textInfo;
		NullCheck(L_628);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_629 = L_628->___textElementInfo_10;
		int32_t L_630 = __this->___m_CharacterCount_48;
		NullCheck(L_629);
		float L_631 = ((L_629)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_630)))->___scale_28;
		G_B107_0 = L_631;
		G_B107_1 = G_B105_0;
		goto IL_1257;
	}

IL_1253:
	{
		float L_632 = V_2;
		float L_633 = V_63;
		G_B107_0 = ((float)(L_632/L_633));
		G_B107_1 = G_B106_0;
	}

IL_1257:
	{
		float L_634 = __this->___m_BaselineOffset_25;
		V_75 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(G_B107_1, G_B107_0)), L_634));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_635 = ___1_textInfo;
		NullCheck(L_635);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_636 = L_635->___textElementInfo_10;
		int32_t L_637 = __this->___m_CharacterCount_48;
		NullCheck(L_636);
		float L_638 = V_75;
		float L_639 = __this->___m_LineOffset_39;
		float L_640 = ((float)il2cpp_codegen_subtract(L_638, L_639));
		V_58 = L_640;
		((L_636)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_637)))->___descender_25 = L_640;
		float L_641 = V_58;
		V_76 = L_641;
		float L_642 = V_75;
		float L_643 = __this->___m_MaxLineDescender_54;
		G_B108_0 = __this;
		if ((((float)L_642) < ((float)L_643)))
		{
			G_B109_0 = __this;
			goto IL_129a;
		}
	}
	{
		float L_644 = __this->___m_MaxLineDescender_54;
		G_B110_0 = L_644;
		G_B110_1 = G_B108_0;
		goto IL_129c;
	}

IL_129a:
	{
		float L_645 = V_75;
		G_B110_0 = L_645;
		G_B110_1 = G_B109_0;
	}

IL_129c:
	{
		NullCheck(G_B110_1);
		G_B110_1->___m_MaxLineDescender_54 = G_B110_0;
		int32_t L_646 = __this->___m_FontStyleInternal_19;
		if ((((int32_t)((int32_t)((int32_t)L_646&((int32_t)256)))) == ((int32_t)((int32_t)256))))
		{
			goto IL_12c9;
		}
	}
	{
		int32_t L_647 = __this->___m_FontStyleInternal_19;
		G_B113_0 = ((((int32_t)((int32_t)((int32_t)L_647&((int32_t)128)))) == ((int32_t)((int32_t)128)))? 1 : 0);
		goto IL_12ca;
	}

IL_12c9:
	{
		G_B113_0 = 1;
	}

IL_12ca:
	{
		V_126 = (bool)G_B113_0;
		bool L_648 = V_126;
		if (!L_648)
		{
			goto IL_1359;
		}
	}
	{
		float L_649 = V_74;
		float L_650 = __this->___m_BaselineOffset_25;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_651 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_651);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_652;
		L_652 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_651, NULL);
		V_57 = L_652;
		float L_653;
		L_653 = FaceInfo_get_subscriptSize_mF6264BFB215FDE6C94A45D2F8FC946ADFCDD2E31((&V_57), NULL);
		V_127 = ((float)(((float)il2cpp_codegen_subtract(L_649, L_650))/L_653));
		float L_654 = __this->___m_MaxLineAscender_53;
		V_74 = L_654;
		float L_655 = V_127;
		float L_656 = __this->___m_MaxLineAscender_53;
		G_B115_0 = __this;
		if ((((float)L_655) > ((float)L_656)))
		{
			G_B116_0 = __this;
			goto IL_130f;
		}
	}
	{
		float L_657 = __this->___m_MaxLineAscender_53;
		G_B117_0 = L_657;
		G_B117_1 = G_B115_0;
		goto IL_1311;
	}

IL_130f:
	{
		float L_658 = V_127;
		G_B117_0 = L_658;
		G_B117_1 = G_B116_0;
	}

IL_1311:
	{
		NullCheck(G_B117_1);
		G_B117_1->___m_MaxLineAscender_53 = G_B117_0;
		float L_659 = V_75;
		float L_660 = __this->___m_BaselineOffset_25;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_661 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_661);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_662;
		L_662 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_661, NULL);
		V_57 = L_662;
		float L_663;
		L_663 = FaceInfo_get_subscriptSize_mF6264BFB215FDE6C94A45D2F8FC946ADFCDD2E31((&V_57), NULL);
		V_128 = ((float)(((float)il2cpp_codegen_subtract(L_659, L_660))/L_663));
		float L_664 = __this->___m_MaxLineDescender_54;
		V_75 = L_664;
		float L_665 = V_128;
		float L_666 = __this->___m_MaxLineDescender_54;
		G_B118_0 = __this;
		if ((((float)L_665) < ((float)L_666)))
		{
			G_B119_0 = __this;
			goto IL_1351;
		}
	}
	{
		float L_667 = __this->___m_MaxLineDescender_54;
		G_B120_0 = L_667;
		G_B120_1 = G_B118_0;
		goto IL_1353;
	}

IL_1351:
	{
		float L_668 = V_128;
		G_B120_0 = L_668;
		G_B120_1 = G_B119_0;
	}

IL_1353:
	{
		NullCheck(G_B120_1);
		G_B120_1->___m_MaxLineDescender_54 = G_B120_0;
	}

IL_1359:
	{
		int32_t L_669 = __this->___m_LineNumber_55;
		if (!L_669)
		{
			goto IL_1369;
		}
	}
	{
		bool L_670 = __this->___m_IsNewPage_66;
		G_B124_0 = ((int32_t)(L_670));
		goto IL_136a;
	}

IL_1369:
	{
		G_B124_0 = 1;
	}

IL_136a:
	{
		V_129 = (bool)G_B124_0;
		bool L_671 = V_129;
		if (!L_671)
		{
			goto IL_13b6;
		}
	}
	{
		float L_672 = __this->___m_MaxAscender_64;
		float L_673 = V_74;
		G_B126_0 = __this;
		if ((((float)L_672) > ((float)L_673)))
		{
			G_B127_0 = __this;
			goto IL_1380;
		}
	}
	{
		float L_674 = V_74;
		G_B128_0 = L_674;
		G_B128_1 = G_B126_0;
		goto IL_1386;
	}

IL_1380:
	{
		float L_675 = __this->___m_MaxAscender_64;
		G_B128_0 = L_675;
		G_B128_1 = G_B127_0;
	}

IL_1386:
	{
		NullCheck(G_B128_1);
		G_B128_1->___m_MaxAscender_64 = G_B128_0;
		float L_676 = __this->___m_MaxCapHeight_63;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_677 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_677);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_678;
		L_678 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_677, NULL);
		V_57 = L_678;
		float L_679;
		L_679 = FaceInfo_get_capLine_m0D95B5D5CEC5CFB12091F5EB5965DE6E38588C88((&V_57), NULL);
		float L_680 = V_2;
		float L_681 = V_63;
		float L_682;
		L_682 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_676, ((float)(((float)il2cpp_codegen_multiply(L_679, L_680))/L_681)), NULL);
		__this->___m_MaxCapHeight_63 = L_682;
	}

IL_13b6:
	{
		float L_683 = __this->___m_LineOffset_39;
		V_130 = (bool)((((float)L_683) == ((float)(0.0f)))? 1 : 0);
		bool L_684 = V_130;
		if (!L_684)
		{
			goto IL_13d7;
		}
	}
	{
		float L_685 = V_24;
		float L_686 = V_74;
		if ((((float)L_685) > ((float)L_686)))
		{
			goto IL_13d3;
		}
	}
	{
		float L_687 = V_74;
		G_B133_0 = L_687;
		goto IL_13d5;
	}

IL_13d3:
	{
		float L_688 = V_24;
		G_B133_0 = L_688;
	}

IL_13d5:
	{
		V_24 = G_B133_0;
	}

IL_13d7:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_689 = ___1_textInfo;
		NullCheck(L_689);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_690 = L_689->___textElementInfo_10;
		int32_t L_691 = __this->___m_CharacterCount_48;
		NullCheck(L_690);
		((L_690)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_691)))->___isVisible_34 = (bool)0;
		int32_t L_692 = V_60;
		if ((((int32_t)L_692) == ((int32_t)((int32_t)9))))
		{
			goto IL_1424;
		}
	}
	{
		int32_t L_693 = V_60;
		if ((((int32_t)L_693) == ((int32_t)((int32_t)160))))
		{
			goto IL_1424;
		}
	}
	{
		int32_t L_694 = V_60;
		if ((((int32_t)L_694) == ((int32_t)((int32_t)8199))))
		{
			goto IL_1424;
		}
	}
	{
		int32_t L_695 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_696;
		L_696 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_695), NULL);
		if (L_696)
		{
			goto IL_1419;
		}
	}
	{
		int32_t L_697 = V_60;
		if ((!(((uint32_t)L_697) == ((uint32_t)((int32_t)8203)))))
		{
			goto IL_1424;
		}
	}

IL_1419:
	{
		uint8_t L_698 = __this->___m_TextElementType_71;
		G_B141_0 = ((((int32_t)L_698) == ((int32_t)2))? 1 : 0);
		goto IL_1425;
	}

IL_1424:
	{
		G_B141_0 = 1;
	}

IL_1425:
	{
		V_131 = (bool)G_B141_0;
		bool L_699 = V_131;
		if (!L_699)
		{
			goto IL_1fe5;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_700 = ___1_textInfo;
		NullCheck(L_700);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_701 = L_700->___textElementInfo_10;
		int32_t L_702 = __this->___m_CharacterCount_48;
		NullCheck(L_701);
		((L_701)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_702)))->___isVisible_34 = (bool)1;
		float L_703 = __this->___m_Width_61;
		if ((!(((float)L_703) == ((float)(-1.0f)))))
		{
			goto IL_146b;
		}
	}
	{
		float L_704 = V_20;
		float L_705 = __this->___m_MarginLeft_59;
		float L_706 = __this->___m_MarginRight_60;
		G_B145_0 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_704, (9.99999975E-05f))), L_705)), L_706));
		goto IL_148c;
	}

IL_146b:
	{
		float L_707 = V_20;
		float L_708 = __this->___m_MarginLeft_59;
		float L_709 = __this->___m_MarginRight_60;
		float L_710 = __this->___m_Width_61;
		float L_711;
		L_711 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_707, (9.99999975E-05f))), L_708)), L_709)), L_710, NULL);
		G_B145_0 = L_711;
	}

IL_148c:
	{
		V_22 = G_B145_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_712 = ___1_textInfo;
		NullCheck(L_712);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_713 = L_712->___lineInfo_13;
		int32_t L_714 = __this->___m_LineNumber_55;
		NullCheck(L_713);
		float L_715 = __this->___m_MarginLeft_59;
		((L_713)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_714)))->___marginLeft_17 = L_715;
		int32_t L_716 = __this->___m_LineJustification_23;
		if ((((int32_t)((int32_t)((int32_t)L_716&((int32_t)16)))) == ((int32_t)((int32_t)16))))
		{
			goto IL_14c4;
		}
	}
	{
		int32_t L_717 = __this->___m_LineJustification_23;
		G_B148_0 = ((((int32_t)((int32_t)((int32_t)L_717&8))) == ((int32_t)8))? 1 : 0);
		goto IL_14c5;
	}

IL_14c4:
	{
		G_B148_0 = 1;
	}

IL_14c5:
	{
		V_132 = (bool)G_B148_0;
		float L_718 = __this->___m_XAdvance_43;
		float L_719;
		L_719 = fabsf(L_718);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_720 = ___0_generationSettings;
		NullCheck(L_720);
		bool L_721 = L_720->___isRightToLeft_24;
		G_B149_0 = L_719;
		if (!L_721)
		{
			G_B150_0 = L_719;
			goto IL_14e1;
		}
	}
	{
		G_B151_0 = (0.0f);
		G_B151_1 = G_B149_0;
		goto IL_14fa;
	}

IL_14e1:
	{
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_722 = __this->___m_CachedTextElement_75;
		NullCheck(L_722);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_723;
		L_723 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_722, NULL);
		NullCheck(L_723);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_724;
		L_724 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_723, NULL);
		V_94 = L_724;
		float L_725;
		L_725 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_94), NULL);
		G_B151_0 = L_725;
		G_B151_1 = G_B150_0;
	}

IL_14fa:
	{
		float L_726 = __this->___m_CharWidthAdjDelta_77;
		int32_t L_727 = V_60;
		G_B152_0 = ((float)il2cpp_codegen_multiply(G_B151_0, ((float)il2cpp_codegen_subtract((1.0f), L_726))));
		G_B152_1 = G_B151_1;
		if ((!(((uint32_t)L_727) == ((uint32_t)((int32_t)173)))))
		{
			G_B153_0 = ((float)il2cpp_codegen_multiply(G_B151_0, ((float)il2cpp_codegen_subtract((1.0f), L_726))));
			G_B153_1 = G_B151_1;
			goto IL_1514;
		}
	}
	{
		float L_728 = V_64;
		G_B154_0 = L_728;
		G_B154_1 = G_B152_0;
		G_B154_2 = G_B152_1;
		goto IL_1515;
	}

IL_1514:
	{
		float L_729 = V_2;
		G_B154_0 = L_729;
		G_B154_1 = G_B153_0;
		G_B154_2 = G_B153_1;
	}

IL_1515:
	{
		V_133 = ((float)il2cpp_codegen_add(G_B154_2, ((float)il2cpp_codegen_multiply(G_B154_1, G_B154_0))));
		float L_730 = V_133;
		float L_731 = V_22;
		bool L_732 = V_132;
		G_B155_0 = L_731;
		G_B155_1 = L_730;
		if (L_732)
		{
			G_B156_0 = L_731;
			G_B156_1 = L_730;
			goto IL_1528;
		}
	}
	{
		G_B157_0 = (1.0f);
		G_B157_1 = G_B155_0;
		G_B157_2 = G_B155_1;
		goto IL_152d;
	}

IL_1528:
	{
		G_B157_0 = (1.04999995f);
		G_B157_1 = G_B156_0;
		G_B157_2 = G_B156_1;
	}

IL_152d:
	{
		V_134 = (bool)((((float)G_B157_2) > ((float)((float)il2cpp_codegen_multiply(G_B157_1, G_B157_0))))? 1 : 0);
		bool L_733 = V_134;
		if (!L_733)
		{
			goto IL_1eaa;
		}
	}
	{
		int32_t L_734 = __this->___m_CharacterCount_48;
		V_18 = ((int32_t)il2cpp_codegen_subtract(L_734, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_735 = ___0_generationSettings;
		NullCheck(L_735);
		bool L_736 = L_735->___wordWrap_12;
		if (!L_736)
		{
			goto IL_155f;
		}
	}
	{
		int32_t L_737 = __this->___m_CharacterCount_48;
		int32_t L_738 = __this->___m_FirstCharacterOfLine_49;
		G_B161_0 = ((((int32_t)((((int32_t)L_737) == ((int32_t)L_738))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_1560;
	}

IL_155f:
	{
		G_B161_0 = 0;
	}

IL_1560:
	{
		V_135 = (bool)G_B161_0;
		bool L_739 = V_135;
		if (!L_739)
		{
			goto IL_1bda;
		}
	}
	{
		int32_t L_740 = V_30;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_741 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		int32_t L_742 = L_741->___previousWordBreak_0;
		bool L_743 = V_27;
		V_138 = (bool)((int32_t)(((((int32_t)L_740) == ((int32_t)L_742))? 1 : 0)|(int32_t)L_743));
		bool L_744 = V_138;
		if (!L_744)
		{
			goto IL_169e;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_745 = ___0_generationSettings;
		NullCheck(L_745);
		bool L_746 = L_745->___autoSize_19;
		if (!L_746)
		{
			goto IL_159e;
		}
	}
	{
		float L_747 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_748 = ___0_generationSettings;
		NullCheck(L_748);
		float L_749 = L_748->___fontSizeMin_20;
		G_B166_0 = ((((float)L_747) > ((float)L_749))? 1 : 0);
		goto IL_159f;
	}

IL_159e:
	{
		G_B166_0 = 0;
	}

IL_159f:
	{
		V_139 = (bool)G_B166_0;
		bool L_750 = V_139;
		if (!L_750)
		{
			goto IL_1670;
		}
	}
	{
		float L_751 = __this->___m_CharWidthAdjDelta_77;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_752 = ___0_generationSettings;
		NullCheck(L_752);
		float L_753 = L_752->___charWidthMaxAdj_44;
		V_140 = (bool)((((float)L_751) < ((float)((float)(L_753/(100.0f)))))? 1 : 0);
		bool L_754 = V_140;
		if (!L_754)
		{
			goto IL_15eb;
		}
	}
	{
		__this->___m_LoopCountA_70 = 0;
		float L_755 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_CharWidthAdjDelta_77 = ((float)il2cpp_codegen_add(L_755, (0.00999999978f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_756 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_757 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_756, L_757, NULL);
		goto IL_6c59;
	}

IL_15eb:
	{
		float L_758 = __this->___m_FontSize_15;
		__this->___m_MaxFontSize_79 = L_758;
		float L_759 = __this->___m_FontSize_15;
		float L_760 = __this->___m_FontSize_15;
		float L_761 = __this->___m_MinFontSize_80;
		float L_762;
		L_762 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_760, L_761))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_subtract(L_759, L_762));
		float L_763 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_764 = ___0_generationSettings;
		NullCheck(L_764);
		float L_765 = L_764->___fontSizeMin_20;
		float L_766;
		L_766 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_763, L_765, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_766, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_767 = __this->___m_LoopCountA_70;
		V_141 = (bool)((((int32_t)L_767) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_768 = V_141;
		if (!L_768)
		{
			goto IL_1662;
		}
	}
	{
		goto IL_6c59;
	}

IL_1662:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_769 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_770 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_769, L_770, NULL);
		goto IL_6c59;
	}

IL_1670:
	{
		bool L_771 = __this->___m_IsCharacterWrappingEnabled_81;
		V_142 = (bool)((((int32_t)L_771) == ((int32_t)0))? 1 : 0);
		bool L_772 = V_142;
		if (!L_772)
		{
			goto IL_169a;
		}
	}
	{
		bool L_773 = V_28;
		V_143 = (bool)((((int32_t)L_773) == ((int32_t)0))? 1 : 0);
		bool L_774 = V_143;
		if (!L_774)
		{
			goto IL_1690;
		}
	}
	{
		V_28 = (bool)1;
		goto IL_1697;
	}

IL_1690:
	{
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)1;
	}

IL_1697:
	{
		goto IL_169d;
	}

IL_169a:
	{
		V_29 = (bool)1;
	}

IL_169d:
	{
	}

IL_169e:
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_775 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_776 = ___1_textInfo;
		int32_t L_777;
		L_777 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_775, L_776, NULL);
		V_59 = L_777;
		int32_t L_778 = V_59;
		V_30 = L_778;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_779 = __this->___m_CharBuffer_4;
		int32_t L_780 = V_59;
		NullCheck(L_779);
		int32_t L_781 = L_780;
		int32_t L_782 = (L_779)->GetAt(static_cast<il2cpp_array_size_t>(L_781));
		V_144 = (bool)((((int32_t)L_782) == ((int32_t)((int32_t)173)))? 1 : 0);
		bool L_783 = V_144;
		if (!L_783)
		{
			goto IL_16e1;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_784 = __this->___m_CharBuffer_4;
		int32_t L_785 = V_59;
		NullCheck(L_784);
		(L_784)->SetAt(static_cast<il2cpp_array_size_t>(L_785), (int32_t)((int32_t)45));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_786 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_787 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_786, L_787, NULL);
		goto IL_6c59;
	}

IL_16e1:
	{
		int32_t L_788 = __this->___m_LineNumber_55;
		if ((((int32_t)L_788) <= ((int32_t)0)))
		{
			goto IL_1715;
		}
	}
	{
		float L_789 = __this->___m_MaxLineAscender_53;
		float L_790 = __this->___m_StartOfLineAscender_82;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_791;
		L_791 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(L_789, L_790, NULL);
		if (L_791)
		{
			goto IL_1715;
		}
	}
	{
		float L_792 = __this->___m_LineHeight_40;
		if ((!(((float)L_792) == ((float)(-32767.0f)))))
		{
			goto IL_1715;
		}
	}
	{
		bool L_793 = __this->___m_IsNewPage_66;
		G_B186_0 = ((((int32_t)L_793) == ((int32_t)0))? 1 : 0);
		goto IL_1716;
	}

IL_1715:
	{
		G_B186_0 = 0;
	}

IL_1716:
	{
		V_145 = (bool)G_B186_0;
		bool L_794 = V_145;
		if (!L_794)
		{
			goto IL_1773;
		}
	}
	{
		float L_795 = __this->___m_MaxLineAscender_53;
		float L_796 = __this->___m_StartOfLineAscender_82;
		V_146 = ((float)il2cpp_codegen_subtract(L_795, L_796));
		int32_t L_797 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_798 = __this->___m_CharacterCount_48;
		float L_799 = V_146;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_800 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_797, L_798, L_799, L_800, NULL);
		float L_801 = __this->___m_LineOffset_39;
		float L_802 = V_146;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_801, L_802));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_803 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		float L_804 = __this->___m_LineOffset_39;
		L_803->___lineOffset_26 = L_804;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_805 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		float L_806 = __this->___m_MaxLineAscender_53;
		L_805->___previousLineAscender_15 = L_806;
	}

IL_1773:
	{
		__this->___m_IsNewPage_66 = (bool)0;
		float L_807 = __this->___m_MaxLineAscender_53;
		float L_808 = __this->___m_LineOffset_39;
		V_136 = ((float)il2cpp_codegen_subtract(L_807, L_808));
		float L_809 = __this->___m_MaxLineDescender_54;
		float L_810 = __this->___m_LineOffset_39;
		V_137 = ((float)il2cpp_codegen_subtract(L_809, L_810));
		float L_811 = __this->___m_MaxDescender_65;
		float L_812 = V_137;
		G_B189_0 = __this;
		if ((((float)L_811) < ((float)L_812)))
		{
			G_B190_0 = __this;
			goto IL_17a7;
		}
	}
	{
		float L_813 = V_137;
		G_B191_0 = L_813;
		G_B191_1 = G_B189_0;
		goto IL_17ad;
	}

IL_17a7:
	{
		float L_814 = __this->___m_MaxDescender_65;
		G_B191_0 = L_814;
		G_B191_1 = G_B190_0;
	}

IL_17ad:
	{
		NullCheck(G_B191_1);
		G_B191_1->___m_MaxDescender_65 = G_B191_0;
		bool L_815 = V_26;
		V_147 = (bool)((((int32_t)L_815) == ((int32_t)0))? 1 : 0);
		bool L_816 = V_147;
		if (!L_816)
		{
			goto IL_17c5;
		}
	}
	{
		float L_817 = __this->___m_MaxDescender_65;
		V_25 = L_817;
	}

IL_17c5:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_818 = ___0_generationSettings;
		NullCheck(L_818);
		bool L_819 = L_818->___useMaxVisibleDescender_36;
		if (!L_819)
		{
			goto IL_17f1;
		}
	}
	{
		int32_t L_820 = __this->___m_CharacterCount_48;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_821 = ___0_generationSettings;
		NullCheck(L_821);
		int32_t L_822 = L_821->___maxVisibleCharacters_32;
		if ((((int32_t)L_820) >= ((int32_t)L_822)))
		{
			goto IL_17ee;
		}
	}
	{
		int32_t L_823 = __this->___m_LineNumber_55;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_824 = ___0_generationSettings;
		NullCheck(L_824);
		int32_t L_825 = L_824->___maxVisibleLines_34;
		G_B197_0 = ((((int32_t)((((int32_t)L_823) < ((int32_t)L_825))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_17ef;
	}

IL_17ee:
	{
		G_B197_0 = 1;
	}

IL_17ef:
	{
		G_B199_0 = G_B197_0;
		goto IL_17f2;
	}

IL_17f1:
	{
		G_B199_0 = 0;
	}

IL_17f2:
	{
		V_148 = (bool)G_B199_0;
		bool L_826 = V_148;
		if (!L_826)
		{
			goto IL_17fb;
		}
	}
	{
		V_26 = (bool)1;
	}

IL_17fb:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_827 = ___1_textInfo;
		NullCheck(L_827);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_828 = L_827->___lineInfo_13;
		int32_t L_829 = __this->___m_LineNumber_55;
		NullCheck(L_828);
		int32_t L_830 = __this->___m_FirstCharacterOfLine_49;
		((L_828)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_829)))->___firstCharacterIndex_6 = L_830;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_831 = ___1_textInfo;
		NullCheck(L_831);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_832 = L_831->___lineInfo_13;
		int32_t L_833 = __this->___m_LineNumber_55;
		NullCheck(L_832);
		int32_t L_834 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_835 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B202_0 = __this;
		G_B202_1 = ((L_832)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_833)));
		if ((((int32_t)L_834) > ((int32_t)L_835)))
		{
			G_B203_0 = __this;
			G_B203_1 = ((L_832)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_833)));
			goto IL_183f;
		}
	}
	{
		int32_t L_836 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B204_0 = L_836;
		G_B204_1 = G_B202_0;
		G_B204_2 = G_B202_1;
		goto IL_1845;
	}

IL_183f:
	{
		int32_t L_837 = __this->___m_FirstCharacterOfLine_49;
		G_B204_0 = L_837;
		G_B204_1 = G_B203_0;
		G_B204_2 = G_B203_1;
	}

IL_1845:
	{
		int32_t L_838 = G_B204_0;
		V_149 = L_838;
		NullCheck(G_B204_1);
		G_B204_1->___m_FirstVisibleCharacterOfLine_51 = L_838;
		int32_t L_839 = V_149;
		G_B204_2->___firstVisibleCharacterIndex_7 = L_839;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_840 = ___1_textInfo;
		NullCheck(L_840);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_841 = L_840->___lineInfo_13;
		int32_t L_842 = __this->___m_LineNumber_55;
		NullCheck(L_841);
		int32_t L_843 = __this->___m_CharacterCount_48;
		G_B205_0 = __this;
		G_B205_1 = ((L_841)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_842)));
		if ((((int32_t)((int32_t)il2cpp_codegen_subtract(L_843, 1))) > ((int32_t)0)))
		{
			G_B206_0 = __this;
			G_B206_1 = ((L_841)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_842)));
			goto IL_1874;
		}
	}
	{
		G_B207_0 = 0;
		G_B207_1 = G_B205_0;
		G_B207_2 = G_B205_1;
		goto IL_187c;
	}

IL_1874:
	{
		int32_t L_844 = __this->___m_CharacterCount_48;
		G_B207_0 = ((int32_t)il2cpp_codegen_subtract(L_844, 1));
		G_B207_1 = G_B206_0;
		G_B207_2 = G_B206_1;
	}

IL_187c:
	{
		int32_t L_845 = G_B207_0;
		V_149 = L_845;
		NullCheck(G_B207_1);
		G_B207_1->___m_LastCharacterOfLine_50 = L_845;
		int32_t L_846 = V_149;
		G_B207_2->___lastCharacterIndex_8 = L_846;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_847 = ___1_textInfo;
		NullCheck(L_847);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_848 = L_847->___lineInfo_13;
		int32_t L_849 = __this->___m_LineNumber_55;
		NullCheck(L_848);
		int32_t L_850 = __this->___m_LastVisibleCharacterOfLine_52;
		int32_t L_851 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B208_0 = __this;
		G_B208_1 = ((L_848)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_849)));
		if ((((int32_t)L_850) < ((int32_t)L_851)))
		{
			G_B209_0 = __this;
			G_B209_1 = ((L_848)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_849)));
			goto IL_18b3;
		}
	}
	{
		int32_t L_852 = __this->___m_LastVisibleCharacterOfLine_52;
		G_B210_0 = L_852;
		G_B210_1 = G_B208_0;
		G_B210_2 = G_B208_1;
		goto IL_18b9;
	}

IL_18b3:
	{
		int32_t L_853 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B210_0 = L_853;
		G_B210_1 = G_B209_0;
		G_B210_2 = G_B209_1;
	}

IL_18b9:
	{
		int32_t L_854 = G_B210_0;
		V_149 = L_854;
		NullCheck(G_B210_1);
		G_B210_1->___m_LastVisibleCharacterOfLine_52 = L_854;
		int32_t L_855 = V_149;
		G_B210_2->___lastVisibleCharacterIndex_9 = L_855;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_856 = ___1_textInfo;
		NullCheck(L_856);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_857 = L_856->___lineInfo_13;
		int32_t L_858 = __this->___m_LineNumber_55;
		NullCheck(L_857);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_859 = ___1_textInfo;
		NullCheck(L_859);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_860 = L_859->___lineInfo_13;
		int32_t L_861 = __this->___m_LineNumber_55;
		NullCheck(L_860);
		int32_t L_862 = ((L_860)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_861)))->___lastCharacterIndex_8;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_863 = ___1_textInfo;
		NullCheck(L_863);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_864 = L_863->___lineInfo_13;
		int32_t L_865 = __this->___m_LineNumber_55;
		NullCheck(L_864);
		int32_t L_866 = ((L_864)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_865)))->___firstCharacterIndex_6;
		((L_857)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_858)))->___characterCount_1 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_862, L_866)), 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_867 = ___1_textInfo;
		NullCheck(L_867);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_868 = L_867->___lineInfo_13;
		int32_t L_869 = __this->___m_LineNumber_55;
		NullCheck(L_868);
		int32_t L_870 = __this->___m_LineVisibleCharacterCount_56;
		((L_868)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_869)))->___visibleCharacterCount_2 = L_870;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_871 = ___1_textInfo;
		NullCheck(L_871);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_872 = L_871->___lineInfo_13;
		int32_t L_873 = __this->___m_LineNumber_55;
		NullCheck(L_872);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_874 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_872)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_873)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_875 = ___1_textInfo;
		NullCheck(L_875);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_876 = L_875->___textElementInfo_10;
		int32_t L_877 = __this->___m_FirstVisibleCharacterOfLine_51;
		NullCheck(L_876);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_878 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_876)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_877)))->___bottomLeft_19);
		float L_879 = L_878->___x_2;
		float L_880 = V_137;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_881;
		memset((&L_881), 0, sizeof(L_881));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_881), L_879, L_880, /*hidden argument*/NULL);
		L_874->___min_0 = L_881;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_882 = ___1_textInfo;
		NullCheck(L_882);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_883 = L_882->___lineInfo_13;
		int32_t L_884 = __this->___m_LineNumber_55;
		NullCheck(L_883);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_885 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_883)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_884)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_886 = ___1_textInfo;
		NullCheck(L_886);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_887 = L_886->___textElementInfo_10;
		int32_t L_888 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_887);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_889 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_887)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_888)))->___topRight_20);
		float L_890 = L_889->___x_2;
		float L_891 = V_136;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_892;
		memset((&L_892), 0, sizeof(L_892));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_892), L_890, L_891, /*hidden argument*/NULL);
		L_885->___max_1 = L_892;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_893 = ___1_textInfo;
		NullCheck(L_893);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_894 = L_893->___lineInfo_13;
		int32_t L_895 = __this->___m_LineNumber_55;
		NullCheck(L_894);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_896 = ___1_textInfo;
		NullCheck(L_896);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_897 = L_896->___lineInfo_13;
		int32_t L_898 = __this->___m_LineNumber_55;
		NullCheck(L_897);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_899 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_897)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_898)))->___lineExtents_20);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_900 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_899->___max_1);
		float L_901 = L_900->___x_0;
		((L_894)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_895)))->___length_10 = L_901;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_902 = ___1_textInfo;
		NullCheck(L_902);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_903 = L_902->___lineInfo_13;
		int32_t L_904 = __this->___m_LineNumber_55;
		NullCheck(L_903);
		float L_905 = V_22;
		((L_903)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_904)))->___width_16 = L_905;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_906 = ___1_textInfo;
		NullCheck(L_906);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_907 = L_906->___lineInfo_13;
		int32_t L_908 = __this->___m_LineNumber_55;
		NullCheck(L_907);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_909 = ___1_textInfo;
		NullCheck(L_909);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_910 = L_909->___textElementInfo_10;
		int32_t L_911 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_910);
		float L_912 = ((L_910)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_911)))->___xAdvance_26;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_913 = ___0_generationSettings;
		NullCheck(L_913);
		float L_914 = L_913->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_915 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_915);
		float L_916;
		L_916 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_915, NULL);
		float L_917 = V_2;
		float L_918 = __this->___m_CSpacing_41;
		((L_907)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_908)))->___maxAdvance_15 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_912, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_914, L_916)), L_917)))), L_918));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_919 = ___1_textInfo;
		NullCheck(L_919);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_920 = L_919->___lineInfo_13;
		int32_t L_921 = __this->___m_LineNumber_55;
		NullCheck(L_920);
		float L_922 = __this->___m_LineOffset_39;
		((L_920)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_921)))->___baseline_13 = ((float)il2cpp_codegen_subtract((0.0f), L_922));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_923 = ___1_textInfo;
		NullCheck(L_923);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_924 = L_923->___lineInfo_13;
		int32_t L_925 = __this->___m_LineNumber_55;
		NullCheck(L_924);
		float L_926 = V_136;
		((L_924)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_925)))->___ascender_12 = L_926;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_927 = ___1_textInfo;
		NullCheck(L_927);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_928 = L_927->___lineInfo_13;
		int32_t L_929 = __this->___m_LineNumber_55;
		NullCheck(L_928);
		float L_930 = V_137;
		((L_928)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_929)))->___descender_14 = L_930;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_931 = ___1_textInfo;
		NullCheck(L_931);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_932 = L_931->___lineInfo_13;
		int32_t L_933 = __this->___m_LineNumber_55;
		NullCheck(L_932);
		float L_934 = V_136;
		float L_935 = V_137;
		float L_936 = V_14;
		float L_937 = V_1;
		((L_932)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_933)))->___lineHeight_11 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_934, L_935)), ((float)il2cpp_codegen_multiply(L_936, L_937))));
		int32_t L_938 = __this->___m_CharacterCount_48;
		__this->___m_FirstCharacterOfLine_49 = L_938;
		__this->___m_LineVisibleCharacterCount_56 = 0;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_939 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState_69);
		int32_t L_940 = V_59;
		int32_t L_941 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_942 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_939, L_940, ((int32_t)il2cpp_codegen_subtract(L_941, 1)), L_942, NULL);
		int32_t L_943 = __this->___m_LineNumber_55;
		__this->___m_LineNumber_55 = ((int32_t)il2cpp_codegen_add(L_943, 1));
		V_15 = (bool)1;
		V_27 = (bool)1;
		int32_t L_944 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_945 = ___1_textInfo;
		NullCheck(L_945);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_946 = L_945->___lineInfo_13;
		NullCheck(L_946);
		V_150 = (bool)((((int32_t)((((int32_t)L_944) < ((int32_t)((int32_t)(((RuntimeArray*)L_946)->max_length))))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_947 = V_150;
		if (!L_947)
		{
			goto IL_1b10;
		}
	}
	{
		int32_t L_948 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_949 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85(L_948, L_949, NULL);
	}

IL_1b10:
	{
		float L_950 = __this->___m_LineHeight_40;
		V_151 = (bool)((((float)L_950) == ((float)(-32767.0f)))? 1 : 0);
		bool L_951 = V_151;
		if (!L_951)
		{
			goto IL_1b91;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_952 = ___1_textInfo;
		NullCheck(L_952);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_953 = L_952->___textElementInfo_10;
		int32_t L_954 = __this->___m_CharacterCount_48;
		NullCheck(L_953);
		float L_955 = ((L_953)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_954)))->___ascender_23;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_956 = ___1_textInfo;
		NullCheck(L_956);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_957 = L_956->___textElementInfo_10;
		int32_t L_958 = __this->___m_CharacterCount_48;
		NullCheck(L_957);
		float L_959 = ((L_957)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_958)))->___baseLine_24;
		V_152 = ((float)il2cpp_codegen_subtract(L_955, L_959));
		float L_960 = __this->___m_MaxLineDescender_54;
		float L_961 = V_152;
		float L_962 = V_14;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_963 = ___0_generationSettings;
		NullCheck(L_963);
		float L_964 = L_963->___lineSpacing_29;
		float L_965 = __this->___m_LineSpacingDelta_83;
		float L_966 = V_1;
		V_77 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_960)), L_961)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_962, L_964)), L_965)), L_966))));
		float L_967 = __this->___m_LineOffset_39;
		float L_968 = V_77;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_967, L_968));
		float L_969 = V_152;
		__this->___m_StartOfLineAscender_82 = L_969;
		goto IL_1bad;
	}

IL_1b91:
	{
		float L_970 = __this->___m_LineOffset_39;
		float L_971 = __this->___m_LineHeight_40;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_972 = ___0_generationSettings;
		NullCheck(L_972);
		float L_973 = L_972->___lineSpacing_29;
		float L_974 = V_1;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_970, ((float)il2cpp_codegen_add(L_971, ((float)il2cpp_codegen_multiply(L_973, L_974))))));
	}

IL_1bad:
	{
		__this->___m_MaxLineAscender_53 = (-32767.0f);
		__this->___m_MaxLineDescender_54 = (32767.0f);
		float L_975 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add((0.0f), L_975));
		goto IL_3289;
	}

IL_1bda:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_976 = ___0_generationSettings;
		NullCheck(L_976);
		bool L_977 = L_976->___autoSize_19;
		if (!L_977)
		{
			goto IL_1bf2;
		}
	}
	{
		float L_978 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_979 = ___0_generationSettings;
		NullCheck(L_979);
		float L_980 = L_979->___fontSizeMin_20;
		G_B219_0 = ((((float)L_978) > ((float)L_980))? 1 : 0);
		goto IL_1bf3;
	}

IL_1bf2:
	{
		G_B219_0 = 0;
	}

IL_1bf3:
	{
		V_153 = (bool)G_B219_0;
		bool L_981 = V_153;
		if (!L_981)
		{
			goto IL_1cc4;
		}
	}
	{
		float L_982 = __this->___m_CharWidthAdjDelta_77;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_983 = ___0_generationSettings;
		NullCheck(L_983);
		float L_984 = L_983->___charWidthMaxAdj_44;
		V_154 = (bool)((((float)L_982) < ((float)((float)(L_984/(100.0f)))))? 1 : 0);
		bool L_985 = V_154;
		if (!L_985)
		{
			goto IL_1c3f;
		}
	}
	{
		__this->___m_LoopCountA_70 = 0;
		float L_986 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_CharWidthAdjDelta_77 = ((float)il2cpp_codegen_add(L_986, (0.00999999978f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_987 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_988 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_987, L_988, NULL);
		goto IL_6c59;
	}

IL_1c3f:
	{
		float L_989 = __this->___m_FontSize_15;
		__this->___m_MaxFontSize_79 = L_989;
		float L_990 = __this->___m_FontSize_15;
		float L_991 = __this->___m_FontSize_15;
		float L_992 = __this->___m_MinFontSize_80;
		float L_993;
		L_993 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_991, L_992))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_subtract(L_990, L_993));
		float L_994 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_995 = ___0_generationSettings;
		NullCheck(L_995);
		float L_996 = L_995->___fontSizeMin_20;
		float L_997;
		L_997 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_994, L_996, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_997, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_998 = __this->___m_LoopCountA_70;
		V_155 = (bool)((((int32_t)L_998) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_999 = V_155;
		if (!L_999)
		{
			goto IL_1cb6;
		}
	}
	{
		goto IL_6c59;
	}

IL_1cb6:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1000 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1001 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1000, L_1001, NULL);
		goto IL_6c59;
	}

IL_1cc4:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1002 = ___0_generationSettings;
		NullCheck(L_1002);
		int32_t L_1003 = L_1002->___overflowMode_11;
		V_157 = L_1003;
		int32_t L_1004 = V_157;
		V_156 = L_1004;
		int32_t L_1005 = V_156;
		switch (L_1005)
		{
			case 0:
			{
				goto IL_1cf8;
			}
			case 1:
			{
				goto IL_1d10;
			}
			case 2:
			{
				goto IL_1e4b;
			}
			case 3:
			{
				goto IL_1e7b;
			}
			case 4:
			{
				goto IL_1e63;
			}
			case 5:
			{
				goto IL_1ea9;
			}
			case 6:
			{
				goto IL_1ea7;
			}
		}
	}
	{
		goto IL_1ea9;
	}

IL_1cf8:
	{
		bool L_1006 = __this->___m_IsMaskingEnabled_84;
		V_158 = L_1006;
		bool L_1007 = V_158;
		if (!L_1007)
		{
			goto IL_1d0b;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_1d0b:
	{
		goto IL_1ea9;
	}

IL_1d10:
	{
		bool L_1008 = __this->___m_IsMaskingEnabled_84;
		V_159 = L_1008;
		bool L_1009 = V_159;
		if (!L_1009)
		{
			goto IL_1d23;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_1d23:
	{
		int32_t L_1010 = __this->___m_CharacterCount_48;
		V_160 = (bool)((((int32_t)L_1010) < ((int32_t)1))? 1 : 0);
		bool L_1011 = V_160;
		if (!L_1011)
		{
			goto IL_1d4f;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1012 = ___1_textInfo;
		NullCheck(L_1012);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1013 = L_1012->___textElementInfo_10;
		int32_t L_1014 = __this->___m_CharacterCount_48;
		NullCheck(L_1013);
		((L_1013)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1014)))->___isVisible_34 = (bool)0;
		goto IL_1ea9;
	}

IL_1d4f:
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1015 = __this->___m_CharBuffer_4;
		int32_t L_1016 = V_59;
		NullCheck(L_1015);
		(L_1015)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1016, 1))), (int32_t)((int32_t)8230));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1017 = __this->___m_CharBuffer_4;
		int32_t L_1018 = V_59;
		NullCheck(L_1017);
		(L_1017)->SetAt(static_cast<il2cpp_array_size_t>(L_1018), (int32_t)0);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1019 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1020 = L_1019->___character_0;
		V_161 = (bool)((!(((RuntimeObject*)(Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC*)L_1020) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_1021 = V_161;
		if (!L_1021)
		{
			goto IL_1e11;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1022 = ___1_textInfo;
		NullCheck(L_1022);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1023 = L_1022->___textElementInfo_10;
		int32_t L_1024 = V_18;
		NullCheck(L_1023);
		((L_1023)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1024)))->___character_0 = ((int32_t)8230);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1025 = ___1_textInfo;
		NullCheck(L_1025);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1026 = L_1025->___textElementInfo_10;
		int32_t L_1027 = V_18;
		NullCheck(L_1026);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1028 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1029 = L_1028->___character_0;
		((L_1026)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1027)))->___textElement_3 = L_1029;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1026)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1027)))->___textElement_3), (void*)L_1029);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1030 = ___1_textInfo;
		NullCheck(L_1030);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1031 = L_1030->___textElementInfo_10;
		int32_t L_1032 = V_18;
		NullCheck(L_1031);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1033 = __this->___m_MaterialReferences_85;
		NullCheck(L_1033);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1034 = ((L_1033)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___fontAsset_1;
		((L_1031)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1032)))->___fontAsset_4 = L_1034;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1031)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1032)))->___fontAsset_4), (void*)L_1034);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1035 = ___1_textInfo;
		NullCheck(L_1035);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1036 = L_1035->___textElementInfo_10;
		int32_t L_1037 = V_18;
		NullCheck(L_1036);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1038 = __this->___m_MaterialReferences_85;
		NullCheck(L_1038);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_1039 = ((L_1038)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___material_3;
		((L_1036)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1037)))->___material_7 = L_1039;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1036)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1037)))->___material_7), (void*)L_1039);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1040 = ___1_textInfo;
		NullCheck(L_1040);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1041 = L_1040->___textElementInfo_10;
		int32_t L_1042 = V_18;
		NullCheck(L_1041);
		((L_1041)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1042)))->___materialReferenceIndex_8 = 0;
		goto IL_1e33;
	}

IL_1e11:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1043 = ___0_generationSettings;
		NullCheck(L_1043);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1044 = L_1043->___fontAsset_4;
		NullCheck(L_1044);
		String_t* L_1045;
		L_1045 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_1044, NULL);
		String_t* L_1046;
		L_1046 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(_stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D, L_1045, _stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9(L_1046, NULL);
	}

IL_1e33:
	{
		int32_t L_1047 = V_18;
		__this->___m_TotalCharacterCount_13 = ((int32_t)il2cpp_codegen_add(L_1047, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1048 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1049 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1048, L_1049, NULL);
		goto IL_6c59;
	}

IL_1e4b:
	{
		bool L_1050 = __this->___m_IsMaskingEnabled_84;
		V_162 = (bool)((((int32_t)L_1050) == ((int32_t)0))? 1 : 0);
		bool L_1051 = V_162;
		if (!L_1051)
		{
			goto IL_1e61;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_1e61:
	{
		goto IL_1ea9;
	}

IL_1e63:
	{
		bool L_1052 = __this->___m_IsMaskingEnabled_84;
		V_163 = (bool)((((int32_t)L_1052) == ((int32_t)0))? 1 : 0);
		bool L_1053 = V_163;
		if (!L_1053)
		{
			goto IL_1e79;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_1e79:
	{
		goto IL_1ea9;
	}

IL_1e7b:
	{
		bool L_1054 = __this->___m_IsMaskingEnabled_84;
		V_164 = L_1054;
		bool L_1055 = V_164;
		if (!L_1055)
		{
			goto IL_1e8e;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_1e8e:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1056 = ___1_textInfo;
		NullCheck(L_1056);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1057 = L_1056->___textElementInfo_10;
		int32_t L_1058 = __this->___m_CharacterCount_48;
		NullCheck(L_1057);
		((L_1057)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1058)))->___isVisible_34 = (bool)0;
		goto IL_1ea9;
	}

IL_1ea7:
	{
		goto IL_1ea9;
	}

IL_1ea9:
	{
	}

IL_1eaa:
	{
		int32_t L_1059 = V_60;
		if ((((int32_t)L_1059) == ((int32_t)((int32_t)9))))
		{
			goto IL_1ec4;
		}
	}
	{
		int32_t L_1060 = V_60;
		if ((((int32_t)L_1060) == ((int32_t)((int32_t)160))))
		{
			goto IL_1ec4;
		}
	}
	{
		int32_t L_1061 = V_60;
		G_B253_0 = ((((int32_t)L_1061) == ((int32_t)((int32_t)8199)))? 1 : 0);
		goto IL_1ec5;
	}

IL_1ec4:
	{
		G_B253_0 = 1;
	}

IL_1ec5:
	{
		V_165 = (bool)G_B253_0;
		bool L_1062 = V_165;
		if (!L_1062)
		{
			goto IL_1f20;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1063 = ___1_textInfo;
		NullCheck(L_1063);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1064 = L_1063->___textElementInfo_10;
		int32_t L_1065 = __this->___m_CharacterCount_48;
		NullCheck(L_1064);
		((L_1064)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1065)))->___isVisible_34 = (bool)0;
		int32_t L_1066 = __this->___m_CharacterCount_48;
		__this->___m_LastVisibleCharacterOfLine_52 = L_1066;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1067 = ___1_textInfo;
		NullCheck(L_1067);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1068 = L_1067->___lineInfo_13;
		int32_t L_1069 = __this->___m_LineNumber_55;
		NullCheck(L_1068);
		int32_t* L_1070 = (int32_t*)(&((L_1068)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1069)))->___spaceCount_3);
		int32_t* L_1071 = L_1070;
		int32_t L_1072 = *((int32_t*)L_1071);
		*((int32_t*)L_1071) = (int32_t)((int32_t)il2cpp_codegen_add(L_1072, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1073 = ___1_textInfo;
		V_166 = L_1073;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1074 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1075 = V_166;
		NullCheck(L_1075);
		int32_t L_1076 = L_1075->___spaceCount_4;
		NullCheck(L_1074);
		L_1074->___spaceCount_4 = ((int32_t)il2cpp_codegen_add(L_1076, 1));
		goto IL_1f7d;
	}

IL_1f20:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1077 = ___0_generationSettings;
		NullCheck(L_1077);
		bool L_1078 = L_1077->___overrideRichTextColors_17;
		V_168 = L_1078;
		bool L_1079 = V_168;
		if (!L_1079)
		{
			goto IL_1f37;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1080 = __this->___m_FontColor32_27;
		V_167 = L_1080;
		goto IL_1f3f;
	}

IL_1f37:
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1081 = __this->___m_HtmlColor_28;
		V_167 = L_1081;
	}

IL_1f3f:
	{
		uint8_t L_1082 = __this->___m_TextElementType_71;
		V_169 = (bool)((((int32_t)L_1082) == ((int32_t)1))? 1 : 0);
		bool L_1083 = V_169;
		if (!L_1083)
		{
			goto IL_1f60;
		}
	}
	{
		float L_1084 = V_3;
		float L_1085 = V_68;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1086 = V_167;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1087 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1088 = ___1_textInfo;
		TextGenerator_SaveGlyphVertexInfo_m0CD6E1D45488FFC6675294AC64F40AC23C986A09(__this, L_1084, L_1085, L_1086, L_1087, L_1088, NULL);
		goto IL_1f7c;
	}

IL_1f60:
	{
		uint8_t L_1089 = __this->___m_TextElementType_71;
		V_170 = (bool)((((int32_t)L_1089) == ((int32_t)2))? 1 : 0);
		bool L_1090 = V_170;
		if (!L_1090)
		{
			goto IL_1f7c;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_1091 = V_167;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1092 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1093 = ___1_textInfo;
		TextGenerator_SaveSpriteVertexInfo_m4B47901F01927E7CC4E486A1C4354AFBF4D138A5(__this, L_1091, L_1092, L_1093, NULL);
	}

IL_1f7c:
	{
	}

IL_1f7d:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1094 = ___1_textInfo;
		NullCheck(L_1094);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1095 = L_1094->___textElementInfo_10;
		int32_t L_1096 = __this->___m_CharacterCount_48;
		NullCheck(L_1095);
		bool L_1097 = ((L_1095)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1096)))->___isVisible_34;
		if (!L_1097)
		{
			goto IL_1fa3;
		}
	}
	{
		int32_t L_1098 = V_60;
		G_B266_0 = ((((int32_t)((((int32_t)L_1098) == ((int32_t)((int32_t)173)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_1fa4;
	}

IL_1fa3:
	{
		G_B266_0 = 0;
	}

IL_1fa4:
	{
		V_171 = (bool)G_B266_0;
		bool L_1099 = V_171;
		if (!L_1099)
		{
			goto IL_1fdf;
		}
	}
	{
		bool L_1100 = V_15;
		V_172 = L_1100;
		bool L_1101 = V_172;
		if (!L_1101)
		{
			goto IL_1fc4;
		}
	}
	{
		V_15 = (bool)0;
		int32_t L_1102 = __this->___m_CharacterCount_48;
		__this->___m_FirstVisibleCharacterOfLine_51 = L_1102;
	}

IL_1fc4:
	{
		int32_t L_1103 = __this->___m_LineVisibleCharacterCount_56;
		__this->___m_LineVisibleCharacterCount_56 = ((int32_t)il2cpp_codegen_add(L_1103, 1));
		int32_t L_1104 = __this->___m_CharacterCount_48;
		__this->___m_LastVisibleCharacterOfLine_52 = L_1104;
	}

IL_1fdf:
	{
		goto IL_2074;
	}

IL_1fe5:
	{
		int32_t L_1105 = V_60;
		if ((((int32_t)L_1105) == ((int32_t)((int32_t)10))))
		{
			goto IL_1ff6;
		}
	}
	{
		int32_t L_1106 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1107;
		L_1107 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(((int32_t)(uint16_t)L_1106), NULL);
		if (!L_1107)
		{
			goto IL_2016;
		}
	}

IL_1ff6:
	{
		int32_t L_1108 = V_60;
		if ((((int32_t)L_1108) == ((int32_t)((int32_t)173))))
		{
			goto IL_2016;
		}
	}
	{
		int32_t L_1109 = V_60;
		if ((((int32_t)L_1109) == ((int32_t)((int32_t)8203))))
		{
			goto IL_2016;
		}
	}
	{
		int32_t L_1110 = V_60;
		G_B277_0 = ((((int32_t)((((int32_t)L_1110) == ((int32_t)((int32_t)8288)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2017;
	}

IL_2016:
	{
		G_B277_0 = 0;
	}

IL_2017:
	{
		V_173 = (bool)G_B277_0;
		bool L_1111 = V_173;
		if (!L_1111)
		{
			goto IL_2073;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1112 = ___1_textInfo;
		NullCheck(L_1112);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1113 = L_1112->___lineInfo_13;
		int32_t L_1114 = __this->___m_LineNumber_55;
		NullCheck(L_1113);
		int32_t* L_1115 = (int32_t*)(&((L_1113)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1114)))->___spaceCount_3);
		int32_t* L_1116 = L_1115;
		int32_t L_1117 = *((int32_t*)L_1116);
		*((int32_t*)L_1116) = (int32_t)((int32_t)il2cpp_codegen_add(L_1117, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1118 = ___1_textInfo;
		V_166 = L_1118;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1119 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1120 = V_166;
		NullCheck(L_1120);
		int32_t L_1121 = L_1120->___spaceCount_4;
		NullCheck(L_1119);
		L_1119->___spaceCount_4 = ((int32_t)il2cpp_codegen_add(L_1121, 1));
		int32_t L_1122 = V_60;
		V_174 = (bool)((((int32_t)L_1122) == ((int32_t)((int32_t)160)))? 1 : 0);
		bool L_1123 = V_174;
		if (!L_1123)
		{
			goto IL_2072;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1124 = ___1_textInfo;
		NullCheck(L_1124);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1125 = L_1124->___lineInfo_13;
		int32_t L_1126 = __this->___m_LineNumber_55;
		NullCheck(L_1125);
		((L_1125)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1126)))->___controlCharacterCount_0 = 1;
	}

IL_2072:
	{
	}

IL_2073:
	{
	}

IL_2074:
	{
		int32_t L_1127 = __this->___m_LineNumber_55;
		if ((((int32_t)L_1127) <= ((int32_t)0)))
		{
			goto IL_20a8;
		}
	}
	{
		float L_1128 = __this->___m_MaxLineAscender_53;
		float L_1129 = __this->___m_StartOfLineAscender_82;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_1130;
		L_1130 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(L_1128, L_1129, NULL);
		if (L_1130)
		{
			goto IL_20a8;
		}
	}
	{
		float L_1131 = __this->___m_LineHeight_40;
		if ((!(((float)L_1131) == ((float)(-32767.0f)))))
		{
			goto IL_20a8;
		}
	}
	{
		bool L_1132 = __this->___m_IsNewPage_66;
		G_B287_0 = ((((int32_t)L_1132) == ((int32_t)0))? 1 : 0);
		goto IL_20a9;
	}

IL_20a8:
	{
		G_B287_0 = 0;
	}

IL_20a9:
	{
		V_175 = (bool)G_B287_0;
		bool L_1133 = V_175;
		if (!L_1133)
		{
			goto IL_211c;
		}
	}
	{
		float L_1134 = __this->___m_MaxLineAscender_53;
		float L_1135 = __this->___m_StartOfLineAscender_82;
		V_176 = ((float)il2cpp_codegen_subtract(L_1134, L_1135));
		int32_t L_1136 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_1137 = __this->___m_CharacterCount_48;
		float L_1138 = V_176;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1139 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_1136, L_1137, L_1138, L_1139, NULL);
		float L_1140 = V_76;
		float L_1141 = V_176;
		V_76 = ((float)il2cpp_codegen_subtract(L_1140, L_1141));
		float L_1142 = __this->___m_LineOffset_39;
		float L_1143 = V_176;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1142, L_1143));
		float L_1144 = __this->___m_StartOfLineAscender_82;
		float L_1145 = V_176;
		__this->___m_StartOfLineAscender_82 = ((float)il2cpp_codegen_add(L_1144, L_1145));
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1146 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		float L_1147 = __this->___m_LineOffset_39;
		L_1146->___lineOffset_26 = L_1147;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1148 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		float L_1149 = __this->___m_StartOfLineAscender_82;
		L_1148->___previousLineAscender_15 = L_1149;
	}

IL_211c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1150 = ___1_textInfo;
		NullCheck(L_1150);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1151 = L_1150->___textElementInfo_10;
		int32_t L_1152 = __this->___m_CharacterCount_48;
		NullCheck(L_1151);
		int32_t L_1153 = __this->___m_LineNumber_55;
		((L_1151)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1152)))->___lineNumber_11 = L_1153;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1154 = ___1_textInfo;
		NullCheck(L_1154);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1155 = L_1154->___textElementInfo_10;
		int32_t L_1156 = __this->___m_CharacterCount_48;
		NullCheck(L_1155);
		int32_t L_1157 = __this->___m_PageNumber_58;
		((L_1155)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1156)))->___pageNumber_12 = L_1157;
		int32_t L_1158 = V_60;
		if ((((int32_t)L_1158) == ((int32_t)((int32_t)10))))
		{
			goto IL_2169;
		}
	}
	{
		int32_t L_1159 = V_60;
		if ((((int32_t)L_1159) == ((int32_t)((int32_t)13))))
		{
			goto IL_2169;
		}
	}
	{
		int32_t L_1160 = V_60;
		if ((!(((uint32_t)L_1160) == ((uint32_t)((int32_t)8230)))))
		{
			goto IL_2184;
		}
	}

IL_2169:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1161 = ___1_textInfo;
		NullCheck(L_1161);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1162 = L_1161->___lineInfo_13;
		int32_t L_1163 = __this->___m_LineNumber_55;
		NullCheck(L_1162);
		int32_t L_1164 = ((L_1162)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1163)))->___characterCount_1;
		G_B294_0 = ((((int32_t)L_1164) == ((int32_t)1))? 1 : 0);
		goto IL_2185;
	}

IL_2184:
	{
		G_B294_0 = 1;
	}

IL_2185:
	{
		V_177 = (bool)G_B294_0;
		bool L_1165 = V_177;
		if (!L_1165)
		{
			goto IL_21a7;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1166 = ___1_textInfo;
		NullCheck(L_1166);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1167 = L_1166->___lineInfo_13;
		int32_t L_1168 = __this->___m_LineNumber_55;
		NullCheck(L_1167);
		int32_t L_1169 = __this->___m_LineJustification_23;
		((L_1167)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1168)))->___alignment_19 = L_1169;
	}

IL_21a7:
	{
		float L_1170 = __this->___m_MaxAscender_64;
		float L_1171 = V_76;
		float L_1172 = V_21;
		V_178 = (bool)((((float)((float)il2cpp_codegen_subtract(L_1170, L_1171))) > ((float)((float)il2cpp_codegen_add(L_1172, (9.99999975E-05f)))))? 1 : 0);
		bool L_1173 = V_178;
		if (!L_1173)
		{
			goto IL_2609;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1174 = ___0_generationSettings;
		NullCheck(L_1174);
		bool L_1175 = L_1174->___autoSize_19;
		if (!L_1175)
		{
			goto IL_21e5;
		}
	}
	{
		float L_1176 = __this->___m_LineSpacingDelta_83;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1177 = ___0_generationSettings;
		NullCheck(L_1177);
		float L_1178 = L_1177->___lineSpacingMax_31;
		if ((!(((float)L_1176) > ((float)L_1178))))
		{
			goto IL_21e5;
		}
	}
	{
		int32_t L_1179 = __this->___m_LineNumber_55;
		G_B301_0 = ((((int32_t)L_1179) > ((int32_t)0))? 1 : 0);
		goto IL_21e6;
	}

IL_21e5:
	{
		G_B301_0 = 0;
	}

IL_21e6:
	{
		V_179 = (bool)G_B301_0;
		bool L_1180 = V_179;
		if (!L_1180)
		{
			goto IL_2214;
		}
	}
	{
		__this->___m_LoopCountA_70 = 0;
		float L_1181 = __this->___m_LineSpacingDelta_83;
		__this->___m_LineSpacingDelta_83 = ((float)il2cpp_codegen_subtract(L_1181, (1.0f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1182 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1183 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1182, L_1183, NULL);
		goto IL_6c59;
	}

IL_2214:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1184 = ___0_generationSettings;
		NullCheck(L_1184);
		bool L_1185 = L_1184->___autoSize_19;
		if (!L_1185)
		{
			goto IL_222c;
		}
	}
	{
		float L_1186 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1187 = ___0_generationSettings;
		NullCheck(L_1187);
		float L_1188 = L_1187->___fontSizeMin_20;
		G_B306_0 = ((((float)L_1186) > ((float)L_1188))? 1 : 0);
		goto IL_222d;
	}

IL_222c:
	{
		G_B306_0 = 0;
	}

IL_222d:
	{
		V_180 = (bool)G_B306_0;
		bool L_1189 = V_180;
		if (!L_1189)
		{
			goto IL_22bc;
		}
	}
	{
		float L_1190 = __this->___m_FontSize_15;
		__this->___m_MaxFontSize_79 = L_1190;
		float L_1191 = __this->___m_FontSize_15;
		float L_1192 = __this->___m_FontSize_15;
		float L_1193 = __this->___m_MinFontSize_80;
		float L_1194;
		L_1194 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1192, L_1193))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_subtract(L_1191, L_1194));
		float L_1195 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1196 = ___0_generationSettings;
		NullCheck(L_1196);
		float L_1197 = L_1196->___fontSizeMin_20;
		float L_1198;
		L_1198 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1195, L_1197, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1198, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_1199 = __this->___m_LoopCountA_70;
		V_181 = (bool)((((int32_t)L_1199) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_1200 = V_181;
		if (!L_1200)
		{
			goto IL_22ae;
		}
	}
	{
		goto IL_6c59;
	}

IL_22ae:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1201 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1202 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1201, L_1202, NULL);
		goto IL_6c59;
	}

IL_22bc:
	{
		int32_t L_1203 = __this->___m_FirstOverflowCharacterIndex_57;
		V_182 = (bool)((((int32_t)L_1203) == ((int32_t)(-1)))? 1 : 0);
		bool L_1204 = V_182;
		if (!L_1204)
		{
			goto IL_22d7;
		}
	}
	{
		int32_t L_1205 = __this->___m_CharacterCount_48;
		__this->___m_FirstOverflowCharacterIndex_57 = L_1205;
	}

IL_22d7:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1206 = ___0_generationSettings;
		NullCheck(L_1206);
		int32_t L_1207 = L_1206->___overflowMode_11;
		V_184 = L_1207;
		int32_t L_1208 = V_184;
		V_183 = L_1208;
		int32_t L_1209 = V_183;
		switch (L_1209)
		{
			case 0:
			{
				goto IL_230b;
			}
			case 1:
			{
				goto IL_2323;
			}
			case 2:
			{
				goto IL_246b;
			}
			case 3:
			{
				goto IL_24a1;
			}
			case 4:
			{
				goto IL_2486;
			}
			case 5:
			{
				goto IL_2506;
			}
			case 6:
			{
				goto IL_25c6;
			}
		}
	}
	{
		goto IL_2608;
	}

IL_230b:
	{
		bool L_1210 = __this->___m_IsMaskingEnabled_84;
		V_185 = L_1210;
		bool L_1211 = V_185;
		if (!L_1211)
		{
			goto IL_231e;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_231e:
	{
		goto IL_2608;
	}

IL_2323:
	{
		bool L_1212 = __this->___m_IsMaskingEnabled_84;
		V_186 = L_1212;
		bool L_1213 = V_186;
		if (!L_1213)
		{
			goto IL_2336;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_2336:
	{
		int32_t L_1214 = __this->___m_LineNumber_55;
		V_187 = (bool)((((int32_t)L_1214) > ((int32_t)0))? 1 : 0);
		bool L_1215 = V_187;
		if (!L_1215)
		{
			goto IL_2465;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1216 = __this->___m_CharBuffer_4;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1217 = ___1_textInfo;
		NullCheck(L_1217);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1218 = L_1217->___textElementInfo_10;
		int32_t L_1219 = V_18;
		NullCheck(L_1218);
		int32_t L_1220 = ((L_1218)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1219)))->___index_1;
		NullCheck(L_1216);
		(L_1216)->SetAt(static_cast<il2cpp_array_size_t>(L_1220), (int32_t)((int32_t)8230));
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1221 = __this->___m_CharBuffer_4;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1222 = ___1_textInfo;
		NullCheck(L_1222);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1223 = L_1222->___textElementInfo_10;
		int32_t L_1224 = V_18;
		NullCheck(L_1223);
		int32_t L_1225 = ((L_1223)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1224)))->___index_1;
		NullCheck(L_1221);
		(L_1221)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_1225, 1))), (int32_t)0);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1226 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1227 = L_1226->___character_0;
		V_188 = (bool)((!(((RuntimeObject*)(Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC*)L_1227) <= ((RuntimeObject*)(RuntimeObject*)NULL)))? 1 : 0);
		bool L_1228 = V_188;
		if (!L_1228)
		{
			goto IL_242b;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1229 = ___1_textInfo;
		NullCheck(L_1229);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1230 = L_1229->___textElementInfo_10;
		int32_t L_1231 = V_18;
		NullCheck(L_1230);
		((L_1230)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1231)))->___character_0 = ((int32_t)8230);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1232 = ___1_textInfo;
		NullCheck(L_1232);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1233 = L_1232->___textElementInfo_10;
		int32_t L_1234 = V_18;
		NullCheck(L_1233);
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_1235 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Ellipsis_97);
		Character_t9B671B493FAC8D43638C69AF6AE92CBD103D80EC* L_1236 = L_1235->___character_0;
		((L_1233)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1234)))->___textElement_3 = L_1236;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1233)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1234)))->___textElement_3), (void*)L_1236);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1237 = ___1_textInfo;
		NullCheck(L_1237);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1238 = L_1237->___textElementInfo_10;
		int32_t L_1239 = V_18;
		NullCheck(L_1238);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1240 = __this->___m_MaterialReferences_85;
		NullCheck(L_1240);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1241 = ((L_1240)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___fontAsset_1;
		((L_1238)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1239)))->___fontAsset_4 = L_1241;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1238)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1239)))->___fontAsset_4), (void*)L_1241);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1242 = ___1_textInfo;
		NullCheck(L_1242);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1243 = L_1242->___textElementInfo_10;
		int32_t L_1244 = V_18;
		NullCheck(L_1243);
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1245 = __this->___m_MaterialReferences_85;
		NullCheck(L_1245);
		Material_t18053F08F347D0DCA5E1140EC7EC4533DD8A14E3* L_1246 = ((L_1245)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___material_3;
		((L_1243)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1244)))->___material_7 = L_1246;
		Il2CppCodeGenWriteBarrier((void**)(&((L_1243)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1244)))->___material_7), (void*)L_1246);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1247 = ___1_textInfo;
		NullCheck(L_1247);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1248 = L_1247->___textElementInfo_10;
		int32_t L_1249 = V_18;
		NullCheck(L_1248);
		((L_1248)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1249)))->___materialReferenceIndex_8 = 0;
		goto IL_244d;
	}

IL_242b:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1250 = ___0_generationSettings;
		NullCheck(L_1250);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1251 = L_1250->___fontAsset_4;
		NullCheck(L_1251);
		String_t* L_1252;
		L_1252 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_1251, NULL);
		String_t* L_1253;
		L_1253 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(_stringLiteral45F6DDE1A98CAC15AB9ED3B1B435261E3210927D, L_1252, _stringLiteral0A0DAF77271D6DA2C6A1C08A805866EB837D591E, NULL);
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_LogWarning_m33EF1B897E0C7C6FF538989610BFAFFEF4628CA9(L_1253, NULL);
	}

IL_244d:
	{
		int32_t L_1254 = V_18;
		__this->___m_TotalCharacterCount_13 = ((int32_t)il2cpp_codegen_add(L_1254, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1255 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1256 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1255, L_1256, NULL);
		goto IL_6c59;
	}

IL_2465:
	{
		goto IL_2608;
	}

IL_246b:
	{
		bool L_1257 = __this->___m_IsMaskingEnabled_84;
		V_189 = (bool)((((int32_t)L_1257) == ((int32_t)0))? 1 : 0);
		bool L_1258 = V_189;
		if (!L_1258)
		{
			goto IL_2481;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_2481:
	{
		goto IL_2608;
	}

IL_2486:
	{
		bool L_1259 = __this->___m_IsMaskingEnabled_84;
		V_190 = (bool)((((int32_t)L_1259) == ((int32_t)0))? 1 : 0);
		bool L_1260 = V_190;
		if (!L_1260)
		{
			goto IL_249c;
		}
	}
	{
		TextGenerator_EnableMasking_mB38D92D32518523DE33A2FCD85A67DE481BB0991(__this, NULL);
	}

IL_249c:
	{
		goto IL_2608;
	}

IL_24a1:
	{
		bool L_1261 = __this->___m_IsMaskingEnabled_84;
		V_191 = L_1261;
		bool L_1262 = V_191;
		if (!L_1262)
		{
			goto IL_24b4;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_24b4:
	{
		int32_t L_1263 = __this->___m_LineNumber_55;
		V_192 = (bool)((((int32_t)L_1263) > ((int32_t)0))? 1 : 0);
		bool L_1264 = V_192;
		if (!L_1264)
		{
			goto IL_24f8;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1265 = __this->___m_CharBuffer_4;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1266 = ___1_textInfo;
		NullCheck(L_1266);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1267 = L_1266->___textElementInfo_10;
		int32_t L_1268 = V_18;
		NullCheck(L_1267);
		int32_t L_1269 = ((L_1267)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1268)))->___index_1;
		NullCheck(L_1265);
		(L_1265)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_1269, 1))), (int32_t)0);
		int32_t L_1270 = V_18;
		__this->___m_TotalCharacterCount_13 = ((int32_t)il2cpp_codegen_add(L_1270, 1));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1271 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1272 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1271, L_1272, NULL);
		goto IL_6c59;
	}

IL_24f8:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1273 = ___1_textInfo;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)0, L_1273, NULL);
		goto IL_6c59;
	}

IL_2506:
	{
		bool L_1274 = __this->___m_IsMaskingEnabled_84;
		V_193 = L_1274;
		bool L_1275 = V_193;
		if (!L_1275)
		{
			goto IL_2519;
		}
	}
	{
		TextGenerator_DisableMasking_mBDE8E47000367F45FC907243C845A11DBDD89950(__this, NULL);
	}

IL_2519:
	{
		int32_t L_1276 = V_60;
		if ((((int32_t)L_1276) == ((int32_t)((int32_t)13))))
		{
			goto IL_2527;
		}
	}
	{
		int32_t L_1277 = V_60;
		G_B341_0 = ((((int32_t)L_1277) == ((int32_t)((int32_t)10)))? 1 : 0);
		goto IL_2528;
	}

IL_2527:
	{
		G_B341_0 = 1;
	}

IL_2528:
	{
		V_194 = (bool)G_B341_0;
		bool L_1278 = V_194;
		if (!L_1278)
		{
			goto IL_2533;
		}
	}
	{
		goto IL_2608;
	}

IL_2533:
	{
		int32_t L_1279 = V_59;
		V_195 = (bool)((((int32_t)L_1279) == ((int32_t)0))? 1 : 0);
		bool L_1280 = V_195;
		if (!L_1280)
		{
			goto IL_2544;
		}
	}
	{
		goto IL_6c59;
	}

IL_2544:
	{
		int32_t L_1281 = V_17;
		int32_t L_1282 = V_59;
		V_196 = (bool)((((int32_t)L_1281) == ((int32_t)L_1282))? 1 : 0);
		bool L_1283 = V_196;
		if (!L_1283)
		{
			goto IL_255c;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1284 = __this->___m_CharBuffer_4;
		int32_t L_1285 = V_59;
		NullCheck(L_1284);
		(L_1284)->SetAt(static_cast<il2cpp_array_size_t>(L_1285), (int32_t)0);
	}

IL_255c:
	{
		int32_t L_1286 = V_59;
		V_17 = L_1286;
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1287 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState_69);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1288 = ___1_textInfo;
		int32_t L_1289;
		L_1289 = TextGenerator_RestoreWordWrappingState_mA63B3DD2C02E61CD8670A32A53163AF6BF765F61(__this, L_1287, L_1288, NULL);
		V_59 = L_1289;
		__this->___m_IsNewPage_66 = (bool)1;
		float L_1290 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add((0.0f), L_1290));
		__this->___m_LineOffset_39 = (0.0f);
		__this->___m_MaxAscender_64 = (0.0f);
		V_24 = (0.0f);
		int32_t L_1291 = __this->___m_LineNumber_55;
		__this->___m_LineNumber_55 = ((int32_t)il2cpp_codegen_add(L_1291, 1));
		int32_t L_1292 = __this->___m_PageNumber_58;
		__this->___m_PageNumber_58 = ((int32_t)il2cpp_codegen_add(L_1292, 1));
		goto IL_3289;
	}

IL_25c6:
	{
		int32_t L_1293 = __this->___m_LineNumber_55;
		V_197 = (bool)((((int32_t)L_1293) > ((int32_t)0))? 1 : 0);
		bool L_1294 = V_197;
		if (!L_1294)
		{
			goto IL_25fa;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1295 = __this->___m_CharBuffer_4;
		int32_t L_1296 = V_59;
		NullCheck(L_1295);
		(L_1295)->SetAt(static_cast<il2cpp_array_size_t>(L_1296), (int32_t)0);
		int32_t L_1297 = __this->___m_CharacterCount_48;
		__this->___m_TotalCharacterCount_13 = L_1297;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1298 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1299 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1298, L_1299, NULL);
		goto IL_6c59;
	}

IL_25fa:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1300 = ___1_textInfo;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_1300, NULL);
		goto IL_6c59;
	}

IL_2608:
	{
	}

IL_2609:
	{
		int32_t L_1301 = V_60;
		V_198 = (bool)((((int32_t)L_1301) == ((int32_t)((int32_t)9)))? 1 : 0);
		bool L_1302 = V_198;
		if (!L_1302)
		{
			goto IL_2671;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1303 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1303);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_1304;
		L_1304 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_1303, NULL);
		V_57 = L_1304;
		float L_1305;
		L_1305 = FaceInfo_get_tabWidth_mC6D9F42C40EDD767DE22050E4FBE3878AC96B161((&V_57), NULL);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1306 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1306);
		uint8_t L_1307;
		L_1307 = FontAsset_get_tabMultiple_m9C0422A00BFCF82091F14F4E303E2717247350AE(L_1306, NULL);
		float L_1308 = V_2;
		V_199 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1305, ((float)L_1307))), L_1308));
		float L_1309 = __this->___m_XAdvance_43;
		float L_1310 = V_199;
		float L_1311;
		L_1311 = ceilf(((float)(L_1309/L_1310)));
		float L_1312 = V_199;
		V_200 = ((float)il2cpp_codegen_multiply(L_1311, L_1312));
		float L_1313 = V_200;
		float L_1314 = __this->___m_XAdvance_43;
		G_B354_0 = __this;
		if ((((float)L_1313) > ((float)L_1314)))
		{
			G_B355_0 = __this;
			goto IL_2664;
		}
	}
	{
		float L_1315 = __this->___m_XAdvance_43;
		float L_1316 = V_199;
		G_B356_0 = ((float)il2cpp_codegen_add(L_1315, L_1316));
		G_B356_1 = G_B354_0;
		goto IL_2666;
	}

IL_2664:
	{
		float L_1317 = V_200;
		G_B356_0 = L_1317;
		G_B356_1 = G_B355_0;
	}

IL_2666:
	{
		NullCheck(G_B356_1);
		G_B356_1->___m_XAdvance_43 = G_B356_0;
		goto IL_27da;
	}

IL_2671:
	{
		float L_1318 = __this->___m_MonoSpacing_42;
		V_201 = (bool)((((int32_t)((((float)L_1318) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1319 = V_201;
		if (!L_1319)
		{
			goto IL_26fe;
		}
	}
	{
		float L_1320 = __this->___m_XAdvance_43;
		float L_1321 = __this->___m_MonoSpacing_42;
		float L_1322 = V_67;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1323 = ___0_generationSettings;
		NullCheck(L_1323);
		float L_1324 = L_1323->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1325 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1325);
		float L_1326;
		L_1326 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1325, NULL);
		float L_1327 = V_2;
		float L_1328 = __this->___m_CSpacing_41;
		float L_1329 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1320, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_1321, L_1322)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1324, L_1326)), L_1327)))), L_1328)), ((float)il2cpp_codegen_subtract((1.0f), L_1329))))));
		int32_t L_1330 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1331;
		L_1331 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_1330), NULL);
		if (L_1331)
		{
			goto IL_26dc;
		}
	}
	{
		int32_t L_1332 = V_60;
		G_B361_0 = ((((int32_t)L_1332) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_26dd;
	}

IL_26dc:
	{
		G_B361_0 = 1;
	}

IL_26dd:
	{
		V_202 = (bool)G_B361_0;
		bool L_1333 = V_202;
		if (!L_1333)
		{
			goto IL_26f8;
		}
	}
	{
		float L_1334 = __this->___m_XAdvance_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1335 = ___0_generationSettings;
		NullCheck(L_1335);
		float L_1336 = L_1335->___wordSpacing_28;
		float L_1337 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1334, ((float)il2cpp_codegen_multiply(L_1336, L_1337))));
	}

IL_26f8:
	{
		goto IL_27da;
	}

IL_26fe:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1338 = ___0_generationSettings;
		NullCheck(L_1338);
		bool L_1339 = L_1338->___isRightToLeft_24;
		V_203 = (bool)((((int32_t)L_1339) == ((int32_t)0))? 1 : 0);
		bool L_1340 = V_203;
		if (!L_1340)
		{
			goto IL_27c2;
		}
	}
	{
		V_204 = (1.0f);
		bool L_1341 = __this->___m_IsFxMatrixSet_38;
		V_205 = L_1341;
		bool L_1342 = V_205;
		if (!L_1342)
		{
			goto IL_2731;
		}
	}
	{
		Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6* L_1343 = (Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6*)(&__this->___m_FxMatrix_78);
		float L_1344 = L_1343->___m00_0;
		V_204 = L_1344;
	}

IL_2731:
	{
		float L_1345 = __this->___m_XAdvance_43;
		TextElement_tCEF567A8810788262275B39DC39CBA6EBE7472DA* L_1346 = __this->___m_CachedTextElement_75;
		NullCheck(L_1346);
		Glyph_t700CF8EBE04ED4AEAB520885AAA1B309E02A103F* L_1347;
		L_1347 = TextElement_get_glyph_m101DBCCA0CDE2461B504174272A2FFCD53EA59E2(L_1346, NULL);
		NullCheck(L_1347);
		GlyphMetrics_t6C1C65A891A6279A0EE807C436436B1E44F7AF1A L_1348;
		L_1348 = Glyph_get_metrics_mB6E9D3D1899E35BA257638F6F58B7D260170B6FA(L_1347, NULL);
		V_94 = L_1348;
		float L_1349;
		L_1349 = GlyphMetrics_get_horizontalAdvance_m110E66C340A19E672FB1C26DFB875AB6900AFFF1((&V_94), NULL);
		float L_1350 = V_204;
		float L_1351 = V_4;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1352 = ___0_generationSettings;
		NullCheck(L_1352);
		float L_1353 = L_1352->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1354 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1354);
		float L_1355;
		L_1355 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1354, NULL);
		float L_1356;
		L_1356 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_65), NULL);
		float L_1357 = V_2;
		float L_1358 = __this->___m_CSpacing_41;
		float L_1359 = __this->___m_CharWidthAdjDelta_77;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1345, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_1349, L_1350)), L_1351)), L_1353)), L_1355)), L_1356)), L_1357)), L_1358)), ((float)il2cpp_codegen_subtract((1.0f), L_1359))))));
		int32_t L_1360 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1361;
		L_1361 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_1360), NULL);
		if (L_1361)
		{
			goto IL_27a3;
		}
	}
	{
		int32_t L_1362 = V_60;
		G_B370_0 = ((((int32_t)L_1362) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_27a4;
	}

IL_27a3:
	{
		G_B370_0 = 1;
	}

IL_27a4:
	{
		V_206 = (bool)G_B370_0;
		bool L_1363 = V_206;
		if (!L_1363)
		{
			goto IL_27bf;
		}
	}
	{
		float L_1364 = __this->___m_XAdvance_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1365 = ___0_generationSettings;
		NullCheck(L_1365);
		float L_1366 = L_1365->___wordSpacing_28;
		float L_1367 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(L_1364, ((float)il2cpp_codegen_multiply(L_1366, L_1367))));
	}

IL_27bf:
	{
		goto IL_27da;
	}

IL_27c2:
	{
		float L_1368 = __this->___m_XAdvance_43;
		float L_1369;
		L_1369 = GlyphValueRecord_get_xAdvance_m6C392027FA91E0705C1585C5EF40D984AAA0013E((&V_65), NULL);
		float L_1370 = V_2;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_subtract(L_1368, ((float)il2cpp_codegen_multiply(L_1369, L_1370))));
	}

IL_27da:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1371 = ___1_textInfo;
		NullCheck(L_1371);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1372 = L_1371->___textElementInfo_10;
		int32_t L_1373 = __this->___m_CharacterCount_48;
		NullCheck(L_1372);
		float L_1374 = __this->___m_XAdvance_43;
		((L_1372)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1373)))->___xAdvance_26 = L_1374;
		int32_t L_1375 = V_60;
		V_207 = (bool)((((int32_t)L_1375) == ((int32_t)((int32_t)13)))? 1 : 0);
		bool L_1376 = V_207;
		if (!L_1376)
		{
			goto IL_2816;
		}
	}
	{
		float L_1377 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add((0.0f), L_1377));
	}

IL_2816:
	{
		int32_t L_1378 = V_60;
		if ((((int32_t)L_1378) == ((int32_t)((int32_t)10))))
		{
			goto IL_2829;
		}
	}
	{
		int32_t L_1379 = __this->___m_CharacterCount_48;
		int32_t L_1380 = V_0;
		G_B379_0 = ((((int32_t)L_1379) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1380, 1))))? 1 : 0);
		goto IL_282a;
	}

IL_2829:
	{
		G_B379_0 = 1;
	}

IL_282a:
	{
		V_208 = (bool)G_B379_0;
		bool L_1381 = V_208;
		if (!L_1381)
		{
			goto IL_2dc8;
		}
	}
	{
		int32_t L_1382 = __this->___m_LineNumber_55;
		if ((((int32_t)L_1382) <= ((int32_t)0)))
		{
			goto IL_2868;
		}
	}
	{
		float L_1383 = __this->___m_MaxLineAscender_53;
		float L_1384 = __this->___m_StartOfLineAscender_82;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_1385;
		L_1385 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(L_1383, L_1384, NULL);
		if (L_1385)
		{
			goto IL_2868;
		}
	}
	{
		float L_1386 = __this->___m_LineHeight_40;
		if ((!(((float)L_1386) == ((float)(-32767.0f)))))
		{
			goto IL_2868;
		}
	}
	{
		bool L_1387 = __this->___m_IsNewPage_66;
		G_B385_0 = ((((int32_t)L_1387) == ((int32_t)0))? 1 : 0);
		goto IL_2869;
	}

IL_2868:
	{
		G_B385_0 = 0;
	}

IL_2869:
	{
		V_211 = (bool)G_B385_0;
		bool L_1388 = V_211;
		if (!L_1388)
		{
			goto IL_28a4;
		}
	}
	{
		float L_1389 = __this->___m_MaxLineAscender_53;
		float L_1390 = __this->___m_StartOfLineAscender_82;
		V_212 = ((float)il2cpp_codegen_subtract(L_1389, L_1390));
		int32_t L_1391 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_1392 = __this->___m_CharacterCount_48;
		float L_1393 = V_212;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1394 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_AdjustLineOffset_m811C187EA3E41781116F0C7A679B05BB27874123(L_1391, L_1392, L_1393, L_1394, NULL);
		float L_1395 = __this->___m_LineOffset_39;
		float L_1396 = V_212;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1395, L_1396));
	}

IL_28a4:
	{
		__this->___m_IsNewPage_66 = (bool)0;
		float L_1397 = __this->___m_MaxLineAscender_53;
		float L_1398 = __this->___m_LineOffset_39;
		V_209 = ((float)il2cpp_codegen_subtract(L_1397, L_1398));
		float L_1399 = __this->___m_MaxLineDescender_54;
		float L_1400 = __this->___m_LineOffset_39;
		V_210 = ((float)il2cpp_codegen_subtract(L_1399, L_1400));
		float L_1401 = __this->___m_MaxDescender_65;
		float L_1402 = V_210;
		G_B388_0 = __this;
		if ((((float)L_1401) < ((float)L_1402)))
		{
			G_B389_0 = __this;
			goto IL_28d8;
		}
	}
	{
		float L_1403 = V_210;
		G_B390_0 = L_1403;
		G_B390_1 = G_B388_0;
		goto IL_28de;
	}

IL_28d8:
	{
		float L_1404 = __this->___m_MaxDescender_65;
		G_B390_0 = L_1404;
		G_B390_1 = G_B389_0;
	}

IL_28de:
	{
		NullCheck(G_B390_1);
		G_B390_1->___m_MaxDescender_65 = G_B390_0;
		bool L_1405 = V_26;
		V_213 = (bool)((((int32_t)L_1405) == ((int32_t)0))? 1 : 0);
		bool L_1406 = V_213;
		if (!L_1406)
		{
			goto IL_28f6;
		}
	}
	{
		float L_1407 = __this->___m_MaxDescender_65;
		V_25 = L_1407;
	}

IL_28f6:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1408 = ___0_generationSettings;
		NullCheck(L_1408);
		bool L_1409 = L_1408->___useMaxVisibleDescender_36;
		if (!L_1409)
		{
			goto IL_2922;
		}
	}
	{
		int32_t L_1410 = __this->___m_CharacterCount_48;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1411 = ___0_generationSettings;
		NullCheck(L_1411);
		int32_t L_1412 = L_1411->___maxVisibleCharacters_32;
		if ((((int32_t)L_1410) >= ((int32_t)L_1412)))
		{
			goto IL_291f;
		}
	}
	{
		int32_t L_1413 = __this->___m_LineNumber_55;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1414 = ___0_generationSettings;
		NullCheck(L_1414);
		int32_t L_1415 = L_1414->___maxVisibleLines_34;
		G_B396_0 = ((((int32_t)((((int32_t)L_1413) < ((int32_t)L_1415))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2920;
	}

IL_291f:
	{
		G_B396_0 = 1;
	}

IL_2920:
	{
		G_B398_0 = G_B396_0;
		goto IL_2923;
	}

IL_2922:
	{
		G_B398_0 = 0;
	}

IL_2923:
	{
		V_214 = (bool)G_B398_0;
		bool L_1416 = V_214;
		if (!L_1416)
		{
			goto IL_292c;
		}
	}
	{
		V_26 = (bool)1;
	}

IL_292c:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1417 = ___1_textInfo;
		NullCheck(L_1417);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1418 = L_1417->___lineInfo_13;
		int32_t L_1419 = __this->___m_LineNumber_55;
		NullCheck(L_1418);
		int32_t L_1420 = __this->___m_FirstCharacterOfLine_49;
		((L_1418)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1419)))->___firstCharacterIndex_6 = L_1420;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1421 = ___1_textInfo;
		NullCheck(L_1421);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1422 = L_1421->___lineInfo_13;
		int32_t L_1423 = __this->___m_LineNumber_55;
		NullCheck(L_1422);
		int32_t L_1424 = __this->___m_FirstCharacterOfLine_49;
		int32_t L_1425 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B401_0 = __this;
		G_B401_1 = ((L_1422)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1423)));
		if ((((int32_t)L_1424) > ((int32_t)L_1425)))
		{
			G_B402_0 = __this;
			G_B402_1 = ((L_1422)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1423)));
			goto IL_2970;
		}
	}
	{
		int32_t L_1426 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B403_0 = L_1426;
		G_B403_1 = G_B401_0;
		G_B403_2 = G_B401_1;
		goto IL_2976;
	}

IL_2970:
	{
		int32_t L_1427 = __this->___m_FirstCharacterOfLine_49;
		G_B403_0 = L_1427;
		G_B403_1 = G_B402_0;
		G_B403_2 = G_B402_1;
	}

IL_2976:
	{
		int32_t L_1428 = G_B403_0;
		V_149 = L_1428;
		NullCheck(G_B403_1);
		G_B403_1->___m_FirstVisibleCharacterOfLine_51 = L_1428;
		int32_t L_1429 = V_149;
		G_B403_2->___firstVisibleCharacterIndex_7 = L_1429;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1430 = ___1_textInfo;
		NullCheck(L_1430);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1431 = L_1430->___lineInfo_13;
		int32_t L_1432 = __this->___m_LineNumber_55;
		NullCheck(L_1431);
		int32_t L_1433 = __this->___m_CharacterCount_48;
		int32_t L_1434 = L_1433;
		V_149 = L_1434;
		__this->___m_LastCharacterOfLine_50 = L_1434;
		int32_t L_1435 = V_149;
		((L_1431)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1432)))->___lastCharacterIndex_8 = L_1435;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1436 = ___1_textInfo;
		NullCheck(L_1436);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1437 = L_1436->___lineInfo_13;
		int32_t L_1438 = __this->___m_LineNumber_55;
		NullCheck(L_1437);
		int32_t L_1439 = __this->___m_LastVisibleCharacterOfLine_52;
		int32_t L_1440 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B404_0 = __this;
		G_B404_1 = ((L_1437)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1438)));
		if ((((int32_t)L_1439) < ((int32_t)L_1440)))
		{
			G_B405_0 = __this;
			G_B405_1 = ((L_1437)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1438)));
			goto IL_29d4;
		}
	}
	{
		int32_t L_1441 = __this->___m_LastVisibleCharacterOfLine_52;
		G_B406_0 = L_1441;
		G_B406_1 = G_B404_0;
		G_B406_2 = G_B404_1;
		goto IL_29da;
	}

IL_29d4:
	{
		int32_t L_1442 = __this->___m_FirstVisibleCharacterOfLine_51;
		G_B406_0 = L_1442;
		G_B406_1 = G_B405_0;
		G_B406_2 = G_B405_1;
	}

IL_29da:
	{
		int32_t L_1443 = G_B406_0;
		V_149 = L_1443;
		NullCheck(G_B406_1);
		G_B406_1->___m_LastVisibleCharacterOfLine_52 = L_1443;
		int32_t L_1444 = V_149;
		G_B406_2->___lastVisibleCharacterIndex_9 = L_1444;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1445 = ___1_textInfo;
		NullCheck(L_1445);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1446 = L_1445->___lineInfo_13;
		int32_t L_1447 = __this->___m_LineNumber_55;
		NullCheck(L_1446);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1448 = ___1_textInfo;
		NullCheck(L_1448);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1449 = L_1448->___lineInfo_13;
		int32_t L_1450 = __this->___m_LineNumber_55;
		NullCheck(L_1449);
		int32_t L_1451 = ((L_1449)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1450)))->___lastCharacterIndex_8;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1452 = ___1_textInfo;
		NullCheck(L_1452);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1453 = L_1452->___lineInfo_13;
		int32_t L_1454 = __this->___m_LineNumber_55;
		NullCheck(L_1453);
		int32_t L_1455 = ((L_1453)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1454)))->___firstCharacterIndex_6;
		((L_1446)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1447)))->___characterCount_1 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_1451, L_1455)), 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1456 = ___1_textInfo;
		NullCheck(L_1456);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1457 = L_1456->___lineInfo_13;
		int32_t L_1458 = __this->___m_LineNumber_55;
		NullCheck(L_1457);
		int32_t L_1459 = __this->___m_LineVisibleCharacterCount_56;
		((L_1457)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1458)))->___visibleCharacterCount_2 = L_1459;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1460 = ___1_textInfo;
		NullCheck(L_1460);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1461 = L_1460->___lineInfo_13;
		int32_t L_1462 = __this->___m_LineNumber_55;
		NullCheck(L_1461);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1463 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_1461)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1462)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1464 = ___1_textInfo;
		NullCheck(L_1464);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1465 = L_1464->___textElementInfo_10;
		int32_t L_1466 = __this->___m_FirstVisibleCharacterOfLine_51;
		NullCheck(L_1465);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1467 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1465)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1466)))->___bottomLeft_19);
		float L_1468 = L_1467->___x_2;
		float L_1469 = V_210;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1470;
		memset((&L_1470), 0, sizeof(L_1470));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_1470), L_1468, L_1469, /*hidden argument*/NULL);
		L_1463->___min_0 = L_1470;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1471 = ___1_textInfo;
		NullCheck(L_1471);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1472 = L_1471->___lineInfo_13;
		int32_t L_1473 = __this->___m_LineNumber_55;
		NullCheck(L_1472);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1474 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_1472)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1473)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1475 = ___1_textInfo;
		NullCheck(L_1475);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1476 = L_1475->___textElementInfo_10;
		int32_t L_1477 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_1476);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1478 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1476)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1477)))->___topRight_20);
		float L_1479 = L_1478->___x_2;
		float L_1480 = V_209;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1481;
		memset((&L_1481), 0, sizeof(L_1481));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_1481), L_1479, L_1480, /*hidden argument*/NULL);
		L_1474->___max_1 = L_1481;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1482 = ___1_textInfo;
		NullCheck(L_1482);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1483 = L_1482->___lineInfo_13;
		int32_t L_1484 = __this->___m_LineNumber_55;
		NullCheck(L_1483);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1485 = ___1_textInfo;
		NullCheck(L_1485);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1486 = L_1485->___lineInfo_13;
		int32_t L_1487 = __this->___m_LineNumber_55;
		NullCheck(L_1486);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1488 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_1486)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1487)))->___lineExtents_20);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1489 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1488->___max_1);
		float L_1490 = L_1489->___x_0;
		float L_1491 = V_3;
		float L_1492 = V_2;
		((L_1483)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1484)))->___length_10 = ((float)il2cpp_codegen_subtract(L_1490, ((float)il2cpp_codegen_multiply(L_1491, L_1492))));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1493 = ___1_textInfo;
		NullCheck(L_1493);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1494 = L_1493->___lineInfo_13;
		int32_t L_1495 = __this->___m_LineNumber_55;
		NullCheck(L_1494);
		float L_1496 = V_22;
		((L_1494)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1495)))->___width_16 = L_1496;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1497 = ___1_textInfo;
		NullCheck(L_1497);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1498 = L_1497->___lineInfo_13;
		int32_t L_1499 = __this->___m_LineNumber_55;
		NullCheck(L_1498);
		int32_t L_1500 = ((L_1498)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1499)))->___characterCount_1;
		V_215 = (bool)((((int32_t)L_1500) == ((int32_t)1))? 1 : 0);
		bool L_1501 = V_215;
		if (!L_1501)
		{
			goto IL_2b51;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1502 = ___1_textInfo;
		NullCheck(L_1502);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1503 = L_1502->___lineInfo_13;
		int32_t L_1504 = __this->___m_LineNumber_55;
		NullCheck(L_1503);
		int32_t L_1505 = __this->___m_LineJustification_23;
		((L_1503)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1504)))->___alignment_19 = L_1505;
	}

IL_2b51:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1506 = ___1_textInfo;
		NullCheck(L_1506);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1507 = L_1506->___textElementInfo_10;
		int32_t L_1508 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_1507);
		bool L_1509 = ((L_1507)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1508)))->___isVisible_34;
		V_216 = L_1509;
		bool L_1510 = V_216;
		if (!L_1510)
		{
			goto IL_2bb7;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1511 = ___1_textInfo;
		NullCheck(L_1511);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1512 = L_1511->___lineInfo_13;
		int32_t L_1513 = __this->___m_LineNumber_55;
		NullCheck(L_1512);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1514 = ___1_textInfo;
		NullCheck(L_1514);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1515 = L_1514->___textElementInfo_10;
		int32_t L_1516 = __this->___m_LastVisibleCharacterOfLine_52;
		NullCheck(L_1515);
		float L_1517 = ((L_1515)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1516)))->___xAdvance_26;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1518 = ___0_generationSettings;
		NullCheck(L_1518);
		float L_1519 = L_1518->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1520 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1520);
		float L_1521;
		L_1521 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1520, NULL);
		float L_1522 = V_2;
		float L_1523 = __this->___m_CSpacing_41;
		((L_1512)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1513)))->___maxAdvance_15 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_1517, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1519, L_1521)), L_1522)))), L_1523));
		goto IL_2bff;
	}

IL_2bb7:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1524 = ___1_textInfo;
		NullCheck(L_1524);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1525 = L_1524->___lineInfo_13;
		int32_t L_1526 = __this->___m_LineNumber_55;
		NullCheck(L_1525);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1527 = ___1_textInfo;
		NullCheck(L_1527);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1528 = L_1527->___textElementInfo_10;
		int32_t L_1529 = __this->___m_LastCharacterOfLine_50;
		NullCheck(L_1528);
		float L_1530 = ((L_1528)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1529)))->___xAdvance_26;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1531 = ___0_generationSettings;
		NullCheck(L_1531);
		float L_1532 = L_1531->___characterSpacing_27;
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_1533 = __this->___m_CurrentFontAsset_7;
		NullCheck(L_1533);
		float L_1534;
		L_1534 = FontAsset_get_regularStyleSpacing_mB7EEEA236312F5AC31FD3B787808279206F521B1(L_1533, NULL);
		float L_1535 = V_2;
		float L_1536 = __this->___m_CSpacing_41;
		((L_1525)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1526)))->___maxAdvance_15 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_1530, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1532, L_1534)), L_1535)))), L_1536));
	}

IL_2bff:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1537 = ___1_textInfo;
		NullCheck(L_1537);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1538 = L_1537->___lineInfo_13;
		int32_t L_1539 = __this->___m_LineNumber_55;
		NullCheck(L_1538);
		float L_1540 = __this->___m_LineOffset_39;
		((L_1538)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1539)))->___baseline_13 = ((float)il2cpp_codegen_subtract((0.0f), L_1540));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1541 = ___1_textInfo;
		NullCheck(L_1541);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1542 = L_1541->___lineInfo_13;
		int32_t L_1543 = __this->___m_LineNumber_55;
		NullCheck(L_1542);
		float L_1544 = V_209;
		((L_1542)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1543)))->___ascender_12 = L_1544;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1545 = ___1_textInfo;
		NullCheck(L_1545);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1546 = L_1545->___lineInfo_13;
		int32_t L_1547 = __this->___m_LineNumber_55;
		NullCheck(L_1546);
		float L_1548 = V_210;
		((L_1546)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1547)))->___descender_14 = L_1548;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1549 = ___1_textInfo;
		NullCheck(L_1549);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1550 = L_1549->___lineInfo_13;
		int32_t L_1551 = __this->___m_LineNumber_55;
		NullCheck(L_1550);
		float L_1552 = V_209;
		float L_1553 = V_210;
		float L_1554 = V_14;
		float L_1555 = V_1;
		((L_1550)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1551)))->___lineHeight_11 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_1552, L_1553)), ((float)il2cpp_codegen_multiply(L_1554, L_1555))));
		int32_t L_1556 = __this->___m_CharacterCount_48;
		__this->___m_FirstCharacterOfLine_49 = ((int32_t)il2cpp_codegen_add(L_1556, 1));
		__this->___m_LineVisibleCharacterCount_56 = 0;
		int32_t L_1557 = V_60;
		V_217 = (bool)((((int32_t)L_1557) == ((int32_t)((int32_t)10)))? 1 : 0);
		bool L_1558 = V_217;
		if (!L_1558)
		{
			goto IL_2dc7;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1559 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedLineState_69);
		int32_t L_1560 = V_59;
		int32_t L_1561 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1562 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1559, L_1560, L_1561, L_1562, NULL);
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1563 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		int32_t L_1564 = V_59;
		int32_t L_1565 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1566 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1563, L_1564, L_1565, L_1566, NULL);
		int32_t L_1567 = __this->___m_LineNumber_55;
		__this->___m_LineNumber_55 = ((int32_t)il2cpp_codegen_add(L_1567, 1));
		V_15 = (bool)1;
		V_28 = (bool)0;
		V_27 = (bool)1;
		int32_t L_1568 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1569 = ___1_textInfo;
		NullCheck(L_1569);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_1570 = L_1569->___lineInfo_13;
		NullCheck(L_1570);
		V_218 = (bool)((((int32_t)((((int32_t)L_1568) < ((int32_t)((int32_t)(((RuntimeArray*)L_1570)->max_length))))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1571 = V_218;
		if (!L_1571)
		{
			goto IL_2cff;
		}
	}
	{
		int32_t L_1572 = __this->___m_LineNumber_55;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1573 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_ResizeLineExtents_m2EA9BE32A38D5E075DEF8EDA9EC01766E45C0F85(L_1572, L_1573, NULL);
	}

IL_2cff:
	{
		float L_1574 = __this->___m_LineHeight_40;
		V_219 = (bool)((((float)L_1574) == ((float)(-32767.0f)))? 1 : 0);
		bool L_1575 = V_219;
		if (!L_1575)
		{
			goto IL_2d50;
		}
	}
	{
		float L_1576 = __this->___m_MaxLineDescender_54;
		float L_1577 = V_74;
		float L_1578 = V_14;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1579 = ___0_generationSettings;
		NullCheck(L_1579);
		float L_1580 = L_1579->___lineSpacing_29;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1581 = ___0_generationSettings;
		NullCheck(L_1581);
		float L_1582 = L_1581->___paragraphSpacing_30;
		float L_1583 = __this->___m_LineSpacingDelta_83;
		float L_1584 = V_1;
		V_77 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_1576)), L_1577)), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1578, L_1580)), L_1582)), L_1583)), L_1584))));
		float L_1585 = __this->___m_LineOffset_39;
		float L_1586 = V_77;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1585, L_1586));
		goto IL_2d73;
	}

IL_2d50:
	{
		float L_1587 = __this->___m_LineOffset_39;
		float L_1588 = __this->___m_LineHeight_40;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1589 = ___0_generationSettings;
		NullCheck(L_1589);
		float L_1590 = L_1589->___lineSpacing_29;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1591 = ___0_generationSettings;
		NullCheck(L_1591);
		float L_1592 = L_1591->___paragraphSpacing_30;
		float L_1593 = V_1;
		__this->___m_LineOffset_39 = ((float)il2cpp_codegen_add(L_1587, ((float)il2cpp_codegen_add(L_1588, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_1590, L_1592)), L_1593))))));
	}

IL_2d73:
	{
		__this->___m_MaxLineAscender_53 = (-32767.0f);
		__this->___m_MaxLineDescender_54 = (32767.0f);
		float L_1594 = V_74;
		__this->___m_StartOfLineAscender_82 = L_1594;
		float L_1595 = __this->___m_TagLineIndent_44;
		float L_1596 = __this->___m_TagIndent_45;
		__this->___m_XAdvance_43 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add((0.0f), L_1595)), L_1596));
		int32_t L_1597 = __this->___m_CharacterCount_48;
		V_18 = ((int32_t)il2cpp_codegen_subtract(L_1597, 1));
		int32_t L_1598 = __this->___m_CharacterCount_48;
		__this->___m_CharacterCount_48 = ((int32_t)il2cpp_codegen_add(L_1598, 1));
		goto IL_3289;
	}

IL_2dc7:
	{
	}

IL_2dc8:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1599 = ___1_textInfo;
		NullCheck(L_1599);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1600 = L_1599->___textElementInfo_10;
		int32_t L_1601 = __this->___m_CharacterCount_48;
		NullCheck(L_1600);
		bool L_1602 = ((L_1600)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1601)))->___isVisible_34;
		V_220 = L_1602;
		bool L_1603 = V_220;
		if (!L_1603)
		{
			goto IL_2ee9;
		}
	}
	{
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1604 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1605 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1604->___min_0);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1606 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1607 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1606->___min_0);
		float L_1608 = L_1607->___x_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1609 = ___1_textInfo;
		NullCheck(L_1609);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1610 = L_1609->___textElementInfo_10;
		int32_t L_1611 = __this->___m_CharacterCount_48;
		NullCheck(L_1610);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1612 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1610)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1611)))->___bottomLeft_19);
		float L_1613 = L_1612->___x_2;
		float L_1614;
		L_1614 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1608, L_1613, NULL);
		L_1605->___x_0 = L_1614;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1615 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1616 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1615->___min_0);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1617 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1618 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1617->___min_0);
		float L_1619 = L_1618->___y_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1620 = ___1_textInfo;
		NullCheck(L_1620);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1621 = L_1620->___textElementInfo_10;
		int32_t L_1622 = __this->___m_CharacterCount_48;
		NullCheck(L_1621);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1623 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1621)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1622)))->___bottomLeft_19);
		float L_1624 = L_1623->___y_3;
		float L_1625;
		L_1625 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1619, L_1624, NULL);
		L_1616->___y_1 = L_1625;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1626 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1627 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1626->___max_1);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1628 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1629 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1628->___max_1);
		float L_1630 = L_1629->___x_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1631 = ___1_textInfo;
		NullCheck(L_1631);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1632 = L_1631->___textElementInfo_10;
		int32_t L_1633 = __this->___m_CharacterCount_48;
		NullCheck(L_1632);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1634 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1632)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1633)))->___topRight_20);
		float L_1635 = L_1634->___x_2;
		float L_1636;
		L_1636 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1630, L_1635, NULL);
		L_1627->___x_0 = L_1636;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1637 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1638 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1637->___max_1);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1639 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1640 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1639->___max_1);
		float L_1641 = L_1640->___y_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1642 = ___1_textInfo;
		NullCheck(L_1642);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1643 = L_1642->___textElementInfo_10;
		int32_t L_1644 = __this->___m_CharacterCount_48;
		NullCheck(L_1643);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_1645 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_1643)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1644)))->___topRight_20);
		float L_1646 = L_1645->___y_3;
		float L_1647;
		L_1647 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_1641, L_1646, NULL);
		L_1638->___y_1 = L_1647;
	}

IL_2ee9:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1648 = ___0_generationSettings;
		NullCheck(L_1648);
		int32_t L_1649 = L_1648->___overflowMode_11;
		if ((!(((uint32_t)L_1649) == ((uint32_t)5))))
		{
			goto IL_2f03;
		}
	}
	{
		int32_t L_1650 = V_60;
		if ((((int32_t)L_1650) == ((int32_t)((int32_t)13))))
		{
			goto IL_2f03;
		}
	}
	{
		int32_t L_1651 = V_60;
		G_B425_0 = ((((int32_t)((((int32_t)L_1651) == ((int32_t)((int32_t)10)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_2f04;
	}

IL_2f03:
	{
		G_B425_0 = 0;
	}

IL_2f04:
	{
		V_221 = (bool)G_B425_0;
		bool L_1652 = V_221;
		if (!L_1652)
		{
			goto IL_307b;
		}
	}
	{
		int32_t L_1653 = __this->___m_PageNumber_58;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1654 = ___1_textInfo;
		NullCheck(L_1654);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1655 = L_1654->___pageInfo_14;
		NullCheck(L_1655);
		V_222 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_1653, 1))) > ((int32_t)((int32_t)(((RuntimeArray*)L_1655)->max_length))))? 1 : 0);
		bool L_1656 = V_222;
		if (!L_1656)
		{
			goto IL_2f3b;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1657 = ___1_textInfo;
		NullCheck(L_1657);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4** L_1658 = (PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4**)(&L_1657->___pageInfo_14);
		int32_t L_1659 = __this->___m_PageNumber_58;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8(L_1658, ((int32_t)il2cpp_codegen_add(L_1659, 1)), (bool)1, TextInfo_Resize_TisPageInfo_tFFF6B289E9A37E4D69353B32F941421180DA5909_m356AAB6CAA9298FF4C0E067A3ACE9A0AD2D78DE8_RuntimeMethod_var);
	}

IL_2f3b:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1660 = ___1_textInfo;
		NullCheck(L_1660);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1661 = L_1660->___pageInfo_14;
		int32_t L_1662 = __this->___m_PageNumber_58;
		NullCheck(L_1661);
		float L_1663 = V_24;
		((L_1661)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1662)))->___ascender_2 = L_1663;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1664 = ___1_textInfo;
		NullCheck(L_1664);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1665 = L_1664->___pageInfo_14;
		int32_t L_1666 = __this->___m_PageNumber_58;
		NullCheck(L_1665);
		float L_1667 = V_75;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1668 = ___1_textInfo;
		NullCheck(L_1668);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1669 = L_1668->___pageInfo_14;
		int32_t L_1670 = __this->___m_PageNumber_58;
		NullCheck(L_1669);
		float L_1671 = ((L_1669)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1670)))->___descender_4;
		G_B429_0 = ((L_1665)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1666)));
		if ((((float)L_1667) < ((float)L_1671)))
		{
			G_B430_0 = ((L_1665)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1666)));
			goto IL_2f96;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1672 = ___1_textInfo;
		NullCheck(L_1672);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1673 = L_1672->___pageInfo_14;
		int32_t L_1674 = __this->___m_PageNumber_58;
		NullCheck(L_1673);
		float L_1675 = ((L_1673)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1674)))->___descender_4;
		G_B431_0 = L_1675;
		G_B431_1 = G_B429_0;
		goto IL_2f98;
	}

IL_2f96:
	{
		float L_1676 = V_75;
		G_B431_0 = L_1676;
		G_B431_1 = G_B430_0;
	}

IL_2f98:
	{
		G_B431_1->___descender_4 = G_B431_0;
		int32_t L_1677 = __this->___m_PageNumber_58;
		if (L_1677)
		{
			goto IL_2fb0;
		}
	}
	{
		int32_t L_1678 = __this->___m_CharacterCount_48;
		G_B434_0 = ((((int32_t)L_1678) == ((int32_t)0))? 1 : 0);
		goto IL_2fb1;
	}

IL_2fb0:
	{
		G_B434_0 = 0;
	}

IL_2fb1:
	{
		V_223 = (bool)G_B434_0;
		bool L_1679 = V_223;
		if (!L_1679)
		{
			goto IL_2fd8;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1680 = ___1_textInfo;
		NullCheck(L_1680);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1681 = L_1680->___pageInfo_14;
		int32_t L_1682 = __this->___m_PageNumber_58;
		NullCheck(L_1681);
		int32_t L_1683 = __this->___m_CharacterCount_48;
		((L_1681)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1682)))->___firstCharacterIndex_0 = L_1683;
		goto IL_307a;
	}

IL_2fd8:
	{
		int32_t L_1684 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_1684) <= ((int32_t)0)))
		{
			goto IL_3006;
		}
	}
	{
		int32_t L_1685 = __this->___m_PageNumber_58;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1686 = ___1_textInfo;
		NullCheck(L_1686);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1687 = L_1686->___textElementInfo_10;
		int32_t L_1688 = __this->___m_CharacterCount_48;
		NullCheck(L_1687);
		int32_t L_1689 = ((L_1687)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1688, 1)))))->___pageNumber_12;
		G_B439_0 = ((((int32_t)((((int32_t)L_1685) == ((int32_t)L_1689))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_3007;
	}

IL_3006:
	{
		G_B439_0 = 0;
	}

IL_3007:
	{
		V_224 = (bool)G_B439_0;
		bool L_1690 = V_224;
		if (!L_1690)
		{
			goto IL_304d;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1691 = ___1_textInfo;
		NullCheck(L_1691);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1692 = L_1691->___pageInfo_14;
		int32_t L_1693 = __this->___m_PageNumber_58;
		NullCheck(L_1692);
		int32_t L_1694 = __this->___m_CharacterCount_48;
		((L_1692)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_1693, 1)))))->___lastCharacterIndex_1 = ((int32_t)il2cpp_codegen_subtract(L_1694, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1695 = ___1_textInfo;
		NullCheck(L_1695);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1696 = L_1695->___pageInfo_14;
		int32_t L_1697 = __this->___m_PageNumber_58;
		NullCheck(L_1696);
		int32_t L_1698 = __this->___m_CharacterCount_48;
		((L_1696)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1697)))->___firstCharacterIndex_0 = L_1698;
		goto IL_307a;
	}

IL_304d:
	{
		int32_t L_1699 = __this->___m_CharacterCount_48;
		int32_t L_1700 = V_0;
		V_225 = (bool)((((int32_t)L_1699) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1700, 1))))? 1 : 0);
		bool L_1701 = V_225;
		if (!L_1701)
		{
			goto IL_307a;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1702 = ___1_textInfo;
		NullCheck(L_1702);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1703 = L_1702->___pageInfo_14;
		int32_t L_1704 = __this->___m_PageNumber_58;
		NullCheck(L_1703);
		int32_t L_1705 = __this->___m_CharacterCount_48;
		((L_1703)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1704)))->___lastCharacterIndex_1 = L_1705;
	}

IL_307a:
	{
	}

IL_307b:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1706 = ___0_generationSettings;
		NullCheck(L_1706);
		bool L_1707 = L_1706->___wordWrap_12;
		if (L_1707)
		{
			goto IL_3097;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1708 = ___0_generationSettings;
		NullCheck(L_1708);
		int32_t L_1709 = L_1708->___overflowMode_11;
		if ((((int32_t)L_1709) == ((int32_t)3)))
		{
			goto IL_3097;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1710 = ___0_generationSettings;
		NullCheck(L_1710);
		int32_t L_1711 = L_1710->___overflowMode_11;
		G_B448_0 = ((((int32_t)L_1711) == ((int32_t)1))? 1 : 0);
		goto IL_3098;
	}

IL_3097:
	{
		G_B448_0 = 1;
	}

IL_3098:
	{
		V_226 = (bool)G_B448_0;
		bool L_1712 = V_226;
		if (!L_1712)
		{
			goto IL_327a;
		}
	}
	{
		int32_t L_1713 = V_60;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_1714;
		L_1714 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(((int32_t)(uint16_t)L_1713), NULL);
		if (L_1714)
		{
			goto IL_30c4;
		}
	}
	{
		int32_t L_1715 = V_60;
		if ((((int32_t)L_1715) == ((int32_t)((int32_t)8203))))
		{
			goto IL_30c4;
		}
	}
	{
		int32_t L_1716 = V_60;
		if ((((int32_t)L_1716) == ((int32_t)((int32_t)45))))
		{
			goto IL_30c4;
		}
	}
	{
		int32_t L_1717 = V_60;
		if ((!(((uint32_t)L_1717) == ((uint32_t)((int32_t)173)))))
		{
			goto IL_3104;
		}
	}

IL_30c4:
	{
		bool L_1718 = __this->___m_IsNonBreakingSpace_67;
		bool L_1719 = V_28;
		if (!((int32_t)(((((int32_t)L_1718) == ((int32_t)0))? 1 : 0)|(int32_t)L_1719)))
		{
			goto IL_3104;
		}
	}
	{
		int32_t L_1720 = V_60;
		if ((((int32_t)L_1720) == ((int32_t)((int32_t)160))))
		{
			goto IL_3104;
		}
	}
	{
		int32_t L_1721 = V_60;
		if ((((int32_t)L_1721) == ((int32_t)((int32_t)8199))))
		{
			goto IL_3104;
		}
	}
	{
		int32_t L_1722 = V_60;
		if ((((int32_t)L_1722) == ((int32_t)((int32_t)8209))))
		{
			goto IL_3104;
		}
	}
	{
		int32_t L_1723 = V_60;
		if ((((int32_t)L_1723) == ((int32_t)((int32_t)8239))))
		{
			goto IL_3104;
		}
	}
	{
		int32_t L_1724 = V_60;
		G_B460_0 = ((((int32_t)((((int32_t)L_1724) == ((int32_t)((int32_t)8288)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_3105;
	}

IL_3104:
	{
		G_B460_0 = 0;
	}

IL_3105:
	{
		V_227 = (bool)G_B460_0;
		bool L_1725 = V_227;
		if (!L_1725)
		{
			goto IL_3132;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1726 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		int32_t L_1727 = V_59;
		int32_t L_1728 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1729 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1726, L_1727, L_1728, L_1729, NULL);
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)0;
		V_27 = (bool)0;
		goto IL_3279;
	}

IL_3132:
	{
		int32_t L_1730 = V_60;
		if ((((int32_t)L_1730) <= ((int32_t)((int32_t)4352))))
		{
			goto IL_3144;
		}
	}
	{
		int32_t L_1731 = V_60;
		if ((((int32_t)L_1731) < ((int32_t)((int32_t)4607))))
		{
			goto IL_31b0;
		}
	}

IL_3144:
	{
		int32_t L_1732 = V_60;
		if ((((int32_t)L_1732) <= ((int32_t)((int32_t)11904))))
		{
			goto IL_3156;
		}
	}
	{
		int32_t L_1733 = V_60;
		if ((((int32_t)L_1733) < ((int32_t)((int32_t)40959))))
		{
			goto IL_31b0;
		}
	}

IL_3156:
	{
		int32_t L_1734 = V_60;
		if ((((int32_t)L_1734) <= ((int32_t)((int32_t)43360))))
		{
			goto IL_3168;
		}
	}
	{
		int32_t L_1735 = V_60;
		if ((((int32_t)L_1735) < ((int32_t)((int32_t)43391))))
		{
			goto IL_31b0;
		}
	}

IL_3168:
	{
		int32_t L_1736 = V_60;
		if ((((int32_t)L_1736) <= ((int32_t)((int32_t)44032))))
		{
			goto IL_317a;
		}
	}
	{
		int32_t L_1737 = V_60;
		if ((((int32_t)L_1737) < ((int32_t)((int32_t)55295))))
		{
			goto IL_31b0;
		}
	}

IL_317a:
	{
		int32_t L_1738 = V_60;
		if ((((int32_t)L_1738) <= ((int32_t)((int32_t)63744))))
		{
			goto IL_318c;
		}
	}
	{
		int32_t L_1739 = V_60;
		if ((((int32_t)L_1739) < ((int32_t)((int32_t)64255))))
		{
			goto IL_31b0;
		}
	}

IL_318c:
	{
		int32_t L_1740 = V_60;
		if ((((int32_t)L_1740) <= ((int32_t)((int32_t)65072))))
		{
			goto IL_319e;
		}
	}
	{
		int32_t L_1741 = V_60;
		if ((((int32_t)L_1741) < ((int32_t)((int32_t)65103))))
		{
			goto IL_31b0;
		}
	}

IL_319e:
	{
		int32_t L_1742 = V_60;
		if ((((int32_t)L_1742) <= ((int32_t)((int32_t)65280))))
		{
			goto IL_31bb;
		}
	}
	{
		int32_t L_1743 = V_60;
		if ((((int32_t)L_1743) >= ((int32_t)((int32_t)65519))))
		{
			goto IL_31bb;
		}
	}

IL_31b0:
	{
		bool L_1744 = __this->___m_IsNonBreakingSpace_67;
		G_B478_0 = ((((int32_t)L_1744) == ((int32_t)0))? 1 : 0);
		goto IL_31bc;
	}

IL_31bb:
	{
		G_B478_0 = 0;
	}

IL_31bc:
	{
		V_228 = (bool)G_B478_0;
		bool L_1745 = V_228;
		if (!L_1745)
		{
			goto IL_324d;
		}
	}
	{
		bool L_1746 = V_27;
		bool L_1747 = V_29;
		if (((int32_t)((int32_t)L_1746|(int32_t)L_1747)))
		{
			goto IL_3221;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_1748 = V_23;
		NullCheck(L_1748);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_1749;
		L_1749 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_1748, NULL);
		NullCheck(L_1749);
		HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* L_1750;
		L_1750 = UnicodeLineBreakingRules_get_leadingCharactersLookup_m1DAC015D7E37112EAE0437E6472AEA0719DFF3DC(L_1749, NULL);
		int32_t L_1751 = V_60;
		NullCheck(L_1750);
		bool L_1752;
		L_1752 = HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9(L_1750, L_1751, HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		if (L_1752)
		{
			goto IL_321e;
		}
	}
	{
		int32_t L_1753 = __this->___m_CharacterCount_48;
		int32_t L_1754 = V_0;
		if ((((int32_t)L_1753) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_1754, 1)))))
		{
			goto IL_321b;
		}
	}
	{
		TextSettings_tB7F55685AFFD4A96F714427BCACFD6958E357D64* L_1755 = V_23;
		NullCheck(L_1755);
		UnicodeLineBreakingRules_t80BE36F5E16AE48FE7B6DE1C91D36B1142B4EC0E* L_1756;
		L_1756 = TextSettings_get_lineBreakingRules_m96E2C32D4F08309D904B0BCD83CEBE8CD6716A04(L_1755, NULL);
		NullCheck(L_1756);
		HashSet_1_t5DD20B42149A11AEBF12A75505306E6EFC34943A* L_1757;
		L_1757 = UnicodeLineBreakingRules_get_followingCharactersLookup_m5510A21873DC5DA66F4A2DFA4C26A5EFAD494D8B(L_1756, NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1758 = ___1_textInfo;
		NullCheck(L_1758);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_1759 = L_1758->___textElementInfo_10;
		int32_t L_1760 = __this->___m_CharacterCount_48;
		NullCheck(L_1759);
		Il2CppChar L_1761 = ((L_1759)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_1760, 1)))))->___character_0;
		NullCheck(L_1757);
		bool L_1762;
		L_1762 = HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9(L_1757, L_1761, HashSet_1_Contains_m02385B663B65E53485251FFFD116D0F26BA172B9_RuntimeMethod_var);
		G_B484_0 = ((((int32_t)L_1762) == ((int32_t)0))? 1 : 0);
		goto IL_321c;
	}

IL_321b:
	{
		G_B484_0 = 0;
	}

IL_321c:
	{
		G_B486_0 = G_B484_0;
		goto IL_321f;
	}

IL_321e:
	{
		G_B486_0 = 0;
	}

IL_321f:
	{
		G_B488_0 = G_B486_0;
		goto IL_3222;
	}

IL_3221:
	{
		G_B488_0 = 1;
	}

IL_3222:
	{
		V_229 = (bool)G_B488_0;
		bool L_1763 = V_229;
		if (!L_1763)
		{
			goto IL_324a;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1764 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		int32_t L_1765 = V_59;
		int32_t L_1766 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1767 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1764, L_1765, L_1766, L_1767, NULL);
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)0;
		V_27 = (bool)0;
	}

IL_324a:
	{
		goto IL_3279;
	}

IL_324d:
	{
		bool L_1768 = V_27;
		if (L_1768)
		{
			goto IL_3259;
		}
	}
	{
		bool L_1769 = __this->___m_IsCharacterWrappingEnabled_81;
		G_B494_0 = ((int32_t)(L_1769));
		goto IL_325a;
	}

IL_3259:
	{
		G_B494_0 = 1;
	}

IL_325a:
	{
		bool L_1770 = V_29;
		V_230 = (bool)((int32_t)(G_B494_0|(int32_t)L_1770));
		bool L_1771 = V_230;
		if (!L_1771)
		{
			goto IL_3279;
		}
	}
	{
		WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123* L_1772 = (WordWrapState_tD71131CF008362DB9562FB9794AE9D9225D8F123*)(&__this->___m_SavedWordWrapState_68);
		int32_t L_1773 = V_59;
		int32_t L_1774 = __this->___m_CharacterCount_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1775 = ___1_textInfo;
		TextGenerator_SaveWordWrappingState_mC07B2C5977EECE10216F8C6AC9CC4204F7EF1936(__this, L_1772, L_1773, L_1774, L_1775, NULL);
	}

IL_3279:
	{
	}

IL_327a:
	{
		int32_t L_1776 = __this->___m_CharacterCount_48;
		__this->___m_CharacterCount_48 = ((int32_t)il2cpp_codegen_add(L_1776, 1));
	}

IL_3289:
	{
		int32_t L_1777 = V_59;
		V_149 = L_1777;
		int32_t L_1778 = V_149;
		V_59 = ((int32_t)il2cpp_codegen_add(L_1778, 1));
	}

IL_3293:
	{
		int32_t L_1779 = V_59;
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1780 = __this->___m_CharBuffer_4;
		NullCheck(L_1780);
		if ((((int32_t)L_1779) >= ((int32_t)((int32_t)(((RuntimeArray*)L_1780)->max_length)))))
		{
			goto IL_32ad;
		}
	}
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_1781 = __this->___m_CharBuffer_4;
		int32_t L_1782 = V_59;
		NullCheck(L_1781);
		int32_t L_1783 = L_1782;
		int32_t L_1784 = (L_1781)->GetAt(static_cast<il2cpp_array_size_t>(L_1783));
		G_B502_0 = ((!(((uint32_t)L_1784) <= ((uint32_t)0)))? 1 : 0);
		goto IL_32ae;
	}

IL_32ad:
	{
		G_B502_0 = 0;
	}

IL_32ae:
	{
		V_231 = (bool)G_B502_0;
		bool L_1785 = V_231;
		if (L_1785)
		{
			goto IL_0496;
		}
	}
	{
		float L_1786 = __this->___m_MaxFontSize_79;
		float L_1787 = __this->___m_MinFontSize_80;
		V_32 = ((float)il2cpp_codegen_subtract(L_1786, L_1787));
		bool L_1788 = __this->___m_IsCharacterWrappingEnabled_81;
		if (L_1788)
		{
			goto IL_32ef;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1789 = ___0_generationSettings;
		NullCheck(L_1789);
		bool L_1790 = L_1789->___autoSize_19;
		if (!L_1790)
		{
			goto IL_32ef;
		}
	}
	{
		float L_1791 = V_32;
		if ((!(((float)L_1791) > ((float)(0.050999999f)))))
		{
			goto IL_32ef;
		}
	}
	{
		float L_1792 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1793 = ___0_generationSettings;
		NullCheck(L_1793);
		float L_1794 = L_1793->___fontSizeMax_21;
		G_B508_0 = ((((float)L_1792) < ((float)L_1794))? 1 : 0);
		goto IL_32f0;
	}

IL_32ef:
	{
		G_B508_0 = 0;
	}

IL_32f0:
	{
		V_232 = (bool)G_B508_0;
		bool L_1795 = V_232;
		if (!L_1795)
		{
			goto IL_337f;
		}
	}
	{
		float L_1796 = __this->___m_FontSize_15;
		__this->___m_MinFontSize_80 = L_1796;
		float L_1797 = __this->___m_FontSize_15;
		float L_1798 = __this->___m_MaxFontSize_79;
		float L_1799 = __this->___m_FontSize_15;
		float L_1800;
		L_1800 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(((float)(((float)il2cpp_codegen_subtract(L_1798, L_1799))/(2.0f))), (0.0500000007f), NULL);
		__this->___m_FontSize_15 = ((float)il2cpp_codegen_add(L_1797, L_1800));
		float L_1801 = __this->___m_FontSize_15;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1802 = ___0_generationSettings;
		NullCheck(L_1802);
		float L_1803 = L_1802->___fontSizeMax_21;
		float L_1804;
		L_1804 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_1801, L_1803, NULL);
		__this->___m_FontSize_15 = ((float)(((float)il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1804, (20.0f))), (0.5f)))))/(20.0f)));
		int32_t L_1805 = __this->___m_LoopCountA_70;
		V_233 = (bool)((((int32_t)L_1805) > ((int32_t)((int32_t)20)))? 1 : 0);
		bool L_1806 = V_233;
		if (!L_1806)
		{
			goto IL_3371;
		}
	}
	{
		goto IL_6c59;
	}

IL_3371:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1807 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1808 = ___1_textInfo;
		TextGenerator_GenerateTextMesh_mAB70FC29A49A6C4F8211EA977E37C66BE67D1831(__this, L_1807, L_1808, NULL);
		goto IL_6c59;
	}

IL_337f:
	{
		__this->___m_IsCharacterWrappingEnabled_81 = (bool)0;
		int32_t L_1809 = __this->___m_CharacterCount_48;
		V_234 = (bool)((((int32_t)L_1809) == ((int32_t)0))? 1 : 0);
		bool L_1810 = V_234;
		if (!L_1810)
		{
			goto IL_33a3;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1811 = ___1_textInfo;
		TextGenerator_ClearMesh_m68BA46B0365FC730BA5D2E6BDF2528BD370B2D83((bool)1, L_1811, NULL);
		goto IL_6c59;
	}

IL_33a3:
	{
		MaterialReferenceU5BU5D_t4A9B88114E223BD96CE5121053664023CE2DE07E* L_1812 = __this->___m_MaterialReferences_85;
		NullCheck(L_1812);
		int32_t L_1813 = ((L_1812)->GetAddressAt(static_cast<il2cpp_array_size_t>(0)))->___referenceCount_8;
		V_33 = ((int32_t)il2cpp_codegen_multiply(L_1813, 4));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1814 = ___1_textInfo;
		NullCheck(L_1814);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_1815 = L_1814->___meshInfo_15;
		NullCheck(L_1815);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_Clear_m06992FEB7AC9B2AE1728BEDFC8D8A39DE1AAD475(((L_1815)->GetAddressAt(static_cast<il2cpp_array_size_t>(0))), (bool)0, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1816;
		L_1816 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_34 = L_1816;
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1817 = __this->___m_RectTransformCorners_1;
		V_35 = L_1817;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1818 = ___0_generationSettings;
		NullCheck(L_1818);
		int32_t L_1819 = L_1818->___textAlignment_10;
		V_236 = L_1819;
		int32_t L_1820 = V_236;
		V_235 = L_1820;
		int32_t L_1821 = V_235;
		if ((((int32_t)L_1821) > ((int32_t)((int32_t)1056))))
		{
			goto IL_3518;
		}
	}
	{
		int32_t L_1822 = V_235;
		if ((((int32_t)L_1822) > ((int32_t)((int32_t)516))))
		{
			goto IL_347f;
		}
	}
	{
		int32_t L_1823 = V_235;
		if ((((int32_t)L_1823) > ((int32_t)((int32_t)264))))
		{
			goto IL_3436;
		}
	}
	{
		int32_t L_1824 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1824, ((int32_t)257)))) > ((uint32_t)1))))
		{
			goto IL_363e;
		}
	}
	{
		goto IL_3417;
	}

IL_3417:
	{
		int32_t L_1825 = V_235;
		if ((((int32_t)L_1825) == ((int32_t)((int32_t)260))))
		{
			goto IL_363e;
		}
	}
	{
		goto IL_3425;
	}

IL_3425:
	{
		int32_t L_1826 = V_235;
		if ((((int32_t)L_1826) == ((int32_t)((int32_t)264))))
		{
			goto IL_363e;
		}
	}
	{
		goto IL_3989;
	}

IL_3436:
	{
		int32_t L_1827 = V_235;
		if ((((int32_t)L_1827) > ((int32_t)((int32_t)288))))
		{
			goto IL_345e;
		}
	}
	{
		int32_t L_1828 = V_235;
		if ((((int32_t)L_1828) == ((int32_t)((int32_t)272))))
		{
			goto IL_363e;
		}
	}
	{
		goto IL_344d;
	}

IL_344d:
	{
		int32_t L_1829 = V_235;
		if ((((int32_t)L_1829) == ((int32_t)((int32_t)288))))
		{
			goto IL_363e;
		}
	}
	{
		goto IL_3989;
	}

IL_345e:
	{
		int32_t L_1830 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1830, ((int32_t)513)))) > ((uint32_t)1))))
		{
			goto IL_36d7;
		}
	}
	{
		goto IL_346e;
	}

IL_346e:
	{
		int32_t L_1831 = V_235;
		if ((((int32_t)L_1831) == ((int32_t)((int32_t)516))))
		{
			goto IL_36d7;
		}
	}
	{
		goto IL_3989;
	}

IL_347f:
	{
		int32_t L_1832 = V_235;
		if ((((int32_t)L_1832) > ((int32_t)((int32_t)1026))))
		{
			goto IL_34d1;
		}
	}
	{
		int32_t L_1833 = V_235;
		if ((((int32_t)L_1833) > ((int32_t)((int32_t)528))))
		{
			goto IL_34b0;
		}
	}
	{
		int32_t L_1834 = V_235;
		if ((((int32_t)L_1834) == ((int32_t)((int32_t)520))))
		{
			goto IL_36d7;
		}
	}
	{
		goto IL_349f;
	}

IL_349f:
	{
		int32_t L_1835 = V_235;
		if ((((int32_t)L_1835) == ((int32_t)((int32_t)528))))
		{
			goto IL_36d7;
		}
	}
	{
		goto IL_3989;
	}

IL_34b0:
	{
		int32_t L_1836 = V_235;
		if ((((int32_t)L_1836) == ((int32_t)((int32_t)544))))
		{
			goto IL_36d7;
		}
	}
	{
		goto IL_34be;
	}

IL_34be:
	{
		int32_t L_1837 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1837, ((int32_t)1025)))) > ((uint32_t)1))))
		{
			goto IL_37d0;
		}
	}
	{
		goto IL_3989;
	}

IL_34d1:
	{
		int32_t L_1838 = V_235;
		if ((((int32_t)L_1838) > ((int32_t)((int32_t)1032))))
		{
			goto IL_34f9;
		}
	}
	{
		int32_t L_1839 = V_235;
		if ((((int32_t)L_1839) == ((int32_t)((int32_t)1028))))
		{
			goto IL_37d0;
		}
	}
	{
		goto IL_34e8;
	}

IL_34e8:
	{
		int32_t L_1840 = V_235;
		if ((((int32_t)L_1840) == ((int32_t)((int32_t)1032))))
		{
			goto IL_37d0;
		}
	}
	{
		goto IL_3989;
	}

IL_34f9:
	{
		int32_t L_1841 = V_235;
		if ((((int32_t)L_1841) == ((int32_t)((int32_t)1040))))
		{
			goto IL_37d0;
		}
	}
	{
		goto IL_3507;
	}

IL_3507:
	{
		int32_t L_1842 = V_235;
		if ((((int32_t)L_1842) == ((int32_t)((int32_t)1056))))
		{
			goto IL_37d0;
		}
	}
	{
		goto IL_3989;
	}

IL_3518:
	{
		int32_t L_1843 = V_235;
		if ((((int32_t)L_1843) > ((int32_t)((int32_t)4100))))
		{
			goto IL_35a5;
		}
	}
	{
		int32_t L_1844 = V_235;
		if ((((int32_t)L_1844) > ((int32_t)((int32_t)2056))))
		{
			goto IL_355c;
		}
	}
	{
		int32_t L_1845 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1845, ((int32_t)2049)))) > ((uint32_t)1))))
		{
			goto IL_3865;
		}
	}
	{
		goto IL_353d;
	}

IL_353d:
	{
		int32_t L_1846 = V_235;
		if ((((int32_t)L_1846) == ((int32_t)((int32_t)2052))))
		{
			goto IL_3865;
		}
	}
	{
		goto IL_354b;
	}

IL_354b:
	{
		int32_t L_1847 = V_235;
		if ((((int32_t)L_1847) == ((int32_t)((int32_t)2056))))
		{
			goto IL_3865;
		}
	}
	{
		goto IL_3989;
	}

IL_355c:
	{
		int32_t L_1848 = V_235;
		if ((((int32_t)L_1848) > ((int32_t)((int32_t)2080))))
		{
			goto IL_3584;
		}
	}
	{
		int32_t L_1849 = V_235;
		if ((((int32_t)L_1849) == ((int32_t)((int32_t)2064))))
		{
			goto IL_3865;
		}
	}
	{
		goto IL_3573;
	}

IL_3573:
	{
		int32_t L_1850 = V_235;
		if ((((int32_t)L_1850) == ((int32_t)((int32_t)2080))))
		{
			goto IL_3865;
		}
	}
	{
		goto IL_3989;
	}

IL_3584:
	{
		int32_t L_1851 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1851, ((int32_t)4097)))) > ((uint32_t)1))))
		{
			goto IL_38ac;
		}
	}
	{
		goto IL_3594;
	}

IL_3594:
	{
		int32_t L_1852 = V_235;
		if ((((int32_t)L_1852) == ((int32_t)((int32_t)4100))))
		{
			goto IL_38ac;
		}
	}
	{
		goto IL_3989;
	}

IL_35a5:
	{
		int32_t L_1853 = V_235;
		if ((((int32_t)L_1853) > ((int32_t)((int32_t)8194))))
		{
			goto IL_35f7;
		}
	}
	{
		int32_t L_1854 = V_235;
		if ((((int32_t)L_1854) > ((int32_t)((int32_t)4112))))
		{
			goto IL_35d6;
		}
	}
	{
		int32_t L_1855 = V_235;
		if ((((int32_t)L_1855) == ((int32_t)((int32_t)4104))))
		{
			goto IL_38ac;
		}
	}
	{
		goto IL_35c5;
	}

IL_35c5:
	{
		int32_t L_1856 = V_235;
		if ((((int32_t)L_1856) == ((int32_t)((int32_t)4112))))
		{
			goto IL_38ac;
		}
	}
	{
		goto IL_3989;
	}

IL_35d6:
	{
		int32_t L_1857 = V_235;
		if ((((int32_t)L_1857) == ((int32_t)((int32_t)4128))))
		{
			goto IL_38ac;
		}
	}
	{
		goto IL_35e4;
	}

IL_35e4:
	{
		int32_t L_1858 = V_235;
		if ((!(((uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)L_1858, ((int32_t)8193)))) > ((uint32_t)1))))
		{
			goto IL_3928;
		}
	}
	{
		goto IL_3989;
	}

IL_35f7:
	{
		int32_t L_1859 = V_235;
		if ((((int32_t)L_1859) > ((int32_t)((int32_t)8200))))
		{
			goto IL_361f;
		}
	}
	{
		int32_t L_1860 = V_235;
		if ((((int32_t)L_1860) == ((int32_t)((int32_t)8196))))
		{
			goto IL_3928;
		}
	}
	{
		goto IL_360e;
	}

IL_360e:
	{
		int32_t L_1861 = V_235;
		if ((((int32_t)L_1861) == ((int32_t)((int32_t)8200))))
		{
			goto IL_3928;
		}
	}
	{
		goto IL_3989;
	}

IL_361f:
	{
		int32_t L_1862 = V_235;
		if ((((int32_t)L_1862) == ((int32_t)((int32_t)8208))))
		{
			goto IL_3928;
		}
	}
	{
		goto IL_362d;
	}

IL_362d:
	{
		int32_t L_1863 = V_235;
		if ((((int32_t)L_1863) == ((int32_t)((int32_t)8224))))
		{
			goto IL_3928;
		}
	}
	{
		goto IL_3989;
	}

IL_363e:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1864 = ___0_generationSettings;
		NullCheck(L_1864);
		int32_t L_1865 = L_1864->___overflowMode_11;
		V_237 = (bool)((((int32_t)((((int32_t)L_1865) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1866 = V_237;
		if (!L_1866)
		{
			goto IL_368c;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1867 = V_35;
		NullCheck(L_1867);
		int32_t L_1868 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1869 = (L_1867)->GetAt(static_cast<il2cpp_array_size_t>(L_1868));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1870 = V_19;
		float L_1871 = L_1870.___x_1;
		float L_1872 = __this->___m_MaxAscender_64;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1873 = V_19;
		float L_1874 = L_1873.___y_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1875;
		memset((&L_1875), 0, sizeof(L_1875));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1875), ((float)il2cpp_codegen_add((0.0f), L_1871)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract((0.0f), L_1872)), L_1874)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1876;
		L_1876 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1869, L_1875, NULL);
		V_34 = L_1876;
		goto IL_36d2;
	}

IL_368c:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1877 = V_35;
		NullCheck(L_1877);
		int32_t L_1878 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1879 = (L_1877)->GetAt(static_cast<il2cpp_array_size_t>(L_1878));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1880 = V_19;
		float L_1881 = L_1880.___x_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1882 = ___1_textInfo;
		NullCheck(L_1882);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1883 = L_1882->___pageInfo_14;
		int32_t L_1884 = V_16;
		NullCheck(L_1883);
		float L_1885 = ((L_1883)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1884)))->___ascender_2;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1886 = V_19;
		float L_1887 = L_1886.___y_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1888;
		memset((&L_1888), 0, sizeof(L_1888));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1888), ((float)il2cpp_codegen_add((0.0f), L_1881)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract((0.0f), L_1885)), L_1887)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1889;
		L_1889 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1879, L_1888, NULL);
		V_34 = L_1889;
	}

IL_36d2:
	{
		goto IL_3989;
	}

IL_36d7:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1890 = ___0_generationSettings;
		NullCheck(L_1890);
		int32_t L_1891 = L_1890->___overflowMode_11;
		V_238 = (bool)((((int32_t)((((int32_t)L_1891) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1892 = V_238;
		if (!L_1892)
		{
			goto IL_374d;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1893 = V_35;
		NullCheck(L_1893);
		int32_t L_1894 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1895 = (L_1893)->GetAt(static_cast<il2cpp_array_size_t>(L_1894));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1896 = V_35;
		NullCheck(L_1896);
		int32_t L_1897 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1898 = (L_1896)->GetAt(static_cast<il2cpp_array_size_t>(L_1897));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1899;
		L_1899 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1895, L_1898, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1900;
		L_1900 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1899, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1901 = V_19;
		float L_1902 = L_1901.___x_1;
		float L_1903 = __this->___m_MaxAscender_64;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1904 = V_19;
		float L_1905 = L_1904.___y_2;
		float L_1906 = V_25;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1907 = V_19;
		float L_1908 = L_1907.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1909;
		memset((&L_1909), 0, sizeof(L_1909));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1909), ((float)il2cpp_codegen_add((0.0f), L_1902)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1903, L_1905)), L_1906)), L_1908))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1910;
		L_1910 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1900, L_1909, NULL);
		V_34 = L_1910;
		goto IL_37cb;
	}

IL_374d:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1911 = V_35;
		NullCheck(L_1911);
		int32_t L_1912 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1913 = (L_1911)->GetAt(static_cast<il2cpp_array_size_t>(L_1912));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1914 = V_35;
		NullCheck(L_1914);
		int32_t L_1915 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1916 = (L_1914)->GetAt(static_cast<il2cpp_array_size_t>(L_1915));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1917;
		L_1917 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1913, L_1916, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1918;
		L_1918 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1917, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1919 = V_19;
		float L_1920 = L_1919.___x_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1921 = ___1_textInfo;
		NullCheck(L_1921);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1922 = L_1921->___pageInfo_14;
		int32_t L_1923 = V_16;
		NullCheck(L_1922);
		float L_1924 = ((L_1922)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1923)))->___ascender_2;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1925 = V_19;
		float L_1926 = L_1925.___y_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1927 = ___1_textInfo;
		NullCheck(L_1927);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1928 = L_1927->___pageInfo_14;
		int32_t L_1929 = V_16;
		NullCheck(L_1928);
		float L_1930 = ((L_1928)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1929)))->___descender_4;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1931 = V_19;
		float L_1932 = L_1931.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1933;
		memset((&L_1933), 0, sizeof(L_1933));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1933), ((float)il2cpp_codegen_add((0.0f), L_1920)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1924, L_1926)), L_1930)), L_1932))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1934;
		L_1934 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1918, L_1933, NULL);
		V_34 = L_1934;
	}

IL_37cb:
	{
		goto IL_3989;
	}

IL_37d0:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_1935 = ___0_generationSettings;
		NullCheck(L_1935);
		int32_t L_1936 = L_1935->___overflowMode_11;
		V_239 = (bool)((((int32_t)((((int32_t)L_1936) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_1937 = V_239;
		if (!L_1937)
		{
			goto IL_381a;
		}
	}
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1938 = V_35;
		NullCheck(L_1938);
		int32_t L_1939 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1940 = (L_1938)->GetAt(static_cast<il2cpp_array_size_t>(L_1939));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1941 = V_19;
		float L_1942 = L_1941.___x_1;
		float L_1943 = V_25;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1944 = V_19;
		float L_1945 = L_1944.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1946;
		memset((&L_1946), 0, sizeof(L_1946));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1946), ((float)il2cpp_codegen_add((0.0f), L_1942)), ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_1943)), L_1945)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1947;
		L_1947 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1940, L_1946, NULL);
		V_34 = L_1947;
		goto IL_3860;
	}

IL_381a:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1948 = V_35;
		NullCheck(L_1948);
		int32_t L_1949 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1950 = (L_1948)->GetAt(static_cast<il2cpp_array_size_t>(L_1949));
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1951 = V_19;
		float L_1952 = L_1951.___x_1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_1953 = ___1_textInfo;
		NullCheck(L_1953);
		PageInfoU5BU5D_tFEA2CF88695491CFC2F2A2EF6BDCC56E52B0A6D4* L_1954 = L_1953->___pageInfo_14;
		int32_t L_1955 = V_16;
		NullCheck(L_1954);
		float L_1956 = ((L_1954)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_1955)))->___descender_4;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1957 = V_19;
		float L_1958 = L_1957.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1959;
		memset((&L_1959), 0, sizeof(L_1959));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1959), ((float)il2cpp_codegen_add((0.0f), L_1952)), ((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract((0.0f), L_1956)), L_1958)), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1960;
		L_1960 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1950, L_1959, NULL);
		V_34 = L_1960;
	}

IL_3860:
	{
		goto IL_3989;
	}

IL_3865:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1961 = V_35;
		NullCheck(L_1961);
		int32_t L_1962 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1963 = (L_1961)->GetAt(static_cast<il2cpp_array_size_t>(L_1962));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1964 = V_35;
		NullCheck(L_1964);
		int32_t L_1965 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1966 = (L_1964)->GetAt(static_cast<il2cpp_array_size_t>(L_1965));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1967;
		L_1967 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1963, L_1966, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1968;
		L_1968 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1967, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1969 = V_19;
		float L_1970 = L_1969.___x_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1971;
		memset((&L_1971), 0, sizeof(L_1971));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1971), ((float)il2cpp_codegen_add((0.0f), L_1970)), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1972;
		L_1972 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1968, L_1971, NULL);
		V_34 = L_1972;
		goto IL_3989;
	}

IL_38ac:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1973 = V_35;
		NullCheck(L_1973);
		int32_t L_1974 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1975 = (L_1973)->GetAt(static_cast<il2cpp_array_size_t>(L_1974));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1976 = V_35;
		NullCheck(L_1976);
		int32_t L_1977 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1978 = (L_1976)->GetAt(static_cast<il2cpp_array_size_t>(L_1977));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1979;
		L_1979 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1975, L_1978, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1980;
		L_1980 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_1979, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1981 = V_19;
		float L_1982 = L_1981.___x_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1983 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1984 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1983->___max_1);
		float L_1985 = L_1984->___y_1;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1986 = V_19;
		float L_1987 = L_1986.___y_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_1988 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_1989 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_1988->___min_0);
		float L_1990 = L_1989->___y_1;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_1991 = V_19;
		float L_1992 = L_1991.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1993;
		memset((&L_1993), 0, sizeof(L_1993));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_1993), ((float)il2cpp_codegen_add((0.0f), L_1982)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_1985, L_1987)), L_1990)), L_1992))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1994;
		L_1994 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1980, L_1993, NULL);
		V_34 = L_1994;
		goto IL_3989;
	}

IL_3928:
	{
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1995 = V_35;
		NullCheck(L_1995);
		int32_t L_1996 = 0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1997 = (L_1995)->GetAt(static_cast<il2cpp_array_size_t>(L_1996));
		Vector3U5BU5D_tFF1859CCE176131B909E2044F76443064254679C* L_1998 = V_35;
		NullCheck(L_1998);
		int32_t L_1999 = 1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2000 = (L_1998)->GetAt(static_cast<il2cpp_array_size_t>(L_1999));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2001;
		L_2001 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_1997, L_2000, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2002;
		L_2002 = Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline(L_2001, (2.0f), NULL);
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2003 = V_19;
		float L_2004 = L_2003.___x_1;
		float L_2005 = __this->___m_MaxCapHeight_63;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2006 = V_19;
		float L_2007 = L_2006.___y_2;
		Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 L_2008 = V_19;
		float L_2009 = L_2008.___w_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2010;
		memset((&L_2010), 0, sizeof(L_2010));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2010), ((float)il2cpp_codegen_add((0.0f), L_2004)), ((float)il2cpp_codegen_subtract((0.0f), ((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_subtract(L_2005, L_2007)), L_2009))/(2.0f))))), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2011;
		L_2011 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2002, L_2010, NULL);
		V_34 = L_2011;
		goto IL_3989;
	}

IL_3989:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2012;
		L_2012 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		V_36 = L_2012;
		V_37 = 0;
		V_38 = 0;
		V_39 = 0;
		V_40 = (bool)0;
		V_41 = (bool)0;
		V_42 = 0;
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_2013;
		L_2013 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2014;
		L_2014 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_2013, NULL);
		V_43 = L_2014;
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_2015;
		L_2015 = Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline(NULL);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_2016;
		L_2016 = Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline(L_2015, NULL);
		V_44 = L_2016;
		Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline((&V_45), (uint8_t)((int32_t)255), (uint8_t)((int32_t)255), (uint8_t)0, (uint8_t)((int32_t)64), NULL);
		V_46 = (0.0f);
		V_47 = (0.0f);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		V_50 = 0;
		V_51 = (0.0f);
		V_52 = (0.0f);
		V_53 = (0.0f);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2017 = ___1_textInfo;
		NullCheck(L_2017);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2018 = L_2017->___textElementInfo_10;
		V_54 = L_2018;
		V_240 = 0;
		goto IL_6b32;
	}

IL_3a12:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2019 = V_54;
		int32_t L_2020 = V_240;
		NullCheck(L_2019);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_2021 = ((L_2019)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2020)))->___fontAsset_4;
		V_241 = L_2021;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2022 = V_54;
		int32_t L_2023 = V_240;
		NullCheck(L_2022);
		Il2CppChar L_2024 = ((L_2022)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2023)))->___character_0;
		V_242 = L_2024;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2025 = V_54;
		int32_t L_2026 = V_240;
		NullCheck(L_2025);
		int32_t L_2027 = ((L_2025)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2026)))->___lineNumber_11;
		V_243 = L_2027;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_2028 = ___1_textInfo;
		NullCheck(L_2028);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_2029 = L_2028->___lineInfo_13;
		int32_t L_2030 = V_243;
		NullCheck(L_2029);
		int32_t L_2031 = L_2030;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2032 = (L_2029)->GetAt(static_cast<il2cpp_array_size_t>(L_2031));
		V_244 = L_2032;
		int32_t L_2033 = V_243;
		V_38 = ((int32_t)il2cpp_codegen_add(L_2033, 1));
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2034 = V_244;
		int32_t L_2035 = L_2034.___alignment_19;
		V_245 = L_2035;
		int32_t L_2036 = V_245;
		V_257 = L_2036;
		int32_t L_2037 = V_257;
		V_256 = L_2037;
		int32_t L_2038 = V_256;
		if ((((int32_t)L_2038) > ((int32_t)((int32_t)1056))))
		{
			goto IL_3bc6;
		}
	}
	{
		int32_t L_2039 = V_256;
		if ((((int32_t)L_2039) > ((int32_t)((int32_t)520))))
		{
			goto IL_3b36;
		}
	}
	{
		int32_t L_2040 = V_256;
		if ((((int32_t)L_2040) > ((int32_t)((int32_t)272))))
		{
			goto IL_3aec;
		}
	}
	{
		int32_t L_2041 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2041, ((int32_t)257))))
		{
			case 0:
			{
				goto IL_3d07;
			}
			case 1:
			{
				goto IL_3d61;
			}
			case 2:
			{
				goto IL_41e9;
			}
			case 3:
			{
				goto IL_3def;
			}
		}
	}
	{
		goto IL_3ac5;
	}

IL_3ac5:
	{
		int32_t L_2042 = V_256;
		if ((((int32_t)L_2042) == ((int32_t)((int32_t)264))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3ad7;
	}

IL_3ad7:
	{
		int32_t L_2043 = V_256;
		if ((((int32_t)L_2043) == ((int32_t)((int32_t)272))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_41e9;
	}

IL_3aec:
	{
		int32_t L_2044 = V_256;
		if ((((int32_t)L_2044) == ((int32_t)((int32_t)288))))
		{
			goto IL_3d9a;
		}
	}
	{
		goto IL_3afe;
	}

IL_3afe:
	{
		int32_t L_2045 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2045, ((int32_t)513))))
		{
			case 0:
			{
				goto IL_3d07;
			}
			case 1:
			{
				goto IL_3d61;
			}
			case 2:
			{
				goto IL_41e9;
			}
			case 3:
			{
				goto IL_3def;
			}
		}
	}
	{
		goto IL_3b21;
	}

IL_3b21:
	{
		int32_t L_2046 = V_256;
		if ((((int32_t)L_2046) == ((int32_t)((int32_t)520))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_41e9;
	}

IL_3b36:
	{
		int32_t L_2047 = V_256;
		if ((((int32_t)L_2047) > ((int32_t)((int32_t)1028))))
		{
			goto IL_3b8d;
		}
	}
	{
		int32_t L_2048 = V_256;
		if ((((int32_t)L_2048) == ((int32_t)((int32_t)528))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3b55;
	}

IL_3b55:
	{
		int32_t L_2049 = V_256;
		if ((((int32_t)L_2049) == ((int32_t)((int32_t)544))))
		{
			goto IL_3d9a;
		}
	}
	{
		goto IL_3b67;
	}

IL_3b67:
	{
		int32_t L_2050 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2050, ((int32_t)1025))))
		{
			case 0:
			{
				goto IL_3d07;
			}
			case 1:
			{
				goto IL_3d61;
			}
			case 2:
			{
				goto IL_41e9;
			}
			case 3:
			{
				goto IL_3def;
			}
		}
	}
	{
		goto IL_41e9;
	}

IL_3b8d:
	{
		int32_t L_2051 = V_256;
		if ((((int32_t)L_2051) == ((int32_t)((int32_t)1032))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3b9f;
	}

IL_3b9f:
	{
		int32_t L_2052 = V_256;
		if ((((int32_t)L_2052) == ((int32_t)((int32_t)1040))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3bb1;
	}

IL_3bb1:
	{
		int32_t L_2053 = V_256;
		if ((((int32_t)L_2053) == ((int32_t)((int32_t)1056))))
		{
			goto IL_3d9a;
		}
	}
	{
		goto IL_41e9;
	}

IL_3bc6:
	{
		int32_t L_2054 = V_256;
		if ((((int32_t)L_2054) > ((int32_t)((int32_t)4104))))
		{
			goto IL_3c77;
		}
	}
	{
		int32_t L_2055 = V_256;
		if ((((int32_t)L_2055) > ((int32_t)((int32_t)2064))))
		{
			goto IL_3c2d;
		}
	}
	{
		int32_t L_2056 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2056, ((int32_t)2049))))
		{
			case 0:
			{
				goto IL_3d07;
			}
			case 1:
			{
				goto IL_3d61;
			}
			case 2:
			{
				goto IL_41e9;
			}
			case 3:
			{
				goto IL_3def;
			}
		}
	}
	{
		goto IL_3c06;
	}

IL_3c06:
	{
		int32_t L_2057 = V_256;
		if ((((int32_t)L_2057) == ((int32_t)((int32_t)2056))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3c18;
	}

IL_3c18:
	{
		int32_t L_2058 = V_256;
		if ((((int32_t)L_2058) == ((int32_t)((int32_t)2064))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_41e9;
	}

IL_3c2d:
	{
		int32_t L_2059 = V_256;
		if ((((int32_t)L_2059) == ((int32_t)((int32_t)2080))))
		{
			goto IL_3d9a;
		}
	}
	{
		goto IL_3c3f;
	}

IL_3c3f:
	{
		int32_t L_2060 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2060, ((int32_t)4097))))
		{
			case 0:
			{
				goto IL_3d07;
			}
			case 1:
			{
				goto IL_3d61;
			}
			case 2:
			{
				goto IL_41e9;
			}
			case 3:
			{
				goto IL_3def;
			}
		}
	}
	{
		goto IL_3c62;
	}

IL_3c62:
	{
		int32_t L_2061 = V_256;
		if ((((int32_t)L_2061) == ((int32_t)((int32_t)4104))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_41e9;
	}

IL_3c77:
	{
		int32_t L_2062 = V_256;
		if ((((int32_t)L_2062) > ((int32_t)((int32_t)8196))))
		{
			goto IL_3cce;
		}
	}
	{
		int32_t L_2063 = V_256;
		if ((((int32_t)L_2063) == ((int32_t)((int32_t)4112))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3c96;
	}

IL_3c96:
	{
		int32_t L_2064 = V_256;
		if ((((int32_t)L_2064) == ((int32_t)((int32_t)4128))))
		{
			goto IL_3d9a;
		}
	}
	{
		goto IL_3ca8;
	}

IL_3ca8:
	{
		int32_t L_2065 = V_256;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_2065, ((int32_t)8193))))
		{
			case 0:
			{
				goto IL_3d07;
			}
			case 1:
			{
				goto IL_3d61;
			}
			case 2:
			{
				goto IL_41e9;
			}
			case 3:
			{
				goto IL_3def;
			}
		}
	}
	{
		goto IL_41e9;
	}

IL_3cce:
	{
		int32_t L_2066 = V_256;
		if ((((int32_t)L_2066) == ((int32_t)((int32_t)8200))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3ce0;
	}

IL_3ce0:
	{
		int32_t L_2067 = V_256;
		if ((((int32_t)L_2067) == ((int32_t)((int32_t)8208))))
		{
			goto IL_3e55;
		}
	}
	{
		goto IL_3cf2;
	}

IL_3cf2:
	{
		int32_t L_2068 = V_256;
		if ((((int32_t)L_2068) == ((int32_t)((int32_t)8224))))
		{
			goto IL_3d9a;
		}
	}
	{
		goto IL_41e9;
	}

IL_3d07:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2069 = ___0_generationSettings;
		NullCheck(L_2069);
		bool L_2070 = L_2069->___isRightToLeft_24;
		V_258 = (bool)((((int32_t)L_2070) == ((int32_t)0))? 1 : 0);
		bool L_2071 = V_258;
		if (!L_2071)
		{
			goto IL_3d3e;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2072 = V_244;
		float L_2073 = L_2072.___marginLeft_17;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add((0.0f), L_2073)), (0.0f), (0.0f), NULL);
		goto IL_3d5c;
	}

IL_3d3e:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2074 = V_244;
		float L_2075 = L_2074.___maxAdvance_15;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract((0.0f), L_2075)), (0.0f), (0.0f), NULL);
	}

IL_3d5c:
	{
		goto IL_41e9;
	}

IL_3d61:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2076 = V_244;
		float L_2077 = L_2076.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2078 = V_244;
		float L_2079 = L_2078.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2080 = V_244;
		float L_2081 = L_2080.___maxAdvance_15;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2077, ((float)(L_2079/(2.0f))))), ((float)(L_2081/(2.0f))))), (0.0f), (0.0f), NULL);
		goto IL_41e9;
	}

IL_3d9a:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2082 = V_244;
		float L_2083 = L_2082.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2084 = V_244;
		float L_2085 = L_2084.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2086 = V_244;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2087 = L_2086.___lineExtents_20;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2088 = L_2087.___min_0;
		float L_2089 = L_2088.___x_0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2090 = V_244;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2091 = L_2090.___lineExtents_20;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2092 = L_2091.___max_1;
		float L_2093 = L_2092.___x_0;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2083, ((float)(L_2085/(2.0f))))), ((float)(((float)il2cpp_codegen_add(L_2089, L_2093))/(2.0f))))), (0.0f), (0.0f), NULL);
		goto IL_41e9;
	}

IL_3def:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2094 = ___0_generationSettings;
		NullCheck(L_2094);
		bool L_2095 = L_2094->___isRightToLeft_24;
		V_259 = (bool)((((int32_t)L_2095) == ((int32_t)0))? 1 : 0);
		bool L_2096 = V_259;
		if (!L_2096)
		{
			goto IL_3e30;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2097 = V_244;
		float L_2098 = L_2097.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2099 = V_244;
		float L_2100 = L_2099.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2101 = V_244;
		float L_2102 = L_2101.___maxAdvance_15;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2098, L_2100)), L_2102)), (0.0f), (0.0f), NULL);
		goto IL_3e50;
	}

IL_3e30:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2103 = V_244;
		float L_2104 = L_2103.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2105 = V_244;
		float L_2106 = L_2105.___width_16;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add(L_2104, L_2106)), (0.0f), (0.0f), NULL);
	}

IL_3e50:
	{
		goto IL_41e9;
	}

IL_3e55:
	{
		Il2CppChar L_2107 = V_242;
		if ((((int32_t)L_2107) == ((int32_t)((int32_t)173))))
		{
			goto IL_3e72;
		}
	}
	{
		Il2CppChar L_2108 = V_242;
		if ((((int32_t)L_2108) == ((int32_t)((int32_t)8203))))
		{
			goto IL_3e72;
		}
	}
	{
		Il2CppChar L_2109 = V_242;
		G_B672_0 = ((((int32_t)L_2109) == ((int32_t)((int32_t)8288)))? 1 : 0);
		goto IL_3e73;
	}

IL_3e72:
	{
		G_B672_0 = 1;
	}

IL_3e73:
	{
		V_260 = (bool)G_B672_0;
		bool L_2110 = V_260;
		if (!L_2110)
		{
			goto IL_3e86;
		}
	}
	{
		goto IL_41e9;
	}

IL_3e86:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2111 = V_54;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2112 = V_244;
		int32_t L_2113 = L_2112.___lastCharacterIndex_8;
		NullCheck(L_2111);
		Il2CppChar L_2114 = ((L_2111)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2113)))->___character_0;
		V_254 = L_2114;
		int32_t L_2115 = V_245;
		V_255 = (bool)((((int32_t)((int32_t)((int32_t)L_2115&((int32_t)16)))) == ((int32_t)((int32_t)16)))? 1 : 0);
		Il2CppChar L_2116 = V_254;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2117;
		L_2117 = Char_IsControl_m133C10360BE82B7580E4D3ECE3C881A6C82B3F7F(L_2116, NULL);
		if (L_2117)
		{
			goto IL_3ebf;
		}
	}
	{
		int32_t L_2118 = V_243;
		int32_t L_2119 = __this->___m_LineNumber_55;
		G_B677_0 = ((((int32_t)L_2118) < ((int32_t)L_2119))? 1 : 0);
		goto IL_3ec0;
	}

IL_3ebf:
	{
		G_B677_0 = 0;
	}

IL_3ec0:
	{
		bool L_2120 = V_255;
		if (((int32_t)(G_B677_0|(int32_t)L_2120)))
		{
			goto IL_3edb;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2121 = V_244;
		float L_2122 = L_2121.___maxAdvance_15;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2123 = V_244;
		float L_2124 = L_2123.___width_16;
		G_B680_0 = ((((float)L_2122) > ((float)L_2124))? 1 : 0);
		goto IL_3edc;
	}

IL_3edb:
	{
		G_B680_0 = 1;
	}

IL_3edc:
	{
		V_261 = (bool)G_B680_0;
		bool L_2125 = V_261;
		if (!L_2125)
		{
			goto IL_4194;
		}
	}
	{
		int32_t L_2126 = V_243;
		int32_t L_2127 = V_39;
		if ((!(((uint32_t)L_2126) == ((uint32_t)L_2127))))
		{
			goto IL_3f04;
		}
	}
	{
		int32_t L_2128 = V_240;
		if (!L_2128)
		{
			goto IL_3f04;
		}
	}
	{
		int32_t L_2129 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2130 = ___0_generationSettings;
		NullCheck(L_2130);
		int32_t L_2131 = L_2130->___firstVisibleCharacter_35;
		G_B685_0 = ((((int32_t)L_2129) == ((int32_t)L_2131))? 1 : 0);
		goto IL_3f05;
	}

IL_3f04:
	{
		G_B685_0 = 1;
	}

IL_3f05:
	{
		V_262 = (bool)G_B685_0;
		bool L_2132 = V_262;
		if (!L_2132)
		{
			goto IL_3f88;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2133 = ___0_generationSettings;
		NullCheck(L_2133);
		bool L_2134 = L_2133->___isRightToLeft_24;
		V_263 = (bool)((((int32_t)L_2134) == ((int32_t)0))? 1 : 0);
		bool L_2135 = V_263;
		if (!L_2135)
		{
			goto IL_3f45;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2136 = V_244;
		float L_2137 = L_2136.___marginLeft_17;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), L_2137, (0.0f), (0.0f), NULL);
		goto IL_3f65;
	}

IL_3f45:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2138 = V_244;
		float L_2139 = L_2138.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2140 = V_244;
		float L_2141 = L_2140.___width_16;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add(L_2139, L_2141)), (0.0f), (0.0f), NULL);
	}

IL_3f65:
	{
		Il2CppChar L_2142 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2143;
		L_2143 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_2142, NULL);
		V_264 = L_2143;
		bool L_2144 = V_264;
		if (!L_2144)
		{
			goto IL_3f7f;
		}
	}
	{
		V_40 = (bool)1;
		goto IL_3f82;
	}

IL_3f7f:
	{
		V_40 = (bool)0;
	}

IL_3f82:
	{
		goto IL_4191;
	}

IL_3f88:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2145 = ___0_generationSettings;
		NullCheck(L_2145);
		bool L_2146 = L_2145->___isRightToLeft_24;
		if (!L_2146)
		{
			goto IL_3fa2;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2147 = V_244;
		float L_2148 = L_2147.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2149 = V_244;
		float L_2150 = L_2149.___maxAdvance_15;
		G_B696_0 = ((float)il2cpp_codegen_add(L_2148, L_2150));
		goto IL_3fb1;
	}

IL_3fa2:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2151 = V_244;
		float L_2152 = L_2151.___width_16;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2153 = V_244;
		float L_2154 = L_2153.___maxAdvance_15;
		G_B696_0 = ((float)il2cpp_codegen_subtract(L_2152, L_2154));
	}

IL_3fb1:
	{
		V_265 = G_B696_0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2155 = V_244;
		int32_t L_2156 = L_2155.___visibleCharacterCount_2;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2157 = V_244;
		int32_t L_2158 = L_2157.___controlCharacterCount_0;
		V_266 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_2156, 1)), L_2158));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2159 = V_54;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2160 = V_244;
		int32_t L_2161 = L_2160.___lastCharacterIndex_8;
		NullCheck(L_2159);
		bool L_2162 = ((L_2159)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2161)))->___isVisible_34;
		if (L_2162)
		{
			goto IL_3fee;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2163 = V_244;
		int32_t L_2164 = L_2163.___spaceCount_3;
		G_B699_0 = ((int32_t)il2cpp_codegen_subtract(L_2164, 1));
		goto IL_3ff5;
	}

IL_3fee:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2165 = V_244;
		int32_t L_2166 = L_2165.___spaceCount_3;
		G_B699_0 = L_2166;
	}

IL_3ff5:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2167 = V_244;
		int32_t L_2168 = L_2167.___controlCharacterCount_0;
		V_267 = ((int32_t)il2cpp_codegen_subtract(G_B699_0, L_2168));
		bool L_2169 = V_40;
		V_269 = L_2169;
		bool L_2170 = V_269;
		if (!L_2170)
		{
			goto IL_4031;
		}
	}
	{
		int32_t L_2171 = V_267;
		V_267 = ((int32_t)il2cpp_codegen_subtract(L_2171, 1));
		int32_t L_2172 = V_266;
		V_266 = ((int32_t)il2cpp_codegen_add(L_2172, 1));
	}

IL_4031:
	{
		int32_t L_2173 = V_267;
		if ((((int32_t)L_2173) > ((int32_t)0)))
		{
			goto IL_4041;
		}
	}
	{
		G_B704_0 = (1.0f);
		goto IL_4047;
	}

IL_4041:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2174 = ___0_generationSettings;
		NullCheck(L_2174);
		float L_2175 = L_2174->___wordWrappingRatio_13;
		G_B704_0 = L_2175;
	}

IL_4047:
	{
		V_268 = G_B704_0;
		int32_t L_2176 = V_267;
		V_270 = (bool)((((int32_t)L_2176) < ((int32_t)1))? 1 : 0);
		bool L_2177 = V_270;
		if (!L_2177)
		{
			goto IL_406b;
		}
	}
	{
		V_267 = 1;
	}

IL_406b:
	{
		Il2CppChar L_2178 = V_242;
		if ((((int32_t)L_2178) == ((int32_t)((int32_t)160))))
		{
			goto IL_4086;
		}
	}
	{
		Il2CppChar L_2179 = V_242;
		if ((((int32_t)L_2179) == ((int32_t)((int32_t)9))))
		{
			goto IL_4083;
		}
	}
	{
		Il2CppChar L_2180 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_2181;
		L_2181 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_2180, NULL);
		G_B710_0 = ((int32_t)(L_2181));
		goto IL_4084;
	}

IL_4083:
	{
		G_B710_0 = 1;
	}

IL_4084:
	{
		G_B712_0 = G_B710_0;
		goto IL_4087;
	}

IL_4086:
	{
		G_B712_0 = 0;
	}

IL_4087:
	{
		V_271 = (bool)G_B712_0;
		bool L_2182 = V_271;
		if (!L_2182)
		{
			goto IL_411b;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2183 = ___0_generationSettings;
		NullCheck(L_2183);
		bool L_2184 = L_2183->___isRightToLeft_24;
		V_272 = (bool)((((int32_t)L_2184) == ((int32_t)0))? 1 : 0);
		bool L_2185 = V_272;
		if (!L_2185)
		{
			goto IL_40e5;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2186 = V_36;
		float L_2187 = V_265;
		float L_2188 = V_268;
		int32_t L_2189 = V_267;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2190;
		memset((&L_2190), 0, sizeof(L_2190));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2190), ((float)(((float)il2cpp_codegen_multiply(L_2187, ((float)il2cpp_codegen_subtract((1.0f), L_2188))))/((float)L_2189))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2191;
		L_2191 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2186, L_2190, NULL);
		V_36 = L_2191;
		goto IL_4118;
	}

IL_40e5:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2192 = V_36;
		float L_2193 = V_265;
		float L_2194 = V_268;
		int32_t L_2195 = V_267;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2196;
		memset((&L_2196), 0, sizeof(L_2196));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2196), ((float)(((float)il2cpp_codegen_multiply(L_2193, ((float)il2cpp_codegen_subtract((1.0f), L_2194))))/((float)L_2195))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2197;
		L_2197 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_2192, L_2196, NULL);
		V_36 = L_2197;
	}

IL_4118:
	{
		goto IL_4190;
	}

IL_411b:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2198 = ___0_generationSettings;
		NullCheck(L_2198);
		bool L_2199 = L_2198->___isRightToLeft_24;
		V_273 = (bool)((((int32_t)L_2199) == ((int32_t)0))? 1 : 0);
		bool L_2200 = V_273;
		if (!L_2200)
		{
			goto IL_4162;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2201 = V_36;
		float L_2202 = V_265;
		float L_2203 = V_268;
		int32_t L_2204 = V_266;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2205;
		memset((&L_2205), 0, sizeof(L_2205));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2205), ((float)(((float)il2cpp_codegen_multiply(L_2202, L_2203))/((float)L_2204))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2206;
		L_2206 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2201, L_2205, NULL);
		V_36 = L_2206;
		goto IL_418f;
	}

IL_4162:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2207 = V_36;
		float L_2208 = V_265;
		float L_2209 = V_268;
		int32_t L_2210 = V_266;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2211;
		memset((&L_2211), 0, sizeof(L_2211));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2211), ((float)(((float)il2cpp_codegen_multiply(L_2208, L_2209))/((float)L_2210))), (0.0f), (0.0f), /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2212;
		L_2212 = Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline(L_2207, L_2211, NULL);
		V_36 = L_2212;
	}

IL_418f:
	{
	}

IL_4190:
	{
	}

IL_4191:
	{
		goto IL_41e7;
	}

IL_4194:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2213 = ___0_generationSettings;
		NullCheck(L_2213);
		bool L_2214 = L_2213->___isRightToLeft_24;
		V_274 = (bool)((((int32_t)L_2214) == ((int32_t)0))? 1 : 0);
		bool L_2215 = V_274;
		if (!L_2215)
		{
			goto IL_41c6;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2216 = V_244;
		float L_2217 = L_2216.___marginLeft_17;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), L_2217, (0.0f), (0.0f), NULL);
		goto IL_41e6;
	}

IL_41c6:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2218 = V_244;
		float L_2219 = L_2218.___marginLeft_17;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2220 = V_244;
		float L_2221 = L_2220.___width_16;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_36), ((float)il2cpp_codegen_add(L_2219, L_2221)), (0.0f), (0.0f), NULL);
	}

IL_41e6:
	{
	}

IL_41e7:
	{
		goto IL_41e9;
	}

IL_41e9:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2222 = V_34;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2223 = V_36;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2224;
		L_2224 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2222, L_2223, NULL);
		V_246 = L_2224;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2225 = V_54;
		int32_t L_2226 = V_240;
		NullCheck(L_2225);
		bool L_2227 = ((L_2225)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2226)))->___isVisible_34;
		V_247 = L_2227;
		bool L_2228 = V_247;
		V_275 = L_2228;
		bool L_2229 = V_275;
		if (!L_2229)
		{
			goto IL_556b;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2230 = V_54;
		int32_t L_2231 = V_240;
		NullCheck(L_2230);
		uint8_t L_2232 = ((L_2230)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2231)))->___elementType_2;
		V_276 = L_2232;
		uint8_t L_2233 = V_276;
		V_280 = L_2233;
		uint8_t L_2234 = V_280;
		V_279 = L_2234;
		uint8_t L_2235 = V_279;
		if ((((int32_t)L_2235) == ((int32_t)1)))
		{
			goto IL_4260;
		}
	}
	{
		goto IL_424f;
	}

IL_424f:
	{
		uint8_t L_2236 = V_279;
		if ((((int32_t)L_2236) == ((int32_t)2)))
		{
			goto IL_5269;
		}
	}
	{
		goto IL_526b;
	}

IL_4260:
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2237 = V_244;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2238 = L_2237.___lineExtents_20;
		V_277 = L_2238;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2239 = ___0_generationSettings;
		NullCheck(L_2239);
		float L_2240 = L_2239->___uvLineOffset_41;
		int32_t L_2241 = V_243;
		V_278 = (fmodf(((float)il2cpp_codegen_multiply(L_2240, ((float)L_2241))), (1.0f)));
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2242 = ___0_generationSettings;
		NullCheck(L_2242);
		int32_t L_2243 = L_2242->___horizontalMapping_39;
		V_283 = L_2243;
		int32_t L_2244 = V_283;
		V_282 = L_2244;
		int32_t L_2245 = V_282;
		switch (L_2245)
		{
			case 0:
			{
				goto IL_42bb;
			}
			case 1:
			{
				goto IL_4334;
			}
			case 2:
			{
				goto IL_46d1;
			}
			case 3:
			{
				goto IL_489e;
			}
		}
	}
	{
		goto IL_4d19;
	}

IL_42bb:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2246 = V_54;
		int32_t L_2247 = V_240;
		NullCheck(L_2246);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2248 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2246)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2247)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2249 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2248->___uv2_2);
		L_2249->___x_0 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2250 = V_54;
		int32_t L_2251 = V_240;
		NullCheck(L_2250);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2252 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2250)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2251)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2253 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2252->___uv2_2);
		L_2253->___x_0 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2254 = V_54;
		int32_t L_2255 = V_240;
		NullCheck(L_2254);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2256 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2254)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2255)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2257 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2256->___uv2_2);
		L_2257->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2258 = V_54;
		int32_t L_2259 = V_240;
		NullCheck(L_2258);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2260 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2258)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2259)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2261 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2260->___uv2_2);
		L_2261->___x_0 = (1.0f);
		goto IL_4d19;
	}

IL_4334:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2262 = ___0_generationSettings;
		NullCheck(L_2262);
		int32_t L_2263 = L_2262->___textAlignment_10;
		V_284 = (bool)((((int32_t)((((int32_t)L_2263) == ((int32_t)((int32_t)520)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_2264 = V_284;
		if (!L_2264)
		{
			goto IL_4503;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2265 = V_54;
		int32_t L_2266 = V_240;
		NullCheck(L_2265);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2267 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2265)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2266)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2268 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2267->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2269 = V_54;
		int32_t L_2270 = V_240;
		NullCheck(L_2269);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2271 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2269)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2270)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2272 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2271->___position_0);
		float L_2273 = L_2272->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2274 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2275 = L_2274.___min_0;
		float L_2276 = L_2275.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2277 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2278 = L_2277.___max_1;
		float L_2279 = L_2278.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2280 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2281 = L_2280.___min_0;
		float L_2282 = L_2281.___x_0;
		float L_2283 = V_278;
		L_2268->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2273, L_2276))/((float)il2cpp_codegen_subtract(L_2279, L_2282)))), L_2283));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2284 = V_54;
		int32_t L_2285 = V_240;
		NullCheck(L_2284);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2286 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2284)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2285)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2287 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2286->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2288 = V_54;
		int32_t L_2289 = V_240;
		NullCheck(L_2288);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2290 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2288)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2289)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2291 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2290->___position_0);
		float L_2292 = L_2291->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2293 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2294 = L_2293.___min_0;
		float L_2295 = L_2294.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2296 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2297 = L_2296.___max_1;
		float L_2298 = L_2297.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2299 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2300 = L_2299.___min_0;
		float L_2301 = L_2300.___x_0;
		float L_2302 = V_278;
		L_2287->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2292, L_2295))/((float)il2cpp_codegen_subtract(L_2298, L_2301)))), L_2302));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2303 = V_54;
		int32_t L_2304 = V_240;
		NullCheck(L_2303);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2305 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2303)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2304)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2306 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2305->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2307 = V_54;
		int32_t L_2308 = V_240;
		NullCheck(L_2307);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2309 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2307)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2308)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2310 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2309->___position_0);
		float L_2311 = L_2310->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2312 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2313 = L_2312.___min_0;
		float L_2314 = L_2313.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2315 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2316 = L_2315.___max_1;
		float L_2317 = L_2316.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2318 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2319 = L_2318.___min_0;
		float L_2320 = L_2319.___x_0;
		float L_2321 = V_278;
		L_2306->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2311, L_2314))/((float)il2cpp_codegen_subtract(L_2317, L_2320)))), L_2321));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2322 = V_54;
		int32_t L_2323 = V_240;
		NullCheck(L_2322);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2324 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2322)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2323)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2325 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2324->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2326 = V_54;
		int32_t L_2327 = V_240;
		NullCheck(L_2326);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2328 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2326)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2327)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2329 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2328->___position_0);
		float L_2330 = L_2329->___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2331 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2332 = L_2331.___min_0;
		float L_2333 = L_2332.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2334 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2335 = L_2334.___max_1;
		float L_2336 = L_2335.___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2337 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2338 = L_2337.___min_0;
		float L_2339 = L_2338.___x_0;
		float L_2340 = V_278;
		L_2325->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2330, L_2333))/((float)il2cpp_codegen_subtract(L_2336, L_2339)))), L_2340));
		goto IL_4d19;
	}

IL_4503:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2341 = V_54;
		int32_t L_2342 = V_240;
		NullCheck(L_2341);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2343 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2341)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2342)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2344 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2343->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2345 = V_54;
		int32_t L_2346 = V_240;
		NullCheck(L_2345);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2347 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2345)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2346)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2348 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2347->___position_0);
		float L_2349 = L_2348->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2350 = V_36;
		float L_2351 = L_2350.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2352 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2353 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2352->___min_0);
		float L_2354 = L_2353->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2355 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2356 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2355->___max_1);
		float L_2357 = L_2356->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2358 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2359 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2358->___min_0);
		float L_2360 = L_2359->___x_0;
		float L_2361 = V_278;
		L_2344->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2349, L_2351)), L_2354))/((float)il2cpp_codegen_subtract(L_2357, L_2360)))), L_2361));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2362 = V_54;
		int32_t L_2363 = V_240;
		NullCheck(L_2362);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2364 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2362)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2363)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2365 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2364->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2366 = V_54;
		int32_t L_2367 = V_240;
		NullCheck(L_2366);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2368 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2366)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2367)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2369 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2368->___position_0);
		float L_2370 = L_2369->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2371 = V_36;
		float L_2372 = L_2371.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2373 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2374 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2373->___min_0);
		float L_2375 = L_2374->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2376 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2377 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2376->___max_1);
		float L_2378 = L_2377->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2379 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2380 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2379->___min_0);
		float L_2381 = L_2380->___x_0;
		float L_2382 = V_278;
		L_2365->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2370, L_2372)), L_2375))/((float)il2cpp_codegen_subtract(L_2378, L_2381)))), L_2382));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2383 = V_54;
		int32_t L_2384 = V_240;
		NullCheck(L_2383);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2385 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2383)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2384)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2386 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2385->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2387 = V_54;
		int32_t L_2388 = V_240;
		NullCheck(L_2387);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2389 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2387)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2388)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2390 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2389->___position_0);
		float L_2391 = L_2390->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2392 = V_36;
		float L_2393 = L_2392.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2394 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2395 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2394->___min_0);
		float L_2396 = L_2395->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2397 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2398 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2397->___max_1);
		float L_2399 = L_2398->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2400 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2401 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2400->___min_0);
		float L_2402 = L_2401->___x_0;
		float L_2403 = V_278;
		L_2386->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2391, L_2393)), L_2396))/((float)il2cpp_codegen_subtract(L_2399, L_2402)))), L_2403));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2404 = V_54;
		int32_t L_2405 = V_240;
		NullCheck(L_2404);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2406 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2404)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2405)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2407 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2406->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2408 = V_54;
		int32_t L_2409 = V_240;
		NullCheck(L_2408);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2410 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2408)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2409)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2411 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2410->___position_0);
		float L_2412 = L_2411->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2413 = V_36;
		float L_2414 = L_2413.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2415 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2416 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2415->___min_0);
		float L_2417 = L_2416->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2418 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2419 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2418->___max_1);
		float L_2420 = L_2419->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2421 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2422 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2421->___min_0);
		float L_2423 = L_2422->___x_0;
		float L_2424 = V_278;
		L_2407->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2412, L_2414)), L_2417))/((float)il2cpp_codegen_subtract(L_2420, L_2423)))), L_2424));
		goto IL_4d19;
	}

IL_46d1:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2425 = V_54;
		int32_t L_2426 = V_240;
		NullCheck(L_2425);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2427 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2425)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2426)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2428 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2427->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2429 = V_54;
		int32_t L_2430 = V_240;
		NullCheck(L_2429);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2431 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2429)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2430)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2432 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2431->___position_0);
		float L_2433 = L_2432->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2434 = V_36;
		float L_2435 = L_2434.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2436 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2437 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2436->___min_0);
		float L_2438 = L_2437->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2439 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2440 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2439->___max_1);
		float L_2441 = L_2440->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2442 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2443 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2442->___min_0);
		float L_2444 = L_2443->___x_0;
		float L_2445 = V_278;
		L_2428->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2433, L_2435)), L_2438))/((float)il2cpp_codegen_subtract(L_2441, L_2444)))), L_2445));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2446 = V_54;
		int32_t L_2447 = V_240;
		NullCheck(L_2446);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2448 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2446)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2447)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2449 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2448->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2450 = V_54;
		int32_t L_2451 = V_240;
		NullCheck(L_2450);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2452 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2450)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2451)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2453 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2452->___position_0);
		float L_2454 = L_2453->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2455 = V_36;
		float L_2456 = L_2455.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2457 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2458 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2457->___min_0);
		float L_2459 = L_2458->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2460 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2461 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2460->___max_1);
		float L_2462 = L_2461->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2463 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2464 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2463->___min_0);
		float L_2465 = L_2464->___x_0;
		float L_2466 = V_278;
		L_2449->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2454, L_2456)), L_2459))/((float)il2cpp_codegen_subtract(L_2462, L_2465)))), L_2466));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2467 = V_54;
		int32_t L_2468 = V_240;
		NullCheck(L_2467);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2469 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2467)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2468)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2470 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2469->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2471 = V_54;
		int32_t L_2472 = V_240;
		NullCheck(L_2471);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2473 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2471)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2472)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2474 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2473->___position_0);
		float L_2475 = L_2474->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2476 = V_36;
		float L_2477 = L_2476.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2478 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2479 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2478->___min_0);
		float L_2480 = L_2479->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2481 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2482 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2481->___max_1);
		float L_2483 = L_2482->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2484 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2485 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2484->___min_0);
		float L_2486 = L_2485->___x_0;
		float L_2487 = V_278;
		L_2470->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2475, L_2477)), L_2480))/((float)il2cpp_codegen_subtract(L_2483, L_2486)))), L_2487));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2488 = V_54;
		int32_t L_2489 = V_240;
		NullCheck(L_2488);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2490 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2488)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2489)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2491 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2490->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2492 = V_54;
		int32_t L_2493 = V_240;
		NullCheck(L_2492);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2494 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2492)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2493)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2495 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2494->___position_0);
		float L_2496 = L_2495->___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2497 = V_36;
		float L_2498 = L_2497.___x_2;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2499 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2500 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2499->___min_0);
		float L_2501 = L_2500->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2502 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2503 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2502->___max_1);
		float L_2504 = L_2503->___x_0;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2505 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2506 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2505->___min_0);
		float L_2507 = L_2506->___x_0;
		float L_2508 = V_278;
		L_2491->___x_0 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(L_2496, L_2498)), L_2501))/((float)il2cpp_codegen_subtract(L_2504, L_2507)))), L_2508));
		goto IL_4d19;
	}

IL_489e:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2509 = ___0_generationSettings;
		NullCheck(L_2509);
		int32_t L_2510 = L_2509->___verticalMapping_40;
		V_286 = L_2510;
		int32_t L_2511 = V_286;
		V_285 = L_2511;
		int32_t L_2512 = V_285;
		switch (L_2512)
		{
			case 0:
			{
				goto IL_48d6;
			}
			case 1:
			{
				goto IL_494f;
			}
			case 2:
			{
				goto IL_4a88;
			}
			case 3:
			{
				goto IL_4bbe;
			}
		}
	}
	{
		goto IL_4bcb;
	}

IL_48d6:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2513 = V_54;
		int32_t L_2514 = V_240;
		NullCheck(L_2513);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2515 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2513)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2514)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2516 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2515->___uv2_2);
		L_2516->___y_1 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2517 = V_54;
		int32_t L_2518 = V_240;
		NullCheck(L_2517);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2519 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2517)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2518)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2520 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2519->___uv2_2);
		L_2520->___y_1 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2521 = V_54;
		int32_t L_2522 = V_240;
		NullCheck(L_2521);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2523 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2521)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2522)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2524 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2523->___uv2_2);
		L_2524->___y_1 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2525 = V_54;
		int32_t L_2526 = V_240;
		NullCheck(L_2525);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2527 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2525)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2526)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2528 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2527->___uv2_2);
		L_2528->___y_1 = (1.0f);
		goto IL_4bcb;
	}

IL_494f:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2529 = V_54;
		int32_t L_2530 = V_240;
		NullCheck(L_2529);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2531 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2529)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2530)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2532 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2531->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2533 = V_54;
		int32_t L_2534 = V_240;
		NullCheck(L_2533);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2535 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2533)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2534)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2536 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2535->___position_0);
		float L_2537 = L_2536->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2538 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2539 = L_2538.___min_0;
		float L_2540 = L_2539.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2541 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2542 = L_2541.___max_1;
		float L_2543 = L_2542.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2544 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2545 = L_2544.___min_0;
		float L_2546 = L_2545.___y_1;
		float L_2547 = V_278;
		L_2532->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2537, L_2540))/((float)il2cpp_codegen_subtract(L_2543, L_2546)))), L_2547));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2548 = V_54;
		int32_t L_2549 = V_240;
		NullCheck(L_2548);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2550 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2548)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2549)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2551 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2550->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2552 = V_54;
		int32_t L_2553 = V_240;
		NullCheck(L_2552);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2554 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2552)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2553)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2555 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2554->___position_0);
		float L_2556 = L_2555->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2557 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2558 = L_2557.___min_0;
		float L_2559 = L_2558.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2560 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2561 = L_2560.___max_1;
		float L_2562 = L_2561.___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6 L_2563 = V_277;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2564 = L_2563.___min_0;
		float L_2565 = L_2564.___y_1;
		float L_2566 = V_278;
		L_2551->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2556, L_2559))/((float)il2cpp_codegen_subtract(L_2562, L_2565)))), L_2566));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2567 = V_54;
		int32_t L_2568 = V_240;
		NullCheck(L_2567);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2569 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2567)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2568)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2570 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2569->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2571 = V_54;
		int32_t L_2572 = V_240;
		NullCheck(L_2571);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2573 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2571)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2572)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2574 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2573->___uv2_2);
		float L_2575 = L_2574->___y_1;
		L_2570->___y_1 = L_2575;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2576 = V_54;
		int32_t L_2577 = V_240;
		NullCheck(L_2576);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2578 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2576)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2577)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2579 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2578->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2580 = V_54;
		int32_t L_2581 = V_240;
		NullCheck(L_2580);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2582 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2580)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2581)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2583 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2582->___uv2_2);
		float L_2584 = L_2583->___y_1;
		L_2579->___y_1 = L_2584;
		goto IL_4bcb;
	}

IL_4a88:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2585 = V_54;
		int32_t L_2586 = V_240;
		NullCheck(L_2585);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2587 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2585)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2586)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2588 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2587->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2589 = V_54;
		int32_t L_2590 = V_240;
		NullCheck(L_2589);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2591 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2589)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2590)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2592 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2591->___position_0);
		float L_2593 = L_2592->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2594 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2595 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2594->___min_0);
		float L_2596 = L_2595->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2597 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2598 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2597->___max_1);
		float L_2599 = L_2598->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2600 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2601 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2600->___min_0);
		float L_2602 = L_2601->___y_1;
		float L_2603 = V_278;
		L_2588->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2593, L_2596))/((float)il2cpp_codegen_subtract(L_2599, L_2602)))), L_2603));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2604 = V_54;
		int32_t L_2605 = V_240;
		NullCheck(L_2604);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2606 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2604)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2605)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2607 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2606->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2608 = V_54;
		int32_t L_2609 = V_240;
		NullCheck(L_2608);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2610 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2608)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2609)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2611 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2610->___position_0);
		float L_2612 = L_2611->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2613 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2614 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2613->___min_0);
		float L_2615 = L_2614->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2616 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2617 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2616->___max_1);
		float L_2618 = L_2617->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2619 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2620 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2619->___min_0);
		float L_2621 = L_2620->___y_1;
		float L_2622 = V_278;
		L_2607->___y_1 = ((float)il2cpp_codegen_add(((float)(((float)il2cpp_codegen_subtract(L_2612, L_2615))/((float)il2cpp_codegen_subtract(L_2618, L_2621)))), L_2622));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2623 = V_54;
		int32_t L_2624 = V_240;
		NullCheck(L_2623);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2625 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2623)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2624)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2626 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2625->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2627 = V_54;
		int32_t L_2628 = V_240;
		NullCheck(L_2627);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2629 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2627)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2628)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2630 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2629->___uv2_2);
		float L_2631 = L_2630->___y_1;
		L_2626->___y_1 = L_2631;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2632 = V_54;
		int32_t L_2633 = V_240;
		NullCheck(L_2632);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2634 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2632)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2633)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2635 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2634->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2636 = V_54;
		int32_t L_2637 = V_240;
		NullCheck(L_2636);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2638 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2636)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2637)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2639 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2638->___uv2_2);
		float L_2640 = L_2639->___y_1;
		L_2635->___y_1 = L_2640;
		goto IL_4bcb;
	}

IL_4bbe:
	{
		il2cpp_codegen_runtime_class_init_inline(Debug_t8394C7EEAECA3689C2C9B9DE9C7166D73596276F_il2cpp_TypeInfo_var);
		Debug_Log_m87A9A3C761FF5C43ED8A53B16190A53D08F818BB(_stringLiteralAFB91D1DF3A99213A5F62F37EB0B31E6121411C4, NULL);
		goto IL_4bcb;
	}

IL_4bcb:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2641 = V_54;
		int32_t L_2642 = V_240;
		NullCheck(L_2641);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2643 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2641)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2642)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2644 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2643->___uv2_2);
		float L_2645 = L_2644->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2646 = V_54;
		int32_t L_2647 = V_240;
		NullCheck(L_2646);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2648 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2646)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2647)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2649 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2648->___uv2_2);
		float L_2650 = L_2649->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2651 = V_54;
		int32_t L_2652 = V_240;
		NullCheck(L_2651);
		float L_2653 = ((L_2651)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2652)))->___aspectRatio_27;
		V_281 = ((float)(((float)il2cpp_codegen_subtract((1.0f), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_2645, L_2650)), L_2653))))/(2.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2654 = V_54;
		int32_t L_2655 = V_240;
		NullCheck(L_2654);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2656 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2654)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2655)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2657 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2656->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2658 = V_54;
		int32_t L_2659 = V_240;
		NullCheck(L_2658);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2660 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2658)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2659)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2661 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2660->___uv2_2);
		float L_2662 = L_2661->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2663 = V_54;
		int32_t L_2664 = V_240;
		NullCheck(L_2663);
		float L_2665 = ((L_2663)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2664)))->___aspectRatio_27;
		float L_2666 = V_281;
		float L_2667 = V_278;
		L_2657->___x_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_2662, L_2665)), L_2666)), L_2667));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2668 = V_54;
		int32_t L_2669 = V_240;
		NullCheck(L_2668);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2670 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2668)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2669)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2671 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2670->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2672 = V_54;
		int32_t L_2673 = V_240;
		NullCheck(L_2672);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2674 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2672)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2673)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2675 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2674->___uv2_2);
		float L_2676 = L_2675->___x_0;
		L_2671->___x_0 = L_2676;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2677 = V_54;
		int32_t L_2678 = V_240;
		NullCheck(L_2677);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2679 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2677)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2678)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2680 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2679->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2681 = V_54;
		int32_t L_2682 = V_240;
		NullCheck(L_2681);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2683 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2681)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2682)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2684 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2683->___uv2_2);
		float L_2685 = L_2684->___y_1;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2686 = V_54;
		int32_t L_2687 = V_240;
		NullCheck(L_2686);
		float L_2688 = ((L_2686)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2687)))->___aspectRatio_27;
		float L_2689 = V_281;
		float L_2690 = V_278;
		L_2680->___x_0 = ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_2685, L_2688)), L_2689)), L_2690));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2691 = V_54;
		int32_t L_2692 = V_240;
		NullCheck(L_2691);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2693 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2691)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2692)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2694 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2693->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2695 = V_54;
		int32_t L_2696 = V_240;
		NullCheck(L_2695);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2697 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2695)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2696)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2698 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2697->___uv2_2);
		float L_2699 = L_2698->___x_0;
		L_2694->___x_0 = L_2699;
		goto IL_4d19;
	}

IL_4d19:
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2700 = ___0_generationSettings;
		NullCheck(L_2700);
		int32_t L_2701 = L_2700->___verticalMapping_40;
		V_289 = L_2701;
		int32_t L_2702 = V_289;
		V_288 = L_2702;
		int32_t L_2703 = V_288;
		switch (L_2703)
		{
			case 0:
			{
				goto IL_4d51;
			}
			case 1:
			{
				goto IL_4dca;
			}
			case 2:
			{
				goto IL_4ebf;
			}
			case 3:
			{
				goto IL_4fea;
			}
		}
	}
	{
		goto IL_512a;
	}

IL_4d51:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2704 = V_54;
		int32_t L_2705 = V_240;
		NullCheck(L_2704);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2706 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2704)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2705)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2707 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2706->___uv2_2);
		L_2707->___y_1 = (0.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2708 = V_54;
		int32_t L_2709 = V_240;
		NullCheck(L_2708);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2710 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2708)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2709)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2711 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2710->___uv2_2);
		L_2711->___y_1 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2712 = V_54;
		int32_t L_2713 = V_240;
		NullCheck(L_2712);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2714 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2712)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2713)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2715 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2714->___uv2_2);
		L_2715->___y_1 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2716 = V_54;
		int32_t L_2717 = V_240;
		NullCheck(L_2716);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2718 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2716)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2717)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2719 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2718->___uv2_2);
		L_2719->___y_1 = (0.0f);
		goto IL_512a;
	}

IL_4dca:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2720 = V_54;
		int32_t L_2721 = V_240;
		NullCheck(L_2720);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2722 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2720)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2721)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2723 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2722->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2724 = V_54;
		int32_t L_2725 = V_240;
		NullCheck(L_2724);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2726 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2724)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2725)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2727 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2726->___position_0);
		float L_2728 = L_2727->___y_3;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2729 = V_244;
		float L_2730 = L_2729.___descender_14;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2731 = V_244;
		float L_2732 = L_2731.___ascender_12;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2733 = V_244;
		float L_2734 = L_2733.___descender_14;
		L_2723->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2728, L_2730))/((float)il2cpp_codegen_subtract(L_2732, L_2734))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2735 = V_54;
		int32_t L_2736 = V_240;
		NullCheck(L_2735);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2737 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2735)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2736)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2738 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2737->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2739 = V_54;
		int32_t L_2740 = V_240;
		NullCheck(L_2739);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2741 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2739)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2740)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2742 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2741->___position_0);
		float L_2743 = L_2742->___y_3;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2744 = V_244;
		float L_2745 = L_2744.___descender_14;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2746 = V_244;
		float L_2747 = L_2746.___ascender_12;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_2748 = V_244;
		float L_2749 = L_2748.___descender_14;
		L_2738->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2743, L_2745))/((float)il2cpp_codegen_subtract(L_2747, L_2749))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2750 = V_54;
		int32_t L_2751 = V_240;
		NullCheck(L_2750);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2752 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2750)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2751)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2753 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2752->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2754 = V_54;
		int32_t L_2755 = V_240;
		NullCheck(L_2754);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2756 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2754)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2755)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2757 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2756->___uv2_2);
		float L_2758 = L_2757->___y_1;
		L_2753->___y_1 = L_2758;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2759 = V_54;
		int32_t L_2760 = V_240;
		NullCheck(L_2759);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2761 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2759)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2760)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2762 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2761->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2763 = V_54;
		int32_t L_2764 = V_240;
		NullCheck(L_2763);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2765 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2763)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2764)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2766 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2765->___uv2_2);
		float L_2767 = L_2766->___y_1;
		L_2762->___y_1 = L_2767;
		goto IL_512a;
	}

IL_4ebf:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2768 = V_54;
		int32_t L_2769 = V_240;
		NullCheck(L_2768);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2770 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2768)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2769)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2771 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2770->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2772 = V_54;
		int32_t L_2773 = V_240;
		NullCheck(L_2772);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2774 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2772)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2773)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2775 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2774->___position_0);
		float L_2776 = L_2775->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2777 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2778 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2777->___min_0);
		float L_2779 = L_2778->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2780 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2781 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2780->___max_1);
		float L_2782 = L_2781->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2783 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2784 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2783->___min_0);
		float L_2785 = L_2784->___y_1;
		L_2771->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2776, L_2779))/((float)il2cpp_codegen_subtract(L_2782, L_2785))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2786 = V_54;
		int32_t L_2787 = V_240;
		NullCheck(L_2786);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2788 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2786)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2787)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2789 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2788->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2790 = V_54;
		int32_t L_2791 = V_240;
		NullCheck(L_2790);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2792 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2790)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2791)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2793 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2792->___position_0);
		float L_2794 = L_2793->___y_3;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2795 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2796 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2795->___min_0);
		float L_2797 = L_2796->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2798 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2799 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2798->___max_1);
		float L_2800 = L_2799->___y_1;
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_2801 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&__this->___m_MeshExtents_62);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2802 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2801->___min_0);
		float L_2803 = L_2802->___y_1;
		L_2789->___y_1 = ((float)(((float)il2cpp_codegen_subtract(L_2794, L_2797))/((float)il2cpp_codegen_subtract(L_2800, L_2803))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2804 = V_54;
		int32_t L_2805 = V_240;
		NullCheck(L_2804);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2806 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2804)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2805)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2807 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2806->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2808 = V_54;
		int32_t L_2809 = V_240;
		NullCheck(L_2808);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2810 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2808)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2809)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2811 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2810->___uv2_2);
		float L_2812 = L_2811->___y_1;
		L_2807->___y_1 = L_2812;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2813 = V_54;
		int32_t L_2814 = V_240;
		NullCheck(L_2813);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2815 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2813)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2814)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2816 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2815->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2817 = V_54;
		int32_t L_2818 = V_240;
		NullCheck(L_2817);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2819 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2817)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2818)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2820 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2819->___uv2_2);
		float L_2821 = L_2820->___y_1;
		L_2816->___y_1 = L_2821;
		goto IL_512a;
	}

IL_4fea:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2822 = V_54;
		int32_t L_2823 = V_240;
		NullCheck(L_2822);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2824 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2822)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2823)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2825 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2824->___uv2_2);
		float L_2826 = L_2825->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2827 = V_54;
		int32_t L_2828 = V_240;
		NullCheck(L_2827);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2829 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2827)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2828)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2830 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2829->___uv2_2);
		float L_2831 = L_2830->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2832 = V_54;
		int32_t L_2833 = V_240;
		NullCheck(L_2832);
		float L_2834 = ((L_2832)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2833)))->___aspectRatio_27;
		V_287 = ((float)(((float)il2cpp_codegen_subtract((1.0f), ((float)(((float)il2cpp_codegen_add(L_2826, L_2831))/L_2834))))/(2.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2835 = V_54;
		int32_t L_2836 = V_240;
		NullCheck(L_2835);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2837 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2835)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2836)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2838 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2837->___uv2_2);
		float L_2839 = V_287;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2840 = V_54;
		int32_t L_2841 = V_240;
		NullCheck(L_2840);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2842 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2840)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2841)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2843 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2842->___uv2_2);
		float L_2844 = L_2843->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2845 = V_54;
		int32_t L_2846 = V_240;
		NullCheck(L_2845);
		float L_2847 = ((L_2845)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2846)))->___aspectRatio_27;
		L_2838->___y_1 = ((float)il2cpp_codegen_add(L_2839, ((float)(L_2844/L_2847))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2848 = V_54;
		int32_t L_2849 = V_240;
		NullCheck(L_2848);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2850 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2848)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2849)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2851 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2850->___uv2_2);
		float L_2852 = V_287;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2853 = V_54;
		int32_t L_2854 = V_240;
		NullCheck(L_2853);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2855 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2853)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2854)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2856 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2855->___uv2_2);
		float L_2857 = L_2856->___x_0;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2858 = V_54;
		int32_t L_2859 = V_240;
		NullCheck(L_2858);
		float L_2860 = ((L_2858)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2859)))->___aspectRatio_27;
		L_2851->___y_1 = ((float)il2cpp_codegen_add(L_2852, ((float)(L_2857/L_2860))));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2861 = V_54;
		int32_t L_2862 = V_240;
		NullCheck(L_2861);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2863 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2861)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2862)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2864 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2863->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2865 = V_54;
		int32_t L_2866 = V_240;
		NullCheck(L_2865);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2867 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2865)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2866)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2868 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2867->___uv2_2);
		float L_2869 = L_2868->___y_1;
		L_2864->___y_1 = L_2869;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2870 = V_54;
		int32_t L_2871 = V_240;
		NullCheck(L_2870);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2872 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2870)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2871)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2873 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2872->___uv2_2);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2874 = V_54;
		int32_t L_2875 = V_240;
		NullCheck(L_2874);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2876 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2874)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2875)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2877 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2876->___uv2_2);
		float L_2878 = L_2877->___y_1;
		L_2873->___y_1 = L_2878;
		goto IL_512a;
	}

IL_512a:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2879 = V_54;
		int32_t L_2880 = V_240;
		NullCheck(L_2879);
		float L_2881 = ((L_2879)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2880)))->___scale_28;
		float L_2882 = __this->___m_CharWidthAdjDelta_77;
		V_46 = ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_multiply(L_2881, ((float)il2cpp_codegen_subtract((1.0f), L_2882)))), (1.0f)));
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2883 = V_54;
		int32_t L_2884 = V_240;
		NullCheck(L_2883);
		bool L_2885 = ((L_2883)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2884)))->___isUsingAlternateTypeface_9;
		if (L_2885)
		{
			goto IL_5172;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2886 = V_54;
		int32_t L_2887 = V_240;
		NullCheck(L_2886);
		int32_t L_2888 = ((L_2886)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2887)))->___style_33;
		G_B756_0 = ((((int32_t)((int32_t)((int32_t)L_2888&1))) == ((int32_t)1))? 1 : 0);
		goto IL_5173;
	}

IL_5172:
	{
		G_B756_0 = 0;
	}

IL_5173:
	{
		V_290 = (bool)G_B756_0;
		bool L_2889 = V_290;
		if (!L_2889)
		{
			goto IL_518b;
		}
	}
	{
		float L_2890 = V_46;
		V_46 = ((float)il2cpp_codegen_multiply(L_2890, (-1.0f)));
	}

IL_518b:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2891 = V_54;
		int32_t L_2892 = V_240;
		NullCheck(L_2891);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2893 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2891)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2892)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2894 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2893->___uv2_2);
		L_2894->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2895 = V_54;
		int32_t L_2896 = V_240;
		NullCheck(L_2895);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2897 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2895)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2896)))->___vertexBottomLeft_15);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2898 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2897->___uv2_2);
		float L_2899 = V_46;
		L_2898->___y_1 = L_2899;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2900 = V_54;
		int32_t L_2901 = V_240;
		NullCheck(L_2900);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2902 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2900)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2901)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2903 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2902->___uv2_2);
		L_2903->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2904 = V_54;
		int32_t L_2905 = V_240;
		NullCheck(L_2904);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2906 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2904)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2905)))->___vertexTopLeft_14);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2907 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2906->___uv2_2);
		float L_2908 = V_46;
		L_2907->___y_1 = L_2908;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2909 = V_54;
		int32_t L_2910 = V_240;
		NullCheck(L_2909);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2911 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2909)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2910)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2912 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2911->___uv2_2);
		L_2912->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2913 = V_54;
		int32_t L_2914 = V_240;
		NullCheck(L_2913);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2915 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2913)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2914)))->___vertexTopRight_16);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2916 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2915->___uv2_2);
		float L_2917 = V_46;
		L_2916->___y_1 = L_2917;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2918 = V_54;
		int32_t L_2919 = V_240;
		NullCheck(L_2918);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2920 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2918)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2919)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2921 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2920->___uv2_2);
		L_2921->___x_0 = (1.0f);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2922 = V_54;
		int32_t L_2923 = V_240;
		NullCheck(L_2922);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2924 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2922)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2923)))->___vertexBottomRight_17);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* L_2925 = (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7*)(&L_2924->___uv2_2);
		float L_2926 = V_46;
		L_2925->___y_1 = L_2926;
		goto IL_526b;
	}

IL_5269:
	{
		goto IL_526b;
	}

IL_526b:
	{
		int32_t L_2927 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2928 = ___0_generationSettings;
		NullCheck(L_2928);
		int32_t L_2929 = L_2928->___maxVisibleCharacters_32;
		if ((((int32_t)L_2927) >= ((int32_t)L_2929)))
		{
			goto IL_5297;
		}
	}
	{
		int32_t L_2930 = V_37;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2931 = ___0_generationSettings;
		NullCheck(L_2931);
		int32_t L_2932 = L_2931->___maxVisibleWords_33;
		if ((((int32_t)L_2930) >= ((int32_t)L_2932)))
		{
			goto IL_5297;
		}
	}
	{
		int32_t L_2933 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2934 = ___0_generationSettings;
		NullCheck(L_2934);
		int32_t L_2935 = L_2934->___maxVisibleLines_34;
		if ((((int32_t)L_2933) >= ((int32_t)L_2935)))
		{
			goto IL_5297;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2936 = ___0_generationSettings;
		NullCheck(L_2936);
		int32_t L_2937 = L_2936->___overflowMode_11;
		G_B765_0 = ((((int32_t)((((int32_t)L_2937) == ((int32_t)5))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5298;
	}

IL_5297:
	{
		G_B765_0 = 0;
	}

IL_5298:
	{
		V_291 = (bool)G_B765_0;
		bool L_2938 = V_291;
		if (!L_2938)
		{
			goto IL_5388;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2939 = V_54;
		int32_t L_2940 = V_240;
		NullCheck(L_2939);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2941 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2939)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2940)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2942 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2941->___position_0);
		V_292 = L_2942;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2943 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2944 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2945 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2944);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2946 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2947;
		L_2947 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2945, L_2946, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2943 = L_2947;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2948 = V_54;
		int32_t L_2949 = V_240;
		NullCheck(L_2948);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2950 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2948)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2949)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2951 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2950->___position_0);
		V_292 = L_2951;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2952 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2953 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2954 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2953);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2955 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2956;
		L_2956 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2954, L_2955, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2952 = L_2956;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2957 = V_54;
		int32_t L_2958 = V_240;
		NullCheck(L_2957);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2959 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2957)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2958)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2960 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2959->___position_0);
		V_292 = L_2960;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2961 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2962 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2963 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2962);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2964 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2965;
		L_2965 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2963, L_2964, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2961 = L_2965;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2966 = V_54;
		int32_t L_2967 = V_240;
		NullCheck(L_2966);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2968 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2966)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2967)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2969 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2968->___position_0);
		V_292 = L_2969;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2970 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2971 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2972 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2971);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2973 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2974;
		L_2974 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2972, L_2973, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2970 = L_2974;
		goto IL_5522;
	}

IL_5388:
	{
		int32_t L_2975 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2976 = ___0_generationSettings;
		NullCheck(L_2976);
		int32_t L_2977 = L_2976->___maxVisibleCharacters_32;
		if ((((int32_t)L_2975) >= ((int32_t)L_2977)))
		{
			goto IL_53c3;
		}
	}
	{
		int32_t L_2978 = V_37;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2979 = ___0_generationSettings;
		NullCheck(L_2979);
		int32_t L_2980 = L_2979->___maxVisibleWords_33;
		if ((((int32_t)L_2978) >= ((int32_t)L_2980)))
		{
			goto IL_53c3;
		}
	}
	{
		int32_t L_2981 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2982 = ___0_generationSettings;
		NullCheck(L_2982);
		int32_t L_2983 = L_2982->___maxVisibleLines_34;
		if ((((int32_t)L_2981) >= ((int32_t)L_2983)))
		{
			goto IL_53c3;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_2984 = ___0_generationSettings;
		NullCheck(L_2984);
		int32_t L_2985 = L_2984->___overflowMode_11;
		if ((!(((uint32_t)L_2985) == ((uint32_t)5))))
		{
			goto IL_53c3;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2986 = V_54;
		int32_t L_2987 = V_240;
		NullCheck(L_2986);
		int32_t L_2988 = ((L_2986)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2987)))->___pageNumber_12;
		int32_t L_2989 = V_16;
		G_B773_0 = ((((int32_t)L_2988) == ((int32_t)L_2989))? 1 : 0);
		goto IL_53c4;
	}

IL_53c3:
	{
		G_B773_0 = 0;
	}

IL_53c4:
	{
		V_293 = (bool)G_B773_0;
		bool L_2990 = V_293;
		if (!L_2990)
		{
			goto IL_54b1;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_2991 = V_54;
		int32_t L_2992 = V_240;
		NullCheck(L_2991);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_2993 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_2991)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_2992)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2994 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_2993->___position_0);
		V_292 = L_2994;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2995 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_2996 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2997 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2996);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2998 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2999;
		L_2999 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_2997, L_2998, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_2995 = L_2999;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3000 = V_54;
		int32_t L_3001 = V_240;
		NullCheck(L_3000);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3002 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3000)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3001)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3003 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3002->___position_0);
		V_292 = L_3003;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3004 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3005 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3006 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3005);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3007 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3008;
		L_3008 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3006, L_3007, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3004 = L_3008;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3009 = V_54;
		int32_t L_3010 = V_240;
		NullCheck(L_3009);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3011 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3009)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3010)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3012 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3011->___position_0);
		V_292 = L_3012;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3013 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3014 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3015 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3014);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3016 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3017;
		L_3017 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3015, L_3016, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3013 = L_3017;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3018 = V_54;
		int32_t L_3019 = V_240;
		NullCheck(L_3018);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3020 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3018)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3019)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3021 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&L_3020->___position_0);
		V_292 = L_3021;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3022 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3023 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3024 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3023);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3025 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3026;
		L_3026 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3024, L_3025, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3022 = L_3026;
		goto IL_5522;
	}

IL_54b1:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3027 = V_54;
		int32_t L_3028 = V_240;
		NullCheck(L_3027);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3029 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3027)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3028)))->___vertexBottomLeft_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3030;
		L_3030 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3029->___position_0 = L_3030;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3031 = V_54;
		int32_t L_3032 = V_240;
		NullCheck(L_3031);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3033 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3031)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3032)))->___vertexTopLeft_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3034;
		L_3034 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3033->___position_0 = L_3034;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3035 = V_54;
		int32_t L_3036 = V_240;
		NullCheck(L_3035);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3037 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3035)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3036)))->___vertexTopRight_16);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3038;
		L_3038 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3037->___position_0 = L_3038;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3039 = V_54;
		int32_t L_3040 = V_240;
		NullCheck(L_3039);
		TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9* L_3041 = (TextVertex_tF030A16DC67EAF3F6C9C9C0564D4B88758B173A9*)(&((L_3039)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3040)))->___vertexBottomRight_17);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3042;
		L_3042 = Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline(NULL);
		L_3041->___position_0 = L_3042;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3043 = V_54;
		int32_t L_3044 = V_240;
		NullCheck(L_3043);
		((L_3043)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3044)))->___isVisible_34 = (bool)0;
	}

IL_5522:
	{
		uint8_t L_3045 = V_276;
		V_294 = (bool)((((int32_t)L_3045) == ((int32_t)1))? 1 : 0);
		bool L_3046 = V_294;
		if (!L_3046)
		{
			goto IL_5547;
		}
	}
	{
		int32_t L_3047 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3048 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3049 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_FillCharacterVertexBuffers_m54CA97C6C26BA84BC949845B20E9DADF2F0C19CA(L_3047, L_3048, L_3049, NULL);
		goto IL_556a;
	}

IL_5547:
	{
		uint8_t L_3050 = V_276;
		V_295 = (bool)((((int32_t)L_3050) == ((int32_t)2))? 1 : 0);
		bool L_3051 = V_295;
		if (!L_3051)
		{
			goto IL_556a;
		}
	}
	{
		int32_t L_3052 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3053 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3054 = ___1_textInfo;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		TextGeneratorUtilities_FillSpriteVertexBuffers_m4305B80FA32FE21A59AF68A5501226E5A4203CC3(L_3052, L_3053, L_3054, NULL);
	}

IL_556a:
	{
	}

IL_556b:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3055 = ___1_textInfo;
		NullCheck(L_3055);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3056 = L_3055->___textElementInfo_10;
		int32_t L_3057 = V_240;
		NullCheck(L_3056);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3058 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3056)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3057)))->___bottomLeft_19);
		V_292 = L_3058;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3059 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3060 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3061 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3060);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3062 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3063;
		L_3063 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3061, L_3062, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3059 = L_3063;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3064 = ___1_textInfo;
		NullCheck(L_3064);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3065 = L_3064->___textElementInfo_10;
		int32_t L_3066 = V_240;
		NullCheck(L_3065);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3067 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3065)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3066)))->___topLeft_18);
		V_292 = L_3067;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3068 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3069 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3070 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3069);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3071 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3072;
		L_3072 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3070, L_3071, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3068 = L_3072;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3073 = ___1_textInfo;
		NullCheck(L_3073);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3074 = L_3073->___textElementInfo_10;
		int32_t L_3075 = V_240;
		NullCheck(L_3074);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3076 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3074)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3075)))->___topRight_20);
		V_292 = L_3076;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3077 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3078 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3079 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3078);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3080 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3081;
		L_3081 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3079, L_3080, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3077 = L_3081;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3082 = ___1_textInfo;
		NullCheck(L_3082);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3083 = L_3082->___textElementInfo_10;
		int32_t L_3084 = V_240;
		NullCheck(L_3083);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3085 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3083)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3084)))->___bottomRight_21);
		V_292 = L_3085;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3086 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3087 = V_292;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3088 = (*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3087);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3089 = V_246;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3090;
		L_3090 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_3088, L_3089, NULL);
		*(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)L_3086 = L_3090;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3091 = ___1_textInfo;
		NullCheck(L_3091);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3092 = L_3091->___textElementInfo_10;
		int32_t L_3093 = V_240;
		NullCheck(L_3092);
		float* L_3094 = (float*)(&((L_3092)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3093)))->___origin_22);
		float* L_3095 = L_3094;
		float L_3096 = *((float*)L_3095);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3097 = V_246;
		float L_3098 = L_3097.___x_2;
		*((float*)L_3095) = (float)((float)il2cpp_codegen_add(L_3096, L_3098));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3099 = ___1_textInfo;
		NullCheck(L_3099);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3100 = L_3099->___textElementInfo_10;
		int32_t L_3101 = V_240;
		NullCheck(L_3100);
		float* L_3102 = (float*)(&((L_3100)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3101)))->___xAdvance_26);
		float* L_3103 = L_3102;
		float L_3104 = *((float*)L_3103);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3105 = V_246;
		float L_3106 = L_3105.___x_2;
		*((float*)L_3103) = (float)((float)il2cpp_codegen_add(L_3104, L_3106));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3107 = ___1_textInfo;
		NullCheck(L_3107);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3108 = L_3107->___textElementInfo_10;
		int32_t L_3109 = V_240;
		NullCheck(L_3108);
		float* L_3110 = (float*)(&((L_3108)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3109)))->___ascender_23);
		float* L_3111 = L_3110;
		float L_3112 = *((float*)L_3111);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3113 = V_246;
		float L_3114 = L_3113.___y_3;
		*((float*)L_3111) = (float)((float)il2cpp_codegen_add(L_3112, L_3114));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3115 = ___1_textInfo;
		NullCheck(L_3115);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3116 = L_3115->___textElementInfo_10;
		int32_t L_3117 = V_240;
		NullCheck(L_3116);
		float* L_3118 = (float*)(&((L_3116)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3117)))->___descender_25);
		float* L_3119 = L_3118;
		float L_3120 = *((float*)L_3119);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3121 = V_246;
		float L_3122 = L_3121.___y_3;
		*((float*)L_3119) = (float)((float)il2cpp_codegen_add(L_3120, L_3122));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3123 = ___1_textInfo;
		NullCheck(L_3123);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3124 = L_3123->___textElementInfo_10;
		int32_t L_3125 = V_240;
		NullCheck(L_3124);
		float* L_3126 = (float*)(&((L_3124)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3125)))->___baseLine_24);
		float* L_3127 = L_3126;
		float L_3128 = *((float*)L_3127);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3129 = V_246;
		float L_3130 = L_3129.___y_3;
		*((float*)L_3127) = (float)((float)il2cpp_codegen_add(L_3128, L_3130));
		int32_t L_3131 = V_243;
		int32_t L_3132 = V_39;
		if ((!(((uint32_t)L_3131) == ((uint32_t)L_3132))))
		{
			goto IL_56e4;
		}
	}
	{
		int32_t L_3133 = V_240;
		int32_t L_3134 = __this->___m_CharacterCount_48;
		G_B784_0 = ((((int32_t)L_3133) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3134, 1))))? 1 : 0);
		goto IL_56e5;
	}

IL_56e4:
	{
		G_B784_0 = 1;
	}

IL_56e5:
	{
		V_296 = (bool)G_B784_0;
		bool L_3135 = V_296;
		if (!L_3135)
		{
			goto IL_5935;
		}
	}
	{
		int32_t L_3136 = V_243;
		int32_t L_3137 = V_39;
		V_297 = (bool)((((int32_t)((((int32_t)L_3136) == ((int32_t)L_3137))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		bool L_3138 = V_297;
		if (!L_3138)
		{
			goto IL_5814;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3139 = ___1_textInfo;
		NullCheck(L_3139);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3140 = L_3139->___lineInfo_13;
		int32_t L_3141 = V_39;
		NullCheck(L_3140);
		float* L_3142 = (float*)(&((L_3140)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3141)))->___baseline_13);
		float* L_3143 = L_3142;
		float L_3144 = *((float*)L_3143);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3145 = V_246;
		float L_3146 = L_3145.___y_3;
		*((float*)L_3143) = (float)((float)il2cpp_codegen_add(L_3144, L_3146));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3147 = ___1_textInfo;
		NullCheck(L_3147);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3148 = L_3147->___lineInfo_13;
		int32_t L_3149 = V_39;
		NullCheck(L_3148);
		float* L_3150 = (float*)(&((L_3148)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3149)))->___ascender_12);
		float* L_3151 = L_3150;
		float L_3152 = *((float*)L_3151);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3153 = V_246;
		float L_3154 = L_3153.___y_3;
		*((float*)L_3151) = (float)((float)il2cpp_codegen_add(L_3152, L_3154));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3155 = ___1_textInfo;
		NullCheck(L_3155);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3156 = L_3155->___lineInfo_13;
		int32_t L_3157 = V_39;
		NullCheck(L_3156);
		float* L_3158 = (float*)(&((L_3156)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3157)))->___descender_14);
		float* L_3159 = L_3158;
		float L_3160 = *((float*)L_3159);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3161 = V_246;
		float L_3162 = L_3161.___y_3;
		*((float*)L_3159) = (float)((float)il2cpp_codegen_add(L_3160, L_3162));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3163 = ___1_textInfo;
		NullCheck(L_3163);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3164 = L_3163->___lineInfo_13;
		int32_t L_3165 = V_39;
		NullCheck(L_3164);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3166 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3164)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3165)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3167 = ___1_textInfo;
		NullCheck(L_3167);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3168 = L_3167->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3169 = ___1_textInfo;
		NullCheck(L_3169);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3170 = L_3169->___lineInfo_13;
		int32_t L_3171 = V_39;
		NullCheck(L_3170);
		int32_t L_3172 = ((L_3170)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3171)))->___firstCharacterIndex_6;
		NullCheck(L_3168);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3173 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3168)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3172)))->___bottomLeft_19);
		float L_3174 = L_3173->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3175 = ___1_textInfo;
		NullCheck(L_3175);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3176 = L_3175->___lineInfo_13;
		int32_t L_3177 = V_39;
		NullCheck(L_3176);
		float L_3178 = ((L_3176)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3177)))->___descender_14;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3179;
		memset((&L_3179), 0, sizeof(L_3179));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3179), L_3174, L_3178, /*hidden argument*/NULL);
		L_3166->___min_0 = L_3179;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3180 = ___1_textInfo;
		NullCheck(L_3180);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3181 = L_3180->___lineInfo_13;
		int32_t L_3182 = V_39;
		NullCheck(L_3181);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3183 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3181)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3182)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3184 = ___1_textInfo;
		NullCheck(L_3184);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3185 = L_3184->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3186 = ___1_textInfo;
		NullCheck(L_3186);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3187 = L_3186->___lineInfo_13;
		int32_t L_3188 = V_39;
		NullCheck(L_3187);
		int32_t L_3189 = ((L_3187)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3188)))->___lastVisibleCharacterIndex_9;
		NullCheck(L_3185);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3190 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3185)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3189)))->___topRight_20);
		float L_3191 = L_3190->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3192 = ___1_textInfo;
		NullCheck(L_3192);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3193 = L_3192->___lineInfo_13;
		int32_t L_3194 = V_39;
		NullCheck(L_3193);
		float L_3195 = ((L_3193)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3194)))->___ascender_12;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3196;
		memset((&L_3196), 0, sizeof(L_3196));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3196), L_3191, L_3195, /*hidden argument*/NULL);
		L_3183->___max_1 = L_3196;
	}

IL_5814:
	{
		int32_t L_3197 = V_240;
		int32_t L_3198 = __this->___m_CharacterCount_48;
		V_298 = (bool)((((int32_t)L_3197) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3198, 1))))? 1 : 0);
		bool L_3199 = V_298;
		if (!L_3199)
		{
			goto IL_5934;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3200 = ___1_textInfo;
		NullCheck(L_3200);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3201 = L_3200->___lineInfo_13;
		int32_t L_3202 = V_243;
		NullCheck(L_3201);
		float* L_3203 = (float*)(&((L_3201)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3202)))->___baseline_13);
		float* L_3204 = L_3203;
		float L_3205 = *((float*)L_3204);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3206 = V_246;
		float L_3207 = L_3206.___y_3;
		*((float*)L_3204) = (float)((float)il2cpp_codegen_add(L_3205, L_3207));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3208 = ___1_textInfo;
		NullCheck(L_3208);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3209 = L_3208->___lineInfo_13;
		int32_t L_3210 = V_243;
		NullCheck(L_3209);
		float* L_3211 = (float*)(&((L_3209)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3210)))->___ascender_12);
		float* L_3212 = L_3211;
		float L_3213 = *((float*)L_3212);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3214 = V_246;
		float L_3215 = L_3214.___y_3;
		*((float*)L_3212) = (float)((float)il2cpp_codegen_add(L_3213, L_3215));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3216 = ___1_textInfo;
		NullCheck(L_3216);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3217 = L_3216->___lineInfo_13;
		int32_t L_3218 = V_243;
		NullCheck(L_3217);
		float* L_3219 = (float*)(&((L_3217)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3218)))->___descender_14);
		float* L_3220 = L_3219;
		float L_3221 = *((float*)L_3220);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3222 = V_246;
		float L_3223 = L_3222.___y_3;
		*((float*)L_3220) = (float)((float)il2cpp_codegen_add(L_3221, L_3223));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3224 = ___1_textInfo;
		NullCheck(L_3224);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3225 = L_3224->___lineInfo_13;
		int32_t L_3226 = V_243;
		NullCheck(L_3225);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3227 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3225)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3226)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3228 = ___1_textInfo;
		NullCheck(L_3228);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3229 = L_3228->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3230 = ___1_textInfo;
		NullCheck(L_3230);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3231 = L_3230->___lineInfo_13;
		int32_t L_3232 = V_243;
		NullCheck(L_3231);
		int32_t L_3233 = ((L_3231)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3232)))->___firstCharacterIndex_6;
		NullCheck(L_3229);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3234 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3229)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3233)))->___bottomLeft_19);
		float L_3235 = L_3234->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3236 = ___1_textInfo;
		NullCheck(L_3236);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3237 = L_3236->___lineInfo_13;
		int32_t L_3238 = V_243;
		NullCheck(L_3237);
		float L_3239 = ((L_3237)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3238)))->___descender_14;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3240;
		memset((&L_3240), 0, sizeof(L_3240));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3240), L_3235, L_3239, /*hidden argument*/NULL);
		L_3227->___min_0 = L_3240;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3241 = ___1_textInfo;
		NullCheck(L_3241);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3242 = L_3241->___lineInfo_13;
		int32_t L_3243 = V_243;
		NullCheck(L_3242);
		Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6* L_3244 = (Extents_t369FB2B84521A0229C2FA3D4C8592B14E07CEFE6*)(&((L_3242)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3243)))->___lineExtents_20);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3245 = ___1_textInfo;
		NullCheck(L_3245);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3246 = L_3245->___textElementInfo_10;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3247 = ___1_textInfo;
		NullCheck(L_3247);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3248 = L_3247->___lineInfo_13;
		int32_t L_3249 = V_243;
		NullCheck(L_3248);
		int32_t L_3250 = ((L_3248)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3249)))->___lastVisibleCharacterIndex_9;
		NullCheck(L_3246);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3251 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3246)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3250)))->___topRight_20);
		float L_3252 = L_3251->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3253 = ___1_textInfo;
		NullCheck(L_3253);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3254 = L_3253->___lineInfo_13;
		int32_t L_3255 = V_243;
		NullCheck(L_3254);
		float L_3256 = ((L_3254)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3255)))->___ascender_12;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3257;
		memset((&L_3257), 0, sizeof(L_3257));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_3257), L_3252, L_3256, /*hidden argument*/NULL);
		L_3244->___max_1 = L_3257;
	}

IL_5934:
	{
	}

IL_5935:
	{
		Il2CppChar L_3258 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3259;
		L_3259 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3258, NULL);
		if (L_3259)
		{
			goto IL_5961;
		}
	}
	{
		Il2CppChar L_3260 = V_242;
		if ((((int32_t)L_3260) == ((int32_t)((int32_t)45))))
		{
			goto IL_5961;
		}
	}
	{
		Il2CppChar L_3261 = V_242;
		if ((((int32_t)L_3261) == ((int32_t)((int32_t)173))))
		{
			goto IL_5961;
		}
	}
	{
		Il2CppChar L_3262 = V_242;
		if ((((int32_t)L_3262) == ((int32_t)((int32_t)8208))))
		{
			goto IL_5961;
		}
	}
	{
		Il2CppChar L_3263 = V_242;
		G_B796_0 = ((((int32_t)L_3263) == ((int32_t)((int32_t)8209)))? 1 : 0);
		goto IL_5962;
	}

IL_5961:
	{
		G_B796_0 = 1;
	}

IL_5962:
	{
		V_299 = (bool)G_B796_0;
		bool L_3264 = V_299;
		if (!L_3264)
		{
			goto IL_5a89;
		}
	}
	{
		bool L_3265 = V_41;
		V_300 = (bool)((((int32_t)L_3265) == ((int32_t)0))? 1 : 0);
		bool L_3266 = V_300;
		if (!L_3266)
		{
			goto IL_5990;
		}
	}
	{
		V_41 = (bool)1;
		int32_t L_3267 = V_240;
		V_42 = L_3267;
	}

IL_5990:
	{
		bool L_3268 = V_41;
		if (!L_3268)
		{
			goto IL_59a2;
		}
	}
	{
		int32_t L_3269 = V_240;
		int32_t L_3270 = __this->___m_CharacterCount_48;
		G_B802_0 = ((((int32_t)L_3269) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3270, 1))))? 1 : 0);
		goto IL_59a3;
	}

IL_59a2:
	{
		G_B802_0 = 0;
	}

IL_59a3:
	{
		V_301 = (bool)G_B802_0;
		bool L_3271 = V_301;
		if (!L_3271)
		{
			goto IL_5a83;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3272 = ___1_textInfo;
		NullCheck(L_3272);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3273 = L_3272->___wordInfo_11;
		NullCheck(L_3273);
		V_302 = ((int32_t)(((RuntimeArray*)L_3273)->max_length));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3274 = ___1_textInfo;
		NullCheck(L_3274);
		int32_t L_3275 = L_3274->___wordCount_5;
		V_303 = L_3275;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3276 = ___1_textInfo;
		NullCheck(L_3276);
		int32_t L_3277 = L_3276->___wordCount_5;
		int32_t L_3278 = V_302;
		V_304 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_3277, 1))) > ((int32_t)L_3278))? 1 : 0);
		bool L_3279 = V_304;
		if (!L_3279)
		{
			goto IL_5a01;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3280 = ___1_textInfo;
		NullCheck(L_3280);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** L_3281 = (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**)(&L_3280->___wordInfo_11);
		int32_t L_3282 = V_302;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D(L_3281, ((int32_t)il2cpp_codegen_add(L_3282, 1)), TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
	}

IL_5a01:
	{
		int32_t L_3283 = V_240;
		V_248 = L_3283;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3284 = ___1_textInfo;
		NullCheck(L_3284);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3285 = L_3284->___wordInfo_11;
		int32_t L_3286 = V_303;
		NullCheck(L_3285);
		int32_t L_3287 = V_42;
		((L_3285)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3286)))->___firstCharacterIndex_0 = L_3287;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3288 = ___1_textInfo;
		NullCheck(L_3288);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3289 = L_3288->___wordInfo_11;
		int32_t L_3290 = V_303;
		NullCheck(L_3289);
		int32_t L_3291 = V_248;
		((L_3289)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3290)))->___lastCharacterIndex_1 = L_3291;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3292 = ___1_textInfo;
		NullCheck(L_3292);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3293 = L_3292->___wordInfo_11;
		int32_t L_3294 = V_303;
		NullCheck(L_3293);
		int32_t L_3295 = V_248;
		int32_t L_3296 = V_42;
		((L_3293)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3294)))->___characterCount_2 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_3295, L_3296)), 1));
		int32_t L_3297 = V_37;
		V_37 = ((int32_t)il2cpp_codegen_add(L_3297, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3298 = ___1_textInfo;
		V_166 = L_3298;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3299 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3300 = V_166;
		NullCheck(L_3300);
		int32_t L_3301 = L_3300->___wordCount_5;
		NullCheck(L_3299);
		L_3299->___wordCount_5 = ((int32_t)il2cpp_codegen_add(L_3301, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3302 = ___1_textInfo;
		NullCheck(L_3302);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3303 = L_3302->___lineInfo_13;
		int32_t L_3304 = V_243;
		NullCheck(L_3303);
		int32_t* L_3305 = (int32_t*)(&((L_3303)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3304)))->___wordCount_5);
		int32_t* L_3306 = L_3305;
		int32_t L_3307 = *((int32_t*)L_3306);
		*((int32_t*)L_3306) = (int32_t)((int32_t)il2cpp_codegen_add(L_3307, 1));
	}

IL_5a83:
	{
		goto IL_5c3d;
	}

IL_5a89:
	{
		bool L_3308 = V_41;
		if (L_3308)
		{
			goto IL_5ac0;
		}
	}
	{
		int32_t L_3309 = V_240;
		if (L_3309)
		{
			goto IL_5abd;
		}
	}
	{
		Il2CppChar L_3310 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3311;
		L_3311 = Char_IsPunctuation_m619E42D942E22C9BA1DDB8E704BECA546C376473(L_3310, NULL);
		if (!L_3311)
		{
			goto IL_5aba;
		}
	}
	{
		Il2CppChar L_3312 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3313;
		L_3313 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3312, NULL);
		if (L_3313)
		{
			goto IL_5aba;
		}
	}
	{
		Il2CppChar L_3314 = V_242;
		if ((((int32_t)L_3314) == ((int32_t)((int32_t)8203))))
		{
			goto IL_5aba;
		}
	}
	{
		int32_t L_3315 = V_240;
		int32_t L_3316 = __this->___m_CharacterCount_48;
		G_B814_0 = ((((int32_t)L_3315) == ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3316, 1))))? 1 : 0);
		goto IL_5abb;
	}

IL_5aba:
	{
		G_B814_0 = 1;
	}

IL_5abb:
	{
		G_B816_0 = G_B814_0;
		goto IL_5abe;
	}

IL_5abd:
	{
		G_B816_0 = 0;
	}

IL_5abe:
	{
		G_B818_0 = G_B816_0;
		goto IL_5ac1;
	}

IL_5ac0:
	{
		G_B818_0 = 1;
	}

IL_5ac1:
	{
		V_305 = (bool)G_B818_0;
		bool L_3317 = V_305;
		if (!L_3317)
		{
			goto IL_5c3d;
		}
	}
	{
		int32_t L_3318 = V_240;
		if ((((int32_t)L_3318) <= ((int32_t)0)))
		{
			goto IL_5b2c;
		}
	}
	{
		int32_t L_3319 = V_240;
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3320 = V_54;
		NullCheck(L_3320);
		if ((((int32_t)L_3319) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_3320)->max_length)), 1)))))
		{
			goto IL_5b2c;
		}
	}
	{
		int32_t L_3321 = V_240;
		int32_t L_3322 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3321) >= ((int32_t)L_3322)))
		{
			goto IL_5b2c;
		}
	}
	{
		Il2CppChar L_3323 = V_242;
		if ((((int32_t)L_3323) == ((int32_t)((int32_t)39))))
		{
			goto IL_5afb;
		}
	}
	{
		Il2CppChar L_3324 = V_242;
		if ((!(((uint32_t)L_3324) == ((uint32_t)((int32_t)8217)))))
		{
			goto IL_5b2c;
		}
	}

IL_5afb:
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3325 = V_54;
		int32_t L_3326 = V_240;
		NullCheck(L_3325);
		Il2CppChar L_3327 = ((L_3325)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3326, 1)))))->___character_0;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3328;
		L_3328 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3327, NULL);
		if (!L_3328)
		{
			goto IL_5b2c;
		}
	}
	{
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3329 = V_54;
		int32_t L_3330 = V_240;
		NullCheck(L_3329);
		Il2CppChar L_3331 = ((L_3329)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3330, 1)))))->___character_0;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3332;
		L_3332 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3331, NULL);
		G_B827_0 = ((((int32_t)L_3332) == ((int32_t)0))? 1 : 0);
		goto IL_5b2d;
	}

IL_5b2c:
	{
		G_B827_0 = 1;
	}

IL_5b2d:
	{
		V_306 = (bool)G_B827_0;
		bool L_3333 = V_306;
		if (!L_3333)
		{
			goto IL_5c3c;
		}
	}
	{
		int32_t L_3334 = V_240;
		int32_t L_3335 = __this->___m_CharacterCount_48;
		if ((!(((uint32_t)L_3334) == ((uint32_t)((int32_t)il2cpp_codegen_subtract(L_3335, 1))))))
		{
			goto IL_5b54;
		}
	}
	{
		Il2CppChar L_3336 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3337;
		L_3337 = Char_IsLetterOrDigit_m14049A362108679FD23E424FD9C5C42057359B72(L_3336, NULL);
		if (L_3337)
		{
			goto IL_5b5a;
		}
	}

IL_5b54:
	{
		int32_t L_3338 = V_240;
		G_B832_0 = ((int32_t)il2cpp_codegen_subtract(L_3338, 1));
		goto IL_5b5c;
	}

IL_5b5a:
	{
		int32_t L_3339 = V_240;
		G_B832_0 = L_3339;
	}

IL_5b5c:
	{
		V_248 = G_B832_0;
		V_41 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3340 = ___1_textInfo;
		NullCheck(L_3340);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3341 = L_3340->___wordInfo_11;
		NullCheck(L_3341);
		V_307 = ((int32_t)(((RuntimeArray*)L_3341)->max_length));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3342 = ___1_textInfo;
		NullCheck(L_3342);
		int32_t L_3343 = L_3342->___wordCount_5;
		V_308 = L_3343;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3344 = ___1_textInfo;
		NullCheck(L_3344);
		int32_t L_3345 = L_3344->___wordCount_5;
		int32_t L_3346 = V_307;
		V_309 = (bool)((((int32_t)((int32_t)il2cpp_codegen_add(L_3345, 1))) > ((int32_t)L_3346))? 1 : 0);
		bool L_3347 = V_309;
		if (!L_3347)
		{
			goto IL_5bad;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3348 = ___1_textInfo;
		NullCheck(L_3348);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B** L_3349 = (WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B**)(&L_3348->___wordInfo_11);
		int32_t L_3350 = V_307;
		il2cpp_codegen_runtime_class_init_inline(TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09_il2cpp_TypeInfo_var);
		TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D(L_3349, ((int32_t)il2cpp_codegen_add(L_3350, 1)), TextInfo_Resize_TisWordInfo_tA466206097891A5A2590896EE164AFC406EB060D_m979FAC74E1ACB2C4A59ED1F2C66707E97688D48D_RuntimeMethod_var);
	}

IL_5bad:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3351 = ___1_textInfo;
		NullCheck(L_3351);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3352 = L_3351->___wordInfo_11;
		int32_t L_3353 = V_308;
		NullCheck(L_3352);
		int32_t L_3354 = V_42;
		((L_3352)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3353)))->___firstCharacterIndex_0 = L_3354;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3355 = ___1_textInfo;
		NullCheck(L_3355);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3356 = L_3355->___wordInfo_11;
		int32_t L_3357 = V_308;
		NullCheck(L_3356);
		int32_t L_3358 = V_248;
		((L_3356)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3357)))->___lastCharacterIndex_1 = L_3358;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3359 = ___1_textInfo;
		NullCheck(L_3359);
		WordInfoU5BU5D_tAD74C9720883D7BB229A20FFAE9EFD2CF9963F7B* L_3360 = L_3359->___wordInfo_11;
		int32_t L_3361 = V_308;
		NullCheck(L_3360);
		int32_t L_3362 = V_248;
		int32_t L_3363 = V_42;
		((L_3360)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3361)))->___characterCount_2 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_subtract(L_3362, L_3363)), 1));
		int32_t L_3364 = V_37;
		V_37 = ((int32_t)il2cpp_codegen_add(L_3364, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3365 = ___1_textInfo;
		V_166 = L_3365;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3366 = V_166;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3367 = V_166;
		NullCheck(L_3367);
		int32_t L_3368 = L_3367->___wordCount_5;
		NullCheck(L_3366);
		L_3366->___wordCount_5 = ((int32_t)il2cpp_codegen_add(L_3368, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3369 = ___1_textInfo;
		NullCheck(L_3369);
		LineInfoU5BU5D_t37598F2175B291797270D1161DC29B6296FB169D* L_3370 = L_3369->___lineInfo_13;
		int32_t L_3371 = V_243;
		NullCheck(L_3370);
		int32_t* L_3372 = (int32_t*)(&((L_3370)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3371)))->___wordCount_5);
		V_310 = L_3372;
		int32_t* L_3373 = V_310;
		int32_t* L_3374 = V_310;
		int32_t L_3375 = *((int32_t*)L_3374);
		*((int32_t*)L_3373) = (int32_t)((int32_t)il2cpp_codegen_add(L_3375, 1));
	}

IL_5c3c:
	{
	}

IL_5c3d:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3376 = ___1_textInfo;
		NullCheck(L_3376);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3377 = L_3376->___textElementInfo_10;
		int32_t L_3378 = V_240;
		NullCheck(L_3377);
		int32_t L_3379 = ((L_3377)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3378)))->___style_33;
		V_249 = (bool)((((int32_t)((int32_t)((int32_t)L_3379&4))) == ((int32_t)4))? 1 : 0);
		bool L_3380 = V_249;
		V_311 = L_3380;
		bool L_3381 = V_311;
		if (!L_3381)
		{
			goto IL_6104;
		}
	}
	{
		V_312 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3382 = ___1_textInfo;
		NullCheck(L_3382);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3383 = L_3382->___textElementInfo_10;
		int32_t L_3384 = V_240;
		NullCheck(L_3383);
		int32_t L_3385 = ((L_3383)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3384)))->___pageNumber_12;
		V_313 = L_3385;
		int32_t L_3386 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3387 = ___0_generationSettings;
		NullCheck(L_3387);
		int32_t L_3388 = L_3387->___maxVisibleCharacters_32;
		if ((((int32_t)L_3386) > ((int32_t)L_3388)))
		{
			goto IL_5cbe;
		}
	}
	{
		int32_t L_3389 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3390 = ___0_generationSettings;
		NullCheck(L_3390);
		int32_t L_3391 = L_3390->___maxVisibleLines_34;
		if ((((int32_t)L_3389) > ((int32_t)L_3391)))
		{
			goto IL_5cbe;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3392 = ___0_generationSettings;
		NullCheck(L_3392);
		int32_t L_3393 = L_3392->___overflowMode_11;
		if ((!(((uint32_t)L_3393) == ((uint32_t)5))))
		{
			goto IL_5cbb;
		}
	}
	{
		int32_t L_3394 = V_313;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3395 = ___0_generationSettings;
		NullCheck(L_3395);
		int32_t L_3396 = L_3395->___pageToDisplay_38;
		G_B842_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_3394, 1))) == ((int32_t)L_3396))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5cbc;
	}

IL_5cbb:
	{
		G_B842_0 = 0;
	}

IL_5cbc:
	{
		G_B844_0 = G_B842_0;
		goto IL_5cbf;
	}

IL_5cbe:
	{
		G_B844_0 = 1;
	}

IL_5cbf:
	{
		V_314 = (bool)G_B844_0;
		bool L_3397 = V_314;
		if (!L_3397)
		{
			goto IL_5cd4;
		}
	}
	{
		V_312 = (bool)0;
	}

IL_5cd4:
	{
		Il2CppChar L_3398 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3399;
		L_3399 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3398, NULL);
		if (L_3399)
		{
			goto IL_5ceb;
		}
	}
	{
		Il2CppChar L_3400 = V_242;
		G_B849_0 = ((((int32_t)((((int32_t)L_3400) == ((int32_t)((int32_t)8203)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5cec;
	}

IL_5ceb:
	{
		G_B849_0 = 0;
	}

IL_5cec:
	{
		V_315 = (bool)G_B849_0;
		bool L_3401 = V_315;
		if (!L_3401)
		{
			goto IL_5d63;
		}
	}
	{
		float L_3402 = V_48;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3403 = ___1_textInfo;
		NullCheck(L_3403);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3404 = L_3403->___textElementInfo_10;
		int32_t L_3405 = V_240;
		NullCheck(L_3404);
		float L_3406 = ((L_3404)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3405)))->___scale_28;
		float L_3407;
		L_3407 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3402, L_3406, NULL);
		V_48 = L_3407;
		int32_t L_3408 = V_313;
		int32_t L_3409 = V_50;
		if ((((int32_t)L_3408) == ((int32_t)L_3409)))
		{
			goto IL_5d27;
		}
	}
	{
		G_B853_0 = (32767.0f);
		goto IL_5d29;
	}

IL_5d27:
	{
		float L_3410 = V_49;
		G_B853_0 = L_3410;
	}

IL_5d29:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3411 = ___1_textInfo;
		NullCheck(L_3411);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3412 = L_3411->___textElementInfo_10;
		int32_t L_3413 = V_240;
		NullCheck(L_3412);
		float L_3414 = ((L_3412)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3413)))->___baseLine_24;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3415 = ___0_generationSettings;
		NullCheck(L_3415);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3416 = L_3415->___fontAsset_4;
		NullCheck(L_3416);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_3417;
		L_3417 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_3416, NULL);
		V_57 = L_3417;
		float L_3418;
		L_3418 = FaceInfo_get_underlineOffset_mB1CBB29ECFFE69047F35E654E7F90755F95DD251((&V_57), NULL);
		float L_3419 = V_48;
		float L_3420;
		L_3420 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(G_B853_0, ((float)il2cpp_codegen_add(L_3414, ((float)il2cpp_codegen_multiply(L_3418, L_3419)))), NULL);
		V_49 = L_3420;
		int32_t L_3421 = V_313;
		V_50 = L_3421;
	}

IL_5d63:
	{
		bool L_3422 = V_5;
		bool L_3423 = V_312;
		if (!((int32_t)(((((int32_t)L_3422) == ((int32_t)0))? 1 : 0)&(int32_t)L_3423)))
		{
			goto IL_5d8d;
		}
	}
	{
		int32_t L_3424 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3425 = V_244;
		int32_t L_3426 = L_3425.___lastVisibleCharacterIndex_9;
		if ((((int32_t)L_3424) > ((int32_t)L_3426)))
		{
			goto IL_5d8d;
		}
	}
	{
		Il2CppChar L_3427 = V_242;
		if ((((int32_t)L_3427) == ((int32_t)((int32_t)10))))
		{
			goto IL_5d8d;
		}
	}
	{
		Il2CppChar L_3428 = V_242;
		G_B859_0 = ((((int32_t)((((int32_t)L_3428) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5d8e;
	}

IL_5d8d:
	{
		G_B859_0 = 0;
	}

IL_5d8e:
	{
		V_316 = (bool)G_B859_0;
		bool L_3429 = V_316;
		if (!L_3429)
		{
			goto IL_5e34;
		}
	}
	{
		int32_t L_3430 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3431 = V_244;
		int32_t L_3432 = L_3431.___lastVisibleCharacterIndex_9;
		if ((!(((uint32_t)L_3430) == ((uint32_t)L_3432))))
		{
			goto IL_5db7;
		}
	}
	{
		Il2CppChar L_3433 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3434;
		L_3434 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3433, NULL);
		G_B863_0 = ((((int32_t)L_3434) == ((int32_t)0))? 1 : 0);
		goto IL_5db8;
	}

IL_5db7:
	{
		G_B863_0 = 1;
	}

IL_5db8:
	{
		V_317 = (bool)G_B863_0;
		bool L_3435 = V_317;
		if (!L_3435)
		{
			goto IL_5e33;
		}
	}
	{
		V_5 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3436 = ___1_textInfo;
		NullCheck(L_3436);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3437 = L_3436->___textElementInfo_10;
		int32_t L_3438 = V_240;
		NullCheck(L_3437);
		float L_3439 = ((L_3437)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3438)))->___scale_28;
		V_47 = L_3439;
		float L_3440 = V_48;
		V_318 = (bool)((((float)L_3440) == ((float)(0.0f)))? 1 : 0);
		bool L_3441 = V_318;
		if (!L_3441)
		{
			goto IL_5df9;
		}
	}
	{
		float L_3442 = V_47;
		V_48 = L_3442;
	}

IL_5df9:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3443 = ___1_textInfo;
		NullCheck(L_3443);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3444 = L_3443->___textElementInfo_10;
		int32_t L_3445 = V_240;
		NullCheck(L_3444);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3446 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3444)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3445)))->___bottomLeft_19);
		float L_3447 = L_3446->___x_2;
		float L_3448 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_6), L_3447, L_3448, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3449 = ___1_textInfo;
		NullCheck(L_3449);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3450 = L_3449->___textElementInfo_10;
		int32_t L_3451 = V_240;
		NullCheck(L_3450);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3452 = ((L_3450)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3451)))->___underlineColor_30;
		V_43 = L_3452;
	}

IL_5e33:
	{
	}

IL_5e34:
	{
		bool L_3453 = V_5;
		if (!L_3453)
		{
			goto IL_5e43;
		}
	}
	{
		int32_t L_3454 = __this->___m_CharacterCount_48;
		G_B871_0 = ((((int32_t)L_3454) == ((int32_t)1))? 1 : 0);
		goto IL_5e44;
	}

IL_5e43:
	{
		G_B871_0 = 0;
	}

IL_5e44:
	{
		V_319 = (bool)G_B871_0;
		bool L_3455 = V_319;
		if (!L_3455)
		{
			goto IL_5ebc;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3456 = ___1_textInfo;
		NullCheck(L_3456);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3457 = L_3456->___textElementInfo_10;
		int32_t L_3458 = V_240;
		NullCheck(L_3457);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3459 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3457)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3458)))->___topRight_20);
		float L_3460 = L_3459->___x_2;
		float L_3461 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3460, L_3461, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3462 = ___1_textInfo;
		NullCheck(L_3462);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3463 = L_3462->___textElementInfo_10;
		int32_t L_3464 = V_240;
		NullCheck(L_3463);
		float L_3465 = ((L_3463)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3464)))->___scale_28;
		V_250 = L_3465;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3466 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3467 = V_7;
		float L_3468 = V_47;
		float L_3469 = V_250;
		float L_3470 = V_48;
		float L_3471 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3472 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3473 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3474 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3466, L_3467, (&V_33), L_3468, L_3469, L_3470, L_3471, L_3472, L_3473, L_3474, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		goto IL_6101;
	}

IL_5ebc:
	{
		bool L_3475 = V_5;
		if (!L_3475)
		{
			goto IL_5ede;
		}
	}
	{
		int32_t L_3476 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3477 = V_244;
		int32_t L_3478 = L_3477.___lastCharacterIndex_8;
		if ((((int32_t)L_3476) == ((int32_t)L_3478)))
		{
			goto IL_5edb;
		}
	}
	{
		int32_t L_3479 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3480 = V_244;
		int32_t L_3481 = L_3480.___lastVisibleCharacterIndex_9;
		G_B877_0 = ((((int32_t)((((int32_t)L_3479) < ((int32_t)L_3481))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_5edc;
	}

IL_5edb:
	{
		G_B877_0 = 1;
	}

IL_5edc:
	{
		G_B879_0 = G_B877_0;
		goto IL_5edf;
	}

IL_5ede:
	{
		G_B879_0 = 0;
	}

IL_5edf:
	{
		V_320 = (bool)G_B879_0;
		bool L_3482 = V_320;
		if (!L_3482)
		{
			goto IL_5fd1;
		}
	}
	{
		Il2CppChar L_3483 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3484;
		L_3484 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3483, NULL);
		if (L_3484)
		{
			goto IL_5f05;
		}
	}
	{
		Il2CppChar L_3485 = V_242;
		G_B883_0 = ((((int32_t)L_3485) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_5f06;
	}

IL_5f05:
	{
		G_B883_0 = 1;
	}

IL_5f06:
	{
		V_321 = (bool)G_B883_0;
		bool L_3486 = V_321;
		if (!L_3486)
		{
			goto IL_5f66;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3487 = V_244;
		int32_t L_3488 = L_3487.___lastVisibleCharacterIndex_9;
		V_322 = L_3488;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3489 = ___1_textInfo;
		NullCheck(L_3489);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3490 = L_3489->___textElementInfo_10;
		int32_t L_3491 = V_322;
		NullCheck(L_3490);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3492 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3490)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3491)))->___topRight_20);
		float L_3493 = L_3492->___x_2;
		float L_3494 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3493, L_3494, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3495 = ___1_textInfo;
		NullCheck(L_3495);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3496 = L_3495->___textElementInfo_10;
		int32_t L_3497 = V_322;
		NullCheck(L_3496);
		float L_3498 = ((L_3496)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3497)))->___scale_28;
		V_250 = L_3498;
		goto IL_5fa1;
	}

IL_5f66:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3499 = ___1_textInfo;
		NullCheck(L_3499);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3500 = L_3499->___textElementInfo_10;
		int32_t L_3501 = V_240;
		NullCheck(L_3500);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3502 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3500)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3501)))->___topRight_20);
		float L_3503 = L_3502->___x_2;
		float L_3504 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3503, L_3504, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3505 = ___1_textInfo;
		NullCheck(L_3505);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3506 = L_3505->___textElementInfo_10;
		int32_t L_3507 = V_240;
		NullCheck(L_3506);
		float L_3508 = ((L_3506)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3507)))->___scale_28;
		V_250 = L_3508;
	}

IL_5fa1:
	{
		V_5 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3509 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3510 = V_7;
		float L_3511 = V_47;
		float L_3512 = V_250;
		float L_3513 = V_48;
		float L_3514 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3515 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3516 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3517 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3509, L_3510, (&V_33), L_3511, L_3512, L_3513, L_3514, L_3515, L_3516, L_3517, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		goto IL_6101;
	}

IL_5fd1:
	{
		bool L_3518 = V_5;
		if (!L_3518)
		{
			goto IL_5fe0;
		}
	}
	{
		bool L_3519 = V_312;
		G_B890_0 = ((((int32_t)L_3519) == ((int32_t)0))? 1 : 0);
		goto IL_5fe1;
	}

IL_5fe0:
	{
		G_B890_0 = 0;
	}

IL_5fe1:
	{
		V_323 = (bool)G_B890_0;
		bool L_3520 = V_323;
		if (!L_3520)
		{
			goto IL_605d;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3521 = ___1_textInfo;
		NullCheck(L_3521);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3522 = L_3521->___textElementInfo_10;
		int32_t L_3523 = V_240;
		NullCheck(L_3522);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3524 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3522)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3523, 1)))))->___topRight_20);
		float L_3525 = L_3524->___x_2;
		float L_3526 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3525, L_3526, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3527 = ___1_textInfo;
		NullCheck(L_3527);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3528 = L_3527->___textElementInfo_10;
		int32_t L_3529 = V_240;
		NullCheck(L_3528);
		float L_3530 = ((L_3528)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3529, 1)))))->___scale_28;
		V_250 = L_3530;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3531 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3532 = V_7;
		float L_3533 = V_47;
		float L_3534 = V_250;
		float L_3535 = V_48;
		float L_3536 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3537 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3538 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3539 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3531, L_3532, (&V_33), L_3533, L_3534, L_3535, L_3536, L_3537, L_3538, L_3539, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
		goto IL_6101;
	}

IL_605d:
	{
		bool L_3540 = V_5;
		if (!L_3540)
		{
			goto IL_608d;
		}
	}
	{
		int32_t L_3541 = V_240;
		int32_t L_3542 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3541) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_3542, 1)))))
		{
			goto IL_608d;
		}
	}
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3543 = V_43;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3544 = ___1_textInfo;
		NullCheck(L_3544);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3545 = L_3544->___textElementInfo_10;
		int32_t L_3546 = V_240;
		NullCheck(L_3545);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3547 = ((L_3545)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3546, 1)))))->___underlineColor_30;
		bool L_3548;
		L_3548 = ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875(L_3543, L_3547, NULL);
		G_B896_0 = ((((int32_t)L_3548) == ((int32_t)0))? 1 : 0);
		goto IL_608e;
	}

IL_608d:
	{
		G_B896_0 = 0;
	}

IL_608e:
	{
		V_324 = (bool)G_B896_0;
		bool L_3549 = V_324;
		if (!L_3549)
		{
			goto IL_6101;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3550 = ___1_textInfo;
		NullCheck(L_3550);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3551 = L_3550->___textElementInfo_10;
		int32_t L_3552 = V_240;
		NullCheck(L_3551);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3553 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3551)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3552)))->___topRight_20);
		float L_3554 = L_3553->___x_2;
		float L_3555 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3554, L_3555, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3556 = ___1_textInfo;
		NullCheck(L_3556);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3557 = L_3556->___textElementInfo_10;
		int32_t L_3558 = V_240;
		NullCheck(L_3557);
		float L_3559 = ((L_3557)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3558)))->___scale_28;
		V_250 = L_3559;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3560 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3561 = V_7;
		float L_3562 = V_47;
		float L_3563 = V_250;
		float L_3564 = V_48;
		float L_3565 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3566 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3567 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3568 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3560, L_3561, (&V_33), L_3562, L_3563, L_3564, L_3565, L_3566, L_3567, L_3568, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
	}

IL_6101:
	{
		goto IL_617f;
	}

IL_6104:
	{
		bool L_3569 = V_5;
		V_325 = L_3569;
		bool L_3570 = V_325;
		if (!L_3570)
		{
			goto IL_617e;
		}
	}
	{
		V_5 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3571 = ___1_textInfo;
		NullCheck(L_3571);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3572 = L_3571->___textElementInfo_10;
		int32_t L_3573 = V_240;
		NullCheck(L_3572);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3574 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3572)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3573, 1)))))->___topRight_20);
		float L_3575 = L_3574->___x_2;
		float L_3576 = V_49;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_7), L_3575, L_3576, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3577 = ___1_textInfo;
		NullCheck(L_3577);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3578 = L_3577->___textElementInfo_10;
		int32_t L_3579 = V_240;
		NullCheck(L_3578);
		float L_3580 = ((L_3578)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3579, 1)))))->___scale_28;
		V_250 = L_3580;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3581 = V_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3582 = V_7;
		float L_3583 = V_47;
		float L_3584 = V_250;
		float L_3585 = V_48;
		float L_3586 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3587 = V_43;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3588 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3589 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3581, L_3582, (&V_33), L_3583, L_3584, L_3585, L_3586, L_3587, L_3588, L_3589, NULL);
		V_48 = (0.0f);
		V_49 = (32767.0f);
	}

IL_617e:
	{
	}

IL_617f:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3590 = ___1_textInfo;
		NullCheck(L_3590);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3591 = L_3590->___textElementInfo_10;
		int32_t L_3592 = V_240;
		NullCheck(L_3591);
		int32_t L_3593 = ((L_3591)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3592)))->___style_33;
		V_251 = (bool)((((int32_t)((int32_t)((int32_t)L_3593&((int32_t)64)))) == ((int32_t)((int32_t)64)))? 1 : 0);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3594 = V_241;
		NullCheck(L_3594);
		FaceInfo_t12F0319E555A62CBA1D9E51A16C7963393932756 L_3595;
		L_3595 = FontAsset_get_faceInfo_mF020EC579E3C18A6279D55D86AF1C585031B49A9(L_3594, NULL);
		V_57 = L_3595;
		float L_3596;
		L_3596 = FaceInfo_get_strikethroughOffset_m7997E4A1512FE358331B3A6543C62C92A0AA5CA5((&V_57), NULL);
		V_252 = L_3596;
		bool L_3597 = V_251;
		V_326 = L_3597;
		bool L_3598 = V_326;
		if (!L_3598)
		{
			goto IL_66b6;
		}
	}
	{
		int32_t L_3599 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3600 = ___0_generationSettings;
		NullCheck(L_3600);
		int32_t L_3601 = L_3600->___maxVisibleCharacters_32;
		if ((((int32_t)L_3599) > ((int32_t)L_3601)))
		{
			goto IL_61fe;
		}
	}
	{
		int32_t L_3602 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3603 = ___0_generationSettings;
		NullCheck(L_3603);
		int32_t L_3604 = L_3603->___maxVisibleLines_34;
		if ((((int32_t)L_3602) > ((int32_t)L_3604)))
		{
			goto IL_61fe;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3605 = ___0_generationSettings;
		NullCheck(L_3605);
		int32_t L_3606 = L_3605->___overflowMode_11;
		if ((!(((uint32_t)L_3606) == ((uint32_t)5))))
		{
			goto IL_61fb;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3607 = ___1_textInfo;
		NullCheck(L_3607);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3608 = L_3607->___textElementInfo_10;
		int32_t L_3609 = V_240;
		NullCheck(L_3608);
		int32_t L_3610 = ((L_3608)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3609)))->___pageNumber_12;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3611 = ___0_generationSettings;
		NullCheck(L_3611);
		int32_t L_3612 = L_3611->___pageToDisplay_38;
		G_B908_0 = ((((int32_t)((int32_t)il2cpp_codegen_add(L_3610, 1))) == ((int32_t)L_3612))? 1 : 0);
		goto IL_61fc;
	}

IL_61fb:
	{
		G_B908_0 = 1;
	}

IL_61fc:
	{
		G_B910_0 = G_B908_0;
		goto IL_61ff;
	}

IL_61fe:
	{
		G_B910_0 = 0;
	}

IL_61ff:
	{
		V_327 = (bool)G_B910_0;
		bool L_3613 = V_8;
		bool L_3614 = V_327;
		if (!((int32_t)(((((int32_t)L_3613) == ((int32_t)0))? 1 : 0)&(int32_t)L_3614)))
		{
			goto IL_622f;
		}
	}
	{
		int32_t L_3615 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3616 = V_244;
		int32_t L_3617 = L_3616.___lastVisibleCharacterIndex_9;
		if ((((int32_t)L_3615) > ((int32_t)L_3617)))
		{
			goto IL_622f;
		}
	}
	{
		Il2CppChar L_3618 = V_242;
		if ((((int32_t)L_3618) == ((int32_t)((int32_t)10))))
		{
			goto IL_622f;
		}
	}
	{
		Il2CppChar L_3619 = V_242;
		G_B915_0 = ((((int32_t)((((int32_t)L_3619) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_6230;
	}

IL_622f:
	{
		G_B915_0 = 0;
	}

IL_6230:
	{
		V_328 = (bool)G_B915_0;
		bool L_3620 = V_328;
		if (!L_3620)
		{
			goto IL_62fc;
		}
	}
	{
		int32_t L_3621 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3622 = V_244;
		int32_t L_3623 = L_3622.___lastVisibleCharacterIndex_9;
		if ((!(((uint32_t)L_3621) == ((uint32_t)L_3623))))
		{
			goto IL_6259;
		}
	}
	{
		Il2CppChar L_3624 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3625;
		L_3625 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3624, NULL);
		G_B919_0 = ((((int32_t)L_3625) == ((int32_t)0))? 1 : 0);
		goto IL_625a;
	}

IL_6259:
	{
		G_B919_0 = 1;
	}

IL_625a:
	{
		V_329 = (bool)G_B919_0;
		bool L_3626 = V_329;
		if (!L_3626)
		{
			goto IL_62fb;
		}
	}
	{
		V_8 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3627 = ___1_textInfo;
		NullCheck(L_3627);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3628 = L_3627->___textElementInfo_10;
		int32_t L_3629 = V_240;
		NullCheck(L_3628);
		float L_3630 = ((L_3628)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3629)))->___pointSize_10;
		V_51 = L_3630;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3631 = ___1_textInfo;
		NullCheck(L_3631);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3632 = L_3631->___textElementInfo_10;
		int32_t L_3633 = V_240;
		NullCheck(L_3632);
		float L_3634 = ((L_3632)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3633)))->___scale_28;
		V_52 = L_3634;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3635 = ___1_textInfo;
		NullCheck(L_3635);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3636 = L_3635->___textElementInfo_10;
		int32_t L_3637 = V_240;
		NullCheck(L_3636);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3638 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3636)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3637)))->___bottomLeft_19);
		float L_3639 = L_3638->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3640 = ___1_textInfo;
		NullCheck(L_3640);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3641 = L_3640->___textElementInfo_10;
		int32_t L_3642 = V_240;
		NullCheck(L_3641);
		float L_3643 = ((L_3641)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3642)))->___baseLine_24;
		float L_3644 = V_252;
		float L_3645 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_9), L_3639, ((float)il2cpp_codegen_add(L_3643, ((float)il2cpp_codegen_multiply(L_3644, L_3645)))), (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3646 = ___1_textInfo;
		NullCheck(L_3646);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3647 = L_3646->___textElementInfo_10;
		int32_t L_3648 = V_240;
		NullCheck(L_3647);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3649 = ((L_3647)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3648)))->___strikethroughColor_31;
		V_44 = L_3649;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3650 = ___1_textInfo;
		NullCheck(L_3650);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3651 = L_3650->___textElementInfo_10;
		int32_t L_3652 = V_240;
		NullCheck(L_3651);
		float L_3653 = ((L_3651)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3652)))->___baseLine_24;
		V_53 = L_3653;
	}

IL_62fb:
	{
	}

IL_62fc:
	{
		bool L_3654 = V_8;
		if (!L_3654)
		{
			goto IL_630b;
		}
	}
	{
		int32_t L_3655 = __this->___m_CharacterCount_48;
		G_B925_0 = ((((int32_t)L_3655) == ((int32_t)1))? 1 : 0);
		goto IL_630c;
	}

IL_630b:
	{
		G_B925_0 = 0;
	}

IL_630c:
	{
		V_330 = (bool)G_B925_0;
		bool L_3656 = V_330;
		if (!L_3656)
		{
			goto IL_6378;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3657 = ___1_textInfo;
		NullCheck(L_3657);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3658 = L_3657->___textElementInfo_10;
		int32_t L_3659 = V_240;
		NullCheck(L_3658);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3660 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3658)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3659)))->___topRight_20);
		float L_3661 = L_3660->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3662 = ___1_textInfo;
		NullCheck(L_3662);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3663 = L_3662->___textElementInfo_10;
		int32_t L_3664 = V_240;
		NullCheck(L_3663);
		float L_3665 = ((L_3663)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3664)))->___baseLine_24;
		float L_3666 = V_252;
		float L_3667 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3661, ((float)il2cpp_codegen_add(L_3665, ((float)il2cpp_codegen_multiply(L_3666, L_3667)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3668 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3669 = V_10;
		float L_3670 = V_52;
		float L_3671 = V_52;
		float L_3672 = V_52;
		float L_3673 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3674 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3675 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3676 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3668, L_3669, (&V_33), L_3670, L_3671, L_3672, L_3673, L_3674, L_3675, L_3676, NULL);
		goto IL_66b3;
	}

IL_6378:
	{
		bool L_3677 = V_8;
		if (!L_3677)
		{
			goto IL_6389;
		}
	}
	{
		int32_t L_3678 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3679 = V_244;
		int32_t L_3680 = L_3679.___lastCharacterIndex_8;
		G_B930_0 = ((((int32_t)L_3678) == ((int32_t)L_3680))? 1 : 0);
		goto IL_638a;
	}

IL_6389:
	{
		G_B930_0 = 0;
	}

IL_638a:
	{
		V_331 = (bool)G_B930_0;
		bool L_3681 = V_331;
		if (!L_3681)
		{
			goto IL_6472;
		}
	}
	{
		Il2CppChar L_3682 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3683;
		L_3683 = Char_IsWhiteSpace_m02AEC6EA19513CAFC6882CFCA54C45794D2B5924(L_3682, NULL);
		if (L_3683)
		{
			goto IL_63b0;
		}
	}
	{
		Il2CppChar L_3684 = V_242;
		G_B934_0 = ((((int32_t)L_3684) == ((int32_t)((int32_t)8203)))? 1 : 0);
		goto IL_63b1;
	}

IL_63b0:
	{
		G_B934_0 = 1;
	}

IL_63b1:
	{
		V_332 = (bool)G_B934_0;
		bool L_3685 = V_332;
		if (!L_3685)
		{
			goto IL_6413;
		}
	}
	{
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3686 = V_244;
		int32_t L_3687 = L_3686.___lastVisibleCharacterIndex_9;
		V_333 = L_3687;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3688 = ___1_textInfo;
		NullCheck(L_3688);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3689 = L_3688->___textElementInfo_10;
		int32_t L_3690 = V_333;
		NullCheck(L_3689);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3691 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3689)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3690)))->___topRight_20);
		float L_3692 = L_3691->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3693 = ___1_textInfo;
		NullCheck(L_3693);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3694 = L_3693->___textElementInfo_10;
		int32_t L_3695 = V_333;
		NullCheck(L_3694);
		float L_3696 = ((L_3694)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3695)))->___baseLine_24;
		float L_3697 = V_252;
		float L_3698 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3692, ((float)il2cpp_codegen_add(L_3696, ((float)il2cpp_codegen_multiply(L_3697, L_3698)))), (0.0f), NULL);
		goto IL_6450;
	}

IL_6413:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3699 = ___1_textInfo;
		NullCheck(L_3699);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3700 = L_3699->___textElementInfo_10;
		int32_t L_3701 = V_240;
		NullCheck(L_3700);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3702 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3700)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3701)))->___topRight_20);
		float L_3703 = L_3702->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3704 = ___1_textInfo;
		NullCheck(L_3704);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3705 = L_3704->___textElementInfo_10;
		int32_t L_3706 = V_240;
		NullCheck(L_3705);
		float L_3707 = ((L_3705)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3706)))->___baseLine_24;
		float L_3708 = V_252;
		float L_3709 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3703, ((float)il2cpp_codegen_add(L_3707, ((float)il2cpp_codegen_multiply(L_3708, L_3709)))), (0.0f), NULL);
	}

IL_6450:
	{
		V_8 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3710 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3711 = V_10;
		float L_3712 = V_52;
		float L_3713 = V_52;
		float L_3714 = V_52;
		float L_3715 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3716 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3717 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3718 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3710, L_3711, (&V_33), L_3712, L_3713, L_3714, L_3715, L_3716, L_3717, L_3718, NULL);
		goto IL_66b3;
	}

IL_6472:
	{
		bool L_3719 = V_8;
		if (!L_3719)
		{
			goto IL_64c3;
		}
	}
	{
		int32_t L_3720 = V_240;
		int32_t L_3721 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3720) >= ((int32_t)L_3721)))
		{
			goto IL_64c3;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3722 = ___1_textInfo;
		NullCheck(L_3722);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3723 = L_3722->___textElementInfo_10;
		int32_t L_3724 = V_240;
		NullCheck(L_3723);
		float L_3725 = ((L_3723)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3724, 1)))))->___pointSize_10;
		float L_3726 = V_51;
		if ((!(((float)L_3725) == ((float)L_3726))))
		{
			goto IL_64c0;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3727 = ___1_textInfo;
		NullCheck(L_3727);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3728 = L_3727->___textElementInfo_10;
		int32_t L_3729 = V_240;
		NullCheck(L_3728);
		float L_3730 = ((L_3728)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3729, 1)))))->___baseLine_24;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3731 = V_246;
		float L_3732 = L_3731.___y_3;
		float L_3733 = V_53;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		bool L_3734;
		L_3734 = TextGeneratorUtilities_Approximately_m696ABB909732F536F1FF83EA8CE34CF53266794D(((float)il2cpp_codegen_add(L_3730, L_3732)), L_3733, NULL);
		G_B943_0 = ((((int32_t)L_3734) == ((int32_t)0))? 1 : 0);
		goto IL_64c1;
	}

IL_64c0:
	{
		G_B943_0 = 1;
	}

IL_64c1:
	{
		G_B945_0 = G_B943_0;
		goto IL_64c4;
	}

IL_64c3:
	{
		G_B945_0 = 0;
	}

IL_64c4:
	{
		V_334 = (bool)G_B945_0;
		bool L_3735 = V_334;
		if (!L_3735)
		{
			goto IL_659d;
		}
	}
	{
		V_8 = (bool)0;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3736 = V_244;
		int32_t L_3737 = L_3736.___lastVisibleCharacterIndex_9;
		V_335 = L_3737;
		int32_t L_3738 = V_240;
		int32_t L_3739 = V_335;
		V_336 = (bool)((((int32_t)L_3738) > ((int32_t)L_3739))? 1 : 0);
		bool L_3740 = V_336;
		if (!L_3740)
		{
			goto IL_6543;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3741 = ___1_textInfo;
		NullCheck(L_3741);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3742 = L_3741->___textElementInfo_10;
		int32_t L_3743 = V_335;
		NullCheck(L_3742);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3744 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3742)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3743)))->___topRight_20);
		float L_3745 = L_3744->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3746 = ___1_textInfo;
		NullCheck(L_3746);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3747 = L_3746->___textElementInfo_10;
		int32_t L_3748 = V_335;
		NullCheck(L_3747);
		float L_3749 = ((L_3747)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3748)))->___baseLine_24;
		float L_3750 = V_252;
		float L_3751 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3745, ((float)il2cpp_codegen_add(L_3749, ((float)il2cpp_codegen_multiply(L_3750, L_3751)))), (0.0f), NULL);
		goto IL_657e;
	}

IL_6543:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3752 = ___1_textInfo;
		NullCheck(L_3752);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3753 = L_3752->___textElementInfo_10;
		int32_t L_3754 = V_240;
		NullCheck(L_3753);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3755 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3753)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3754)))->___topRight_20);
		float L_3756 = L_3755->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3757 = ___1_textInfo;
		NullCheck(L_3757);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3758 = L_3757->___textElementInfo_10;
		int32_t L_3759 = V_240;
		NullCheck(L_3758);
		float L_3760 = ((L_3758)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3759)))->___baseLine_24;
		float L_3761 = V_252;
		float L_3762 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3756, ((float)il2cpp_codegen_add(L_3760, ((float)il2cpp_codegen_multiply(L_3761, L_3762)))), (0.0f), NULL);
	}

IL_657e:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3763 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3764 = V_10;
		float L_3765 = V_52;
		float L_3766 = V_52;
		float L_3767 = V_52;
		float L_3768 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3769 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3770 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3771 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3763, L_3764, (&V_33), L_3765, L_3766, L_3767, L_3768, L_3769, L_3770, L_3771, NULL);
		goto IL_66b3;
	}

IL_659d:
	{
		bool L_3772 = V_8;
		if (!L_3772)
		{
			goto IL_65ce;
		}
	}
	{
		int32_t L_3773 = V_240;
		int32_t L_3774 = __this->___m_CharacterCount_48;
		if ((((int32_t)L_3773) >= ((int32_t)L_3774)))
		{
			goto IL_65ce;
		}
	}
	{
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3775 = V_241;
		NullCheck(L_3775);
		int32_t L_3776;
		L_3776 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(L_3775, NULL);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3777 = V_54;
		int32_t L_3778 = V_240;
		NullCheck(L_3777);
		FontAsset_t61A6446D934E582651044E33D250EA8D306AB958* L_3779 = ((L_3777)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add(L_3778, 1)))))->___fontAsset_4;
		NullCheck(L_3779);
		int32_t L_3780;
		L_3780 = Object_GetInstanceID_m554FF4073C9465F3835574CC084E68AAEEC6CC6A(L_3779, NULL);
		G_B954_0 = ((((int32_t)((((int32_t)L_3776) == ((int32_t)L_3780))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_65cf;
	}

IL_65ce:
	{
		G_B954_0 = 0;
	}

IL_65cf:
	{
		V_337 = (bool)G_B954_0;
		bool L_3781 = V_337;
		if (!L_3781)
		{
			goto IL_6638;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3782 = ___1_textInfo;
		NullCheck(L_3782);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3783 = L_3782->___textElementInfo_10;
		int32_t L_3784 = V_240;
		NullCheck(L_3783);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3785 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3783)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3784)))->___topRight_20);
		float L_3786 = L_3785->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3787 = ___1_textInfo;
		NullCheck(L_3787);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3788 = L_3787->___textElementInfo_10;
		int32_t L_3789 = V_240;
		NullCheck(L_3788);
		float L_3790 = ((L_3788)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3789)))->___baseLine_24;
		float L_3791 = V_252;
		float L_3792 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3786, ((float)il2cpp_codegen_add(L_3790, ((float)il2cpp_codegen_multiply(L_3791, L_3792)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3793 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3794 = V_10;
		float L_3795 = V_52;
		float L_3796 = V_52;
		float L_3797 = V_52;
		float L_3798 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3799 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3800 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3801 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3793, L_3794, (&V_33), L_3795, L_3796, L_3797, L_3798, L_3799, L_3800, L_3801, NULL);
		goto IL_66b3;
	}

IL_6638:
	{
		bool L_3802 = V_8;
		if (!L_3802)
		{
			goto IL_6647;
		}
	}
	{
		bool L_3803 = V_327;
		G_B959_0 = ((((int32_t)L_3803) == ((int32_t)0))? 1 : 0);
		goto IL_6648;
	}

IL_6647:
	{
		G_B959_0 = 0;
	}

IL_6648:
	{
		V_338 = (bool)G_B959_0;
		bool L_3804 = V_338;
		if (!L_3804)
		{
			goto IL_66b3;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3805 = ___1_textInfo;
		NullCheck(L_3805);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3806 = L_3805->___textElementInfo_10;
		int32_t L_3807 = V_240;
		NullCheck(L_3806);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3808 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3806)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3807, 1)))))->___topRight_20);
		float L_3809 = L_3808->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3810 = ___1_textInfo;
		NullCheck(L_3810);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3811 = L_3810->___textElementInfo_10;
		int32_t L_3812 = V_240;
		NullCheck(L_3811);
		float L_3813 = ((L_3811)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3812, 1)))))->___baseLine_24;
		float L_3814 = V_252;
		float L_3815 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3809, ((float)il2cpp_codegen_add(L_3813, ((float)il2cpp_codegen_multiply(L_3814, L_3815)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3816 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3817 = V_10;
		float L_3818 = V_52;
		float L_3819 = V_52;
		float L_3820 = V_52;
		float L_3821 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3822 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3823 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3824 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3816, L_3817, (&V_33), L_3818, L_3819, L_3820, L_3821, L_3822, L_3823, L_3824, NULL);
	}

IL_66b3:
	{
		goto IL_6725;
	}

IL_66b6:
	{
		bool L_3825 = V_8;
		V_339 = L_3825;
		bool L_3826 = V_339;
		if (!L_3826)
		{
			goto IL_6724;
		}
	}
	{
		V_8 = (bool)0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3827 = ___1_textInfo;
		NullCheck(L_3827);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3828 = L_3827->___textElementInfo_10;
		int32_t L_3829 = V_240;
		NullCheck(L_3828);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3830 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3828)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3829, 1)))))->___topRight_20);
		float L_3831 = L_3830->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3832 = ___1_textInfo;
		NullCheck(L_3832);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3833 = L_3832->___textElementInfo_10;
		int32_t L_3834 = V_240;
		NullCheck(L_3833);
		float L_3835 = ((L_3833)->GetAddressAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_subtract(L_3834, 1)))))->___baseLine_24;
		float L_3836 = V_252;
		float L_3837 = V_52;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_10), L_3831, ((float)il2cpp_codegen_add(L_3835, ((float)il2cpp_codegen_multiply(L_3836, L_3837)))), (0.0f), NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3838 = V_9;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3839 = V_10;
		float L_3840 = V_52;
		float L_3841 = V_52;
		float L_3842 = V_52;
		float L_3843 = V_46;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3844 = V_44;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3845 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3846 = ___1_textInfo;
		TextGenerator_DrawUnderlineMesh_m7BA49F01C2BC1BEF7845A3D8487B45F15A3BB20E(__this, L_3838, L_3839, (&V_33), L_3840, L_3841, L_3842, L_3843, L_3844, L_3845, L_3846, NULL);
	}

IL_6724:
	{
	}

IL_6725:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3847 = ___1_textInfo;
		NullCheck(L_3847);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3848 = L_3847->___textElementInfo_10;
		int32_t L_3849 = V_240;
		NullCheck(L_3848);
		int32_t L_3850 = ((L_3848)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3849)))->___style_33;
		V_253 = (bool)((((int32_t)((int32_t)((int32_t)L_3850&((int32_t)512)))) == ((int32_t)((int32_t)512)))? 1 : 0);
		bool L_3851 = V_253;
		V_340 = L_3851;
		bool L_3852 = V_340;
		if (!L_3852)
		{
			goto IL_6afb;
		}
	}
	{
		V_341 = (bool)1;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3853 = ___1_textInfo;
		NullCheck(L_3853);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3854 = L_3853->___textElementInfo_10;
		int32_t L_3855 = V_240;
		NullCheck(L_3854);
		int32_t L_3856 = ((L_3854)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3855)))->___pageNumber_12;
		V_342 = L_3856;
		int32_t L_3857 = V_240;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3858 = ___0_generationSettings;
		NullCheck(L_3858);
		int32_t L_3859 = L_3858->___maxVisibleCharacters_32;
		if ((((int32_t)L_3857) > ((int32_t)L_3859)))
		{
			goto IL_67ae;
		}
	}
	{
		int32_t L_3860 = V_243;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3861 = ___0_generationSettings;
		NullCheck(L_3861);
		int32_t L_3862 = L_3861->___maxVisibleLines_34;
		if ((((int32_t)L_3860) > ((int32_t)L_3862)))
		{
			goto IL_67ae;
		}
	}
	{
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3863 = ___0_generationSettings;
		NullCheck(L_3863);
		int32_t L_3864 = L_3863->___overflowMode_11;
		if ((!(((uint32_t)L_3864) == ((uint32_t)5))))
		{
			goto IL_67ab;
		}
	}
	{
		int32_t L_3865 = V_342;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3866 = ___0_generationSettings;
		NullCheck(L_3866);
		int32_t L_3867 = L_3866->___pageToDisplay_38;
		G_B971_0 = ((((int32_t)((((int32_t)((int32_t)il2cpp_codegen_add(L_3865, 1))) == ((int32_t)L_3867))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_67ac;
	}

IL_67ab:
	{
		G_B971_0 = 0;
	}

IL_67ac:
	{
		G_B973_0 = G_B971_0;
		goto IL_67af;
	}

IL_67ae:
	{
		G_B973_0 = 1;
	}

IL_67af:
	{
		V_343 = (bool)G_B973_0;
		bool L_3868 = V_343;
		if (!L_3868)
		{
			goto IL_67c4;
		}
	}
	{
		V_341 = (bool)0;
	}

IL_67c4:
	{
		bool L_3869 = V_11;
		bool L_3870 = V_341;
		if (!((int32_t)(((((int32_t)L_3869) == ((int32_t)0))? 1 : 0)&(int32_t)L_3870)))
		{
			goto IL_67ee;
		}
	}
	{
		int32_t L_3871 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3872 = V_244;
		int32_t L_3873 = L_3872.___lastVisibleCharacterIndex_9;
		if ((((int32_t)L_3871) > ((int32_t)L_3873)))
		{
			goto IL_67ee;
		}
	}
	{
		Il2CppChar L_3874 = V_242;
		if ((((int32_t)L_3874) == ((int32_t)((int32_t)10))))
		{
			goto IL_67ee;
		}
	}
	{
		Il2CppChar L_3875 = V_242;
		G_B980_0 = ((((int32_t)((((int32_t)L_3875) == ((int32_t)((int32_t)13)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_67ef;
	}

IL_67ee:
	{
		G_B980_0 = 0;
	}

IL_67ef:
	{
		V_344 = (bool)G_B980_0;
		bool L_3876 = V_344;
		if (!L_3876)
		{
			goto IL_6856;
		}
	}
	{
		int32_t L_3877 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3878 = V_244;
		int32_t L_3879 = L_3878.___lastVisibleCharacterIndex_9;
		if ((!(((uint32_t)L_3877) == ((uint32_t)L_3879))))
		{
			goto IL_6815;
		}
	}
	{
		Il2CppChar L_3880 = V_242;
		il2cpp_codegen_runtime_class_init_inline(Char_t521A6F19B456D956AF452D926C32709DC03D6B17_il2cpp_TypeInfo_var);
		bool L_3881;
		L_3881 = Char_IsSeparator_m8DBA05CCFA10131140E40057E6553F7AC7397BF9(L_3880, NULL);
		G_B984_0 = ((((int32_t)L_3881) == ((int32_t)0))? 1 : 0);
		goto IL_6816;
	}

IL_6815:
	{
		G_B984_0 = 1;
	}

IL_6816:
	{
		V_345 = (bool)G_B984_0;
		bool L_3882 = V_345;
		if (!L_3882)
		{
			goto IL_6855;
		}
	}
	{
		V_11 = (bool)1;
		il2cpp_codegen_runtime_class_init_inline(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3883 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largePositiveVector2_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3884;
		L_3884 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_3883, NULL);
		V_12 = L_3884;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3885 = ((TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_StaticFields*)il2cpp_codegen_static_fields_for(TextGeneratorUtilities_tAD0F329B1A5C7CC27CF63086C11FE092B43FED53_il2cpp_TypeInfo_var))->___largeNegativeVector2_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3886;
		L_3886 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_3885, NULL);
		V_13 = L_3886;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3887 = ___1_textInfo;
		NullCheck(L_3887);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3888 = L_3887->___textElementInfo_10;
		int32_t L_3889 = V_240;
		NullCheck(L_3888);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3890 = ((L_3888)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3889)))->___highlightColor_32;
		V_45 = L_3890;
	}

IL_6855:
	{
	}

IL_6856:
	{
		bool L_3891 = V_11;
		V_346 = L_3891;
		bool L_3892 = V_346;
		if (!L_3892)
		{
			goto IL_6a45;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3893 = ___1_textInfo;
		NullCheck(L_3893);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3894 = L_3893->___textElementInfo_10;
		int32_t L_3895 = V_240;
		NullCheck(L_3894);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3896 = ((L_3894)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3895)))->___highlightColor_32;
		V_347 = L_3896;
		V_348 = (bool)0;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3897 = V_45;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3898 = V_347;
		bool L_3899;
		L_3899 = ColorUtilities_CompareColors_m0F0F140129DEE889FB8AE3B2921C495E94B5E875(L_3897, L_3898, NULL);
		V_349 = (bool)((((int32_t)L_3899) == ((int32_t)0))? 1 : 0);
		bool L_3900 = V_349;
		if (!L_3900)
		{
			goto IL_698a;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3901 = V_13;
		float L_3902 = L_3901.___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3903 = ___1_textInfo;
		NullCheck(L_3903);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3904 = L_3903->___textElementInfo_10;
		int32_t L_3905 = V_240;
		NullCheck(L_3904);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3906 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3904)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3905)))->___bottomLeft_19);
		float L_3907 = L_3906->___x_2;
		(&V_13)->___x_2 = ((float)(((float)il2cpp_codegen_add(L_3902, L_3907))/(2.0f)));
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3908 = V_12;
		float L_3909 = L_3908.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3910 = ___1_textInfo;
		NullCheck(L_3910);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3911 = L_3910->___textElementInfo_10;
		int32_t L_3912 = V_240;
		NullCheck(L_3911);
		float L_3913 = ((L_3911)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3912)))->___descender_25;
		float L_3914;
		L_3914 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_3909, L_3913, NULL);
		(&V_12)->___y_3 = L_3914;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3915 = V_13;
		float L_3916 = L_3915.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3917 = ___1_textInfo;
		NullCheck(L_3917);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3918 = L_3917->___textElementInfo_10;
		int32_t L_3919 = V_240;
		NullCheck(L_3918);
		float L_3920 = ((L_3918)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3919)))->___ascender_23;
		float L_3921;
		L_3921 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3916, L_3920, NULL);
		(&V_13)->___y_3 = L_3921;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3922 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3923 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3924 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3925 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3926 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3922, L_3923, (&V_33), L_3924, L_3925, L_3926, NULL);
		V_11 = (bool)1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3927 = V_13;
		V_12 = L_3927;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3928 = ___1_textInfo;
		NullCheck(L_3928);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3929 = L_3928->___textElementInfo_10;
		int32_t L_3930 = V_240;
		NullCheck(L_3929);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3931 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3929)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3930)))->___topRight_20);
		float L_3932 = L_3931->___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3933 = ___1_textInfo;
		NullCheck(L_3933);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3934 = L_3933->___textElementInfo_10;
		int32_t L_3935 = V_240;
		NullCheck(L_3934);
		float L_3936 = ((L_3934)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3935)))->___descender_25;
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&V_13), L_3932, L_3936, (0.0f), NULL);
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3937 = ___1_textInfo;
		NullCheck(L_3937);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3938 = L_3937->___textElementInfo_10;
		int32_t L_3939 = V_240;
		NullCheck(L_3938);
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3940 = ((L_3938)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3939)))->___highlightColor_32;
		V_45 = L_3940;
		V_348 = (bool)1;
	}

IL_698a:
	{
		bool L_3941 = V_348;
		V_350 = (bool)((((int32_t)L_3941) == ((int32_t)0))? 1 : 0);
		bool L_3942 = V_350;
		if (!L_3942)
		{
			goto IL_6a44;
		}
	}
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3943 = V_12;
		float L_3944 = L_3943.___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3945 = ___1_textInfo;
		NullCheck(L_3945);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3946 = L_3945->___textElementInfo_10;
		int32_t L_3947 = V_240;
		NullCheck(L_3946);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3948 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3946)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3947)))->___bottomLeft_19);
		float L_3949 = L_3948->___x_2;
		float L_3950;
		L_3950 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_3944, L_3949, NULL);
		(&V_12)->___x_2 = L_3950;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3951 = V_12;
		float L_3952 = L_3951.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3953 = ___1_textInfo;
		NullCheck(L_3953);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3954 = L_3953->___textElementInfo_10;
		int32_t L_3955 = V_240;
		NullCheck(L_3954);
		float L_3956 = ((L_3954)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3955)))->___descender_25;
		float L_3957;
		L_3957 = Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline(L_3952, L_3956, NULL);
		(&V_12)->___y_3 = L_3957;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3958 = V_13;
		float L_3959 = L_3958.___x_2;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3960 = ___1_textInfo;
		NullCheck(L_3960);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3961 = L_3960->___textElementInfo_10;
		int32_t L_3962 = V_240;
		NullCheck(L_3961);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* L_3963 = (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2*)(&((L_3961)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3962)))->___topRight_20);
		float L_3964 = L_3963->___x_2;
		float L_3965;
		L_3965 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3959, L_3964, NULL);
		(&V_13)->___x_2 = L_3965;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3966 = V_13;
		float L_3967 = L_3966.___y_3;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3968 = ___1_textInfo;
		NullCheck(L_3968);
		TextElementInfoU5BU5D_tEC28C9B72883EE21AA798913497C69E179A15C4E* L_3969 = L_3968->___textElementInfo_10;
		int32_t L_3970 = V_240;
		NullCheck(L_3969);
		float L_3971 = ((L_3969)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_3970)))->___ascender_23;
		float L_3972;
		L_3972 = Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline(L_3967, L_3971, NULL);
		(&V_13)->___y_3 = L_3972;
	}

IL_6a44:
	{
	}

IL_6a45:
	{
		bool L_3973 = V_11;
		if (!L_3973)
		{
			goto IL_6a54;
		}
	}
	{
		int32_t L_3974 = __this->___m_CharacterCount_48;
		G_B996_0 = ((((int32_t)L_3974) == ((int32_t)1))? 1 : 0);
		goto IL_6a55;
	}

IL_6a54:
	{
		G_B996_0 = 0;
	}

IL_6a55:
	{
		V_351 = (bool)G_B996_0;
		bool L_3975 = V_351;
		if (!L_3975)
		{
			goto IL_6a7b;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3976 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3977 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3978 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3979 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3980 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3976, L_3977, (&V_33), L_3978, L_3979, L_3980, NULL);
		goto IL_6af8;
	}

IL_6a7b:
	{
		bool L_3981 = V_11;
		if (!L_3981)
		{
			goto IL_6a9d;
		}
	}
	{
		int32_t L_3982 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3983 = V_244;
		int32_t L_3984 = L_3983.___lastCharacterIndex_8;
		if ((((int32_t)L_3982) == ((int32_t)L_3984)))
		{
			goto IL_6a9a;
		}
	}
	{
		int32_t L_3985 = V_240;
		LineInfo_t2BBD461B330C46ACA45596A8E72FEA4172F88CF5 L_3986 = V_244;
		int32_t L_3987 = L_3986.___lastVisibleCharacterIndex_9;
		G_B1002_0 = ((((int32_t)((((int32_t)L_3985) < ((int32_t)L_3987))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_6a9b;
	}

IL_6a9a:
	{
		G_B1002_0 = 1;
	}

IL_6a9b:
	{
		G_B1004_0 = G_B1002_0;
		goto IL_6a9e;
	}

IL_6a9d:
	{
		G_B1004_0 = 0;
	}

IL_6a9e:
	{
		V_352 = (bool)G_B1004_0;
		bool L_3988 = V_352;
		if (!L_3988)
		{
			goto IL_6ac4;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3989 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3990 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3991 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_3992 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_3993 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3989, L_3990, (&V_33), L_3991, L_3992, L_3993, NULL);
		goto IL_6af8;
	}

IL_6ac4:
	{
		bool L_3994 = V_11;
		if (!L_3994)
		{
			goto IL_6ad3;
		}
	}
	{
		bool L_3995 = V_341;
		G_B1009_0 = ((((int32_t)L_3995) == ((int32_t)0))? 1 : 0);
		goto IL_6ad4;
	}

IL_6ad3:
	{
		G_B1009_0 = 0;
	}

IL_6ad4:
	{
		V_353 = (bool)G_B1009_0;
		bool L_3996 = V_353;
		if (!L_3996)
		{
			goto IL_6af8;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3997 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3998 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_3999 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4000 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4001 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_3997, L_3998, (&V_33), L_3999, L_4000, L_4001, NULL);
	}

IL_6af8:
	{
		goto IL_6b23;
	}

IL_6afb:
	{
		bool L_4002 = V_11;
		V_354 = L_4002;
		bool L_4003 = V_354;
		if (!L_4003)
		{
			goto IL_6b22;
		}
	}
	{
		V_11 = (bool)0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4004 = V_12;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4005 = V_13;
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_4006 = V_45;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4007 = ___0_generationSettings;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4008 = ___1_textInfo;
		TextGenerator_DrawTextHighlight_m3A8E9A72C0984B5DEEF9858060675F3B517F701B(__this, L_4004, L_4005, (&V_33), L_4006, L_4007, L_4008, NULL);
	}

IL_6b22:
	{
	}

IL_6b23:
	{
		int32_t L_4009 = V_243;
		V_39 = L_4009;
		int32_t L_4010 = V_240;
		V_149 = L_4010;
		int32_t L_4011 = V_149;
		V_240 = ((int32_t)il2cpp_codegen_add(L_4011, 1));
	}

IL_6b32:
	{
		int32_t L_4012 = V_240;
		int32_t L_4013 = __this->___m_CharacterCount_48;
		V_355 = (bool)((((int32_t)L_4012) < ((int32_t)L_4013))? 1 : 0);
		bool L_4014 = V_355;
		if (L_4014)
		{
			goto IL_3a12;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4015 = ___1_textInfo;
		int32_t L_4016 = __this->___m_CharacterCount_48;
		NullCheck(L_4015);
		L_4015->___characterCount_2 = L_4016;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4017 = ___1_textInfo;
		int32_t L_4018 = __this->___m_SpriteCount_86;
		NullCheck(L_4017);
		L_4017->___spriteCount_3 = L_4018;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4019 = ___1_textInfo;
		int32_t L_4020 = V_38;
		NullCheck(L_4019);
		L_4019->___lineCount_7 = L_4020;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4021 = ___1_textInfo;
		int32_t L_4022 = V_37;
		G_B1018_0 = L_4021;
		if (!L_4022)
		{
			G_B1019_0 = L_4021;
			goto IL_6b7b;
		}
	}
	{
		int32_t L_4023 = __this->___m_CharacterCount_48;
		G_B1019_0 = G_B1018_0;
		if ((((int32_t)L_4023) > ((int32_t)0)))
		{
			G_B1020_0 = G_B1018_0;
			goto IL_6b7e;
		}
	}

IL_6b7b:
	{
		G_B1021_0 = 1;
		G_B1021_1 = G_B1019_0;
		goto IL_6b80;
	}

IL_6b7e:
	{
		int32_t L_4024 = V_37;
		G_B1021_0 = L_4024;
		G_B1021_1 = G_B1020_0;
	}

IL_6b80:
	{
		NullCheck(G_B1021_1);
		G_B1021_1->___wordCount_5 = G_B1021_0;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4025 = ___1_textInfo;
		int32_t L_4026 = __this->___m_PageNumber_58;
		NullCheck(L_4025);
		L_4025->___pageCount_8 = ((int32_t)il2cpp_codegen_add(L_4026, 1));
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4027 = ___1_textInfo;
		NullCheck(L_4027);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4028 = L_4027->___meshInfo_15;
		SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD* L_4029 = (SpecialCharacter_t869F8BE65A7FE32AFD4196118258F49A63D8E2BD*)(&__this->___m_Underline_98);
		int32_t L_4030 = L_4029->___materialIndex_3;
		NullCheck(L_4028);
		int32_t L_4031 = V_33;
		((L_4028)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4030)))->___vertexCount_1 = L_4031;
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4032 = ___0_generationSettings;
		NullCheck(L_4032);
		int32_t L_4033 = L_4032->___geometrySortingOrder_42;
		V_356 = (bool)((!(((uint32_t)L_4033) <= ((uint32_t)0)))? 1 : 0);
		bool L_4034 = V_356;
		if (!L_4034)
		{
			goto IL_6bda;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4035 = ___1_textInfo;
		NullCheck(L_4035);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4036 = L_4035->___meshInfo_15;
		NullCheck(L_4036);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1(((L_4036)->GetAddressAt(static_cast<il2cpp_array_size_t>(0))), 1, NULL);
	}

IL_6bda:
	{
		V_357 = 1;
		goto IL_6c3d;
	}

IL_6be3:
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4037 = ___1_textInfo;
		NullCheck(L_4037);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4038 = L_4037->___meshInfo_15;
		int32_t L_4039 = V_357;
		NullCheck(L_4038);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_ClearUnusedVertices_m7B6003EF4CA72C0ABBA4D25DEA8B0BF3934B2830(((L_4038)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4039))), NULL);
		TextGenerationSettings_t3E75DB1D14DF53934AF76C9ACB1CD94A344A92A2* L_4040 = ___0_generationSettings;
		NullCheck(L_4040);
		int32_t L_4041 = L_4040->___geometrySortingOrder_42;
		V_358 = (bool)((!(((uint32_t)L_4041) <= ((uint32_t)0)))? 1 : 0);
		bool L_4042 = V_358;
		if (!L_4042)
		{
			goto IL_6c2a;
		}
	}
	{
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4043 = ___1_textInfo;
		NullCheck(L_4043);
		MeshInfoU5BU5D_t3DF8B75BF4A213334EED197AD25E432212894AC6* L_4044 = L_4043->___meshInfo_15;
		int32_t L_4045 = V_357;
		NullCheck(L_4044);
		il2cpp_codegen_runtime_class_init_inline(MeshInfo_tE55C4A8846CC2C399CCC3FE989476D987B86AB2F_il2cpp_TypeInfo_var);
		MeshInfo_SortGeometry_m92046C53AA6AE75EE3627CE73846296AB3E99DD1(((L_4044)->GetAddressAt(static_cast<il2cpp_array_size_t>(L_4045))), 1, NULL);
	}

IL_6c2a:
	{
		int32_t L_4046 = V_357;
		V_149 = L_4046;
		int32_t L_4047 = V_149;
		V_357 = ((int32_t)il2cpp_codegen_add(L_4047, 1));
	}

IL_6c3d:
	{
		int32_t L_4048 = V_357;
		TextInfo_t27E58E62A7552C66D38C175AF9D22622365F5D09* L_4049 = ___1_textInfo;
		NullCheck(L_4049);
		int32_t L_4050 = L_4049->___materialCount_9;
		V_359 = (bool)((((int32_t)L_4048) < ((int32_t)L_4050))? 1 : 0);
		bool L_4051 = V_359;
		if (L_4051)
		{
			goto IL_6be3;
		}
	}

IL_6c59:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_get_zero_m0C1249C3F25B1C70EAD3CC8B31259975A457AE39_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ((Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields*)il2cpp_codegen_static_fields_for(Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_il2cpp_TypeInfo_var))->___zeroVector_5;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B Color32_op_Implicit_m79AF5E0BDE9CE041CAC4D89CBFA66E71C6DD1B70_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___0_c, const RuntimeMethod* method) 
{
	Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_0 = ___0_c;
		float L_1 = L_0.___r_0;
		float L_2;
		L_2 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_1, NULL);
		float L_3;
		L_3 = bankers_roundf(((float)il2cpp_codegen_multiply(L_2, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_4 = ___0_c;
		float L_5 = L_4.___g_1;
		float L_6;
		L_6 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_5, NULL);
		float L_7;
		L_7 = bankers_roundf(((float)il2cpp_codegen_multiply(L_6, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_8 = ___0_c;
		float L_9 = L_8.___b_2;
		float L_10;
		L_10 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_9, NULL);
		float L_11;
		L_11 = bankers_roundf(((float)il2cpp_codegen_multiply(L_10, (255.0f))));
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_12 = ___0_c;
		float L_13 = L_12.___a_3;
		float L_14;
		L_14 = Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline(L_13, NULL);
		float L_15;
		L_15 = bankers_roundf(((float)il2cpp_codegen_multiply(L_14, (255.0f))));
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_16;
		memset((&L_16), 0, sizeof(L_16));
		Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline((&L_16), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_3), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_7), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_11), (uint8_t)il2cpp_codegen_cast_floating_point<uint8_t, int32_t, float>(L_15), /*hidden argument*/NULL);
		V_0 = L_16;
		goto IL_0065;
	}

IL_0065:
	{
		Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B L_17 = V_0;
		return L_17;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Mathf_Clamp_m4DC36EEFDBE5F07C16249DA568023C5ECCFF0E7B_inline (int32_t ___0_value, int32_t ___1_min, int32_t ___2_max, const RuntimeMethod* method) 
{
	bool V_0 = false;
	bool V_1 = false;
	int32_t V_2 = 0;
	{
		int32_t L_0 = ___0_value;
		int32_t L_1 = ___1_min;
		V_0 = (bool)((((int32_t)L_0) < ((int32_t)L_1))? 1 : 0);
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_000e;
		}
	}
	{
		int32_t L_3 = ___1_min;
		___0_value = L_3;
		goto IL_0019;
	}

IL_000e:
	{
		int32_t L_4 = ___0_value;
		int32_t L_5 = ___2_max;
		V_1 = (bool)((((int32_t)L_4) > ((int32_t)L_5))? 1 : 0);
		bool L_6 = V_1;
		if (!L_6)
		{
			goto IL_0019;
		}
	}
	{
		int32_t L_7 = ___2_max;
		___0_value = L_7;
	}

IL_0019:
	{
		int32_t L_8 = ___0_value;
		V_2 = L_8;
		goto IL_001d;
	}

IL_001d:
	{
		int32_t L_9 = V_2;
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Color_get_white_m068F5AF879B0FCA584E3693F762EA41BB65532C6_inline (const RuntimeMethod* method) 
{
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_0;
		memset((&L_0), 0, sizeof(L_0));
		Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline((&L_0), (1.0f), (1.0f), (1.0f), (1.0f), /*hidden argument*/NULL);
		V_0 = L_0;
		goto IL_001d;
	}

IL_001d:
	{
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x_2 = L_0;
		float L_1 = ___1_y;
		__this->___y_3 = L_1;
		float L_2 = ___2_z;
		__this->___z_4 = L_2;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), ((float)il2cpp_codegen_add(L_9, L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Division_mCC6BB24E372AB96B8380D1678446EF6A8BAE13BB_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x_2;
		float L_2 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___0_a;
		float L_4 = L_3.___y_3;
		float L_5 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___0_a;
		float L_7 = L_6.___z_4;
		float L_8 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_9), ((float)(L_1/L_2)), ((float)(L_4/L_5)), ((float)(L_7/L_8)), /*hidden argument*/NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = V_0;
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Subtraction_mE42023FF80067CB44A1D4A27EB7CF2B24CABB828_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), ((float)il2cpp_codegen_subtract(L_9, L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Max_mF5379E63D2BBAC76D090748695D833934F8AD051_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float G_B3_0 = 0.0f;
	{
		float L_0 = ___0_a;
		float L_1 = ___1_b;
		if ((((float)L_0) > ((float)L_1)))
		{
			goto IL_0008;
		}
	}
	{
		float L_2 = ___1_b;
		G_B3_0 = L_2;
		goto IL_0009;
	}

IL_0008:
	{
		float L_3 = ___0_a;
		G_B3_0 = L_3;
	}

IL_0009:
	{
		V_0 = G_B3_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Min_m747CA71A9483CDB394B13BD0AD048EE17E48FFE4_inline (float ___0_a, float ___1_b, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float G_B3_0 = 0.0f;
	{
		float L_0 = ___0_a;
		float L_1 = ___1_b;
		if ((((float)L_0) < ((float)L_1)))
		{
			goto IL_0008;
		}
	}
	{
		float L_2 = ___1_b;
		G_B3_0 = L_2;
		goto IL_0009;
	}

IL_0008:
	{
		float L_3 = ___0_a;
		G_B3_0 = L_3;
	}

IL_0009:
	{
		V_0 = G_B3_0;
		goto IL_000c;
	}

IL_000c:
	{
		float L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x_0 = L_0;
		float L_1 = ___1_y;
		__this->___y_1 = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color32__ctor_mC9C6B443F0C7CA3F8B174158B2AF6F05E18EAC4E_inline (Color32_t73C5004937BF5BB8AD55323D51AAA40A898EF48B* __this, uint8_t ___0_r, uint8_t ___1_g, uint8_t ___2_b, uint8_t ___3_a, const RuntimeMethod* method) 
{
	{
		__this->___rgba_0 = 0;
		uint8_t L_0 = ___0_r;
		__this->___r_1 = L_0;
		uint8_t L_1 = ___1_g;
		__this->___g_2 = L_1;
		uint8_t L_2 = ___2_b;
		__this->___b_3 = L_2;
		uint8_t L_3 = ___3_a;
		__this->___a_4 = L_3;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_v, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_v;
		float L_1 = L_0.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___0_v;
		float L_3 = L_2.___y_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4;
		memset((&L_4), 0, sizeof(L_4));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_4), L_1, L_3, (0.0f), /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_001a;
	}

IL_001a:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_5 = V_0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp01_mA7E048DBDA832D399A581BE4D6DED9FA44CE0F14_inline (float ___0_value, const RuntimeMethod* method) 
{
	bool V_0 = false;
	float V_1 = 0.0f;
	bool V_2 = false;
	{
		float L_0 = ___0_value;
		V_0 = (bool)((((float)L_0) < ((float)(0.0f)))? 1 : 0);
		bool L_1 = V_0;
		if (!L_1)
		{
			goto IL_0015;
		}
	}
	{
		V_1 = (0.0f);
		goto IL_002d;
	}

IL_0015:
	{
		float L_2 = ___0_value;
		V_2 = (bool)((((float)L_2) > ((float)(1.0f)))? 1 : 0);
		bool L_3 = V_2;
		if (!L_3)
		{
			goto IL_0029;
		}
	}
	{
		V_1 = (1.0f);
		goto IL_002d;
	}

IL_0029:
	{
		float L_4 = ___0_value;
		V_1 = L_4;
		goto IL_002d;
	}

IL_002d:
	{
		float L_5 = V_1;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Color__ctor_m3786F0D6E510D9CFA544523A955870BD2A514C8C_inline (Color_tD001788D726C3A7F1379BEED0260B9591F440C1F* __this, float ___0_r, float ___1_g, float ___2_b, float ___3_a, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_r;
		__this->___r_0 = L_0;
		float L_1 = ___1_g;
		__this->___g_1 = L_1;
		float L_2 = ___2_b;
		__this->___b_2 = L_2;
		float L_3 = ___3_a;
		__this->___a_3 = L_3;
		return;
	}
}
