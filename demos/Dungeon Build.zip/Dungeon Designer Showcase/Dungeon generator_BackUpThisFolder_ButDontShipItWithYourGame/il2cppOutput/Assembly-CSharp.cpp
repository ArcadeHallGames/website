﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>


template <typename R>
struct VirtualFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
struct InterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R>
struct InterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};

// System.Collections.Generic.Dictionary`2<System.Int32,System.Object>
struct Dictionary_2_tA75D1125AC9BE8F005BA9B868B373398E643C907;
// System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>
struct Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E;
// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean>
struct Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240;
// System.Collections.Generic.IEnumerable`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>
struct IEnumerable_1_tFAFBAE859D1BABC544F30E333ABA9FA38A296C2C;
// System.Collections.Generic.IEnumerable`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>
struct IEnumerable_1_t53AA3F65F63B65AA2C5165D539E667705AB34667;
// System.Collections.Generic.IEnumerable`1<System.Object>
struct IEnumerable_1_tF95C9E01A913DD50575531C8305932628663D9E9;
// System.Collections.Generic.IEnumerable`1<DungeonGenerator.Room>
struct IEnumerable_1_t3740075360A20D25C3C39A4F6B5274E3E8388B98;
// System.Collections.Generic.IEnumerable`1<UnityEngine.Vector2Int>
struct IEnumerable_1_t8845214D7CADFAAD7AB98132A368905184A79DDF;
// System.Collections.Generic.IEnumerable`1<DungeonGenerator.DungeonDesigner/Spawnable>
struct IEnumerable_1_t8906334ADC35210FE4E8C912EA41E8E2D9D90F28;
// System.Collections.Generic.IEnumerable`1<DungeonGenerator.Room/Link>
struct IEnumerable_1_t267A243DF490C131F8B0282F7BD13A6318DAE8C1;
// System.Collections.Generic.IEqualityComparer`1<System.Int32>
struct IEqualityComparer_1_tDBFC8496F14612776AF930DBF84AFE7D06D1F0E9;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.Int32,DungeonGenerator.Room/Link>
struct KeyCollection_tE63E793E8A79C7E971A69880F7AF643812E82958;
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>
struct List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE;
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>
struct List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F;
// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>
struct List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E;
// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>
struct List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F;
// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D;
// System.Collections.Generic.List`1<DungeonGenerator.Room>
struct List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE;
// System.Collections.Generic.List`1<UnityEngine.Vector2>
struct List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B;
// System.Collections.Generic.List`1<UnityEngine.Vector2Int>
struct List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D;
// System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>
struct List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2;
// System.Collections.Generic.List`1<DungeonGenerator.Room/Link>
struct List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B;
// System.Predicate`1<System.Object>
struct Predicate_1_t8342C85FF4E41CD1F7024AC0CDC3E5312A32CB12;
// System.Predicate`1<DungeonGenerator.Room>
struct Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9;
// UnityEngine.Events.UnityEvent`1<UnityEngine.SpriteRenderer>
struct UnityEvent_1_t8ABE5544759145B8D7A09F1C54FFCB6907EDD56E;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.Int32,DungeonGenerator.Room/Link>
struct ValueCollection_t55456597A1061EBE3A23DB0E61778D54A9B322DB;
// System.Collections.Generic.Dictionary`2/Entry<System.Int32,DungeonGenerator.Room/Link>[]
struct EntryU5BU5D_t19D825C697A1922625A75D18F2340DF722D690EC;
// System.Collections.Generic.List`1<UnityEngine.Vector2>[]
struct List_1U5BU5D_tDE88DA8DCD79A37A10DCC96911E1242D15FF66FE;
// System.Collections.Generic.List`1<UnityEngine.Vector2Int>[]
struct List_1U5BU5D_tFD185408D24E1854912E54803E8FDEBB0407ECEC;
// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>[]
struct ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E;
// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>[]
struct ValueTuple_2U5BU5D_t59C6CEEC5A03DECC2CAAC8E72EA3F06C0A22708B;
// System.Char[]
struct CharU5BU5D_t799905CF001DD5F13F7DBB310181FC4D8B7D0AAB;
// System.Delegate[]
struct DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771;
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
// System.IntPtr[]
struct IntPtrU5BU5D_tFD177F8C806A6921AD7150264CCC62FA00CAD832;
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
// DungeonGenerator.Room[]
struct RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3;
// System.Diagnostics.StackTrace[]
struct StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA;
// UnityEngine.Vector2Int[]
struct Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534;
// DungeonGenerator.DungeonDesigner/Spawnable[]
struct SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8;
// DungeonGenerator.Model/SpawnPoint[]
struct SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61;
// DungeonGenerator.Room/Graphic[]
struct GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2;
// DungeonGenerator.Room/Link[]
struct LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18;
// UnityEngine.Component
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3;
// UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B;
// System.DelegateData
struct DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E;
// DungeonGenerator.Dungeon
struct Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B;
// DungeonGenerator.DungeonDesigner
struct DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6;
// System.Exception
struct Exception_t;
// UnityEngine.GameObject
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F;
// System.Collections.IDictionary
struct IDictionary_t6D03155AF1FA9083817AA5B6AD7DEEACC26AB220;
// System.Collections.IEnumerator
struct IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// DungeonGenerator.Model
struct Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17;
// UnityEngine.MonoBehaviour
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71;
// System.NotSupportedException
struct NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A;
// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C;
// PixelCollider.PixelCollider2D
struct PixelCollider2D_t6FCBAB552C8143AF518039867DC52AFD086F70FD;
// UnityEngine.PolygonCollider2D
struct PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E;
// DungeonGenerator.Room
struct Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404;
// System.Runtime.Serialization.SafeSerializationManager
struct SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6;
// UnityEngine.Sprite
struct Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99;
// UnityEngine.SpriteRenderer
struct SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B;
// System.String
struct String_t;
// Tester
struct Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD;
// UnityEngine.Texture2D
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4;
// UnityEngine.Transform
struct Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1;
// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
// UnityEngine.WaitForSeconds
struct WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3;
// DungeonGenerator.Dungeon/<>c__DisplayClass13_0
struct U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC;
// DungeonGenerator.DungeonDesigner/<>c
struct U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655;
// DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17
struct U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC;
// DungeonGenerator.Room/Graphic
struct Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD;
// DungeonGenerator.Room/Link
struct Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4;
// Tester/<loop>d__3
struct U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F;

IL2CPP_EXTERN_C RuntimeClass* Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Exception_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteral097BF2A88755542E570BFE1840C914F01A1EA152;
IL2CPP_EXTERN_C String_t* _stringLiteral0A04B971B03DA607CE6C455184037B660CA89F78;
IL2CPP_EXTERN_C String_t* _stringLiteral0F99B65F19EEA35112094186BA90C30A05AC1FC2;
IL2CPP_EXTERN_C String_t* _stringLiteral121E3C04443BF8E117A53A4EA6445D0FAE0FDDF7;
IL2CPP_EXTERN_C String_t* _stringLiteral198AA065BF0F912BD6F5F93869BD5C361671F98B;
IL2CPP_EXTERN_C String_t* _stringLiteral3AB15C9B4C9186E65E2AB6C27CD2FEEC419DE91E;
IL2CPP_EXTERN_C String_t* _stringLiteral3C1FF3ADF4004F789CDD5BD75BAE7EF3FF1177D4;
IL2CPP_EXTERN_C String_t* _stringLiteral430E518F836082E0683698AB9E3F79D39C7F5140;
IL2CPP_EXTERN_C String_t* _stringLiteral606C771900936C652E7DC0D284530387D5ED57D1;
IL2CPP_EXTERN_C String_t* _stringLiteralE02BC3B5D408D1BC5E365A7F3C21C2F13AA96125;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_m838C3ADF8730E17B91A80DDD18BB0830E513D114_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_ContainsKey_m25725AE19289EC9E8D4510E63BB4D41272E7B76A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2__ctor_mB97F1137644FD8446F05E9AA8A86C9840D587C18_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Dictionary_2_set_Item_mFEEAD6949043D033BD1DD28B97C236680AC557BA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Count_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_mB2A88D089B3CEC205E70A7BB7292844B04AD56D9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_AddComponent_TisModel_tC414155249EC7AAC88CDBA8448952AF9525DEC17_mD473FDD0F45F30E0908D9C09D6969E43F9CF0ACF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* GameObject_AddComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_mDC33421D7DA59610EEC9A5E208A162DF9934C391_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_m1902F684694327EBD4B760E536C852CA86EF93BA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mDBE179845F4DD8F7DCD68FFE1AE177FD7E3ED070_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Add_mE5AA8024B0AB1F676B72ABC9CD4E640E72394461_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Clear_m860165F91832E967E3EF62F787A8EC74CECFA78F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Find_m113B5413263A32E5F8E92AB8D0B15530CB79634C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_RemoveAt_m3894E022B8F0201AC450EE7D6B34BF7B7DFC9419_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_ToArray_m774D68B3437B636757CA5CE8C139144E372294EA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_ToArray_mC3E937AF391FBD2071D29BE457FAFAB3BF5DD94F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m2424D4A7D9018A7B7FD865A4B75D47D66E60D866_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m36B74D51D7FC7F3FE3EC1EE076EAD4EB6DBD5FF1_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_mE8B67035812C247866131D058EF6E3284A17B95B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_get_Item_mF7BAD78CA9941DF0CD8F1E94ACD1FFC6BEC5318F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_Reset_m5DA478BBBA8FEE33F186D61520F10B132227BED2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CSpawnU3Eb__12_1_m60B3C71B30B827EA6AB771B0EF357E99EA96FE93_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CSpawnU3Eb__12_2_m240F5CF405EC66C270BCD4801ACF20066633CCBE_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CSpawnU3Eb__12_3_mBFB7BEB81624B39BF596D983CB6B71E91BC0C184_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec_U3CSpawnU3Eb__12_4_m87F641E977858C2103703711151AF1C00AC926F9_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CU3Ec__DisplayClass13_0_U3CGenerateFromLinkU3Eb__0_m267464DB7CBAE1AB6FFB27DCF39E3DD15D91C413_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* U3CloopU3Ed__3_System_Collections_IEnumerator_Reset_mDFBAFEB791DDF7FE317D9CAA3304254E9AA97A22_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ValueTuple_2__ctor_m3315007AD2DBF3F7D006595F0F70623784E08499_RuntimeMethod_var;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;

struct ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E;
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C;
struct ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E;
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918;
struct RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3;
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA;
struct Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534;
struct SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8;
struct SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61;
struct GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2;
struct LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18;

IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_tBB65183F1134474D09FF49B95625D25472B9BA8B 
{
};

// System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>
struct Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E  : public RuntimeObject
{
	// System.Int32[] System.Collections.Generic.Dictionary`2::_buckets
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* ____buckets_0;
	// System.Collections.Generic.Dictionary`2/Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::_entries
	EntryU5BU5D_t19D825C697A1922625A75D18F2340DF722D690EC* ____entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::_count
	int32_t ____count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::_freeList
	int32_t ____freeList_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::_freeCount
	int32_t ____freeCount_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::_version
	int32_t ____version_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::_comparer
	RuntimeObject* ____comparer_6;
	// System.Collections.Generic.Dictionary`2/KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::_keys
	KeyCollection_tE63E793E8A79C7E971A69880F7AF643812E82958* ____keys_7;
	// System.Collections.Generic.Dictionary`2/ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::_values
	ValueCollection_t55456597A1061EBE3A23DB0E61778D54A9B322DB* ____values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject* ____syncRoot_9;
};

// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>
struct List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	List_1U5BU5D_tDE88DA8DCD79A37A10DCC96911E1242D15FF66FE* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>
struct List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	List_1U5BU5D_tFD185408D24E1854912E54803E8FDEBB0407ECEC* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>
struct List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>
struct List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	ValueTuple_2U5BU5D_t59C6CEEC5A03DECC2CAAC8E72EA3F06C0A22708B* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<DungeonGenerator.Room>
struct List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<UnityEngine.Vector2>
struct List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<UnityEngine.Vector2Int>
struct List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>
struct List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.Collections.Generic.List`1<DungeonGenerator.Room/Link>
struct List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B  : public RuntimeObject
{
	// T[] System.Collections.Generic.List`1::_items
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject* ____syncRoot_4;
};

// System.String
struct String_t  : public RuntimeObject
{
	// System.Int32 System.String::_stringLength
	int32_t ____stringLength_4;
	// System.Char System.String::_firstChar
	Il2CppChar ____firstChar_5;
};

// System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};

// UnityEngine.YieldInstruction
struct YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D  : public RuntimeObject
{
};
// Native definition for P/Invoke marshalling of UnityEngine.YieldInstruction
struct YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.YieldInstruction
struct YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_com
{
};

// DungeonGenerator.DungeonDesigner/<>c
struct U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655  : public RuntimeObject
{
};

// DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17
struct U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC  : public RuntimeObject
{
	// System.Int32 DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::<>2__current
	RuntimeObject* ___U3CU3E2__current_1;
	// DungeonGenerator.DungeonDesigner DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::<>4__this
	DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* ___U3CU3E4__this_2;
};

// DungeonGenerator.Room/Graphic
struct Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD  : public RuntimeObject
{
	// UnityEngine.Sprite DungeonGenerator.Room/Graphic::sprite
	Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* ___sprite_0;
	// UnityEngine.PolygonCollider2D DungeonGenerator.Room/Graphic::collider
	PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* ___collider_1;
};

// DungeonGenerator.Room/Link
struct Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4  : public RuntimeObject
{
	// System.Int32 DungeonGenerator.Room/Link::angle
	int32_t ___angle_0;
	// System.Boolean DungeonGenerator.Room/Link::can_generate
	bool ___can_generate_1;
};

// Tester/<loop>d__3
struct U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F  : public RuntimeObject
{
	// System.Int32 Tester/<loop>d__3::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Tester/<loop>d__3::<>2__current
	RuntimeObject* ___U3CU3E2__current_1;
	// Tester Tester/<loop>d__3::<>4__this
	Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* ___U3CU3E4__this_2;
};

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;
};

// UnityEngine.Color
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;
};

// System.Double
struct Double_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F 
{
	// System.Double System.Double::m_value
	double ___m_value_0;
};

// System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2  : public ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F
{
};
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2A1A94B24E3B776EEF4E5E485E290BB9D4D072E2_marshaled_com
{
};

// System.Int32
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;
};

// System.IntPtr
struct IntPtr_t 
{
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;
};

// UnityEngine.Quaternion
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 
{
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;
};

// System.Single
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	// System.Single System.Single::m_value
	float ___m_value_0;
};

// UnityEngine.Vector2
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;
};

// UnityEngine.Vector2Int
struct Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A 
{
	// System.Int32 UnityEngine.Vector2Int::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.Vector2Int::m_Y
	int32_t ___m_Y_1;
};

// UnityEngine.Vector3
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;
};

// System.Void
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};

// UnityEngine.WaitForSeconds
struct WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3  : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D
{
	// System.Single UnityEngine.WaitForSeconds::m_Seconds
	float ___m_Seconds_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.WaitForSeconds
struct WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3_marshaled_pinvoke : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_pinvoke
{
	float ___m_Seconds_0;
};
// Native definition for COM marshalling of UnityEngine.WaitForSeconds
struct WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3_marshaled_com : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_com
{
	float ___m_Seconds_0;
};

// UnityEngine.Bounds
struct Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 
{
	// UnityEngine.Vector3 UnityEngine.Bounds::m_Center
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Center_0;
	// UnityEngine.Vector3 UnityEngine.Bounds::m_Extents
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___m_Extents_1;
};

// UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B  : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D
{
	// System.IntPtr UnityEngine.Coroutine::m_Ptr
	intptr_t ___m_Ptr_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B_marshaled_pinvoke : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Coroutine
struct Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B_marshaled_com : public YieldInstruction_tFCE35FD0907950EFEE9BC2890AC664E41C53728D_marshaled_com
{
	intptr_t ___m_Ptr_0;
};

// System.Delegate
struct Delegate_t  : public RuntimeObject
{
	// System.IntPtr System.Delegate::method_ptr
	intptr_t ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject* ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.IntPtr System.Delegate::interp_method
	intptr_t ___interp_method_7;
	// System.IntPtr System.Delegate::interp_invoke_impl
	intptr_t ___interp_invoke_impl_8;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t* ___method_info_9;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t* ___original_method_info_10;
	// System.DelegateData System.Delegate::data
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_12;
};
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	intptr_t ___interp_method_7;
	intptr_t ___interp_invoke_impl_8;
	MethodInfo_t* ___method_info_9;
	MethodInfo_t* ___original_method_info_10;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	int32_t ___method_is_virtual_12;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	intptr_t ___interp_method_7;
	intptr_t ___interp_invoke_impl_8;
	MethodInfo_t* ___method_info_9;
	MethodInfo_t* ___original_method_info_10;
	DelegateData_t9B286B493293CD2D23A5B2B5EF0E5B1324C2B77E* ___data_11;
	int32_t ___method_is_virtual_12;
};

// System.Exception
struct Exception_t  : public RuntimeObject
{
	// System.String System.Exception::_className
	String_t* ____className_1;
	// System.String System.Exception::_message
	String_t* ____message_2;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_3;
	// System.Exception System.Exception::_innerException
	Exception_t* ____innerException_4;
	// System.String System.Exception::_helpURL
	String_t* ____helpURL_5;
	// System.Object System.Exception::_stackTrace
	RuntimeObject* ____stackTrace_6;
	// System.String System.Exception::_stackTraceString
	String_t* ____stackTraceString_7;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_8;
	// System.Int32 System.Exception::_remoteStackIndex
	int32_t ____remoteStackIndex_9;
	// System.Object System.Exception::_dynamicMethods
	RuntimeObject* ____dynamicMethods_10;
	// System.Int32 System.Exception::_HResult
	int32_t ____HResult_11;
	// System.String System.Exception::_source
	String_t* ____source_12;
	// System.Runtime.Serialization.SafeSerializationManager System.Exception::_safeSerializationManager
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager_13;
	// System.Diagnostics.StackTrace[] System.Exception::captured_traces
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces_14;
	// System.IntPtr[] System.Exception::native_trace_ips
	IntPtrU5BU5D_tFD177F8C806A6921AD7150264CCC62FA00CAD832* ___native_trace_ips_15;
	// System.Int32 System.Exception::caught_in_unmanaged
	int32_t ___caught_in_unmanaged_16;
};
// Native definition for P/Invoke marshalling of System.Exception
struct Exception_t_marshaled_pinvoke
{
	char* ____className_1;
	char* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_pinvoke* ____innerException_4;
	char* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	char* ____stackTraceString_7;
	char* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	char* ____source_12;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager_13;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
	int32_t ___caught_in_unmanaged_16;
};
// Native definition for COM marshalling of System.Exception
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className_1;
	Il2CppChar* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_com* ____innerException_4;
	Il2CppChar* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	Il2CppChar* ____stackTraceString_7;
	Il2CppChar* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	Il2CppChar* ____source_12;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager_13;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces_14;
	Il2CppSafeArray/*NONE*/* ___native_trace_ips_15;
	int32_t ___caught_in_unmanaged_16;
};

// UnityEngine.KeyCode
struct KeyCode_t75B9ECCC26D858F55040DDFF9523681E996D17E9 
{
	// System.Int32 UnityEngine.KeyCode::value__
	int32_t ___value___2;
};

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C  : public RuntimeObject
{
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;
};
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// DungeonGenerator.Dungeon/<>c__DisplayClass13_0
struct U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC  : public RuntimeObject
{
	// UnityEngine.Vector2 DungeonGenerator.Dungeon/<>c__DisplayClass13_0::pos
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___pos_0;
};

// DungeonGenerator.DungeonDesigner/CanFlip
struct CanFlip_t2FEED7BEA44CB7F2527D3895EE2ED351DDC63F9D 
{
	// System.Int32 DungeonGenerator.DungeonDesigner/CanFlip::value__
	int32_t ___value___2;
};

// DungeonGenerator.DungeonDesigner/Orientation
struct Orientation_tF6D7A6DFACCCD3E6DFA8E3A5EE52A4289D53B02A 
{
	// System.Int32 DungeonGenerator.DungeonDesigner/Orientation::value__
	int32_t ___value___2;
};

// DungeonGenerator.Model/Location
struct Location_t4772884A09BB277157D8541CB5FBAADF5B04546F 
{
	// System.Int32 DungeonGenerator.Model/Location::value__
	int32_t ___value___2;
};

// DungeonGenerator.Model/NeedsWall
struct NeedsWall_tE12033AD5B57734DC27E21448B6969ED98243C0F 
{
	// System.Int32 DungeonGenerator.Model/NeedsWall::value__
	int32_t ___value___2;
};

// DungeonGenerator.Model/Type
struct Type_t65BF05AD783278A5F9CB1E510AC6C14F02C104F8 
{
	// System.Int32 DungeonGenerator.Model/Type::value__
	int32_t ___value___2;
};

// UnityEngine.Component
struct Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// UnityEngine.GameObject
struct GameObject_t76FEDD663AB33C991A9C9A23129337651094216F  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// System.MulticastDelegate
struct MulticastDelegate_t  : public Delegate_t
{
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tC5AB7E8F745616680F337909D3A8E6C722CDF771* ___delegates_13;
};
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_13;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_13;
};

// UnityEngine.Sprite
struct Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// System.SystemException
struct SystemException_tCC48D868298F4C0705279823E34B00F4FBDB7295  : public Exception_t
{
};

// UnityEngine.Texture
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700  : public Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C
{
};

// DungeonGenerator.DungeonDesigner/Spawnable
struct Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 
{
	// UnityEngine.GameObject DungeonGenerator.DungeonDesigner/Spawnable::gameObject
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___gameObject_0;
	// DungeonGenerator.DungeonDesigner/Orientation DungeonGenerator.DungeonDesigner/Spawnable::orientation
	int32_t ___orientation_1;
	// DungeonGenerator.DungeonDesigner/CanFlip DungeonGenerator.DungeonDesigner/Spawnable::can_flip
	int32_t ___can_flip_2;
};
// Native definition for P/Invoke marshalling of DungeonGenerator.DungeonDesigner/Spawnable
struct Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_pinvoke
{
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___gameObject_0;
	int32_t ___orientation_1;
	int32_t ___can_flip_2;
};
// Native definition for COM marshalling of DungeonGenerator.DungeonDesigner/Spawnable
struct Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_com
{
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___gameObject_0;
	int32_t ___orientation_1;
	int32_t ___can_flip_2;
};

// DungeonGenerator.Model/SpawnPoint
struct SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 
{
	// UnityEngine.Transform DungeonGenerator.Model/SpawnPoint::t
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___t_0;
	// DungeonGenerator.Model/Type DungeonGenerator.Model/SpawnPoint::type
	int32_t ___type_1;
	// DungeonGenerator.Model/Location DungeonGenerator.Model/SpawnPoint::location
	int32_t ___location_2;
	// DungeonGenerator.Model/NeedsWall DungeonGenerator.Model/SpawnPoint::needs_wall
	int32_t ___needs_wall_3;
};
// Native definition for P/Invoke marshalling of DungeonGenerator.Model/SpawnPoint
struct SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_pinvoke
{
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___t_0;
	int32_t ___type_1;
	int32_t ___location_2;
	int32_t ___needs_wall_3;
};
// Native definition for COM marshalling of DungeonGenerator.Model/SpawnPoint
struct SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_com
{
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___t_0;
	int32_t ___type_1;
	int32_t ___location_2;
	int32_t ___needs_wall_3;
};

// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean>
struct Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240  : public MulticastDelegate_t
{
};

// System.Predicate`1<DungeonGenerator.Room>
struct Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9  : public MulticastDelegate_t
{
};

// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>
struct ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 
{
	// T1 System.ValueTuple`2::Item1
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___Item1_0;
	// T2 System.ValueTuple`2::Item2
	RuntimeObject* ___Item2_1;
};

// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>
struct ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE 
{
	// T1 System.ValueTuple`2::Item1
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___Item1_0;
	// T2 System.ValueTuple`2::Item2
	Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___Item2_1;
};

// UnityEngine.Behaviour
struct Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};

// System.NotSupportedException
struct NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A  : public SystemException_tCC48D868298F4C0705279823E34B00F4FBDB7295
{
};

// UnityEngine.Renderer
struct Renderer_t320575F223BCB177A982E5DDB5DB19FAA89E7FBF  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};

// UnityEngine.Texture2D
struct Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4  : public Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700
{
};

// UnityEngine.Transform
struct Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1  : public Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3
{
};

// DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0
struct U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 
{
	// DungeonGenerator.Model/SpawnPoint DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0::sp
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___sp_0;
};

// UnityEngine.Collider2D
struct Collider2D_t6A17BA7734600EF3F26588E9ED903617D5B8EB52  : public Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA
{
};

// UnityEngine.MonoBehaviour
struct MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71  : public Behaviour_t01970CFBBA658497AE30F311C447DB0440BAB7FA
{
};

// UnityEngine.SpriteRenderer
struct SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B  : public Renderer_t320575F223BCB177A982E5DDB5DB19FAA89E7FBF
{
	// UnityEngine.Events.UnityEvent`1<UnityEngine.SpriteRenderer> UnityEngine.SpriteRenderer::m_SpriteChangeEvent
	UnityEvent_1_t8ABE5544759145B8D7A09F1C54FFCB6907EDD56E* ___m_SpriteChangeEvent_4;
};

// DungeonGenerator.Dungeon
struct Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// System.Single DungeonGenerator.Dungeon::grid
	float ___grid_4;
	// System.Boolean DungeonGenerator.Dungeon::auto_select_grid
	bool ___auto_select_grid_5;
	// System.Boolean DungeonGenerator.Dungeon::activate_rooms
	bool ___activate_rooms_6;
	// System.Boolean DungeonGenerator.Dungeon::activate_walls
	bool ___activate_walls_7;
	// System.Int32 DungeonGenerator.Dungeon::min_complexity
	int32_t ___min_complexity_8;
	// System.Int32 DungeonGenerator.Dungeon::max_complexity
	int32_t ___max_complexity_9;
	// DungeonGenerator.Room[] DungeonGenerator.Dungeon::rooms
	RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* ___rooms_10;
	// System.Collections.Generic.List`1<DungeonGenerator.Room> DungeonGenerator.Dungeon::dungeon
	List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* ___dungeon_11;
};

// DungeonGenerator.DungeonDesigner
struct DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// DungeonGenerator.Dungeon DungeonGenerator.DungeonDesigner::dungeon
	Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ___dungeon_4;
	// DungeonGenerator.Model DungeonGenerator.DungeonDesigner::model
	Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* ___model_5;
	// DungeonGenerator.DungeonDesigner/Spawnable[] DungeonGenerator.DungeonDesigner::loot
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* ___loot_6;
	// DungeonGenerator.DungeonDesigner/Spawnable[] DungeonGenerator.DungeonDesigner::decorations
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* ___decorations_7;
	// DungeonGenerator.DungeonDesigner/Spawnable[] DungeonGenerator.DungeonDesigner::traps
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* ___traps_8;
	// System.Single DungeonGenerator.DungeonDesigner::min_spawn_ratio
	float ___min_spawn_ratio_9;
	// System.Single DungeonGenerator.DungeonDesigner::max_spawn_ratio
	float ___max_spawn_ratio_10;
};

// DungeonGenerator.Model
struct Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// DungeonGenerator.Model/SpawnPoint[] DungeonGenerator.Model::spawnpoints
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* ___spawnpoints_4;
};

// PixelCollider.PixelCollider2D
struct PixelCollider2D_t6FCBAB552C8143AF518039867DC52AFD086F70FD  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// System.Single PixelCollider.PixelCollider2D::alphaCutoff
	float ___alphaCutoff_4;
};

// UnityEngine.PolygonCollider2D
struct PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E  : public Collider2D_t6A17BA7734600EF3F26588E9ED903617D5B8EB52
{
};

// DungeonGenerator.Room
struct Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// DungeonGenerator.Room/Link[] DungeonGenerator.Room::links
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___links_4;
	// DungeonGenerator.Room/Graphic[] DungeonGenerator.Room::graphics
	GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* ___graphics_5;
	// System.Int32 DungeonGenerator.Room::activation_rotation
	int32_t ___activation_rotation_6;
};

// Tester
struct Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD  : public MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71
{
	// DungeonGenerator.Dungeon Tester::_dungeon
	Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ____dungeon_4;
	// DungeonGenerator.DungeonDesigner Tester::_designer
	DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* ____designer_5;
};

// <Module>

// <Module>

// System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>

// System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>

// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>
struct List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	List_1U5BU5D_tDE88DA8DCD79A37A10DCC96911E1242D15FF66FE* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>

// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>
struct List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	List_1U5BU5D_tFD185408D24E1854912E54803E8FDEBB0407ECEC* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>

// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>
struct List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>

// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>
struct List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	ValueTuple_2U5BU5D_t59C6CEEC5A03DECC2CAAC8E72EA3F06C0A22708B* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>

// System.Collections.Generic.List`1<System.Object>
struct List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<System.Object>

// System.Collections.Generic.List`1<DungeonGenerator.Room>
struct List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<DungeonGenerator.Room>

// System.Collections.Generic.List`1<UnityEngine.Vector2>
struct List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<UnityEngine.Vector2>

// System.Collections.Generic.List`1<UnityEngine.Vector2Int>
struct List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<UnityEngine.Vector2Int>

// System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>
struct List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>

// System.Collections.Generic.List`1<DungeonGenerator.Room/Link>
struct List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B_StaticFields
{
	// T[] System.Collections.Generic.List`1::s_emptyArray
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___s_emptyArray_5;
};

// System.Collections.Generic.List`1<DungeonGenerator.Room/Link>

// System.String
struct String_t_StaticFields
{
	// System.String System.String::Empty
	String_t* ___Empty_6;
};

// System.String

// DungeonGenerator.DungeonDesigner/<>c
struct U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields
{
	// DungeonGenerator.DungeonDesigner/<>c DungeonGenerator.DungeonDesigner/<>c::<>9
	U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* ___U3CU3E9_0;
	// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean> DungeonGenerator.DungeonDesigner/<>c::<>9__12_1
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* ___U3CU3E9__12_1_1;
	// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean> DungeonGenerator.DungeonDesigner/<>c::<>9__12_2
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* ___U3CU3E9__12_2_2;
	// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean> DungeonGenerator.DungeonDesigner/<>c::<>9__12_3
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* ___U3CU3E9__12_3_3;
	// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean> DungeonGenerator.DungeonDesigner/<>c::<>9__12_4
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* ___U3CU3E9__12_4_4;
};

// DungeonGenerator.DungeonDesigner/<>c

// DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17

// DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17

// DungeonGenerator.Room/Graphic

// DungeonGenerator.Room/Graphic

// DungeonGenerator.Room/Link

// DungeonGenerator.Room/Link

// Tester/<loop>d__3

// Tester/<loop>d__3

// System.Boolean
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;
};

// System.Boolean

// UnityEngine.Color

// UnityEngine.Color

// System.Double

// System.Double

// System.Int32

// System.Int32

// System.IntPtr
struct IntPtr_t_StaticFields
{
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;
};

// System.IntPtr

// UnityEngine.Quaternion
struct Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974_StaticFields
{
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___identityQuaternion_4;
};

// UnityEngine.Quaternion

// System.Single

// System.Single

// UnityEngine.Vector2
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields
{
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___negativeInfinityVector_9;
};

// UnityEngine.Vector2

// UnityEngine.Vector2Int
struct Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A_StaticFields
{
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Zero
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Zero_2;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_One
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_One_3;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Up
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Up_4;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Down
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Down_5;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Left
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Left_6;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Right
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___s_Right_7;
};

// UnityEngine.Vector2Int

// UnityEngine.Vector3
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2_StaticFields
{
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___negativeInfinityVector_14;
};

// UnityEngine.Vector3

// System.Void

// System.Void

// UnityEngine.WaitForSeconds

// UnityEngine.WaitForSeconds

// UnityEngine.Bounds

// UnityEngine.Bounds

// UnityEngine.Coroutine

// UnityEngine.Coroutine

// System.Exception
struct Exception_t_StaticFields
{
	// System.Object System.Exception::s_EDILock
	RuntimeObject* ___s_EDILock_0;
};

// System.Exception

// UnityEngine.KeyCode

// UnityEngine.KeyCode

// UnityEngine.Object
struct Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_StaticFields
{
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;
};

// UnityEngine.Object

// DungeonGenerator.Dungeon/<>c__DisplayClass13_0

// DungeonGenerator.Dungeon/<>c__DisplayClass13_0

// DungeonGenerator.DungeonDesigner/CanFlip

// DungeonGenerator.DungeonDesigner/CanFlip

// DungeonGenerator.DungeonDesigner/Orientation

// DungeonGenerator.DungeonDesigner/Orientation

// DungeonGenerator.Model/Location

// DungeonGenerator.Model/Location

// DungeonGenerator.Model/NeedsWall

// DungeonGenerator.Model/NeedsWall

// DungeonGenerator.Model/Type

// DungeonGenerator.Model/Type

// UnityEngine.Component

// UnityEngine.Component

// UnityEngine.GameObject

// UnityEngine.GameObject

// UnityEngine.Sprite

// UnityEngine.Sprite

// UnityEngine.Texture
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700_StaticFields
{
	// System.Int32 UnityEngine.Texture::GenerateAllMips
	int32_t ___GenerateAllMips_4;
};

// UnityEngine.Texture

// DungeonGenerator.DungeonDesigner/Spawnable

// DungeonGenerator.DungeonDesigner/Spawnable

// DungeonGenerator.Model/SpawnPoint

// DungeonGenerator.Model/SpawnPoint

// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean>

// System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean>

// System.Predicate`1<DungeonGenerator.Room>

// System.Predicate`1<DungeonGenerator.Room>

// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>

// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>

// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>

// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>

// System.NotSupportedException

// System.NotSupportedException

// UnityEngine.Texture2D

// UnityEngine.Texture2D

// UnityEngine.Transform

// UnityEngine.Transform

// DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0

// DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0

// UnityEngine.MonoBehaviour

// UnityEngine.MonoBehaviour

// UnityEngine.SpriteRenderer

// UnityEngine.SpriteRenderer

// DungeonGenerator.Dungeon

// DungeonGenerator.Dungeon

// DungeonGenerator.DungeonDesigner

// DungeonGenerator.DungeonDesigner

// DungeonGenerator.Model

// DungeonGenerator.Model

// PixelCollider.PixelCollider2D

// PixelCollider.PixelCollider2D

// UnityEngine.PolygonCollider2D

// UnityEngine.PolygonCollider2D

// DungeonGenerator.Room

// DungeonGenerator.Room

// Tester

// Tester
#ifdef __clang__
#pragma clang diagnostic pop
#endif
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA  : public RuntimeArray
{
	ALIGN_FIELD (8) Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 m_Items[1];

	inline Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 value)
	{
		m_Items[index] = value;
	}
};
// DungeonGenerator.Room[]
struct RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3  : public RuntimeArray
{
	ALIGN_FIELD (8) Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* m_Items[1];

	inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// DungeonGenerator.Room/Graphic[]
struct GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2  : public RuntimeArray
{
	ALIGN_FIELD (8) Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* m_Items[1];

	inline Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// DungeonGenerator.Room/Link[]
struct LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18  : public RuntimeArray
{
	ALIGN_FIELD (8) Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* m_Items[1];

	inline Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// System.Int32[]
struct Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C  : public RuntimeArray
{
	ALIGN_FIELD (8) int32_t m_Items[1];

	inline int32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int32_t value)
	{
		m_Items[index] = value;
	}
};
// DungeonGenerator.Model/SpawnPoint[]
struct SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61  : public RuntimeArray
{
	ALIGN_FIELD (8) SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 m_Items[1];

	inline SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___t_0), (void*)NULL);
	}
	inline SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___t_0), (void*)NULL);
	}
};
// DungeonGenerator.Model[]
struct ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E  : public RuntimeArray
{
	ALIGN_FIELD (8) Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* m_Items[1];

	inline Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// DungeonGenerator.DungeonDesigner/Spawnable[]
struct SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8  : public RuntimeArray
{
	ALIGN_FIELD (8) Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 m_Items[1];

	inline Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___gameObject_0), (void*)NULL);
	}
	inline Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___gameObject_0), (void*)NULL);
	}
};
// System.Object[]
struct ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918  : public RuntimeArray
{
	ALIGN_FIELD (8) RuntimeObject* m_Items[1];

	inline RuntimeObject* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline RuntimeObject** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, RuntimeObject* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
	inline RuntimeObject* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline RuntimeObject** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, RuntimeObject* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)m_Items + index, (void*)value);
	}
};
// UnityEngine.Vector2Int[]
struct Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534  : public RuntimeArray
{
	ALIGN_FIELD (8) Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A m_Items[1];

	inline Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A value)
	{
		m_Items[index] = value;
	}
};
// System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>[]
struct ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E  : public RuntimeArray
{
	ALIGN_FIELD (8) ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 m_Items[1];

	inline ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___Item1_0))->___t_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___Item2_1), (void*)NULL);
		#endif
	}
	inline ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier((void**)&((&((m_Items + index)->___Item1_0))->___t_0), (void*)NULL);
		#if IL2CPP_ENABLE_STRICT_WRITE_BARRIERS
		Il2CppCodeGenWriteBarrier((void**)&((m_Items + index)->___Item2_1), (void*)NULL);
		#endif
	}
};


// T UnityEngine.Component::GetComponent<System.Object>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Component_GetComponent_TisRuntimeObject_m7181F81CAEC2CF53F5D2BC79B7425C16E1F80D33_gshared (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<System.Object>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// T[] System.Collections.Generic.List`1<UnityEngine.Vector2>::ToArray()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5_gshared (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F_gshared (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<UnityEngine.Vector2Int>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2>::Add(T)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_gshared_inline (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_item, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<UnityEngine.Vector2Int>::get_Count()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_gshared_inline (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::Add(T)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_mEBCF994CC3814631017F46A387B1A192ED6C85C7_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, RuntimeObject* ___0_item, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::.ctor(System.Collections.Generic.IEnumerable`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, RuntimeObject* ___0_collection, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::RemoveAt(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_RemoveAt_m54F62297ADEE4D4FDA697F49ED807BF901201B54_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::RemoveAt(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::AddRange(System.Collections.Generic.IEnumerable`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, RuntimeObject* ___0_collection, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::InsertRange(System.Int32,System.Collections.Generic.IEnumerable`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, int32_t ___0_index, RuntimeObject* ___1_collection, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::Reverse()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_gshared (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::Add(T)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_gshared_inline (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_item, const RuntimeMethod* method) ;
// T UnityEngine.Object::Instantiate<System.Object>(T,UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Transform)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Object_Instantiate_TisRuntimeObject_m5F38AE6B74636F569647D545E365C5579E5F59CE_gshared (RuntimeObject* ___0_original, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_position, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___2_rotation, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___3_parent, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Object>::Clear()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Clear_m16C1F2C61FED5955F10EB36BC1CB2DF34B128994_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// System.Void System.Predicate`1<System.Object>::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Predicate_1__ctor_m3E007299121A15DF80F4A210FF8C20E5DF688F20_gshared (Predicate_1_t8342C85FF4E41CD1F7024AC0CDC3E5312A32CB12* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<System.Object>::Find(System.Predicate`1<T>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* List_1_Find_m5E78A210541B0D844FE27B94F509313623BE33D3_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, Predicate_1_t8342C85FF4E41CD1F7024AC0CDC3E5312A32CB12* ___0_match, const RuntimeMethod* method) ;
// T[] System.Collections.Generic.List`1<System.Object>::ToArray()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* List_1_ToArray_mD7E4F8E7C11C3C67CB5739FCC0A6E86106A6291F_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.List`1<System.Object>::Remove(T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool List_1_Remove_m4DFA48F4CEB9169601E75FC28517C5C06EFA5AD7_gshared (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, RuntimeObject* ___0_item, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.Dictionary`2<System.Int32,System.Object>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m92E9AB321FBD7147CA109C822D99C8B0610C27B7_gshared (Dictionary_2_tA75D1125AC9BE8F005BA9B868B373398E643C907* __this, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.Dictionary`2<System.Int32,System.Object>::ContainsKey(TKey)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dictionary_2_ContainsKey_mED5C451F158CDDD2B3F4B0720CD248DA9DB27B25_gshared (Dictionary_2_tA75D1125AC9BE8F005BA9B868B373398E643C907* __this, int32_t ___0_key, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.Dictionary`2<System.Int32,System.Object>::set_Item(TKey,TValue)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dictionary_2_set_Item_m2888D71A14F2B8510102F24FEE90552E91B124C1_gshared (Dictionary_2_tA75D1125AC9BE8F005BA9B868B373398E643C907* __this, int32_t ___0_key, RuntimeObject* ___1_value, const RuntimeMethod* method) ;
// TSource System.Linq.Enumerable::ElementAt<System.Object>(System.Collections.Generic.IEnumerable`1<TSource>,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Enumerable_ElementAt_TisRuntimeObject_mC51F008F04886AD65463E3166E3BFAB665994771_gshared (RuntimeObject* ___0_source, int32_t ___1_index, const RuntimeMethod* method) ;
// System.Int32 System.Linq.Enumerable::Count<System.Object>(System.Collections.Generic.IEnumerable`1<TSource>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Enumerable_Count_TisRuntimeObject_mA9FCB8ECCFE8FABC5AA2F8D46F82ACD52279930B_gshared (RuntimeObject* ___0_source, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13_gshared (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>::Add(T)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_gshared_inline (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_item, const RuntimeMethod* method) ;
// T UnityEngine.GameObject::AddComponent<System.Object>()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* GameObject_AddComponent_TisRuntimeObject_m69B93700FACCF372F5753371C6E8FB780800B824_gshared (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method) ;
// T[] System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>::ToArray()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557_gshared (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, const RuntimeMethod* method) ;
// System.Void System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean>::.ctor(System.Object,System.IntPtr)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E_gshared (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method) ;
// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable::Where<DungeonGenerator.DungeonDesigner/Spawnable>(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_gshared (RuntimeObject* ___0_source, Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* ___1_predicate, const RuntimeMethod* method) ;
// TSource[] System.Linq.Enumerable::ToArray<DungeonGenerator.DungeonDesigner/Spawnable>(System.Collections.Generic.IEnumerable`1<TSource>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_gshared (RuntimeObject* ___0_source, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1__ctor_mFAD745D2857BA444828EA86F3E62A0E1FC67AD0A_gshared (List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E* __this, const RuntimeMethod* method) ;
// System.Void System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>::.ctor(T1,T2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ValueTuple_2__ctor_m3A6059B948DC599E9E5E811BDA463EEE707990E3_gshared (ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_item1, RuntimeObject* ___1_item2, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>::Add(T)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_m9423514FF12E538E6D90B267B916270EDAD7F9B5_gshared_inline (List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E* __this, ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 ___0_item, const RuntimeMethod* method) ;
// T System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>::get_Item(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 List_1_get_Item_mEDA9B9B91DA01D4D08200E04EF05599630DFA127_gshared (List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// System.Int32 System.Linq.Enumerable::Count<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>(System.Collections.Generic.IEnumerable`1<TSource>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Enumerable_Count_TisValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13_m69660F582A18655B8BBCEF80EE15B29F52867C23_gshared (RuntimeObject* ___0_source, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,System.Object>>::set_Item(System.Int32,T)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void List_1_set_Item_m358E051D4BC374CF60DF8DD74E61FAD30FAB6ADB_gshared (List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E* __this, int32_t ___0_index, ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 ___1_value, const RuntimeMethod* method) ;

// System.Boolean UnityEngine.Input::GetKeyDown(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Input_GetKeyDown_m789DB780D0567DCC23B501D15AABD4F2E3591A3F (String_t* ___0_name, const RuntimeMethod* method) ;
// System.Void Tester::Show()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tester_Show_m5C9B329A7906F6BC93BEB481C2B0CE8AEF697705 (Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.Time::get_timeScale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Time_get_timeScale_m1F45A413D4EEA08B1E0988022512C137F6C1E616 (const RuntimeMethod* method) ;
// System.Void UnityEngine.Time::set_timeScale(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Time_set_timeScale_mEF84EE4B2376A458387648079B426B267862D331 (float ___0_value, const RuntimeMethod* method) ;
// System.Void UnityEngine.MonoBehaviour::StopCoroutine(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour_StopCoroutine_m1DA0B9343DCDB53221A6CD707CBF0827A6FFF17F (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, String_t* ___0_methodName, const RuntimeMethod* method) ;
// UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* MonoBehaviour_StartCoroutine_m10C4B693B96175C42B0FD00911E072701C220DB4 (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, String_t* ___0_methodName, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Input::GetKeyDown(UnityEngine.KeyCode)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Input_GetKeyDown_mB237DEA6244132670D38990BAB77D813FBB028D2 (int32_t ___0_key, const RuntimeMethod* method) ;
// System.Void UnityEngine.Application::Quit()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Application_Quit_mE304382DB9A6455C2A474C8F364C7387F37E9281 (const RuntimeMethod* method) ;
// System.Void Tester/<loop>d__3::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CloopU3Ed__3__ctor_m0EB9D6D302D7F4E0EA0D8E38B1E447F471228941 (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, int32_t ___0_U3CU3E1__state, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Dungeon::DestroyDungeon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_DestroyDungeon_m11ADC224AEEA4D854500F6D4A7564C2A906EA22F (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Dungeon::GenerateDungeon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateDungeon_m09621F7697AC301ECD310E1320E847D7EDFFB10D (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.MonoBehaviour::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E (MonoBehaviour_t532A11E69716D348D8AA7F854AFCBFCB8AD17F71* __this, const RuntimeMethod* method) ;
// System.Void System.Object::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2 (RuntimeObject* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.WaitForSeconds::.ctor(System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void WaitForSeconds__ctor_m579F95BADEDBAB4B3A7E302C6EE3995926EF2EFC (WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3* __this, float ___0_seconds, const RuntimeMethod* method) ;
// System.Void System.NotSupportedException::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NotSupportedException__ctor_m1398D0CDE19B36AA3DE9392879738C1EA2439CDF (NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A* __this, const RuntimeMethod* method) ;
// System.Single UnityEngine.Mathf::Clamp(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp_mEB9AEA827D27D20FCC787F7375156AF46BB12BBF_inline (float ___0_value, float ___1_min, float ___2_max, const RuntimeMethod* method) ;
// T UnityEngine.Component::GetComponent<UnityEngine.PolygonCollider2D>()
inline PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* Component_GetComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_m838C3ADF8730E17B91A80DDD18BB0830E513D114 (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method)
{
	return ((  PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* (*) (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3*, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m7181F81CAEC2CF53F5D2BC79B7425C16E1F80D33_gshared)(__this, method);
}
// System.Boolean UnityEngine.Object::op_Equality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___0_x, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___1_y, const RuntimeMethod* method) ;
// UnityEngine.GameObject UnityEngine.Component::get_gameObject()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method) ;
// System.String UnityEngine.Object::get_name()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* __this, const RuntimeMethod* method) ;
// System.String System.String::Concat(System.String,System.String,System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B (String_t* ___0_str0, String_t* ___1_str1, String_t* ___2_str2, const RuntimeMethod* method) ;
// System.Void System.Exception::.ctor(System.String)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Exception__ctor_m9B2BD92CD68916245A75109105D9071C9D430E7F (Exception_t* __this, String_t* ___0_message, const RuntimeMethod* method) ;
// T UnityEngine.Component::GetComponent<UnityEngine.SpriteRenderer>()
inline SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45 (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method)
{
	return ((  SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* (*) (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3*, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m7181F81CAEC2CF53F5D2BC79B7425C16E1F80D33_gshared)(__this, method);
}
// System.Void UnityEngine.PolygonCollider2D::set_pathCount(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721 (PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* __this, int32_t ___0_value, const RuntimeMethod* method) ;
// UnityEngine.Sprite UnityEngine.SpriteRenderer::get_sprite()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44 (SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* __this, const RuntimeMethod* method) ;
// UnityEngine.Texture2D UnityEngine.Sprite::get_texture()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045 (Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>::.ctor()
inline void List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17 (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*, const RuntimeMethod*))List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared)(__this, method);
}
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Get_Unit_Paths(UnityEngine.Texture2D,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* PixelCollider2D_Get_Unit_Paths_m6F6B4B95F9074198C788267EFF5D6405AB6A8EB4 (Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___0_texture, float ___1_alphaCutoff, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Simplify_Paths_Phase_1(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* PixelCollider2D_Simplify_Paths_Phase_1_m3054733C750DC0318B29B2941CBE87C5AD6226C1 (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* ___0_Unit_Paths, const RuntimeMethod* method) ;
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Simplify_Paths_Phase_2(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* PixelCollider2D_Simplify_Paths_Phase_2_mDDF788D66579E9EBF363A083056902AC6DE3874A (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* ___0_Input_Paths, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>::.ctor()
inline void List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46 (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE*, const RuntimeMethod*))List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared)(__this, method);
}
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>> PixelCollider.PixelCollider2D::Finalize_Paths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>,UnityEngine.Sprite)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* PixelCollider2D_Finalize_Paths_m88E0EA0CFBDE2DADE57268C1116A9E1E91D47ECF (PixelCollider2D_t6FCBAB552C8143AF518039867DC52AFD086F70FD* __this, List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* ___0_Pixel_Paths, Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* ___1_sprite, const RuntimeMethod* method) ;
// System.Int32 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>::get_Count()
inline int32_t List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_inline (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE*, const RuntimeMethod*))List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline)(__this, method);
}
// T System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>::get_Item(System.Int32)
inline List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* List_1_get_Item_mF7BAD78CA9941DF0CD8F1E94ACD1FFC6BEC5318F (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	return ((  List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* (*) (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE*, int32_t, const RuntimeMethod*))List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared)(__this, ___0_index, method);
}
// T[] System.Collections.Generic.List`1<UnityEngine.Vector2>::ToArray()
inline Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5 (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, const RuntimeMethod* method)
{
	return ((  Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* (*) (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B*, const RuntimeMethod*))List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5_gshared)(__this, method);
}
// System.Void UnityEngine.PolygonCollider2D::SetPath(System.Int32,UnityEngine.Vector2[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PolygonCollider2D_SetPath_mDF03B6FDAE81E25C985F9BA6D372D949A6D9A1C1 (PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* __this, int32_t ___0_index, Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* ___1_points, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Sprite::get_pivot()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Sprite_get_pivot_mDFC0A205317DB2F3B6C720B8A5BE1C27D01C1D44 (Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* __this, const RuntimeMethod* method) ;
// UnityEngine.Bounds UnityEngine.Sprite::get_bounds()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452 (Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Bounds::get_max()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Bounds_get_max_m6446F2AB97C1E57CA89467B9DE52D4EB61F1CB09 (Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Bounds::get_min()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Bounds_get_min_m465AC9BBE1DE5D8E8AD95AC19B9899068FEEBB13 (Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2>::.ctor()
inline void List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B*, const RuntimeMethod*))List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F_gshared)(__this, method);
}
// T System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>::get_Item(System.Int32)
inline List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	return ((  List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* (*) (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*, int32_t, const RuntimeMethod*))List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared)(__this, ___0_index, method);
}
// T System.Collections.Generic.List`1<UnityEngine.Vector2Int>::get_Item(System.Int32)
inline Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	return ((  Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, int32_t, const RuntimeMethod*))List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_gshared)(__this, ___0_index, method);
}
// UnityEngine.Vector2 UnityEngine.Vector2Int::op_Implicit(UnityEngine.Vector2Int)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_v, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Vector2::op_Subtraction(UnityEngine.Vector2,UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Subtraction_m44475FCDAD2DA2F98D78A6625EC2DCDFE8803837_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___1_b, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2>::Add(T)
inline void List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_inline (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B*, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7, const RuntimeMethod*))List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_gshared_inline)(__this, ___0_item, method);
}
// System.Int32 System.Collections.Generic.List`1<UnityEngine.Vector2Int>::get_Count()
inline int32_t List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, const RuntimeMethod*))List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_gshared_inline)(__this, method);
}
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>>::Add(T)
inline void List_1_Add_m1902F684694327EBD4B760E536C852CA86EF93BA_inline (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* __this, List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE*, List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B*, const RuntimeMethod*))List_1_Add_mEBCF994CC3814631017F46A387B1A192ED6C85C7_gshared_inline)(__this, ___0_item, method);
}
// System.Int32 System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>::get_Count()
inline int32_t List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_inline (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*, const RuntimeMethod*))List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline)(__this, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::.ctor(System.Collections.Generic.IEnumerable`1<T>)
inline void List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, RuntimeObject* ___0_collection, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, RuntimeObject*, const RuntimeMethod*))List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B_gshared)(__this, ___0_collection, method);
}
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>::RemoveAt(System.Int32)
inline void List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823 (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*, int32_t, const RuntimeMethod*))List_1_RemoveAt_m54F62297ADEE4D4FDA697F49ED807BF901201B54_gshared)(__this, ___0_index, method);
}
// System.Boolean UnityEngine.Vector2Int::op_Equality(UnityEngine.Vector2Int,UnityEngine.Vector2Int)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Vector2Int_op_Equality_mD80F6ED22EA1200C4F408440D02FE61388C7D6BA_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_lhs, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___1_rhs, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::RemoveAt(System.Int32)
inline void List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0 (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, int32_t, const RuntimeMethod*))List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_gshared)(__this, ___0_index, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::AddRange(System.Collections.Generic.IEnumerable`1<T>)
inline void List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671 (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, RuntimeObject* ___0_collection, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, RuntimeObject*, const RuntimeMethod*))List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671_gshared)(__this, ___0_collection, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::InsertRange(System.Int32,System.Collections.Generic.IEnumerable`1<T>)
inline void List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, int32_t ___0_index, RuntimeObject* ___1_collection, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, int32_t, RuntimeObject*, const RuntimeMethod*))List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C_gshared)(__this, ___0_index, ___1_collection, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::Reverse()
inline void List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91 (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, const RuntimeMethod*))List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>::Add(T)
inline void List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_inline (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* __this, List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*, List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, const RuntimeMethod*))List_1_Add_mEBCF994CC3814631017F46A387B1A192ED6C85C7_gshared_inline)(__this, ___0_item, method);
}
// System.Single UnityEngine.Vector2::get_magnitude()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector2_get_magnitude_m5C59B4056420AEFDB291AD0914A3F675330A75CE_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Vector2::op_Division(UnityEngine.Vector2,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Division_m57A2DCD71E0CE7420851D705D1951F9238902AAB_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, float ___1_d, const RuntimeMethod* method) ;
// System.Boolean UnityEngine.Vector2::op_Equality(UnityEngine.Vector2,UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Vector2_op_Equality_m6F2E069A50E787D131261E5CB25FC9E03F95B5E1_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_lhs, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___1_rhs, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector2Int::.ctor(System.Int32,System.Int32)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
// System.Boolean PixelCollider.PixelCollider2D::pixelSolid(UnityEngine.Texture2D,UnityEngine.Vector2Int,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2 (Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___0_texture, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___1_point, float ___2_alphaCutoff, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::.ctor()
inline void List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, const RuntimeMethod*))List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<UnityEngine.Vector2Int>::Add(T)
inline void List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A, const RuntimeMethod*))List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_gshared_inline)(__this, ___0_item, method);
}
// System.Int32 UnityEngine.Vector2Int::get_x()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Vector2Int::get_y()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* __this, const RuntimeMethod* method) ;
// UnityEngine.Color UnityEngine.Texture2D::GetPixel(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Color_tD001788D726C3A7F1379BEED0260B9591F440C1F Texture2D_GetPixel_m69A17FE5CC220F438C7421DCB50A9E22AAB4A415 (Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Dungeon::GenerateFirst()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateFirst_m8715C4306C6ABCB9E478E73B12132CC2F7E0DD60 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) ;
// UnityEngine.Transform UnityEngine.Component::get_transform()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371 (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method) ;
// System.Collections.IEnumerator UnityEngine.Transform::GetEnumerator()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Transform_GetEnumerator_mA7E1C882ACA0C33E284711CD09971DEA3FFEF404 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
// T UnityEngine.Component::GetComponent<DungeonGenerator.Room>()
inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3* __this, const RuntimeMethod* method)
{
	return ((  Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* (*) (Component_t39FBE53E5EFCF4409111FB22C15FF73717632EC3*, const RuntimeMethod*))Component_GetComponent_TisRuntimeObject_m7181F81CAEC2CF53F5D2BC79B7425C16E1F80D33_gshared)(__this, method);
}
// System.Void DungeonGenerator.Room::ActivateGraphics(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Room_ActivateGraphics_mD775D2203F51E0CB69D089C1BFBDB85996B34BE4 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, bool ___0_generate_skeleton, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Transform::get_localScale()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Transform_get_localScale_m804A002A53A645CDFCD15BB0F37209162720363F (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
// System.Int32 UnityEngine.Random::Range(System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68 (int32_t ___0_minInclusive, int32_t ___1_maxExclusive, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Vector2::get_zero()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_get_zero_m32506C40EC2EE7D5D4410BF40D3EE683A3D5F32C_inline (const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector2::op_Implicit(UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_v, const RuntimeMethod* method) ;
// UnityEngine.Quaternion UnityEngine.Quaternion::Euler(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline (float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
// T UnityEngine.Object::Instantiate<DungeonGenerator.Room>(T,UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Transform)
inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_original, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_position, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___2_rotation, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___3_parent, const RuntimeMethod* method)
{
	return ((  Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* (*) (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404*, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1*, const RuntimeMethod*))Object_Instantiate_TisRuntimeObject_m5F38AE6B74636F569647D545E365C5579E5F59CE_gshared)(___0_original, ___1_position, ___2_rotation, ___3_parent, method);
}
// System.Void DungeonGenerator.Dungeon::GenerateFromRoom(DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateFromRoom_m437D042CBB67DFF7F19FA8A4F8C9639D724EFBA8 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_r, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Room>::Clear()
inline void List_1_Clear_m860165F91832E967E3EF62F787A8EC74CECFA78F_inline (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, const RuntimeMethod*))List_1_Clear_m16C1F2C61FED5955F10EB36BC1CB2DF34B128994_gshared_inline)(__this, method);
}
// System.Void UnityEngine.Object::Destroy(UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object_Destroy_mE97D0A766419A81296E8D4E5C23D01D3FE91ACBB (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___0_obj, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Room>::Add(T)
inline void List_1_Add_mE5AA8024B0AB1F676B72ABC9CD4E640E72394461_inline (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404*, const RuntimeMethod*))List_1_Add_mEBCF994CC3814631017F46A387B1A192ED6C85C7_gshared_inline)(__this, ___0_item, method);
}
// System.Void DungeonGenerator.Dungeon::GenerateFromLink(DungeonGenerator.Room/Link,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateFromLink_m6E4C3BA491302C3D6132DA76D99E86AB1CF369C7 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* ___0_l, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_r, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Dungeon/<>c__DisplayClass13_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass13_0__ctor_m06A2E9304E55E1226138916A1E18D697DA8DDB41 (U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* __this, const RuntimeMethod* method) ;
// DungeonGenerator.Room DungeonGenerator.Dungeon::RandomRoom()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* Dungeon_RandomRoom_mF59C744A7A66100F033CD9536DC5D2495AA8EC9B (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) ;
// System.Int32 DungeonGenerator.Room::get_rotation()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector2 DungeonGenerator.Room::get_position()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector2::.ctor(System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Vector2::op_Multiply(UnityEngine.Vector2,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Multiply_m2D984B613020089BF5165BA4CA10988E2DC771FE_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, float ___1_d, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Vector2::op_Addition(UnityEngine.Vector2,UnityEngine.Vector2)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Addition_m8136742CE6EE33BA4EB81C5F584678455917D2AE_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___1_b, const RuntimeMethod* method) ;
// System.Int32 DungeonGenerator.Dungeon::Normalized(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA (int32_t ___0_angle, const RuntimeMethod* method) ;
// System.Void System.Predicate`1<DungeonGenerator.Room>::.ctor(System.Object,System.IntPtr)
inline void Predicate_1__ctor_m5206A84FE4651A1076EC4EFC55D0824C9F87EDE4 (Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method)
{
	((  void (*) (Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9*, RuntimeObject*, intptr_t, const RuntimeMethod*))Predicate_1__ctor_m3E007299121A15DF80F4A210FF8C20E5DF688F20_gshared)(__this, ___0_object, ___1_method, method);
}
// T System.Collections.Generic.List`1<DungeonGenerator.Room>::Find(System.Predicate`1<T>)
inline Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* List_1_Find_m113B5413263A32E5F8E92AB8D0B15530CB79634C (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9* ___0_match, const RuntimeMethod* method)
{
	return ((  Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9*, const RuntimeMethod*))List_1_Find_m5E78A210541B0D844FE27B94F509313623BE33D3_gshared)(__this, ___0_match, method);
}
// System.Boolean UnityEngine.Object::op_Inequality(UnityEngine.Object,UnityEngine.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602 (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___0_x, Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C* ___1_y, const RuntimeMethod* method) ;
// DungeonGenerator.Room DungeonGenerator.Dungeon::AddRooms(DungeonGenerator.Room,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* Dungeon_AddRooms_m3D3C97690BDF4618559AAC205FFAEB8D40320AFA (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_r1, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_r2, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Room/Link>::.ctor()
inline void List_1__ctor_m2424D4A7D9018A7B7FD865A4B75D47D66E60D866 (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*, const RuntimeMethod*))List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared)(__this, method);
}
// System.Void DungeonGenerator.Room/Link::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* __this, int32_t ___0_angle, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Room/Link>::Add(T)
inline void List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_inline (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* __this, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4*, const RuntimeMethod*))List_1_Add_mEBCF994CC3814631017F46A387B1A192ED6C85C7_gshared_inline)(__this, ___0_item, method);
}
// System.Void DungeonGenerator.Dungeon::<AddRooms>g__Distinct|14_0(System.Collections.Generic.List`1<DungeonGenerator.Room/Link>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_U3CAddRoomsU3Eg__DistinctU7C14_0_mC7B9629734C039FEAC834D902336C88F33E5307E (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* ___0_links, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Dungeon::<AddRooms>g__Sort|14_1(System.Collections.Generic.IEnumerable`1<DungeonGenerator.Room/Link>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_U3CAddRoomsU3Eg__SortU7C14_1_m037CC0569376A031A30912BC8E5F6787F98E06BA (RuntimeObject* ___0_links, const RuntimeMethod* method) ;
// T[] System.Collections.Generic.List`1<DungeonGenerator.Room/Link>::ToArray()
inline LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* List_1_ToArray_m774D68B3437B636757CA5CE8C139144E372294EA (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* __this, const RuntimeMethod* method)
{
	return ((  LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* (*) (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*, const RuntimeMethod*))List_1_ToArray_mD7E4F8E7C11C3C67CB5739FCC0A6E86106A6291F_gshared)(__this, method);
}
// System.Int32 System.Collections.Generic.List`1<DungeonGenerator.Room/Link>::get_Count()
inline int32_t List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_inline (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*, const RuntimeMethod*))List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline)(__this, method);
}
// DungeonGenerator.Room/Link[] DungeonGenerator.Dungeon::<AddRooms>g__NormalizeAngles|14_3(DungeonGenerator.Room/Link[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* Dungeon_U3CAddRoomsU3Eg__NormalizeAnglesU7C14_3_m39FB34A370A8930F673CA42078ED5E2E5B80414C (LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___0_links, int32_t ___1_rotation, const RuntimeMethod* method) ;
// System.Boolean DungeonGenerator.Dungeon::<AddRooms>g__AngleMatch|14_2(DungeonGenerator.Room/Link[],DungeonGenerator.Room/Link[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dungeon_U3CAddRoomsU3Eg__AngleMatchU7C14_2_m02B65223985DB827BB9659F00877C1409FF11A14 (LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___0_l1, LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___1_l2, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Dungeon::<AddRooms>g__DisableLinks|14_4(DungeonGenerator.Room,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_U3CAddRoomsU3Eg__DisableLinksU7C14_4_m1F011D4844CB48DEB66D6EC54EADEF34C784A3C9 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_model, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_room_disable, const RuntimeMethod* method) ;
// System.Boolean System.Collections.Generic.List`1<DungeonGenerator.Room>::Remove(T)
inline bool List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_item, const RuntimeMethod* method)
{
	return ((  bool (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404*, const RuntimeMethod*))List_1_Remove_m4DFA48F4CEB9169601E75FC28517C5C06EFA5AD7_gshared)(__this, ___0_item, method);
}
// System.Int32 System.Collections.Generic.List`1<DungeonGenerator.Room>::get_Count()
inline int32_t List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_inline (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, const RuntimeMethod*))List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline)(__this, method);
}
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Room>::.ctor()
inline void List_1__ctor_mE8B67035812C247866131D058EF6E3284A17B95B (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, const RuntimeMethod*))List_1__ctor_m7F078BB342729BDF11327FD89D7872265328F690_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>::.ctor()
inline void Dictionary_2__ctor_mB97F1137644FD8446F05E9AA8A86C9840D587C18 (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E*, const RuntimeMethod*))Dictionary_2__ctor_m92E9AB321FBD7147CA109C822D99C8B0610C27B7_gshared)(__this, method);
}
// T System.Collections.Generic.List`1<DungeonGenerator.Room/Link>::get_Item(System.Int32)
inline Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50 (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	return ((  Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* (*) (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*, int32_t, const RuntimeMethod*))List_1_get_Item_m33561245D64798C2AB07584C0EC4F240E4839A38_gshared)(__this, ___0_index, method);
}
// System.Boolean System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>::ContainsKey(TKey)
inline bool Dictionary_2_ContainsKey_m25725AE19289EC9E8D4510E63BB4D41272E7B76A (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* __this, int32_t ___0_key, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E*, int32_t, const RuntimeMethod*))Dictionary_2_ContainsKey_mED5C451F158CDDD2B3F4B0720CD248DA9DB27B25_gshared)(__this, ___0_key, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.Int32,DungeonGenerator.Room/Link>::set_Item(TKey,TValue)
inline void Dictionary_2_set_Item_mFEEAD6949043D033BD1DD28B97C236680AC557BA (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* __this, int32_t ___0_key, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* ___1_value, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E*, int32_t, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4*, const RuntimeMethod*))Dictionary_2_set_Item_m2888D71A14F2B8510102F24FEE90552E91B124C1_gshared)(__this, ___0_key, ___1_value, method);
}
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Room/Link>::RemoveAt(System.Int32)
inline void List_1_RemoveAt_m3894E022B8F0201AC450EE7D6B34BF7B7DFC9419 (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	((  void (*) (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*, int32_t, const RuntimeMethod*))List_1_RemoveAt_m54F62297ADEE4D4FDA697F49ED807BF901201B54_gshared)(__this, ___0_index, method);
}
// TSource System.Linq.Enumerable::ElementAt<DungeonGenerator.Room/Link>(System.Collections.Generic.IEnumerable`1<TSource>,System.Int32)
inline Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF (RuntimeObject* ___0_source, int32_t ___1_index, const RuntimeMethod* method)
{
	return ((  Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* (*) (RuntimeObject*, int32_t, const RuntimeMethod*))Enumerable_ElementAt_TisRuntimeObject_mC51F008F04886AD65463E3166E3BFAB665994771_gshared)(___0_source, ___1_index, method);
}
// System.Int32 System.Linq.Enumerable::Count<DungeonGenerator.Room/Link>(System.Collections.Generic.IEnumerable`1<TSource>)
inline int32_t Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964 (RuntimeObject* ___0_source, const RuntimeMethod* method)
{
	return ((  int32_t (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_Count_TisRuntimeObject_mA9FCB8ECCFE8FABC5AA2F8D46F82ACD52279930B_gshared)(___0_source, method);
}
// T[] System.Collections.Generic.List`1<DungeonGenerator.Room>::ToArray()
inline RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* List_1_ToArray_mC3E937AF391FBD2071D29BE457FAFAB3BF5DD94F (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* __this, const RuntimeMethod* method)
{
	return ((  RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* (*) (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*, const RuntimeMethod*))List_1_ToArray_mD7E4F8E7C11C3C67CB5739FCC0A6E86106A6291F_gshared)(__this, method);
}
// System.Int32 DungeonGenerator.Room::GetActivationRotation()
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Room_GetActivationRotation_mD585EEAC58FCB6AB88F219D9E624038EF7C37D1C_inline (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>::.ctor()
inline void List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13 (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2*, const RuntimeMethod*))List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13_gshared)(__this, method);
}
// System.Boolean DungeonGenerator.DungeonDesigner::Contains(System.Array,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DungeonDesigner_Contains_m159F5B7F3AD84DC9185747D461F7224A503E6040 (RuntimeArray* ___0_array, RuntimeObject* ___1_value, const RuntimeMethod* method) ;
// System.Void System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>::Add(T)
inline void List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_inline (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2*, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0, const RuntimeMethod*))List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_gshared_inline)(__this, ___0_item, method);
}
// T UnityEngine.GameObject::AddComponent<DungeonGenerator.Model>()
inline Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* GameObject_AddComponent_TisModel_tC414155249EC7AAC88CDBA8448952AF9525DEC17_mD473FDD0F45F30E0908D9C09D6969E43F9CF0ACF (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method)
{
	return ((  Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* (*) (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F*, const RuntimeMethod*))GameObject_AddComponent_TisRuntimeObject_m69B93700FACCF372F5753371C6E8FB780800B824_gshared)(__this, method);
}
// T[] System.Collections.Generic.List`1<DungeonGenerator.Model/SpawnPoint>::ToArray()
inline SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557 (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, const RuntimeMethod* method)
{
	return ((  SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* (*) (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2*, const RuntimeMethod*))List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557_gshared)(__this, method);
}
// System.Int32 System.Array::IndexOf(System.Array,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Array_IndexOf_m465D44BD098AF24A76CB69293F87849DEE7EBD5C (RuntimeArray* ___0_array, RuntimeObject* ___1_value, const RuntimeMethod* method) ;
// DungeonGenerator.Room[] DungeonGenerator.DungeonDesigner::getDungeon(DungeonGenerator.Dungeon)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ___0_dungeon, const RuntimeMethod* method) ;
// DungeonGenerator.Model DungeonGenerator.DungeonDesigner::RoomToModel(DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* DungeonDesigner_RoomToModel_m7DF305BE8C449842BD12AC327A56C73CAA053B2D (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_r, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.DungeonDesigner::Spawn(DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_Spawn_mD5742B2869D433DCF9417BAD9C357B7A17E1E4F6 (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_sp, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_r, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Transform::get_position()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Addition(UnityEngine.Vector3,UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) ;
// UnityEngine.Quaternion UnityEngine.Transform::get_rotation()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
// T UnityEngine.Object::Instantiate<UnityEngine.GameObject>(T,UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Transform)
inline GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___0_original, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_position, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 ___2_rotation, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___3_parent, const RuntimeMethod* method)
{
	return ((  GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* (*) (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F*, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2, Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1*, const RuntimeMethod*))Object_Instantiate_TisRuntimeObject_m5F38AE6B74636F569647D545E365C5579E5F59CE_gshared)(___0_original, ___1_position, ___2_rotation, ___3_parent, method);
}
// System.Void DungeonGenerator.DungeonDesigner::<Spawn>g__FlipCheck|12_0(DungeonGenerator.DungeonDesigner/Spawnable,UnityEngine.GameObject,DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_U3CSpawnU3Eg__FlipCheckU7C12_0_m0C267CF9CAE77F246C2E72B68168D4B86FE506F2 (Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 ___0_s, GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___1_g, U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4* ___2_p, const RuntimeMethod* method) ;
// DungeonGenerator.DungeonDesigner/Orientation DungeonGenerator.Model::Orientation(DungeonGenerator.Model/SpawnPoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A (SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_sp, const RuntimeMethod* method) ;
// System.Void System.Func`2<DungeonGenerator.DungeonDesigner/Spawnable,System.Boolean>::.ctor(System.Object,System.IntPtr)
inline void Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* __this, RuntimeObject* ___0_object, intptr_t ___1_method, const RuntimeMethod* method)
{
	((  void (*) (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240*, RuntimeObject*, intptr_t, const RuntimeMethod*))Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E_gshared)(__this, ___0_object, ___1_method, method);
}
// System.Collections.Generic.IEnumerable`1<TSource> System.Linq.Enumerable::Where<DungeonGenerator.DungeonDesigner/Spawnable>(System.Collections.Generic.IEnumerable`1<TSource>,System.Func`2<TSource,System.Boolean>)
inline RuntimeObject* Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043 (RuntimeObject* ___0_source, Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* ___1_predicate, const RuntimeMethod* method)
{
	return ((  RuntimeObject* (*) (RuntimeObject*, Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240*, const RuntimeMethod*))Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_gshared)(___0_source, ___1_predicate, method);
}
// TSource[] System.Linq.Enumerable::ToArray<DungeonGenerator.DungeonDesigner/Spawnable>(System.Collections.Generic.IEnumerable`1<TSource>)
inline SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358 (RuntimeObject* ___0_source, const RuntimeMethod* method)
{
	return ((  SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_gshared)(___0_source, method);
}
// System.Void System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>::.ctor()
inline void List_1__ctor_m36B74D51D7FC7F3FE3EC1EE076EAD4EB6DBD5FF1 (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F*, const RuntimeMethod*))List_1__ctor_mFAD745D2857BA444828EA86F3E62A0E1FC67AD0A_gshared)(__this, method);
}
// System.Void System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>::.ctor(T1,T2)
inline void ValueTuple_2__ctor_m3315007AD2DBF3F7D006595F0F70623784E08499 (ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_item1, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_item2, const RuntimeMethod* method)
{
	((  void (*) (ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE*, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404*, const RuntimeMethod*))ValueTuple_2__ctor_m3A6059B948DC599E9E5E811BDA463EEE707990E3_gshared)(__this, ___0_item1, ___1_item2, method);
}
// System.Void System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>::Add(T)
inline void List_1_Add_mDBE179845F4DD8F7DCD68FFE1AE177FD7E3ED070_inline (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* __this, ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE ___0_item, const RuntimeMethod* method)
{
	((  void (*) (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F*, ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE, const RuntimeMethod*))List_1_Add_m9423514FF12E538E6D90B267B916270EDAD7F9B5_gshared_inline)(__this, ___0_item, method);
}
// T System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>::get_Item(System.Int32)
inline ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	return ((  ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE (*) (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F*, int32_t, const RuntimeMethod*))List_1_get_Item_mEDA9B9B91DA01D4D08200E04EF05599630DFA127_gshared)(__this, ___0_index, method);
}
// System.Int32 System.Linq.Enumerable::Count<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>(System.Collections.Generic.IEnumerable`1<TSource>)
inline int32_t Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01 (RuntimeObject* ___0_source, const RuntimeMethod* method)
{
	return ((  int32_t (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_Count_TisValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13_m69660F582A18655B8BBCEF80EE15B29F52867C23_gshared)(___0_source, method);
}
// System.Void System.Collections.Generic.List`1<System.ValueTuple`2<DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room>>::set_Item(System.Int32,T)
inline void List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* __this, int32_t ___0_index, ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE ___1_value, const RuntimeMethod* method)
{
	((  void (*) (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F*, int32_t, ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE, const RuntimeMethod*))List_1_set_Item_m358E051D4BC374CF60DF8DD74E61FAD30FAB6ADB_gshared)(__this, ___0_index, ___1_value, method);
}
// System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDecorateDungeonU3Ed__17__ctor_m1ED48BFA78B792EC4E43CDA3E496583F5172F37B (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, int32_t ___0_U3CU3E1__state, const RuntimeMethod* method) ;
// UnityEngine.Transform UnityEngine.GameObject::get_transform()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
// System.Void UnityEngine.Transform::set_localScale(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_localScale_mBA79E811BAF6C47B80FF76414C12B47B3CD03633 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_value, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.DungeonDesigner/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mD27026C1F9A45AA0C1D922C1165B4629D17494FC (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* __this, const RuntimeMethod* method) ;
// System.Int32 System.Linq.Enumerable::Count<DungeonGenerator.Room>(System.Collections.Generic.IEnumerable`1<TSource>)
inline int32_t Enumerable_Count_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_mB2A88D089B3CEC205E70A7BB7292844B04AD56D9 (RuntimeObject* ___0_source, const RuntimeMethod* method)
{
	return ((  int32_t (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_Count_TisRuntimeObject_mA9FCB8ECCFE8FABC5AA2F8D46F82ACD52279930B_gshared)(___0_source, method);
}
// System.Void DungeonGenerator.DungeonDesigner::SpawnRandomN(DungeonGenerator.Dungeon,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_SpawnRandomN_m56C8F4BF0E57401469B33FCBAEFD04340BC89990 (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ___0_d, int32_t ___1_n, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Model/SpawnPoint::.ctor(UnityEngine.Transform,DungeonGenerator.Model/Type,DungeonGenerator.Model/Location,DungeonGenerator.Model/NeedsWall)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22 (SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0* __this, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___0_t, int32_t ___1_type, int32_t ___2_location, int32_t ___3_needs_wall, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Transform::get_eulerAngles()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Transform_get_eulerAngles_mCAAF48EFCF628F1ED91C2FFE75A4FD19C039DD6A (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, const RuntimeMethod* method) ;
// System.Void UnityEngine.Transform::set_eulerAngles(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_eulerAngles_m9F0BC484A7915A51FAB87230644229B75BACA004 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_value, const RuntimeMethod* method) ;
// UnityEngine.Vector2 UnityEngine.Vector2::op_Implicit(UnityEngine.Vector3)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Implicit_mE8EBEE9291F11BB02F062D6E000F4798968CBD96_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_v, const RuntimeMethod* method) ;
// System.Void UnityEngine.Transform::set_position(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Transform_set_position_mA1A817124BB41B685043DED2A9BA48CDF37C4156 (Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* __this, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_value, const RuntimeMethod* method) ;
// System.Void UnityEngine.SpriteRenderer::set_sprite(UnityEngine.Sprite)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpriteRenderer_set_sprite_m7B176E33955108C60CAE21DFC153A0FAC674CB53 (SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* __this, Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* ___0_value, const RuntimeMethod* method) ;
// System.Void DungeonGenerator.Room::set_rotation(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Room_set_rotation_m436F74FF610C99B98252E1DD84C68089F9FC46A9 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, int32_t ___0_value, const RuntimeMethod* method) ;
// T UnityEngine.GameObject::AddComponent<UnityEngine.PolygonCollider2D>()
inline PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* GameObject_AddComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_mDC33421D7DA59610EEC9A5E208A162DF9934C391 (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* __this, const RuntimeMethod* method)
{
	return ((  PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* (*) (GameObject_t76FEDD663AB33C991A9C9A23129337651094216F*, const RuntimeMethod*))GameObject_AddComponent_TisRuntimeObject_m69B93700FACCF372F5753371C6E8FB780800B824_gshared)(__this, method);
}
// System.Int32 UnityEngine.PolygonCollider2D::get_pathCount()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t PolygonCollider2D_get_pathCount_m2F7EA6C9D0D7E579741DD3CB26BD1B2320570CC3 (PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* __this, const RuntimeMethod* method) ;
// UnityEngine.Vector2[] UnityEngine.PolygonCollider2D::GetPath(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* PolygonCollider2D_GetPath_mE9D53D83FBB110EAC748BA535A1659C262B50F50 (PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* __this, int32_t ___0_index, const RuntimeMethod* method) ;
// UnityEngine.Vector3 UnityEngine.Vector3::op_Multiply(UnityEngine.Vector3,System.Single)
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Multiply_m87BA7C578F96C8E49BB07088DAAC4649F83B0353_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) ;
// UnityEngine.Quaternion UnityEngine.Quaternion::Internal_FromEulerRad(UnityEngine.Vector3)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_Internal_FromEulerRad_m66D4475341F53949471E6870FB5C5E4A5E9BA93E (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_euler, const RuntimeMethod* method) ;
// System.Void System.Array::Clear(System.Array,System.Int32,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Array_Clear_m50BAA3751899858B097D3FF2ED31F284703FE5CB (RuntimeArray* ___0_array, int32_t ___1_index, int32_t ___2_length, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Tester::Update()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tester_Update_mF75D641178A6BCCCEDA69064EB10CD4734438FF5 (Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral0A04B971B03DA607CE6C455184037B660CA89F78);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral198AA065BF0F912BD6F5F93869BD5C361671F98B);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral430E518F836082E0683698AB9E3F79D39C7F5140);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralE02BC3B5D408D1BC5E365A7F3C21C2F13AA96125);
		s_Il2CppMethodInitialized = true;
	}
	int32_t G_B6_0 = 0;
	{
		// if (Input.GetKeyDown("a"))
		bool L_0;
		L_0 = Input_GetKeyDown_m789DB780D0567DCC23B501D15AABD4F2E3591A3F(_stringLiteral0A04B971B03DA607CE6C455184037B660CA89F78, NULL);
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		// Show();
		Tester_Show_m5C9B329A7906F6BC93BEB481C2B0CE8AEF697705(__this, NULL);
	}

IL_0012:
	{
		// if(Input.GetKeyDown("p"))
		bool L_1;
		L_1 = Input_GetKeyDown_m789DB780D0567DCC23B501D15AABD4F2E3591A3F(_stringLiteral198AA065BF0F912BD6F5F93869BD5C361671F98B, NULL);
		if (!L_1)
		{
			goto IL_0034;
		}
	}
	{
		// Time.timeScale = Time.timeScale == 1 ? 0 : 1;
		float L_2;
		L_2 = Time_get_timeScale_m1F45A413D4EEA08B1E0988022512C137F6C1E616(NULL);
		if ((((float)L_2) == ((float)(1.0f))))
		{
			goto IL_002d;
		}
	}
	{
		G_B6_0 = 1;
		goto IL_002e;
	}

IL_002d:
	{
		G_B6_0 = 0;
	}

IL_002e:
	{
		Time_set_timeScale_mEF84EE4B2376A458387648079B426B267862D331(((float)G_B6_0), NULL);
	}

IL_0034:
	{
		// if(Input.GetKeyDown("q"))
		bool L_3;
		L_3 = Input_GetKeyDown_m789DB780D0567DCC23B501D15AABD4F2E3591A3F(_stringLiteral430E518F836082E0683698AB9E3F79D39C7F5140, NULL);
		if (!L_3)
		{
			goto IL_0057;
		}
	}
	{
		// StopCoroutine("loop");
		MonoBehaviour_StopCoroutine_m1DA0B9343DCDB53221A6CD707CBF0827A6FFF17F(__this, _stringLiteralE02BC3B5D408D1BC5E365A7F3C21C2F13AA96125, NULL);
		// StartCoroutine("loop");
		Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* L_4;
		L_4 = MonoBehaviour_StartCoroutine_m10C4B693B96175C42B0FD00911E072701C220DB4(__this, _stringLiteralE02BC3B5D408D1BC5E365A7F3C21C2F13AA96125, NULL);
	}

IL_0057:
	{
		// if(Input.GetKeyDown(KeyCode.Escape))
		bool L_5;
		L_5 = Input_GetKeyDown_mB237DEA6244132670D38990BAB77D813FBB028D2(((int32_t)27), NULL);
		if (!L_5)
		{
			goto IL_0065;
		}
	}
	{
		// Application.Quit();
		Application_Quit_mE304382DB9A6455C2A474C8F364C7387F37E9281(NULL);
	}

IL_0065:
	{
		// if (Input.GetKeyDown(KeyCode.Escape))
		bool L_6;
		L_6 = Input_GetKeyDown_mB237DEA6244132670D38990BAB77D813FBB028D2(((int32_t)27), NULL);
		if (!L_6)
		{
			goto IL_0073;
		}
	}
	{
		// Application.Quit();
		Application_Quit_mE304382DB9A6455C2A474C8F364C7387F37E9281(NULL);
	}

IL_0073:
	{
		// }
		return;
	}
}
// System.Collections.IEnumerator Tester::loop()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* Tester_loop_m1CD17E61D20BA2F286FA8B628BCF58B262C51DC6 (Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* L_0 = (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F*)il2cpp_codegen_object_new(U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		U3CloopU3Ed__3__ctor_m0EB9D6D302D7F4E0EA0D8E38B1E447F471228941(L_0, 0, NULL);
		U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* L_1 = L_0;
		NullCheck(L_1);
		L_1->___U3CU3E4__this_2 = __this;
		Il2CppCodeGenWriteBarrier((void**)(&L_1->___U3CU3E4__this_2), (void*)__this);
		return L_1;
	}
}
// System.Void Tester::Show()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tester_Show_m5C9B329A7906F6BC93BEB481C2B0CE8AEF697705 (Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral121E3C04443BF8E117A53A4EA6445D0FAE0FDDF7);
		s_Il2CppMethodInitialized = true;
	}
	{
		// _dungeon.DestroyDungeon();
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_0 = __this->____dungeon_4;
		NullCheck(L_0);
		Dungeon_DestroyDungeon_m11ADC224AEEA4D854500F6D4A7564C2A906EA22F(L_0, NULL);
		// _designer.StopCoroutine("DecorateDungeon");
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_1 = __this->____designer_5;
		NullCheck(L_1);
		MonoBehaviour_StopCoroutine_m1DA0B9343DCDB53221A6CD707CBF0827A6FFF17F(L_1, _stringLiteral121E3C04443BF8E117A53A4EA6445D0FAE0FDDF7, NULL);
		// _dungeon.GenerateDungeon();
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_2 = __this->____dungeon_4;
		NullCheck(L_2);
		Dungeon_GenerateDungeon_m09621F7697AC301ECD310E1320E847D7EDFFB10D(L_2, NULL);
		// _designer.StartCoroutine("DecorateDungeon");
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_3 = __this->____designer_5;
		NullCheck(L_3);
		Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* L_4;
		L_4 = MonoBehaviour_StartCoroutine_m10C4B693B96175C42B0FD00911E072701C220DB4(L_3, _stringLiteral121E3C04443BF8E117A53A4EA6445D0FAE0FDDF7, NULL);
		// }
		return;
	}
}
// System.Void Tester::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tester__ctor_mB83E1CEF76CEF9C95ADD9D1867EA55A7A9C8DDBB (Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* __this, const RuntimeMethod* method) 
{
	{
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Tester/<loop>d__3::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CloopU3Ed__3__ctor_m0EB9D6D302D7F4E0EA0D8E38B1E447F471228941 (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, int32_t ___0_U3CU3E1__state, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		int32_t L_0 = ___0_U3CU3E1__state;
		__this->___U3CU3E1__state_0 = L_0;
		return;
	}
}
// System.Void Tester/<loop>d__3::System.IDisposable.Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CloopU3Ed__3_System_IDisposable_Dispose_mB0C975BA31BBFB438C3091F78BD2E68FFE103B98 (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, const RuntimeMethod* method) 
{
	{
		return;
	}
}
// System.Boolean Tester/<loop>d__3::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CloopU3Ed__3_MoveNext_m5BE2C670FB6FA809917DFE26C7954AA1A977131E (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* V_1 = NULL;
	{
		int32_t L_0 = __this->___U3CU3E1__state_0;
		V_0 = L_0;
		Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* L_1 = __this->___U3CU3E4__this_2;
		V_1 = L_1;
		int32_t L_2 = V_0;
		if (!L_2)
		{
			goto IL_0017;
		}
	}
	{
		int32_t L_3 = V_0;
		if ((((int32_t)L_3) == ((int32_t)1)))
		{
			goto IL_003d;
		}
	}
	{
		return (bool)0;
	}

IL_0017:
	{
		__this->___U3CU3E1__state_0 = (-1);
	}

IL_001e:
	{
		// Show();
		Tester_tE5917E172DC65F9C4A95C227849DF5B60772C7AD* L_4 = V_1;
		NullCheck(L_4);
		Tester_Show_m5C9B329A7906F6BC93BEB481C2B0CE8AEF697705(L_4, NULL);
		// yield return new WaitForSeconds(2.5f);
		WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3* L_5 = (WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3*)il2cpp_codegen_object_new(WaitForSeconds_tF179DF251655B8DF044952E70A60DF4B358A3DD3_il2cpp_TypeInfo_var);
		NullCheck(L_5);
		WaitForSeconds__ctor_m579F95BADEDBAB4B3A7E302C6EE3995926EF2EFC(L_5, (2.5f), NULL);
		__this->___U3CU3E2__current_1 = L_5;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CU3E2__current_1), (void*)L_5);
		__this->___U3CU3E1__state_0 = 1;
		return (bool)1;
	}

IL_003d:
	{
		__this->___U3CU3E1__state_0 = (-1);
		// while (true)
		goto IL_001e;
	}
}
// System.Object Tester/<loop>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CloopU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m178C36F2562192D59739078AA03BBE78255D3BA9 (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->___U3CU3E2__current_1;
		return L_0;
	}
}
// System.Void Tester/<loop>d__3::System.Collections.IEnumerator.Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CloopU3Ed__3_System_Collections_IEnumerator_Reset_mDFBAFEB791DDF7FE317D9CAA3304254E9AA97A22 (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, const RuntimeMethod* method) 
{
	{
		NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A* L_0 = (NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A_il2cpp_TypeInfo_var)));
		NullCheck(L_0);
		NotSupportedException__ctor_m1398D0CDE19B36AA3DE9392879738C1EA2439CDF(L_0, NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CloopU3Ed__3_System_Collections_IEnumerator_Reset_mDFBAFEB791DDF7FE317D9CAA3304254E9AA97A22_RuntimeMethod_var)));
	}
}
// System.Object Tester/<loop>d__3::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CloopU3Ed__3_System_Collections_IEnumerator_get_Current_mBC9F1FE87350D677977D4968BB9B5183B4DFD414 (U3CloopU3Ed__3_tF8FB4494975572CB29F4BA29BEEC09938826642F* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->___U3CU3E2__current_1;
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void PixelCollider.PixelCollider2D::Regenerate()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7 (PixelCollider2D_t6FCBAB552C8143AF518039867DC52AFD086F70FD* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_m838C3ADF8730E17B91A80DDD18BB0830E513D114_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mF7BAD78CA9941DF0CD8F1E94ACD1FFC6BEC5318F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* V_0 = NULL;
	SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* V_1 = NULL;
	List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* V_2 = NULL;
	List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* V_3 = NULL;
	int32_t V_4 = 0;
	{
		// alphaCutoff = Mathf.Clamp(alphaCutoff, 0, 1);
		float L_0 = __this->___alphaCutoff_4;
		float L_1;
		L_1 = Mathf_Clamp_mEB9AEA827D27D20FCC787F7375156AF46BB12BBF_inline(L_0, (0.0f), (1.0f), NULL);
		__this->___alphaCutoff_4 = L_1;
		// PolygonCollider2D PGC2D = GetComponent<PolygonCollider2D>();
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_2;
		L_2 = Component_GetComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_m838C3ADF8730E17B91A80DDD18BB0830E513D114(__this, Component_GetComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_m838C3ADF8730E17B91A80DDD18BB0830E513D114_RuntimeMethod_var);
		V_0 = L_2;
		// if (PGC2D == null)
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_3 = V_0;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_4;
		L_4 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_3, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_4)
		{
			goto IL_004b;
		}
	}
	{
		// throw new Exception($"PixelCollider2D could not be regenerated because there is no PolygonCollider2D component on \"{gameObject.name}\".");
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_5;
		L_5 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_5);
		String_t* L_6;
		L_6 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_5, NULL);
		String_t* L_7;
		L_7 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral0F99B65F19EEA35112094186BA90C30A05AC1FC2)), L_6, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral606C771900936C652E7DC0D284530387D5ED57D1)), NULL);
		Exception_t* L_8 = (Exception_t*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)));
		NullCheck(L_8);
		Exception__ctor_m9B2BD92CD68916245A75109105D9071C9D430E7F(L_8, L_7, NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_8, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7_RuntimeMethod_var)));
	}

IL_004b:
	{
		// SpriteRenderer SR = GetComponent<SpriteRenderer>();
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_9;
		L_9 = Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45(__this, Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var);
		V_1 = L_9;
		// if (SR == null)
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_10 = V_1;
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_11;
		L_11 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_10, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_11)
		{
			goto IL_0082;
		}
	}
	{
		// PGC2D.pathCount = 0;
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_12 = V_0;
		NullCheck(L_12);
		PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721(L_12, 0, NULL);
		// throw new Exception($"PixelCollider2D could not be regenerated because there is no SpriteRenderer component on \"{gameObject.name}\".");
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_13;
		L_13 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_13);
		String_t* L_14;
		L_14 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_13, NULL);
		String_t* L_15;
		L_15 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral3AB15C9B4C9186E65E2AB6C27CD2FEEC419DE91E)), L_14, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral606C771900936C652E7DC0D284530387D5ED57D1)), NULL);
		Exception_t* L_16 = (Exception_t*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)));
		NullCheck(L_16);
		Exception__ctor_m9B2BD92CD68916245A75109105D9071C9D430E7F(L_16, L_15, NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_16, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7_RuntimeMethod_var)));
	}

IL_0082:
	{
		// if (SR.sprite == null)
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_17 = V_1;
		NullCheck(L_17);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_18;
		L_18 = SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44(L_17, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_19;
		L_19 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_18, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_19)
		{
			goto IL_0098;
		}
	}
	{
		// PGC2D.pathCount = 0;
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_20 = V_0;
		NullCheck(L_20);
		PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721(L_20, 0, NULL);
		// return;
		return;
	}

IL_0098:
	{
		// if (SR.sprite.texture == null)
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_21 = V_1;
		NullCheck(L_21);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_22;
		L_22 = SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44(L_21, NULL);
		NullCheck(L_22);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_23;
		L_23 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_22, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		bool L_24;
		L_24 = Object_op_Equality_mB6120F782D83091EF56A198FCEBCF066DB4A9605(L_23, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_24)
		{
			goto IL_00b3;
		}
	}
	{
		// PGC2D.pathCount = 0;
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_25 = V_0;
		NullCheck(L_25);
		PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721(L_25, 0, NULL);
		// return;
		return;
	}

IL_00b3:
	{
		// if (SR.sprite.texture.isReadable == false)
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_26 = V_1;
		NullCheck(L_26);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_27;
		L_27 = SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44(L_26, NULL);
		NullCheck(L_27);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_28;
		L_28 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_27, NULL);
		NullCheck(L_28);
		bool L_29;
		L_29 = VirtualFuncInvoker0< bool >::Invoke(8 /* System.Boolean UnityEngine.Texture::get_isReadable() */, L_28);
		if (L_29)
		{
			goto IL_00ec;
		}
	}
	{
		// PGC2D.pathCount = 0;
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_30 = V_0;
		NullCheck(L_30);
		PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721(L_30, 0, NULL);
		// throw new Exception($"PixelCollider2D could not be regenerated because on \"{gameObject.name}\" because the sprite does not allow read/write operations.");
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_31;
		L_31 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_31);
		String_t* L_32;
		L_32 = Object_get_name_mAC2F6B897CF1303BA4249B4CB55271AFACBB6392(L_31, NULL);
		String_t* L_33;
		L_33 = String_Concat_m8855A6DE10F84DA7F4EC113CADDB59873A25573B(((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral3C1FF3ADF4004F789CDD5BD75BAE7EF3FF1177D4)), L_32, ((String_t*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&_stringLiteral097BF2A88755542E570BFE1840C914F01A1EA152)), NULL);
		Exception_t* L_34 = (Exception_t*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)));
		NullCheck(L_34);
		Exception__ctor_m9B2BD92CD68916245A75109105D9071C9D430E7F(L_34, L_33, NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_34, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7_RuntimeMethod_var)));
	}

IL_00ec:
	{
		// List<List<Vector2Int>> Pixel_Paths = new List<List<Vector2Int>>();
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_35 = (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*)il2cpp_codegen_object_new(List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var);
		NullCheck(L_35);
		List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17(L_35, List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var);
		V_2 = L_35;
		// Pixel_Paths = Get_Unit_Paths(SR.sprite.texture, alphaCutoff);
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_36 = V_1;
		NullCheck(L_36);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_37;
		L_37 = SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44(L_36, NULL);
		NullCheck(L_37);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_38;
		L_38 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_37, NULL);
		float L_39 = __this->___alphaCutoff_4;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_40;
		L_40 = PixelCollider2D_Get_Unit_Paths_m6F6B4B95F9074198C788267EFF5D6405AB6A8EB4(L_38, L_39, NULL);
		V_2 = L_40;
		// Pixel_Paths = Simplify_Paths_Phase_1(Pixel_Paths);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_41 = V_2;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_42;
		L_42 = PixelCollider2D_Simplify_Paths_Phase_1_m3054733C750DC0318B29B2941CBE87C5AD6226C1(L_41, NULL);
		V_2 = L_42;
		// Pixel_Paths = Simplify_Paths_Phase_2(Pixel_Paths);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_43 = V_2;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_44;
		L_44 = PixelCollider2D_Simplify_Paths_Phase_2_mDDF788D66579E9EBF363A083056902AC6DE3874A(L_43, NULL);
		V_2 = L_44;
		// List<List<Vector2>> World_Paths = new List<List<Vector2>>();
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_45 = (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE*)il2cpp_codegen_object_new(List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE_il2cpp_TypeInfo_var);
		NullCheck(L_45);
		List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46(L_45, List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46_RuntimeMethod_var);
		V_3 = L_45;
		// World_Paths = Finalize_Paths(Pixel_Paths, SR.sprite);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_46 = V_2;
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_47 = V_1;
		NullCheck(L_47);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_48;
		L_48 = SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44(L_47, NULL);
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_49;
		L_49 = PixelCollider2D_Finalize_Paths_m88E0EA0CFBDE2DADE57268C1116A9E1E91D47ECF(__this, L_46, L_48, NULL);
		V_3 = L_49;
		// PGC2D.pathCount = World_Paths.Count;
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_50 = V_0;
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_51 = V_3;
		NullCheck(L_51);
		int32_t L_52;
		L_52 = List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_inline(L_51, List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_RuntimeMethod_var);
		NullCheck(L_50);
		PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721(L_50, L_52, NULL);
		// for (int p = 0; p < World_Paths.Count; p++)
		V_4 = 0;
		goto IL_0157;
	}

IL_013c:
	{
		// PGC2D.SetPath(p, World_Paths[p].ToArray());
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_53 = V_0;
		int32_t L_54 = V_4;
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_55 = V_3;
		int32_t L_56 = V_4;
		NullCheck(L_55);
		List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* L_57;
		L_57 = List_1_get_Item_mF7BAD78CA9941DF0CD8F1E94ACD1FFC6BEC5318F(L_55, L_56, List_1_get_Item_mF7BAD78CA9941DF0CD8F1E94ACD1FFC6BEC5318F_RuntimeMethod_var);
		NullCheck(L_57);
		Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* L_58;
		L_58 = List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5(L_57, List_1_ToArray_m9F2A058632994B7A2310424880C089F9DE5B1BA5_RuntimeMethod_var);
		NullCheck(L_53);
		PolygonCollider2D_SetPath_mDF03B6FDAE81E25C985F9BA6D372D949A6D9A1C1(L_53, L_54, L_58, NULL);
		// for (int p = 0; p < World_Paths.Count; p++)
		int32_t L_59 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_59, 1));
	}

IL_0157:
	{
		// for (int p = 0; p < World_Paths.Count; p++)
		int32_t L_60 = V_4;
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_61 = V_3;
		NullCheck(L_61);
		int32_t L_62;
		L_62 = List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_inline(L_61, List_1_get_Count_mF7C681037936C3D11FCF76CCF6D5D3ABD2B49FF0_RuntimeMethod_var);
		if ((((int32_t)L_60) < ((int32_t)L_62)))
		{
			goto IL_013c;
		}
	}
	{
		// }
		return;
	}
}
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>> PixelCollider.PixelCollider2D::Finalize_Paths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>,UnityEngine.Sprite)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* PixelCollider2D_Finalize_Paths_m88E0EA0CFBDE2DADE57268C1116A9E1E91D47ECF (PixelCollider2D_t6FCBAB552C8143AF518039867DC52AFD086F70FD* __this, List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* ___0_Pixel_Paths, Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* ___1_sprite, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_m1902F684694327EBD4B760E536C852CA86EF93BA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* V_1 = NULL;
	Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* V_4 = NULL;
	int32_t V_5 = 0;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_6;
	memset((&V_6), 0, sizeof(V_6));
	{
		// Vector2 pivot = sprite.pivot;
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_0 = ___1_sprite;
		NullCheck(L_0);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1;
		L_1 = Sprite_get_pivot_mDFC0A205317DB2F3B6C720B8A5BE1C27D01C1D44(L_0, NULL);
		V_0 = L_1;
		// pivot.x *= Mathf.Abs(sprite.bounds.max.x - sprite.bounds.min.x);
		float* L_2 = (float*)(&(&V_0)->___x_0);
		float* L_3 = L_2;
		float L_4 = *((float*)L_3);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_5 = ___1_sprite;
		NullCheck(L_5);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_6;
		L_6 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_5, NULL);
		V_2 = L_6;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_7;
		L_7 = Bounds_get_max_m6446F2AB97C1E57CA89467B9DE52D4EB61F1CB09((&V_2), NULL);
		float L_8 = L_7.___x_2;
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_9 = ___1_sprite;
		NullCheck(L_9);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_10;
		L_10 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_9, NULL);
		V_2 = L_10;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_11;
		L_11 = Bounds_get_min_m465AC9BBE1DE5D8E8AD95AC19B9899068FEEBB13((&V_2), NULL);
		float L_12 = L_11.___x_2;
		float L_13;
		L_13 = fabsf(((float)il2cpp_codegen_subtract(L_8, L_12)));
		*((float*)L_3) = (float)((float)il2cpp_codegen_multiply(L_4, L_13));
		// pivot.x /= sprite.texture.width;
		float* L_14 = (float*)(&(&V_0)->___x_0);
		float* L_15 = L_14;
		float L_16 = *((float*)L_15);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_17 = ___1_sprite;
		NullCheck(L_17);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_18;
		L_18 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_17, NULL);
		NullCheck(L_18);
		int32_t L_19;
		L_19 = VirtualFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_18);
		*((float*)L_15) = (float)((float)(L_16/((float)L_19)));
		// pivot.y *= Mathf.Abs(sprite.bounds.max.y - sprite.bounds.min.y);
		float* L_20 = (float*)(&(&V_0)->___y_1);
		float* L_21 = L_20;
		float L_22 = *((float*)L_21);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_23 = ___1_sprite;
		NullCheck(L_23);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_24;
		L_24 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_23, NULL);
		V_2 = L_24;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_25;
		L_25 = Bounds_get_max_m6446F2AB97C1E57CA89467B9DE52D4EB61F1CB09((&V_2), NULL);
		float L_26 = L_25.___y_3;
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_27 = ___1_sprite;
		NullCheck(L_27);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_28;
		L_28 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_27, NULL);
		V_2 = L_28;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_29;
		L_29 = Bounds_get_min_m465AC9BBE1DE5D8E8AD95AC19B9899068FEEBB13((&V_2), NULL);
		float L_30 = L_29.___y_3;
		float L_31;
		L_31 = fabsf(((float)il2cpp_codegen_subtract(L_26, L_30)));
		*((float*)L_21) = (float)((float)il2cpp_codegen_multiply(L_22, L_31));
		// pivot.y /= sprite.texture.height;
		float* L_32 = (float*)(&(&V_0)->___y_1);
		float* L_33 = L_32;
		float L_34 = *((float*)L_33);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_35 = ___1_sprite;
		NullCheck(L_35);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_36;
		L_36 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_35, NULL);
		NullCheck(L_36);
		int32_t L_37;
		L_37 = VirtualFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_36);
		*((float*)L_33) = (float)((float)(L_34/((float)L_37)));
		// List<List<Vector2>> Output = new List<List<Vector2>>();
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_38 = (List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE*)il2cpp_codegen_object_new(List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE_il2cpp_TypeInfo_var);
		NullCheck(L_38);
		List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46(L_38, List_1__ctor_m0D0309D3E6AD2BAC56B4E173DC817446E16FBF46_RuntimeMethod_var);
		V_1 = L_38;
		// for (int p = 0; p < Pixel_Paths.Count; p++)
		V_3 = 0;
		goto IL_01a8;
	}

IL_00b0:
	{
		// List<Vector2> Current_List = new List<Vector2>();
		List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* L_39 = (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B*)il2cpp_codegen_object_new(List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B_il2cpp_TypeInfo_var);
		NullCheck(L_39);
		List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F(L_39, List_1__ctor_m88C4BD8AC607DB3585552068F4DC437406358D5F_RuntimeMethod_var);
		V_4 = L_39;
		// for (int o = 0; o < Pixel_Paths[p].Count; o++)
		V_5 = 0;
		goto IL_0189;
	}

IL_00bf:
	{
		// Vector2 point = Pixel_Paths[p][o];
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_40 = ___0_Pixel_Paths;
		int32_t L_41 = V_3;
		NullCheck(L_40);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_42;
		L_42 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_40, L_41, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		int32_t L_43 = V_5;
		NullCheck(L_42);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_44;
		L_44 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_42, L_43, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_45;
		L_45 = Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline(L_44, NULL);
		V_6 = L_45;
		// point.x *= Mathf.Abs(sprite.bounds.max.x - sprite.bounds.min.x);
		float* L_46 = (float*)(&(&V_6)->___x_0);
		float* L_47 = L_46;
		float L_48 = *((float*)L_47);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_49 = ___1_sprite;
		NullCheck(L_49);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_50;
		L_50 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_49, NULL);
		V_2 = L_50;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_51;
		L_51 = Bounds_get_max_m6446F2AB97C1E57CA89467B9DE52D4EB61F1CB09((&V_2), NULL);
		float L_52 = L_51.___x_2;
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_53 = ___1_sprite;
		NullCheck(L_53);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_54;
		L_54 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_53, NULL);
		V_2 = L_54;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_55;
		L_55 = Bounds_get_min_m465AC9BBE1DE5D8E8AD95AC19B9899068FEEBB13((&V_2), NULL);
		float L_56 = L_55.___x_2;
		float L_57;
		L_57 = fabsf(((float)il2cpp_codegen_subtract(L_52, L_56)));
		*((float*)L_47) = (float)((float)il2cpp_codegen_multiply(L_48, L_57));
		// point.x /= sprite.texture.width;
		float* L_58 = (float*)(&(&V_6)->___x_0);
		float* L_59 = L_58;
		float L_60 = *((float*)L_59);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_61 = ___1_sprite;
		NullCheck(L_61);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_62;
		L_62 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_61, NULL);
		NullCheck(L_62);
		int32_t L_63;
		L_63 = VirtualFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_62);
		*((float*)L_59) = (float)((float)(L_60/((float)L_63)));
		// point.y *= Mathf.Abs(sprite.bounds.max.y - sprite.bounds.min.y);
		float* L_64 = (float*)(&(&V_6)->___y_1);
		float* L_65 = L_64;
		float L_66 = *((float*)L_65);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_67 = ___1_sprite;
		NullCheck(L_67);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_68;
		L_68 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_67, NULL);
		V_2 = L_68;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_69;
		L_69 = Bounds_get_max_m6446F2AB97C1E57CA89467B9DE52D4EB61F1CB09((&V_2), NULL);
		float L_70 = L_69.___y_3;
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_71 = ___1_sprite;
		NullCheck(L_71);
		Bounds_t367E830C64BBF235ED8C3B2F8CF6254FDCAD39C3 L_72;
		L_72 = Sprite_get_bounds_m042F847F6C5118E6B14A3F79A1E1C53E7DFBF452(L_71, NULL);
		V_2 = L_72;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_73;
		L_73 = Bounds_get_min_m465AC9BBE1DE5D8E8AD95AC19B9899068FEEBB13((&V_2), NULL);
		float L_74 = L_73.___y_3;
		float L_75;
		L_75 = fabsf(((float)il2cpp_codegen_subtract(L_70, L_74)));
		*((float*)L_65) = (float)((float)il2cpp_codegen_multiply(L_66, L_75));
		// point.y /= sprite.texture.height;
		float* L_76 = (float*)(&(&V_6)->___y_1);
		float* L_77 = L_76;
		float L_78 = *((float*)L_77);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_79 = ___1_sprite;
		NullCheck(L_79);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_80;
		L_80 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_79, NULL);
		NullCheck(L_80);
		int32_t L_81;
		L_81 = VirtualFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_80);
		*((float*)L_77) = (float)((float)(L_78/((float)L_81)));
		// point -= pivot;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_82 = V_6;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_83 = V_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_84;
		L_84 = Vector2_op_Subtraction_m44475FCDAD2DA2F98D78A6625EC2DCDFE8803837_inline(L_82, L_83, NULL);
		V_6 = L_84;
		// Current_List.Add(point);
		List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* L_85 = V_4;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_86 = V_6;
		NullCheck(L_85);
		List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_inline(L_85, L_86, List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_RuntimeMethod_var);
		// for (int o = 0; o < Pixel_Paths[p].Count; o++)
		int32_t L_87 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_87, 1));
	}

IL_0189:
	{
		// for (int o = 0; o < Pixel_Paths[p].Count; o++)
		int32_t L_88 = V_5;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_89 = ___0_Pixel_Paths;
		int32_t L_90 = V_3;
		NullCheck(L_89);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_91;
		L_91 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_89, L_90, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_91);
		int32_t L_92;
		L_92 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_91, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		if ((((int32_t)L_88) < ((int32_t)L_92)))
		{
			goto IL_00bf;
		}
	}
	{
		// Output.Add(Current_List);
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_93 = V_1;
		List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* L_94 = V_4;
		NullCheck(L_93);
		List_1_Add_m1902F684694327EBD4B760E536C852CA86EF93BA_inline(L_93, L_94, List_1_Add_m1902F684694327EBD4B760E536C852CA86EF93BA_RuntimeMethod_var);
		// for (int p = 0; p < Pixel_Paths.Count; p++)
		int32_t L_95 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_95, 1));
	}

IL_01a8:
	{
		// for (int p = 0; p < Pixel_Paths.Count; p++)
		int32_t L_96 = V_3;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_97 = ___0_Pixel_Paths;
		NullCheck(L_97);
		int32_t L_98;
		L_98 = List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_inline(L_97, List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		if ((((int32_t)L_96) < ((int32_t)L_98)))
		{
			goto IL_00b0;
		}
	}
	{
		// return Output;
		List_1_t516F8BADEAB460ED0D6E288AB2CA877B5C32A3FE* L_99 = V_1;
		return L_99;
	}
}
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Simplify_Paths_Phase_1(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* PixelCollider2D_Simplify_Paths_Phase_1_m3054733C750DC0318B29B2941CBE87C5AD6226C1 (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* ___0_Unit_Paths, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* V_0 = NULL;
	List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* V_1 = NULL;
	bool V_2 = false;
	int32_t V_3 = 0;
	List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* V_4 = NULL;
	{
		// List<List<Vector2Int>> Output = new List<List<Vector2Int>>();
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_0 = (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*)il2cpp_codegen_object_new(List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17(L_0, List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var);
		V_0 = L_0;
		goto IL_017c;
	}

IL_000b:
	{
		// List<Vector2Int> Current_Path = new List<Vector2Int>(Unit_Paths[0]);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_1 = ___0_Unit_Paths;
		NullCheck(L_1);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_2;
		L_2 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_1, 0, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_3 = (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*)il2cpp_codegen_object_new(List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		NullCheck(L_3);
		List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B(L_3, L_2, List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B_RuntimeMethod_var);
		V_1 = L_3;
		// Unit_Paths.RemoveAt(0);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_4 = ___0_Unit_Paths;
		NullCheck(L_4);
		List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823(L_4, 0, List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var);
		// bool Keep_Looping = true;
		V_2 = (bool)1;
		goto IL_016f;
	}

IL_0026:
	{
		// Keep_Looping = false;
		V_2 = (bool)0;
		// for (int p = 0; p < Unit_Paths.Count; p++)
		V_3 = 0;
		goto IL_0163;
	}

IL_002f:
	{
		// if (Current_Path[Current_Path.Count - 1] == Unit_Paths[p][0])
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_5 = V_1;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_6 = V_1;
		NullCheck(L_6);
		int32_t L_7;
		L_7 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_6, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_5);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_8;
		L_8 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_5, ((int32_t)il2cpp_codegen_subtract(L_7, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_9 = ___0_Unit_Paths;
		int32_t L_10 = V_3;
		NullCheck(L_9);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_11;
		L_11 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_9, L_10, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_11);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_12;
		L_12 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_11, 0, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		bool L_13;
		L_13 = Vector2Int_op_Equality_mD80F6ED22EA1200C4F408440D02FE61388C7D6BA_inline(L_8, L_12, NULL);
		if (!L_13)
		{
			goto IL_007e;
		}
	}
	{
		// Keep_Looping = true;
		V_2 = (bool)1;
		// Current_Path.RemoveAt(Current_Path.Count - 1);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_14 = V_1;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_15 = V_1;
		NullCheck(L_15);
		int32_t L_16;
		L_16 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_15, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_14);
		List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0(L_14, ((int32_t)il2cpp_codegen_subtract(L_16, 1)), List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		// Current_Path.AddRange(Unit_Paths[p]);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_17 = V_1;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_18 = ___0_Unit_Paths;
		int32_t L_19 = V_3;
		NullCheck(L_18);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_20;
		L_20 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_18, L_19, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_17);
		List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671(L_17, L_20, List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671_RuntimeMethod_var);
		// Unit_Paths.RemoveAt(p);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_21 = ___0_Unit_Paths;
		int32_t L_22 = V_3;
		NullCheck(L_21);
		List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823(L_21, L_22, List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var);
		// p--;
		int32_t L_23 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_subtract(L_23, 1));
		goto IL_015f;
	}

IL_007e:
	{
		// else if (Current_Path[0] == Unit_Paths[p][Unit_Paths[p].Count - 1])
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_24 = V_1;
		NullCheck(L_24);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_25;
		L_25 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_24, 0, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_26 = ___0_Unit_Paths;
		int32_t L_27 = V_3;
		NullCheck(L_26);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_28;
		L_28 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_26, L_27, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_29 = ___0_Unit_Paths;
		int32_t L_30 = V_3;
		NullCheck(L_29);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_31;
		L_31 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_29, L_30, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_31);
		int32_t L_32;
		L_32 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_31, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_28);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_33;
		L_33 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_28, ((int32_t)il2cpp_codegen_subtract(L_32, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		bool L_34;
		L_34 = Vector2Int_op_Equality_mD80F6ED22EA1200C4F408440D02FE61388C7D6BA_inline(L_25, L_33, NULL);
		if (!L_34)
		{
			goto IL_00cd;
		}
	}
	{
		// Keep_Looping = true;
		V_2 = (bool)1;
		// Current_Path.RemoveAt(0);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_35 = V_1;
		NullCheck(L_35);
		List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0(L_35, 0, List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		// Current_Path.InsertRange(0, Unit_Paths[p]);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_36 = V_1;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_37 = ___0_Unit_Paths;
		int32_t L_38 = V_3;
		NullCheck(L_37);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_39;
		L_39 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_37, L_38, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_36);
		List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C(L_36, 0, L_39, List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C_RuntimeMethod_var);
		// Unit_Paths.RemoveAt(p);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_40 = ___0_Unit_Paths;
		int32_t L_41 = V_3;
		NullCheck(L_40);
		List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823(L_40, L_41, List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var);
		// p--;
		int32_t L_42 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_subtract(L_42, 1));
		goto IL_015f;
	}

IL_00cd:
	{
		// List<Vector2Int> Flipped_Path = new List<Vector2Int>(Unit_Paths[p]);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_43 = ___0_Unit_Paths;
		int32_t L_44 = V_3;
		NullCheck(L_43);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_45;
		L_45 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_43, L_44, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_46 = (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*)il2cpp_codegen_object_new(List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		NullCheck(L_46);
		List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B(L_46, L_45, List_1__ctor_m4B0BCC3798E3518F875AF4670048DD9F329FE73B_RuntimeMethod_var);
		V_4 = L_46;
		// Flipped_Path.Reverse();
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_47 = V_4;
		NullCheck(L_47);
		List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91(L_47, List_1_Reverse_m5E6E0CF7AE55EE02F932E1B5C5AF204439331C91_RuntimeMethod_var);
		// if (Current_Path[Current_Path.Count - 1] == Flipped_Path[0])
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_48 = V_1;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_49 = V_1;
		NullCheck(L_49);
		int32_t L_50;
		L_50 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_49, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_48);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_51;
		L_51 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_48, ((int32_t)il2cpp_codegen_subtract(L_50, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_52 = V_4;
		NullCheck(L_52);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_53;
		L_53 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_52, 0, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		bool L_54;
		L_54 = Vector2Int_op_Equality_mD80F6ED22EA1200C4F408440D02FE61388C7D6BA_inline(L_51, L_53, NULL);
		if (!L_54)
		{
			goto IL_0124;
		}
	}
	{
		// Keep_Looping = true;
		V_2 = (bool)1;
		// Current_Path.RemoveAt(Current_Path.Count - 1);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_55 = V_1;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_56 = V_1;
		NullCheck(L_56);
		int32_t L_57;
		L_57 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_56, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_55);
		List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0(L_55, ((int32_t)il2cpp_codegen_subtract(L_57, 1)), List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		// Current_Path.AddRange(Flipped_Path);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_58 = V_1;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_59 = V_4;
		NullCheck(L_58);
		List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671(L_58, L_59, List_1_AddRange_m9F59DA3F5D1DBFE4DBA4E39B4DE14730F4F71671_RuntimeMethod_var);
		// Unit_Paths.RemoveAt(p);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_60 = ___0_Unit_Paths;
		int32_t L_61 = V_3;
		NullCheck(L_60);
		List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823(L_60, L_61, List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var);
		// p--;
		int32_t L_62 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_subtract(L_62, 1));
		goto IL_015f;
	}

IL_0124:
	{
		// else if (Current_Path[0] == Flipped_Path[Flipped_Path.Count - 1])
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_63 = V_1;
		NullCheck(L_63);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_64;
		L_64 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_63, 0, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_65 = V_4;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_66 = V_4;
		NullCheck(L_66);
		int32_t L_67;
		L_67 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_66, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_65);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_68;
		L_68 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_65, ((int32_t)il2cpp_codegen_subtract(L_67, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		bool L_69;
		L_69 = Vector2Int_op_Equality_mD80F6ED22EA1200C4F408440D02FE61388C7D6BA_inline(L_64, L_68, NULL);
		if (!L_69)
		{
			goto IL_015f;
		}
	}
	{
		// Keep_Looping = true;
		V_2 = (bool)1;
		// Current_Path.RemoveAt(0);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_70 = V_1;
		NullCheck(L_70);
		List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0(L_70, 0, List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		// Current_Path.InsertRange(0, Flipped_Path);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_71 = V_1;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_72 = V_4;
		NullCheck(L_71);
		List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C(L_71, 0, L_72, List_1_InsertRange_m5360D5D5F6051B27319818CF854B9EEDC0E4AB4C_RuntimeMethod_var);
		// Unit_Paths.RemoveAt(p);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_73 = ___0_Unit_Paths;
		int32_t L_74 = V_3;
		NullCheck(L_73);
		List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823(L_73, L_74, List_1_RemoveAt_m220249013A1F5E2B66A2C0A6F8F15747E5BDE823_RuntimeMethod_var);
		// p--;
		int32_t L_75 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_subtract(L_75, 1));
	}

IL_015f:
	{
		// for (int p = 0; p < Unit_Paths.Count; p++)
		int32_t L_76 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_76, 1));
	}

IL_0163:
	{
		// for (int p = 0; p < Unit_Paths.Count; p++)
		int32_t L_77 = V_3;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_78 = ___0_Unit_Paths;
		NullCheck(L_78);
		int32_t L_79;
		L_79 = List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_inline(L_78, List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		if ((((int32_t)L_77) < ((int32_t)L_79)))
		{
			goto IL_002f;
		}
	}

IL_016f:
	{
		// while (Keep_Looping)
		bool L_80 = V_2;
		if (L_80)
		{
			goto IL_0026;
		}
	}
	{
		// Output.Add(Current_Path);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_81 = V_0;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_82 = V_1;
		NullCheck(L_81);
		List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_inline(L_81, L_82, List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
	}

IL_017c:
	{
		// while (Unit_Paths.Count > 0)
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_83 = ___0_Unit_Paths;
		NullCheck(L_83);
		int32_t L_84;
		L_84 = List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_inline(L_83, List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		if ((((int32_t)L_84) > ((int32_t)0)))
		{
			goto IL_000b;
		}
	}
	{
		// return Output;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_85 = V_0;
		return L_85;
	}
}
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Simplify_Paths_Phase_2(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* PixelCollider2D_Simplify_Paths_Phase_2_mDDF788D66579E9EBF363A083056902AC6DE3874A (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* ___0_Input_Paths, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A V_2;
	memset((&V_2), 0, sizeof(V_2));
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A V_3;
	memset((&V_3), 0, sizeof(V_3));
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_4;
	memset((&V_4), 0, sizeof(V_4));
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_5;
	memset((&V_5), 0, sizeof(V_5));
	{
		// for (int pa = 0; pa < Input_Paths.Count; pa++)
		V_0 = 0;
		goto IL_0107;
	}

IL_0007:
	{
		// for (int po = 0; po < Input_Paths[pa].Count; po++)
		V_1 = 0;
		goto IL_00f1;
	}

IL_000e:
	{
		// Vector2Int Start = new Vector2Int();
		il2cpp_codegen_initobj((&V_2), sizeof(Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A));
		// if (po == 0)
		int32_t L_0 = V_1;
		if (L_0)
		{
			goto IL_0036;
		}
	}
	{
		// Start = Input_Paths[pa][Input_Paths[pa].Count - 1];
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_1 = ___0_Input_Paths;
		int32_t L_2 = V_0;
		NullCheck(L_1);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_3;
		L_3 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_1, L_2, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_4 = ___0_Input_Paths;
		int32_t L_5 = V_0;
		NullCheck(L_4);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_6;
		L_6 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_4, L_5, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_6);
		int32_t L_7;
		L_7 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_6, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		NullCheck(L_3);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_8;
		L_8 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_3, ((int32_t)il2cpp_codegen_subtract(L_7, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		V_2 = L_8;
		goto IL_0046;
	}

IL_0036:
	{
		// Start = Input_Paths[pa][po - 1];
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_9 = ___0_Input_Paths;
		int32_t L_10 = V_0;
		NullCheck(L_9);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_11;
		L_11 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_9, L_10, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		int32_t L_12 = V_1;
		NullCheck(L_11);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_13;
		L_13 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_11, ((int32_t)il2cpp_codegen_subtract(L_12, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		V_2 = L_13;
	}

IL_0046:
	{
		// Vector2Int End = new Vector2Int();
		il2cpp_codegen_initobj((&V_3), sizeof(Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A));
		// if (po == Input_Paths[pa].Count - 1)
		int32_t L_14 = V_1;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_15 = ___0_Input_Paths;
		int32_t L_16 = V_0;
		NullCheck(L_15);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_17;
		L_17 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_15, L_16, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_17);
		int32_t L_18;
		L_18 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_17, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		if ((!(((uint32_t)L_14) == ((uint32_t)((int32_t)il2cpp_codegen_subtract(L_18, 1))))))
		{
			goto IL_006f;
		}
	}
	{
		// End = Input_Paths[pa][0];
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_19 = ___0_Input_Paths;
		int32_t L_20 = V_0;
		NullCheck(L_19);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_21;
		L_21 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_19, L_20, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_21);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_22;
		L_22 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_21, 0, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		V_3 = L_22;
		goto IL_007f;
	}

IL_006f:
	{
		// End = Input_Paths[pa][po + 1];
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_23 = ___0_Input_Paths;
		int32_t L_24 = V_0;
		NullCheck(L_23);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_25;
		L_25 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_23, L_24, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		int32_t L_26 = V_1;
		NullCheck(L_25);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_27;
		L_27 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_25, ((int32_t)il2cpp_codegen_add(L_26, 1)), List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		V_3 = L_27;
	}

IL_007f:
	{
		// Vector2Int Current_Point = Input_Paths[pa][po];
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_28 = ___0_Input_Paths;
		int32_t L_29 = V_0;
		NullCheck(L_28);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_30;
		L_30 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_28, L_29, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		int32_t L_31 = V_1;
		NullCheck(L_30);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_32;
		L_32 = List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A(L_30, L_31, List_1_get_Item_mC90712CBD530245E4BC68D4AB87DDC53EE6C117A_RuntimeMethod_var);
		// Vector2 Direction1 = Current_Point - (Vector2)Start;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_33;
		L_33 = Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline(L_32, NULL);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_34 = V_2;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_35;
		L_35 = Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline(L_34, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_36;
		L_36 = Vector2_op_Subtraction_m44475FCDAD2DA2F98D78A6625EC2DCDFE8803837_inline(L_33, L_35, NULL);
		V_4 = L_36;
		// Direction1 /= Direction1.magnitude;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_37 = V_4;
		float L_38;
		L_38 = Vector2_get_magnitude_m5C59B4056420AEFDB291AD0914A3F675330A75CE_inline((&V_4), NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_39;
		L_39 = Vector2_op_Division_m57A2DCD71E0CE7420851D705D1951F9238902AAB_inline(L_37, L_38, NULL);
		V_4 = L_39;
		// Vector2 Direction2 = End - (Vector2)Start;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_40 = V_3;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_41;
		L_41 = Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline(L_40, NULL);
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_42 = V_2;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_43;
		L_43 = Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline(L_42, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_44;
		L_44 = Vector2_op_Subtraction_m44475FCDAD2DA2F98D78A6625EC2DCDFE8803837_inline(L_41, L_43, NULL);
		V_5 = L_44;
		// Direction2 /= Direction2.magnitude;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_45 = V_5;
		float L_46;
		L_46 = Vector2_get_magnitude_m5C59B4056420AEFDB291AD0914A3F675330A75CE_inline((&V_5), NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_47;
		L_47 = Vector2_op_Division_m57A2DCD71E0CE7420851D705D1951F9238902AAB_inline(L_45, L_46, NULL);
		V_5 = L_47;
		// if (Direction1 == Direction2)
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_48 = V_4;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_49 = V_5;
		bool L_50;
		L_50 = Vector2_op_Equality_m6F2E069A50E787D131261E5CB25FC9E03F95B5E1_inline(L_48, L_49, NULL);
		if (!L_50)
		{
			goto IL_00ed;
		}
	}
	{
		// Input_Paths[pa].RemoveAt(po);
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_51 = ___0_Input_Paths;
		int32_t L_52 = V_0;
		NullCheck(L_51);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_53;
		L_53 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_51, L_52, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		int32_t L_54 = V_1;
		NullCheck(L_53);
		List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0(L_53, L_54, List_1_RemoveAt_m282BDD5EECA05906BAE1C02FE5DDDD895EE05BA0_RuntimeMethod_var);
		// po--;
		int32_t L_55 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_subtract(L_55, 1));
	}

IL_00ed:
	{
		// for (int po = 0; po < Input_Paths[pa].Count; po++)
		int32_t L_56 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_56, 1));
	}

IL_00f1:
	{
		// for (int po = 0; po < Input_Paths[pa].Count; po++)
		int32_t L_57 = V_1;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_58 = ___0_Input_Paths;
		int32_t L_59 = V_0;
		NullCheck(L_58);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_60;
		L_60 = List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D(L_58, L_59, List_1_get_Item_m0F9B422EE000249B4EC3E941AA91664E10EF460D_RuntimeMethod_var);
		NullCheck(L_60);
		int32_t L_61;
		L_61 = List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_inline(L_60, List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_RuntimeMethod_var);
		if ((((int32_t)L_57) < ((int32_t)L_61)))
		{
			goto IL_000e;
		}
	}
	{
		// for (int pa = 0; pa < Input_Paths.Count; pa++)
		int32_t L_62 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_62, 1));
	}

IL_0107:
	{
		// for (int pa = 0; pa < Input_Paths.Count; pa++)
		int32_t L_63 = V_0;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_64 = ___0_Input_Paths;
		NullCheck(L_64);
		int32_t L_65;
		L_65 = List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_inline(L_64, List_1_get_Count_m0C74152A176AEF0F837467C4C83A003CE9746B89_RuntimeMethod_var);
		if ((((int32_t)L_63) < ((int32_t)L_65)))
		{
			goto IL_0007;
		}
	}
	{
		// return Input_Paths;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_66 = ___0_Input_Paths;
		return L_66;
	}
}
// System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Get_Unit_Paths(UnityEngine.Texture2D,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* PixelCollider2D_Get_Unit_Paths_m6F6B4B95F9074198C788267EFF5D6405AB6A8EB4 (Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___0_texture, float ___1_alphaCutoff, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		// List<List<Vector2Int>> Output = new List<List<Vector2Int>>();
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_0 = (List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F*)il2cpp_codegen_object_new(List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17(L_0, List_1__ctor_mF04D0068725DFAEE277FDDB9679C3D02BC685F17_RuntimeMethod_var);
		V_0 = L_0;
		// for (int x = 0; x < texture.width; x++)
		V_1 = 0;
		goto IL_0127;
	}

IL_000d:
	{
		// for (int y = 0; y < texture.height; y++)
		V_2 = 0;
		goto IL_0117;
	}

IL_0014:
	{
		// if (pixelSolid(texture, new Vector2Int(x, y), alphaCutoff))
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_1 = ___0_texture;
		int32_t L_2 = V_1;
		int32_t L_3 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_4;
		memset((&L_4), 0, sizeof(L_4));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_4), L_2, L_3, /*hidden argument*/NULL);
		float L_5 = ___1_alphaCutoff;
		bool L_6;
		L_6 = PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2(L_1, L_4, L_5, NULL);
		if (!L_6)
		{
			goto IL_0113;
		}
	}
	{
		// if (!pixelSolid(texture, new Vector2Int(x, y + 1), alphaCutoff))
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_7 = ___0_texture;
		int32_t L_8 = V_1;
		int32_t L_9 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_10;
		memset((&L_10), 0, sizeof(L_10));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_10), L_8, ((int32_t)il2cpp_codegen_add(L_9, 1)), /*hidden argument*/NULL);
		float L_11 = ___1_alphaCutoff;
		bool L_12;
		L_12 = PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2(L_7, L_10, L_11, NULL);
		if (L_12)
		{
			goto IL_0064;
		}
	}
	{
		// Output.Add(new List<Vector2Int>() { new Vector2Int(x, y + 1), new Vector2Int(x + 1, y + 1) });
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_13 = V_0;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_14 = (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*)il2cpp_codegen_object_new(List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		NullCheck(L_14);
		List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF(L_14, List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_15 = L_14;
		int32_t L_16 = V_1;
		int32_t L_17 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_18;
		memset((&L_18), 0, sizeof(L_18));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_18), L_16, ((int32_t)il2cpp_codegen_add(L_17, 1)), /*hidden argument*/NULL);
		NullCheck(L_15);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_15, L_18, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_19 = L_15;
		int32_t L_20 = V_1;
		int32_t L_21 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_22;
		memset((&L_22), 0, sizeof(L_22));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_22), ((int32_t)il2cpp_codegen_add(L_20, 1)), ((int32_t)il2cpp_codegen_add(L_21, 1)), /*hidden argument*/NULL);
		NullCheck(L_19);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_19, L_22, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		NullCheck(L_13);
		List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_inline(L_13, L_19, List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
	}

IL_0064:
	{
		// if (!pixelSolid(texture, new Vector2Int(x, y - 1), alphaCutoff))
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_23 = ___0_texture;
		int32_t L_24 = V_1;
		int32_t L_25 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_26;
		memset((&L_26), 0, sizeof(L_26));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_26), L_24, ((int32_t)il2cpp_codegen_subtract(L_25, 1)), /*hidden argument*/NULL);
		float L_27 = ___1_alphaCutoff;
		bool L_28;
		L_28 = PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2(L_23, L_26, L_27, NULL);
		if (L_28)
		{
			goto IL_009d;
		}
	}
	{
		// Output.Add(new List<Vector2Int>() { new Vector2Int(x, y), new Vector2Int(x + 1, y) });
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_29 = V_0;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_30 = (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*)il2cpp_codegen_object_new(List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		NullCheck(L_30);
		List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF(L_30, List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_31 = L_30;
		int32_t L_32 = V_1;
		int32_t L_33 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_34;
		memset((&L_34), 0, sizeof(L_34));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_34), L_32, L_33, /*hidden argument*/NULL);
		NullCheck(L_31);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_31, L_34, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_35 = L_31;
		int32_t L_36 = V_1;
		int32_t L_37 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_38;
		memset((&L_38), 0, sizeof(L_38));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_38), ((int32_t)il2cpp_codegen_add(L_36, 1)), L_37, /*hidden argument*/NULL);
		NullCheck(L_35);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_35, L_38, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		NullCheck(L_29);
		List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_inline(L_29, L_35, List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
	}

IL_009d:
	{
		// if (!pixelSolid(texture, new Vector2Int(x + 1, y), alphaCutoff))
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_39 = ___0_texture;
		int32_t L_40 = V_1;
		int32_t L_41 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_42;
		memset((&L_42), 0, sizeof(L_42));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_42), ((int32_t)il2cpp_codegen_add(L_40, 1)), L_41, /*hidden argument*/NULL);
		float L_43 = ___1_alphaCutoff;
		bool L_44;
		L_44 = PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2(L_39, L_42, L_43, NULL);
		if (L_44)
		{
			goto IL_00da;
		}
	}
	{
		// Output.Add(new List<Vector2Int>() { new Vector2Int(x + 1, y), new Vector2Int(x + 1, y + 1) });
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_45 = V_0;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_46 = (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*)il2cpp_codegen_object_new(List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		NullCheck(L_46);
		List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF(L_46, List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_47 = L_46;
		int32_t L_48 = V_1;
		int32_t L_49 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_50;
		memset((&L_50), 0, sizeof(L_50));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_50), ((int32_t)il2cpp_codegen_add(L_48, 1)), L_49, /*hidden argument*/NULL);
		NullCheck(L_47);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_47, L_50, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_51 = L_47;
		int32_t L_52 = V_1;
		int32_t L_53 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_54;
		memset((&L_54), 0, sizeof(L_54));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_54), ((int32_t)il2cpp_codegen_add(L_52, 1)), ((int32_t)il2cpp_codegen_add(L_53, 1)), /*hidden argument*/NULL);
		NullCheck(L_51);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_51, L_54, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		NullCheck(L_45);
		List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_inline(L_45, L_51, List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
	}

IL_00da:
	{
		// if (!pixelSolid(texture, new Vector2Int(x - 1, y), alphaCutoff))
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_55 = ___0_texture;
		int32_t L_56 = V_1;
		int32_t L_57 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_58;
		memset((&L_58), 0, sizeof(L_58));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_58), ((int32_t)il2cpp_codegen_subtract(L_56, 1)), L_57, /*hidden argument*/NULL);
		float L_59 = ___1_alphaCutoff;
		bool L_60;
		L_60 = PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2(L_55, L_58, L_59, NULL);
		if (L_60)
		{
			goto IL_0113;
		}
	}
	{
		// Output.Add(new List<Vector2Int>() { new Vector2Int(x, y), new Vector2Int(x, y + 1) });
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_61 = V_0;
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_62 = (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*)il2cpp_codegen_object_new(List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D_il2cpp_TypeInfo_var);
		NullCheck(L_62);
		List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF(L_62, List_1__ctor_mE1D9FD9DA1EF2CAC4F99EF4E013F05BB8C3507EF_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_63 = L_62;
		int32_t L_64 = V_1;
		int32_t L_65 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_66;
		memset((&L_66), 0, sizeof(L_66));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_66), L_64, L_65, /*hidden argument*/NULL);
		NullCheck(L_63);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_63, L_66, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* L_67 = L_63;
		int32_t L_68 = V_1;
		int32_t L_69 = V_2;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_70;
		memset((&L_70), 0, sizeof(L_70));
		Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline((&L_70), L_68, ((int32_t)il2cpp_codegen_add(L_69, 1)), /*hidden argument*/NULL);
		NullCheck(L_67);
		List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_inline(L_67, L_70, List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_RuntimeMethod_var);
		NullCheck(L_61);
		List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_inline(L_61, L_67, List_1_Add_m2B28ADAAF754C6B4A30F3E9519793F4D25C72FA6_RuntimeMethod_var);
	}

IL_0113:
	{
		// for (int y = 0; y < texture.height; y++)
		int32_t L_71 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_71, 1));
	}

IL_0117:
	{
		// for (int y = 0; y < texture.height; y++)
		int32_t L_72 = V_2;
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_73 = ___0_texture;
		NullCheck(L_73);
		int32_t L_74;
		L_74 = VirtualFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_73);
		if ((((int32_t)L_72) < ((int32_t)L_74)))
		{
			goto IL_0014;
		}
	}
	{
		// for (int x = 0; x < texture.width; x++)
		int32_t L_75 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_75, 1));
	}

IL_0127:
	{
		// for (int x = 0; x < texture.width; x++)
		int32_t L_76 = V_1;
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_77 = ___0_texture;
		NullCheck(L_77);
		int32_t L_78;
		L_78 = VirtualFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_77);
		if ((((int32_t)L_76) < ((int32_t)L_78)))
		{
			goto IL_000d;
		}
	}
	{
		// return Output;
		List_1_tB872EA22ABEC8D5CD08C4DF63240853C60C2F93F* L_79 = V_0;
		return L_79;
	}
}
// System.Boolean PixelCollider.PixelCollider2D::pixelSolid(UnityEngine.Texture2D,UnityEngine.Vector2Int,System.Single)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2 (Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* ___0_texture, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___1_point, float ___2_alphaCutoff, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	{
		// if (point.x < 0 || point.y < 0 || point.x >= texture.width || point.y >= texture.height)
		int32_t L_0;
		L_0 = Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline((&___1_point), NULL);
		if ((((int32_t)L_0) < ((int32_t)0)))
		{
			goto IL_0032;
		}
	}
	{
		int32_t L_1;
		L_1 = Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline((&___1_point), NULL);
		if ((((int32_t)L_1) < ((int32_t)0)))
		{
			goto IL_0032;
		}
	}
	{
		int32_t L_2;
		L_2 = Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline((&___1_point), NULL);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_3 = ___0_texture;
		NullCheck(L_3);
		int32_t L_4;
		L_4 = VirtualFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_3);
		if ((((int32_t)L_2) >= ((int32_t)L_4)))
		{
			goto IL_0032;
		}
	}
	{
		int32_t L_5;
		L_5 = Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline((&___1_point), NULL);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_6 = ___0_texture;
		NullCheck(L_6);
		int32_t L_7;
		L_7 = VirtualFuncInvoker0< int32_t >::Invoke(6 /* System.Int32 UnityEngine.Texture::get_height() */, L_6);
		if ((((int32_t)L_5) < ((int32_t)L_7)))
		{
			goto IL_0034;
		}
	}

IL_0032:
	{
		// return false;
		return (bool)0;
	}

IL_0034:
	{
		// float pixelAlpha = texture.GetPixel(point.x, point.y).a;
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_8 = ___0_texture;
		int32_t L_9;
		L_9 = Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline((&___1_point), NULL);
		int32_t L_10;
		L_10 = Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline((&___1_point), NULL);
		NullCheck(L_8);
		Color_tD001788D726C3A7F1379BEED0260B9591F440C1F L_11;
		L_11 = Texture2D_GetPixel_m69A17FE5CC220F438C7421DCB50A9E22AAB4A415(L_8, L_9, L_10, NULL);
		float L_12 = L_11.___a_3;
		V_0 = L_12;
		// if (alphaCutoff == 0)
		float L_13 = ___2_alphaCutoff;
		if ((!(((float)L_13) == ((float)(0.0f)))))
		{
			goto IL_0062;
		}
	}
	{
		// if (pixelAlpha != 0)
		float L_14 = V_0;
		if ((((float)L_14) == ((float)(0.0f))))
		{
			goto IL_0060;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_0060:
	{
		// return false;
		return (bool)0;
	}

IL_0062:
	{
		// else if (alphaCutoff == 1)
		float L_15 = ___2_alphaCutoff;
		if ((!(((float)L_15) == ((float)(1.0f)))))
		{
			goto IL_0076;
		}
	}
	{
		// if (pixelAlpha == 1)
		float L_16 = V_0;
		if ((!(((float)L_16) == ((float)(1.0f)))))
		{
			goto IL_0074;
		}
	}
	{
		// return true;
		return (bool)1;
	}

IL_0074:
	{
		// return false;
		return (bool)0;
	}

IL_0076:
	{
		// return pixelAlpha >= alphaCutoff;
		float L_17 = V_0;
		float L_18 = ___2_alphaCutoff;
		return (bool)((((int32_t)((!(((float)L_17) >= ((float)L_18)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Void PixelCollider.PixelCollider2D::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PixelCollider2D__ctor_mFE9D9734480050BB89A63B0C1354C03F4299FB10 (PixelCollider2D_t6FCBAB552C8143AF518039867DC52AFD086F70FD* __this, const RuntimeMethod* method) 
{
	{
		// public float alphaCutoff = 0.5f;
		__this->___alphaCutoff_4 = (0.5f);
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.Dungeon::Start()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_Start_m68463C9782D5BAAA0F983EB8A6FFA6EDDA1F1842 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) 
{
	{
		// GenerateDungeon();
		Dungeon_GenerateDungeon_m09621F7697AC301ECD310E1320E847D7EDFFB10D(__this, NULL);
		// }
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::GenerateDungeon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateDungeon_m09621F7697AC301ECD310E1320E847D7EDFFB10D (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	RuntimeObject* V_1 = NULL;
	{
		// GenerateFirst();
		Dungeon_GenerateFirst_m8715C4306C6ABCB9E478E73B12132CC2F7E0DD60(__this, NULL);
		// if (activate_rooms)
		bool L_0 = __this->___activate_rooms_6;
		if (!L_0)
		{
			goto IL_0052;
		}
	}
	{
		// foreach (Transform t in transform)
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_1;
		L_1 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		NullCheck(L_1);
		RuntimeObject* L_2;
		L_2 = Transform_GetEnumerator_mA7E1C882ACA0C33E284711CD09971DEA3FFEF404(L_1, NULL);
		V_0 = L_2;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0041:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_3 = V_0;
					V_1 = ((RuntimeObject*)IsInst((RuntimeObject*)L_3, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var));
					RuntimeObject* L_4 = V_1;
					if (!L_4)
					{
						goto IL_0051;
					}
				}
				{
					RuntimeObject* L_5 = V_1;
					NullCheck(L_5);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_5);
				}

IL_0051:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_0037_1;
			}

IL_001c_1:
			{
				// foreach (Transform t in transform)
				RuntimeObject* L_6 = V_0;
				NullCheck(L_6);
				RuntimeObject* L_7;
				L_7 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(1 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_6);
				// t.GetComponent<Room>().ActivateGraphics(activate_walls);
				NullCheck(((Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1*)CastclassClass((RuntimeObject*)L_7, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var)));
				Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_8;
				L_8 = Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B(((Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1*)CastclassClass((RuntimeObject*)L_7, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var)), Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
				bool L_9 = __this->___activate_walls_7;
				NullCheck(L_8);
				Room_ActivateGraphics_mD775D2203F51E0CB69D089C1BFBDB85996B34BE4(L_8, L_9, NULL);
			}

IL_0037_1:
			{
				// foreach (Transform t in transform)
				RuntimeObject* L_10 = V_0;
				NullCheck(L_10);
				bool L_11;
				L_11 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_10);
				if (L_11)
				{
					goto IL_001c_1;
				}
			}
			{
				goto IL_0052;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0052:
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::GenerateFirst()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateFirst_m8715C4306C6ABCB9E478E73B12132CC2F7E0DD60 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* V_0 = NULL;
	{
		// if (auto_select_grid)
		bool L_0 = __this->___auto_select_grid_5;
		if (!L_0)
		{
			goto IL_009e;
		}
	}
	{
		// if (activate_rooms)
		bool L_1 = __this->___activate_rooms_6;
		if (!L_1)
		{
			goto IL_005d;
		}
	}
	{
		// grid = rooms[0].transform.localScale.x * rooms[0].GetComponent<Room>().graphics[0].sprite.texture.width / 100;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_2 = __this->___rooms_10;
		NullCheck(L_2);
		int32_t L_3 = 0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_4 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		NullCheck(L_4);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_5;
		L_5 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_4, NULL);
		NullCheck(L_5);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6;
		L_6 = Transform_get_localScale_m804A002A53A645CDFCD15BB0F37209162720363F(L_5, NULL);
		float L_7 = L_6.___x_2;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_8 = __this->___rooms_10;
		NullCheck(L_8);
		int32_t L_9 = 0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_10 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		NullCheck(L_10);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_11;
		L_11 = Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B(L_10, Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		NullCheck(L_11);
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_12 = L_11->___graphics_5;
		NullCheck(L_12);
		int32_t L_13 = 0;
		Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* L_14 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_13));
		NullCheck(L_14);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_15 = L_14->___sprite_0;
		NullCheck(L_15);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_16;
		L_16 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_15, NULL);
		NullCheck(L_16);
		int32_t L_17;
		L_17 = VirtualFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_16);
		__this->___grid_4 = ((float)(((float)il2cpp_codegen_multiply(L_7, ((float)L_17)))/(100.0f)));
		goto IL_009e;
	}

IL_005d:
	{
		// grid = rooms[0].transform.localScale.x * rooms[0].GetComponent<SpriteRenderer>().sprite.texture.width / 100;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_18 = __this->___rooms_10;
		NullCheck(L_18);
		int32_t L_19 = 0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_20 = (L_18)->GetAt(static_cast<il2cpp_array_size_t>(L_19));
		NullCheck(L_20);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_21;
		L_21 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_20, NULL);
		NullCheck(L_21);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_22;
		L_22 = Transform_get_localScale_m804A002A53A645CDFCD15BB0F37209162720363F(L_21, NULL);
		float L_23 = L_22.___x_2;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_24 = __this->___rooms_10;
		NullCheck(L_24);
		int32_t L_25 = 0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_26 = (L_24)->GetAt(static_cast<il2cpp_array_size_t>(L_25));
		NullCheck(L_26);
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_27;
		L_27 = Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45(L_26, Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var);
		NullCheck(L_27);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_28;
		L_28 = SpriteRenderer_get_sprite_mEEED0A9E872AE12E56CAF1641F2F592633181D44(L_27, NULL);
		NullCheck(L_28);
		Texture2D_tE6505BC111DD8A424A9DBE8E05D7D09E11FFFCF4* L_29;
		L_29 = Sprite_get_texture_mEEA6640C1B5D38F84CB64C775B201D7D9F48E045(L_28, NULL);
		NullCheck(L_29);
		int32_t L_30;
		L_30 = VirtualFuncInvoker0< int32_t >::Invoke(4 /* System.Int32 UnityEngine.Texture::get_width() */, L_29);
		__this->___grid_4 = ((float)(((float)il2cpp_codegen_multiply(L_23, ((float)L_30)))/(100.0f)));
	}

IL_009e:
	{
		// Room first = Instantiate(rooms[Random.Range(3, 5)], Vector2.zero, Quaternion.Euler(0, 0, 90 * Random.Range(0, 4)), transform);
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_31 = __this->___rooms_10;
		int32_t L_32;
		L_32 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(3, 5, NULL);
		NullCheck(L_31);
		int32_t L_33 = L_32;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_34 = (L_31)->GetAt(static_cast<il2cpp_array_size_t>(L_33));
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_35;
		L_35 = Vector2_get_zero_m32506C40EC2EE7D5D4410BF40D3EE683A3D5F32C_inline(NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_36;
		L_36 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_35, NULL);
		int32_t L_37;
		L_37 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, 4, NULL);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_38;
		L_38 = Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline((0.0f), (0.0f), ((float)((int32_t)il2cpp_codegen_multiply(((int32_t)90), L_37))), NULL);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_39;
		L_39 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_40;
		L_40 = Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523(L_34, L_36, L_38, L_39, Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var);
		V_0 = L_40;
		// GenerateFromRoom(first);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_41 = V_0;
		Dungeon_GenerateFromRoom_m437D042CBB67DFF7F19FA8A4F8C9639D724EFBA8(__this, L_41, NULL);
		// }
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::DestroyDungeon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_DestroyDungeon_m11ADC224AEEA4D854500F6D4A7564C2A906EA22F (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Clear_m860165F91832E967E3EF62F787A8EC74CECFA78F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RuntimeObject* V_0 = NULL;
	RuntimeObject* V_1 = NULL;
	{
		// dungeon.Clear();
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_0 = __this->___dungeon_11;
		NullCheck(L_0);
		List_1_Clear_m860165F91832E967E3EF62F787A8EC74CECFA78F_inline(L_0, List_1_Clear_m860165F91832E967E3EF62F787A8EC74CECFA78F_RuntimeMethod_var);
		// foreach (Transform t in transform)
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_1;
		L_1 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		NullCheck(L_1);
		RuntimeObject* L_2;
		L_2 = Transform_GetEnumerator_mA7E1C882ACA0C33E284711CD09971DEA3FFEF404(L_1, NULL);
		V_0 = L_2;
	}
	{
		auto __finallyBlock = il2cpp::utils::Finally([&]
		{

FINALLY_0038:
			{// begin finally (depth: 1)
				{
					RuntimeObject* L_3 = V_0;
					V_1 = ((RuntimeObject*)IsInst((RuntimeObject*)L_3, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var));
					RuntimeObject* L_4 = V_1;
					if (!L_4)
					{
						goto IL_0048;
					}
				}
				{
					RuntimeObject* L_5 = V_1;
					NullCheck(L_5);
					InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t030E0496B4E0E4E4F086825007979AF51F7248C5_il2cpp_TypeInfo_var, L_5);
				}

IL_0048:
				{
					return;
				}
			}// end finally (depth: 1)
		});
		try
		{// begin try (depth: 1)
			{
				goto IL_002e_1;
			}

IL_0019_1:
			{
				// foreach (Transform t in transform)
				RuntimeObject* L_6 = V_0;
				NullCheck(L_6);
				RuntimeObject* L_7;
				L_7 = InterfaceFuncInvoker0< RuntimeObject* >::Invoke(1 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_6);
				// Destroy(t.gameObject);
				NullCheck(((Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1*)CastclassClass((RuntimeObject*)L_7, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var)));
				GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_8;
				L_8 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(((Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1*)CastclassClass((RuntimeObject*)L_7, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1_il2cpp_TypeInfo_var)), NULL);
				il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
				Object_Destroy_mE97D0A766419A81296E8D4E5C23D01D3FE91ACBB(L_8, NULL);
			}

IL_002e_1:
			{
				// foreach (Transform t in transform)
				RuntimeObject* L_9 = V_0;
				NullCheck(L_9);
				bool L_10;
				L_10 = InterfaceFuncInvoker0< bool >::Invoke(0 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t7B609C2FFA6EB5167D9C62A0C32A21DE2F666DAA_il2cpp_TypeInfo_var, L_9);
				if (L_10)
				{
					goto IL_0019_1;
				}
			}
			{
				goto IL_0049;
			}
		}// end try (depth: 1)
		catch(Il2CppExceptionWrapper& e)
		{
			__finallyBlock.StoreException(e.ex);
		}
	}

IL_0049:
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::GenerateFromRoom(DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateFromRoom_m437D042CBB67DFF7F19FA8A4F8C9639D724EFBA8 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_r, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_mE5AA8024B0AB1F676B72ABC9CD4E640E72394461_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* V_0 = NULL;
	int32_t V_1 = 0;
	Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* V_2 = NULL;
	{
		// dungeon.Add(r);
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_0 = __this->___dungeon_11;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_1 = ___0_r;
		NullCheck(L_0);
		List_1_Add_mE5AA8024B0AB1F676B72ABC9CD4E640E72394461_inline(L_0, L_1, List_1_Add_mE5AA8024B0AB1F676B72ABC9CD4E640E72394461_RuntimeMethod_var);
		// foreach (Room.Link l in r.links)
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_2 = ___0_r;
		NullCheck(L_2);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_3 = L_2->___links_4;
		V_0 = L_3;
		V_1 = 0;
		goto IL_002f;
	}

IL_0017:
	{
		// foreach (Room.Link l in r.links)
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_4 = V_0;
		int32_t L_5 = V_1;
		NullCheck(L_4);
		int32_t L_6 = L_5;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		V_2 = L_7;
		// if (l.can_generate)
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_8 = V_2;
		NullCheck(L_8);
		bool L_9 = L_8->___can_generate_1;
		if (!L_9)
		{
			goto IL_002b;
		}
	}
	{
		// GenerateFromLink(l, r);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_10 = V_2;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_11 = ___0_r;
		Dungeon_GenerateFromLink_m6E4C3BA491302C3D6132DA76D99E86AB1CF369C7(__this, L_10, L_11, NULL);
	}

IL_002b:
	{
		int32_t L_12 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_12, 1));
	}

IL_002f:
	{
		// foreach (Room.Link l in r.links)
		int32_t L_13 = V_1;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_14 = V_0;
		NullCheck(L_14);
		if ((((int32_t)L_13) < ((int32_t)((int32_t)(((RuntimeArray*)L_14)->max_length)))))
		{
			goto IL_0017;
		}
	}
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::GenerateFromLink(DungeonGenerator.Room/Link,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_GenerateFromLink_m6E4C3BA491302C3D6132DA76D99E86AB1CF369C7 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* ___0_l, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_r, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Find_m113B5413263A32E5F8E92AB8D0B15530CB79634C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec__DisplayClass13_0_U3CGenerateFromLinkU3Eb__0_m267464DB7CBAE1AB6FFB27DCF39E3DD15D91C413_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* V_0 = NULL;
	Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* V_4 = NULL;
	Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* V_5 = NULL;
	bool V_6 = false;
	{
		U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* L_0 = (U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC*)il2cpp_codegen_object_new(U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		U3CU3Ec__DisplayClass13_0__ctor_m06A2E9304E55E1226138916A1E18D697DA8DDB41(L_0, NULL);
		V_0 = L_0;
		// if (!l.can_generate)
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_1 = ___0_l;
		NullCheck(L_1);
		bool L_2 = L_1->___can_generate_1;
		if (L_2)
		{
			goto IL_000f;
		}
	}
	{
		// return;
		return;
	}

IL_000f:
	{
		// Room room = RandomRoom();
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_3;
		L_3 = Dungeon_RandomRoom_mF59C744A7A66100F033CD9536DC5D2495AA8EC9B(__this, NULL);
		V_1 = L_3;
		// int index = Random.Range(0, room.links.Length), o = l.angle + r.rotation;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_4 = V_1;
		NullCheck(L_4);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_5 = L_4->___links_4;
		NullCheck(L_5);
		int32_t L_6;
		L_6 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_5)->max_length)), NULL);
		V_2 = L_6;
		// int index = Random.Range(0, room.links.Length), o = l.angle + r.rotation;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_7 = ___0_l;
		NullCheck(L_7);
		int32_t L_8 = L_7->___angle_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_9 = ___1_r;
		NullCheck(L_9);
		int32_t L_10;
		L_10 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(L_9, NULL);
		V_3 = ((int32_t)il2cpp_codegen_add(L_8, L_10));
		// Vector2 pos = r.position + new Vector2((int)Mathf.Cos(o * Mathf.Deg2Rad), (int)Mathf.Sin(o * Mathf.Deg2Rad)) * grid;
		U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* L_11 = V_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_12 = ___1_r;
		NullCheck(L_12);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_13;
		L_13 = Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F(L_12, NULL);
		int32_t L_14 = V_3;
		float L_15;
		L_15 = cosf(((float)il2cpp_codegen_multiply(((float)L_14), (0.0174532924f))));
		int32_t L_16 = V_3;
		float L_17;
		L_17 = sinf(((float)il2cpp_codegen_multiply(((float)L_16), (0.0174532924f))));
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_18;
		memset((&L_18), 0, sizeof(L_18));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_18), ((float)il2cpp_codegen_cast_double_to_int<int32_t>(L_15)), ((float)il2cpp_codegen_cast_double_to_int<int32_t>(L_17)), /*hidden argument*/NULL);
		float L_19 = __this->___grid_4;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_20;
		L_20 = Vector2_op_Multiply_m2D984B613020089BF5165BA4CA10988E2DC771FE_inline(L_18, L_19, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_21;
		L_21 = Vector2_op_Addition_m8136742CE6EE33BA4EB81C5F584678455917D2AE_inline(L_13, L_20, NULL);
		NullCheck(L_11);
		L_11->___pos_0 = L_21;
		// Room generated = Instantiate(room, pos, Quaternion.Euler(0, 0, Normalized(o - room.links[index].angle - 180)), transform);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_22 = V_1;
		U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* L_23 = V_0;
		NullCheck(L_23);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_24 = L_23->___pos_0;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_25;
		L_25 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_24, NULL);
		int32_t L_26 = V_3;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_27 = V_1;
		NullCheck(L_27);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_28 = L_27->___links_4;
		int32_t L_29 = V_2;
		NullCheck(L_28);
		int32_t L_30 = L_29;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_31 = (L_28)->GetAt(static_cast<il2cpp_array_size_t>(L_30));
		NullCheck(L_31);
		int32_t L_32 = L_31->___angle_0;
		int32_t L_33;
		L_33 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_subtract(((int32_t)il2cpp_codegen_subtract(L_26, L_32)), ((int32_t)180))), NULL);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_34;
		L_34 = Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline((0.0f), (0.0f), ((float)L_33), NULL);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_35;
		L_35 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_36;
		L_36 = Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523(L_22, L_25, L_34, L_35, Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var);
		V_4 = L_36;
		// l.can_generate = generated.links[index].can_generate = false;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_37 = ___0_l;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_38 = V_4;
		NullCheck(L_38);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_39 = L_38->___links_4;
		int32_t L_40 = V_2;
		NullCheck(L_39);
		int32_t L_41 = L_40;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_42 = (L_39)->GetAt(static_cast<il2cpp_array_size_t>(L_41));
		int32_t L_43 = 0;
		V_6 = (bool)L_43;
		NullCheck(L_42);
		L_42->___can_generate_1 = (bool)L_43;
		bool L_44 = V_6;
		NullCheck(L_37);
		L_37->___can_generate_1 = L_44;
		// Room check = dungeon.Find(x => x.position == pos);
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_45 = __this->___dungeon_11;
		U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* L_46 = V_0;
		Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9* L_47 = (Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9*)il2cpp_codegen_object_new(Predicate_1_t09D6EDAEA042F373BC89366694C1022C99EF64A9_il2cpp_TypeInfo_var);
		NullCheck(L_47);
		Predicate_1__ctor_m5206A84FE4651A1076EC4EFC55D0824C9F87EDE4(L_47, L_46, (intptr_t)((void*)U3CU3Ec__DisplayClass13_0_U3CGenerateFromLinkU3Eb__0_m267464DB7CBAE1AB6FFB27DCF39E3DD15D91C413_RuntimeMethod_var), NULL);
		NullCheck(L_45);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_48;
		L_48 = List_1_Find_m113B5413263A32E5F8E92AB8D0B15530CB79634C(L_45, L_47, List_1_Find_m113B5413263A32E5F8E92AB8D0B15530CB79634C_RuntimeMethod_var);
		V_5 = L_48;
		// if (check != null)
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_49 = V_5;
		bool L_50;
		L_50 = Object_op_Inequality_mD0BE578448EAA61948F25C32F8DD55AB1F778602(L_49, (Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C*)NULL, NULL);
		if (!L_50)
		{
			goto IL_00fe;
		}
	}
	{
		// generated = AddRooms(generated, check);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_51 = V_4;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_52 = V_5;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_53;
		L_53 = Dungeon_AddRooms_m3D3C97690BDF4618559AAC205FFAEB8D40320AFA(__this, L_51, L_52, NULL);
		V_4 = L_53;
	}

IL_00fe:
	{
		// GenerateFromRoom(generated);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_54 = V_4;
		Dungeon_GenerateFromRoom_m437D042CBB67DFF7F19FA8A4F8C9639D724EFBA8(__this, L_54, NULL);
		// }
		return;
	}
}
// DungeonGenerator.Room DungeonGenerator.Dungeon::AddRooms(DungeonGenerator.Room,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* Dungeon_AddRooms_m3D3C97690BDF4618559AAC205FFAEB8D40320AFA (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_r1, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_r2, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_ToArray_m774D68B3437B636757CA5CE8C139144E372294EA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m2424D4A7D9018A7B7FD865A4B75D47D66E60D866_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* V_0 = NULL;
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* V_1 = NULL;
	Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* V_2 = NULL;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	{
		// List<Room.Link> all_links = new List<Room.Link>();
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_0 = (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B*)il2cpp_codegen_object_new(List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		List_1__ctor_m2424D4A7D9018A7B7FD865A4B75D47D66E60D866(L_0, List_1__ctor_m2424D4A7D9018A7B7FD865A4B75D47D66E60D866_RuntimeMethod_var);
		V_0 = L_0;
		// for (int i = 0; i < r1.links.Length; i++)
		V_4 = 0;
		goto IL_0036;
	}

IL_000b:
	{
		// all_links.Add(new Room.Link(Normalized(r1.links[i].angle + r1.rotation)));
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_1 = V_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_2 = ___0_r1;
		NullCheck(L_2);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_3 = L_2->___links_4;
		int32_t L_4 = V_4;
		NullCheck(L_3);
		int32_t L_5 = L_4;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		NullCheck(L_6);
		int32_t L_7 = L_6->___angle_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_8 = ___0_r1;
		NullCheck(L_8);
		int32_t L_9;
		L_9 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(L_8, NULL);
		int32_t L_10;
		L_10 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_add(L_7, L_9)), NULL);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_11 = (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4*)il2cpp_codegen_object_new(Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_il2cpp_TypeInfo_var);
		NullCheck(L_11);
		Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB(L_11, L_10, NULL);
		NullCheck(L_1);
		List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_inline(L_1, L_11, List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_RuntimeMethod_var);
		// for (int i = 0; i < r1.links.Length; i++)
		int32_t L_12 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_12, 1));
	}

IL_0036:
	{
		// for (int i = 0; i < r1.links.Length; i++)
		int32_t L_13 = V_4;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_14 = ___0_r1;
		NullCheck(L_14);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_15 = L_14->___links_4;
		NullCheck(L_15);
		if ((((int32_t)L_13) < ((int32_t)((int32_t)(((RuntimeArray*)L_15)->max_length)))))
		{
			goto IL_000b;
		}
	}
	{
		// for (int i = 0; i < r2.links.Length; i++)
		V_5 = 0;
		goto IL_0072;
	}

IL_0047:
	{
		// all_links.Add(new Room.Link(Normalized(r2.links[i].angle + r2.rotation)));
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_16 = V_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_17 = ___1_r2;
		NullCheck(L_17);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_18 = L_17->___links_4;
		int32_t L_19 = V_5;
		NullCheck(L_18);
		int32_t L_20 = L_19;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_21 = (L_18)->GetAt(static_cast<il2cpp_array_size_t>(L_20));
		NullCheck(L_21);
		int32_t L_22 = L_21->___angle_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_23 = ___1_r2;
		NullCheck(L_23);
		int32_t L_24;
		L_24 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(L_23, NULL);
		int32_t L_25;
		L_25 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_add(L_22, L_24)), NULL);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_26 = (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4*)il2cpp_codegen_object_new(Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_il2cpp_TypeInfo_var);
		NullCheck(L_26);
		Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB(L_26, L_25, NULL);
		NullCheck(L_16);
		List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_inline(L_16, L_26, List_1_Add_mB89AFA9F3C8DC3B4AB01557C0457D62E809B5A34_RuntimeMethod_var);
		// for (int i = 0; i < r2.links.Length; i++)
		int32_t L_27 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_27, 1));
	}

IL_0072:
	{
		// for (int i = 0; i < r2.links.Length; i++)
		int32_t L_28 = V_5;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_29 = ___1_r2;
		NullCheck(L_29);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_30 = L_29->___links_4;
		NullCheck(L_30);
		if ((((int32_t)L_28) < ((int32_t)((int32_t)(((RuntimeArray*)L_30)->max_length)))))
		{
			goto IL_0047;
		}
	}
	{
		// Distinct(all_links);
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_31 = V_0;
		Dungeon_U3CAddRoomsU3Eg__DistinctU7C14_0_mC7B9629734C039FEAC834D902336C88F33E5307E(L_31, NULL);
		// Sort(all_links);
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_32 = V_0;
		Dungeon_U3CAddRoomsU3Eg__SortU7C14_1_m037CC0569376A031A30912BC8E5F6787F98E06BA(L_32, NULL);
		// Room.Link[] wanted_links = all_links.ToArray();
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_33 = V_0;
		NullCheck(L_33);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_34;
		L_34 = List_1_ToArray_m774D68B3437B636757CA5CE8C139144E372294EA(L_33, List_1_ToArray_m774D68B3437B636757CA5CE8C139144E372294EA_RuntimeMethod_var);
		V_1 = L_34;
		// Room wanted_room_model = rooms[0];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_35 = __this->___rooms_10;
		NullCheck(L_35);
		int32_t L_36 = 0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_37 = (L_35)->GetAt(static_cast<il2cpp_array_size_t>(L_36));
		V_2 = L_37;
		// int wanted_room_rotation = 0;
		V_3 = 0;
		// for (int i = 0; i < rooms.Length; i++)
		V_6 = 0;
		goto IL_0101;
	}

IL_00a1:
	{
		// if (all_links.Count == rooms[i].links.Length)
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_38 = V_0;
		NullCheck(L_38);
		int32_t L_39;
		L_39 = List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_inline(L_38, List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_RuntimeMethod_var);
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_40 = __this->___rooms_10;
		int32_t L_41 = V_6;
		NullCheck(L_40);
		int32_t L_42 = L_41;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_43 = (L_40)->GetAt(static_cast<il2cpp_array_size_t>(L_42));
		NullCheck(L_43);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_44 = L_43->___links_4;
		NullCheck(L_44);
		if ((!(((uint32_t)L_39) == ((uint32_t)((int32_t)(((RuntimeArray*)L_44)->max_length))))))
		{
			goto IL_00fb;
		}
	}
	{
		// for (int rotation = 0; rotation < 4; rotation++)
		V_7 = 0;
		goto IL_00f6;
	}

IL_00be:
	{
		// if (AngleMatch(wanted_links, NormalizeAngles(rooms[i].links, rotation * 90)))
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_45 = V_1;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_46 = __this->___rooms_10;
		int32_t L_47 = V_6;
		NullCheck(L_46);
		int32_t L_48 = L_47;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_49 = (L_46)->GetAt(static_cast<il2cpp_array_size_t>(L_48));
		NullCheck(L_49);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_50 = L_49->___links_4;
		int32_t L_51 = V_7;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_52;
		L_52 = Dungeon_U3CAddRoomsU3Eg__NormalizeAnglesU7C14_3_m39FB34A370A8930F673CA42078ED5E2E5B80414C(L_50, ((int32_t)il2cpp_codegen_multiply(L_51, ((int32_t)90))), NULL);
		bool L_53;
		L_53 = Dungeon_U3CAddRoomsU3Eg__AngleMatchU7C14_2_m02B65223985DB827BB9659F00877C1409FF11A14(L_45, L_52, NULL);
		if (!L_53)
		{
			goto IL_00f0;
		}
	}
	{
		// wanted_room_model = rooms[i];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_54 = __this->___rooms_10;
		int32_t L_55 = V_6;
		NullCheck(L_54);
		int32_t L_56 = L_55;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_57 = (L_54)->GetAt(static_cast<il2cpp_array_size_t>(L_56));
		V_2 = L_57;
		// wanted_room_rotation = rotation * 90;
		int32_t L_58 = V_7;
		V_3 = ((int32_t)il2cpp_codegen_multiply(L_58, ((int32_t)90)));
		// break;
		goto IL_00fb;
	}

IL_00f0:
	{
		// for (int rotation = 0; rotation < 4; rotation++)
		int32_t L_59 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_add(L_59, 1));
	}

IL_00f6:
	{
		// for (int rotation = 0; rotation < 4; rotation++)
		int32_t L_60 = V_7;
		if ((((int32_t)L_60) < ((int32_t)4)))
		{
			goto IL_00be;
		}
	}

IL_00fb:
	{
		// for (int i = 0; i < rooms.Length; i++)
		int32_t L_61 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add(L_61, 1));
	}

IL_0101:
	{
		// for (int i = 0; i < rooms.Length; i++)
		int32_t L_62 = V_6;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_63 = __this->___rooms_10;
		NullCheck(L_63);
		if ((((int32_t)L_62) < ((int32_t)((int32_t)(((RuntimeArray*)L_63)->max_length)))))
		{
			goto IL_00a1;
		}
	}
	{
		// Room room_instance = Instantiate(wanted_room_model, r1.position, Quaternion.Euler(0, 0, wanted_room_rotation), transform);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_64 = V_2;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_65 = ___0_r1;
		NullCheck(L_65);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_66;
		L_66 = Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F(L_65, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_67;
		L_67 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_66, NULL);
		int32_t L_68 = V_3;
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_69;
		L_69 = Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline((0.0f), (0.0f), ((float)L_68), NULL);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_70;
		L_70 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_71;
		L_71 = Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523(L_64, L_67, L_69, L_70, Object_Instantiate_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m651493E61AB67666638E328D41CA654F5DCE4523_RuntimeMethod_var);
		// DisableLinks(room_instance, r1);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_72 = L_71;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_73 = ___0_r1;
		Dungeon_U3CAddRoomsU3Eg__DisableLinksU7C14_4_m1F011D4844CB48DEB66D6EC54EADEF34C784A3C9(L_72, L_73, NULL);
		// DisableLinks(room_instance, r2);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_74 = L_72;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_75 = ___1_r2;
		Dungeon_U3CAddRoomsU3Eg__DisableLinksU7C14_4_m1F011D4844CB48DEB66D6EC54EADEF34C784A3C9(L_74, L_75, NULL);
		// dungeon.Remove(r1);
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_76 = __this->___dungeon_11;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_77 = ___0_r1;
		NullCheck(L_76);
		bool L_78;
		L_78 = List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E(L_76, L_77, List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E_RuntimeMethod_var);
		// dungeon.Remove(r2);
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_79 = __this->___dungeon_11;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_80 = ___1_r2;
		NullCheck(L_79);
		bool L_81;
		L_81 = List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E(L_79, L_80, List_1_Remove_m04F322937D36BC3690F729769BF967D014AE8A7E_RuntimeMethod_var);
		// Destroy(r1.gameObject);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_82 = ___0_r1;
		NullCheck(L_82);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_83;
		L_83 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(L_82, NULL);
		Object_Destroy_mE97D0A766419A81296E8D4E5C23D01D3FE91ACBB(L_83, NULL);
		// Destroy(r2.gameObject);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_84 = ___1_r2;
		NullCheck(L_84);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_85;
		L_85 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(L_84, NULL);
		Object_Destroy_mE97D0A766419A81296E8D4E5C23D01D3FE91ACBB(L_85, NULL);
		// return room_instance;
		return L_74;
	}
}
// DungeonGenerator.Room DungeonGenerator.Dungeon::RandomRoom()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* Dungeon_RandomRoom_mF59C744A7A66100F033CD9536DC5D2495AA8EC9B (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// if (dungeon.Count < min_complexity)
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_0 = __this->___dungeon_11;
		NullCheck(L_0);
		int32_t L_1;
		L_1 = List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_inline(L_0, List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_RuntimeMethod_var);
		int32_t L_2 = __this->___min_complexity_8;
		if ((((int32_t)L_1) >= ((int32_t)L_2)))
		{
			goto IL_002b;
		}
	}
	{
		// return rooms[Random.Range(1, rooms.Length - 2)];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_3 = __this->___rooms_10;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_4 = __this->___rooms_10;
		NullCheck(L_4);
		int32_t L_5;
		L_5 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(1, ((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_4)->max_length)), 2)), NULL);
		NullCheck(L_3);
		int32_t L_6 = L_5;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_7 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		return L_7;
	}

IL_002b:
	{
		// if (dungeon.Count > max_complexity)
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_8 = __this->___dungeon_11;
		NullCheck(L_8);
		int32_t L_9;
		L_9 = List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_inline(L_8, List_1_get_Count_m898DB3D879D1D434D1F6C708E3F3E71D8FE8B49D_RuntimeMethod_var);
		int32_t L_10 = __this->___max_complexity_9;
		if ((((int32_t)L_9) <= ((int32_t)L_10)))
		{
			goto IL_0047;
		}
	}
	{
		// return rooms[0];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_11 = __this->___rooms_10;
		NullCheck(L_11);
		int32_t L_12 = 0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_13 = (L_11)->GetAt(static_cast<il2cpp_array_size_t>(L_12));
		return L_13;
	}

IL_0047:
	{
		// return rooms[Random.Range(0, rooms.Length - 3)];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_14 = __this->___rooms_10;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_15 = __this->___rooms_10;
		NullCheck(L_15);
		int32_t L_16;
		L_16 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)il2cpp_codegen_subtract(((int32_t)(((RuntimeArray*)L_15)->max_length)), 3)), NULL);
		NullCheck(L_14);
		int32_t L_17 = L_16;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_18 = (L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_17));
		return L_18;
	}
}
// System.Int32 DungeonGenerator.Dungeon::Normalized(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA (int32_t ___0_angle, const RuntimeMethod* method) 
{
	{
		// public static int Normalized(int angle) => (angle + 360) % 360;
		int32_t L_0 = ___0_angle;
		return ((int32_t)(((int32_t)il2cpp_codegen_add(L_0, ((int32_t)360)))%((int32_t)360)));
	}
}
// System.Void DungeonGenerator.Dungeon::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon__ctor_mFE80CC90F277257724D6F229110BFDBAEFEACF05 (Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_mE8B67035812C247866131D058EF6E3284A17B95B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// public List<Room> dungeon = new List<Room>();
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_0 = (List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE*)il2cpp_codegen_object_new(List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		List_1__ctor_mE8B67035812C247866131D058EF6E3284A17B95B(L_0, List_1__ctor_mE8B67035812C247866131D058EF6E3284A17B95B_RuntimeMethod_var);
		__this->___dungeon_11 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___dungeon_11), (void*)L_0);
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::<AddRooms>g__Distinct|14_0(System.Collections.Generic.List`1<DungeonGenerator.Room/Link>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_U3CAddRoomsU3Eg__DistinctU7C14_0_mC7B9629734C039FEAC834D902336C88F33E5307E (List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* ___0_links, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_ContainsKey_m25725AE19289EC9E8D4510E63BB4D41272E7B76A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2__ctor_mB97F1137644FD8446F05E9AA8A86C9840D587C18_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_set_Item_mFEEAD6949043D033BD1DD28B97C236680AC557BA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_RemoveAt_m3894E022B8F0201AC450EE7D6B34BF7B7DFC9419_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* V_0 = NULL;
	int32_t V_1 = 0;
	{
		// Dictionary<int, Room.Link> distinctAngles = new Dictionary<int, Room.Link>();
		Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* L_0 = (Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E*)il2cpp_codegen_object_new(Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		Dictionary_2__ctor_mB97F1137644FD8446F05E9AA8A86C9840D587C18(L_0, Dictionary_2__ctor_mB97F1137644FD8446F05E9AA8A86C9840D587C18_RuntimeMethod_var);
		V_0 = L_0;
		// int index = 0;
		V_1 = 0;
		goto IL_0044;
	}

IL_000a:
	{
		// if (!distinctAngles.ContainsKey(links[index].angle))
		Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* L_1 = V_0;
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_2 = ___0_links;
		int32_t L_3 = V_1;
		NullCheck(L_2);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_4;
		L_4 = List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50(L_2, L_3, List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50_RuntimeMethod_var);
		NullCheck(L_4);
		int32_t L_5 = L_4->___angle_0;
		NullCheck(L_1);
		bool L_6;
		L_6 = Dictionary_2_ContainsKey_m25725AE19289EC9E8D4510E63BB4D41272E7B76A(L_1, L_5, Dictionary_2_ContainsKey_m25725AE19289EC9E8D4510E63BB4D41272E7B76A_RuntimeMethod_var);
		if (L_6)
		{
			goto IL_003d;
		}
	}
	{
		// distinctAngles[links[index].angle] = links[index];
		Dictionary_2_tF3A5D355E008D7CBD67FF51AEFA47D3D4A76F05E* L_7 = V_0;
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_8 = ___0_links;
		int32_t L_9 = V_1;
		NullCheck(L_8);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_10;
		L_10 = List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50(L_8, L_9, List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50_RuntimeMethod_var);
		NullCheck(L_10);
		int32_t L_11 = L_10->___angle_0;
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_12 = ___0_links;
		int32_t L_13 = V_1;
		NullCheck(L_12);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_14;
		L_14 = List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50(L_12, L_13, List_1_get_Item_mAC8F686FCF889F5AD816D29AE6CE1C058F49CD50_RuntimeMethod_var);
		NullCheck(L_7);
		Dictionary_2_set_Item_mFEEAD6949043D033BD1DD28B97C236680AC557BA(L_7, L_11, L_14, Dictionary_2_set_Item_mFEEAD6949043D033BD1DD28B97C236680AC557BA_RuntimeMethod_var);
		// index++;
		int32_t L_15 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_15, 1));
		goto IL_0044;
	}

IL_003d:
	{
		// links.RemoveAt(index);
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_16 = ___0_links;
		int32_t L_17 = V_1;
		NullCheck(L_16);
		List_1_RemoveAt_m3894E022B8F0201AC450EE7D6B34BF7B7DFC9419(L_16, L_17, List_1_RemoveAt_m3894E022B8F0201AC450EE7D6B34BF7B7DFC9419_RuntimeMethod_var);
	}

IL_0044:
	{
		// while (index < links.Count)
		int32_t L_18 = V_1;
		List_1_t4D7966A4511D992E0447288A64EFE8B8EEB2B04B* L_19 = ___0_links;
		NullCheck(L_19);
		int32_t L_20;
		L_20 = List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_inline(L_19, List_1_get_Count_mBEE3DDE33008B2FD9F2A5BB36C3AF815E5666CE5_RuntimeMethod_var);
		if ((((int32_t)L_18) < ((int32_t)L_20)))
		{
			goto IL_000a;
		}
	}
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.Dungeon::<AddRooms>g__Sort|14_1(System.Collections.Generic.IEnumerable`1<DungeonGenerator.Room/Link>)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_U3CAddRoomsU3Eg__SortU7C14_1_m037CC0569376A031A30912BC8E5F6787F98E06BA (RuntimeObject* ___0_links, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		// for (int i = 0; i < links.Count() - 1; i++)
		V_0 = 0;
		goto IL_0098;
	}

IL_0007:
	{
		// for (int j = i + 1; j < links.Count(); j++)
		int32_t L_0 = V_0;
		V_1 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		goto IL_0088;
	}

IL_000d:
	{
		// if (links.ElementAt(i).angle > links.ElementAt(j).angle)
		RuntimeObject* L_1 = ___0_links;
		int32_t L_2 = V_0;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_3;
		L_3 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_1, L_2, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		NullCheck(L_3);
		int32_t L_4 = L_3->___angle_0;
		RuntimeObject* L_5 = ___0_links;
		int32_t L_6 = V_1;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_7;
		L_7 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_5, L_6, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		NullCheck(L_7);
		int32_t L_8 = L_7->___angle_0;
		if ((((int32_t)L_4) <= ((int32_t)L_8)))
		{
			goto IL_0084;
		}
	}
	{
		// links.ElementAt(i).angle ^= links.ElementAt(j).angle;
		RuntimeObject* L_9 = ___0_links;
		int32_t L_10 = V_0;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_11;
		L_11 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_9, L_10, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_12 = L_11;
		NullCheck(L_12);
		int32_t L_13 = L_12->___angle_0;
		RuntimeObject* L_14 = ___0_links;
		int32_t L_15 = V_1;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_16;
		L_16 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_14, L_15, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		NullCheck(L_16);
		int32_t L_17 = L_16->___angle_0;
		NullCheck(L_12);
		L_12->___angle_0 = ((int32_t)(L_13^L_17));
		// links.ElementAt(j).angle ^= links.ElementAt(i).angle;
		RuntimeObject* L_18 = ___0_links;
		int32_t L_19 = V_1;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_20;
		L_20 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_18, L_19, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_21 = L_20;
		NullCheck(L_21);
		int32_t L_22 = L_21->___angle_0;
		RuntimeObject* L_23 = ___0_links;
		int32_t L_24 = V_0;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_25;
		L_25 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_23, L_24, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		NullCheck(L_25);
		int32_t L_26 = L_25->___angle_0;
		NullCheck(L_21);
		L_21->___angle_0 = ((int32_t)(L_22^L_26));
		// links.ElementAt(i).angle ^= links.ElementAt(j).angle;
		RuntimeObject* L_27 = ___0_links;
		int32_t L_28 = V_0;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_29;
		L_29 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_27, L_28, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_30 = L_29;
		NullCheck(L_30);
		int32_t L_31 = L_30->___angle_0;
		RuntimeObject* L_32 = ___0_links;
		int32_t L_33 = V_1;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_34;
		L_34 = Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF(L_32, L_33, Enumerable_ElementAt_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m2A6291E0955CEB1A3BC40B5A9C45472A4A21E8CF_RuntimeMethod_var);
		NullCheck(L_34);
		int32_t L_35 = L_34->___angle_0;
		NullCheck(L_30);
		L_30->___angle_0 = ((int32_t)(L_31^L_35));
	}

IL_0084:
	{
		// for (int j = i + 1; j < links.Count(); j++)
		int32_t L_36 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_36, 1));
	}

IL_0088:
	{
		// for (int j = i + 1; j < links.Count(); j++)
		int32_t L_37 = V_1;
		RuntimeObject* L_38 = ___0_links;
		int32_t L_39;
		L_39 = Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964(L_38, Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964_RuntimeMethod_var);
		if ((((int32_t)L_37) < ((int32_t)L_39)))
		{
			goto IL_000d;
		}
	}
	{
		// for (int i = 0; i < links.Count() - 1; i++)
		int32_t L_40 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_40, 1));
	}

IL_0098:
	{
		// for (int i = 0; i < links.Count() - 1; i++)
		int32_t L_41 = V_0;
		RuntimeObject* L_42 = ___0_links;
		int32_t L_43;
		L_43 = Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964(L_42, Enumerable_Count_TisLink_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_m3215D62671A1F4ADCA0AEFAB8B084911555D5964_RuntimeMethod_var);
		if ((((int32_t)L_41) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_43, 1)))))
		{
			goto IL_0007;
		}
	}
	{
		// }
		return;
	}
}
// System.Boolean DungeonGenerator.Dungeon::<AddRooms>g__AngleMatch|14_2(DungeonGenerator.Room/Link[],DungeonGenerator.Room/Link[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Dungeon_U3CAddRoomsU3Eg__AngleMatchU7C14_2_m02B65223985DB827BB9659F00877C1409FF11A14 (LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___0_l1, LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___1_l2, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		// for (int i = 0; i < l1.Length; i++)
		V_0 = 0;
		goto IL_001c;
	}

IL_0004:
	{
		// if (l1[i].angle != l2[i].angle)
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_0 = ___0_l1;
		int32_t L_1 = V_0;
		NullCheck(L_0);
		int32_t L_2 = L_1;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_3 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_2));
		NullCheck(L_3);
		int32_t L_4 = L_3->___angle_0;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_5 = ___1_l2;
		int32_t L_6 = V_0;
		NullCheck(L_5);
		int32_t L_7 = L_6;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		NullCheck(L_8);
		int32_t L_9 = L_8->___angle_0;
		if ((((int32_t)L_4) == ((int32_t)L_9)))
		{
			goto IL_0018;
		}
	}
	{
		// return false;
		return (bool)0;
	}

IL_0018:
	{
		// for (int i = 0; i < l1.Length; i++)
		int32_t L_10 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_10, 1));
	}

IL_001c:
	{
		// for (int i = 0; i < l1.Length; i++)
		int32_t L_11 = V_0;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_12 = ___0_l1;
		NullCheck(L_12);
		if ((((int32_t)L_11) < ((int32_t)((int32_t)(((RuntimeArray*)L_12)->max_length)))))
		{
			goto IL_0004;
		}
	}
	{
		// return true;
		return (bool)1;
	}
}
// DungeonGenerator.Room/Link[] DungeonGenerator.Dungeon::<AddRooms>g__NormalizeAngles|14_3(DungeonGenerator.Room/Link[],System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* Dungeon_U3CAddRoomsU3Eg__NormalizeAnglesU7C14_3_m39FB34A370A8930F673CA42078ED5E2E5B80414C (LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* ___0_links, int32_t ___1_rotation, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* V_0 = NULL;
	int32_t V_1 = 0;
	{
		// Room.Link[] l = new Room.Link[links.Length];
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_0 = ___0_links;
		NullCheck(L_0);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_1 = (LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18*)(LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18*)SZArrayNew(LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18_il2cpp_TypeInfo_var, (uint32_t)((int32_t)(((RuntimeArray*)L_0)->max_length)));
		V_0 = L_1;
		// for (int i = 0; i < l.Length; i++)
		V_1 = 0;
		goto IL_0028;
	}

IL_000d:
	{
		// l[i] = new Room.Link(Normalized(links[i].angle + rotation));
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_2 = V_0;
		int32_t L_3 = V_1;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_4 = ___0_links;
		int32_t L_5 = V_1;
		NullCheck(L_4);
		int32_t L_6 = L_5;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		NullCheck(L_7);
		int32_t L_8 = L_7->___angle_0;
		int32_t L_9 = ___1_rotation;
		int32_t L_10;
		L_10 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_add(L_8, L_9)), NULL);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_11 = (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4*)il2cpp_codegen_object_new(Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4_il2cpp_TypeInfo_var);
		NullCheck(L_11);
		Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB(L_11, L_10, NULL);
		NullCheck(L_2);
		ArrayElementTypeCheck (L_2, L_11);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(L_3), (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4*)L_11);
		// for (int i = 0; i < l.Length; i++)
		int32_t L_12 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_12, 1));
	}

IL_0028:
	{
		// for (int i = 0; i < l.Length; i++)
		int32_t L_13 = V_1;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_14 = V_0;
		NullCheck(L_14);
		if ((((int32_t)L_13) < ((int32_t)((int32_t)(((RuntimeArray*)L_14)->max_length)))))
		{
			goto IL_000d;
		}
	}
	{
		// Sort(l);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_15 = V_0;
		Dungeon_U3CAddRoomsU3Eg__SortU7C14_1_m037CC0569376A031A30912BC8E5F6787F98E06BA((RuntimeObject*)L_15, NULL);
		// return l;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_16 = V_0;
		return L_16;
	}
}
// System.Void DungeonGenerator.Dungeon::<AddRooms>g__DisableLinks|14_4(DungeonGenerator.Room,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Dungeon_U3CAddRoomsU3Eg__DisableLinksU7C14_4_m1F011D4844CB48DEB66D6EC54EADEF34C784A3C9 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_model, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_room_disable, const RuntimeMethod* method) 
{
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* V_0 = NULL;
	int32_t V_1 = 0;
	Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* V_2 = NULL;
	LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* V_3 = NULL;
	int32_t V_4 = 0;
	Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* V_5 = NULL;
	{
		// foreach (Room.Link link_disable in room_disable.links)
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_0 = ___1_room_disable;
		NullCheck(L_0);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_1 = L_0->___links_4;
		V_0 = L_1;
		V_1 = 0;
		goto IL_006d;
	}

IL_000b:
	{
		// foreach (Room.Link link_disable in room_disable.links)
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_2 = V_0;
		int32_t L_3 = V_1;
		NullCheck(L_2);
		int32_t L_4 = L_3;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_2 = L_5;
		// foreach (Room.Link link in model.links)
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_6 = ___0_model;
		NullCheck(L_6);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_7 = L_6->___links_4;
		V_3 = L_7;
		V_4 = 0;
		goto IL_0062;
	}

IL_001b:
	{
		// foreach (Room.Link link in model.links)
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_8 = V_3;
		int32_t L_9 = V_4;
		NullCheck(L_8);
		int32_t L_10 = L_9;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		V_5 = L_11;
		// if (Normalized(link.angle + model.rotation) == Normalized(link_disable.angle + room_disable.rotation))
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_12 = V_5;
		NullCheck(L_12);
		int32_t L_13 = L_12->___angle_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_14 = ___0_model;
		NullCheck(L_14);
		int32_t L_15;
		L_15 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(L_14, NULL);
		int32_t L_16;
		L_16 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_add(L_13, L_15)), NULL);
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_17 = V_2;
		NullCheck(L_17);
		int32_t L_18 = L_17->___angle_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_19 = ___1_room_disable;
		NullCheck(L_19);
		int32_t L_20;
		L_20 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(L_19, NULL);
		int32_t L_21;
		L_21 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_add(L_18, L_20)), NULL);
		if ((!(((uint32_t)L_16) == ((uint32_t)L_21))))
		{
			goto IL_005c;
		}
	}
	{
		// link.can_generate &= link_disable.can_generate;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_22 = V_5;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_23 = L_22;
		NullCheck(L_23);
		bool L_24 = L_23->___can_generate_1;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_25 = V_2;
		NullCheck(L_25);
		bool L_26 = L_25->___can_generate_1;
		NullCheck(L_23);
		L_23->___can_generate_1 = (bool)((int32_t)((int32_t)L_24&(int32_t)L_26));
	}

IL_005c:
	{
		int32_t L_27 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_27, 1));
	}

IL_0062:
	{
		// foreach (Room.Link link in model.links)
		int32_t L_28 = V_4;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_29 = V_3;
		NullCheck(L_29);
		if ((((int32_t)L_28) < ((int32_t)((int32_t)(((RuntimeArray*)L_29)->max_length)))))
		{
			goto IL_001b;
		}
	}
	{
		int32_t L_30 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_30, 1));
	}

IL_006d:
	{
		// foreach (Room.Link link_disable in room_disable.links)
		int32_t L_31 = V_1;
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_32 = V_0;
		NullCheck(L_32);
		if ((((int32_t)L_31) < ((int32_t)((int32_t)(((RuntimeArray*)L_32)->max_length)))))
		{
			goto IL_000b;
		}
	}
	{
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.Dungeon/<>c__DisplayClass13_0::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__DisplayClass13_0__ctor_m06A2E9304E55E1226138916A1E18D697DA8DDB41 (U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean DungeonGenerator.Dungeon/<>c__DisplayClass13_0::<GenerateFromLink>b__0(DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec__DisplayClass13_0_U3CGenerateFromLinkU3Eb__0_m267464DB7CBAE1AB6FFB27DCF39E3DD15D91C413 (U3CU3Ec__DisplayClass13_0_t40C67448E37299D70697FF41D2CE55D21068AFEC* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_x, const RuntimeMethod* method) 
{
	{
		// Room check = dungeon.Find(x => x.position == pos);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_0 = ___0_x;
		NullCheck(L_0);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1;
		L_1 = Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F(L_0, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = __this->___pos_0;
		bool L_3;
		L_3 = Vector2_op_Equality_m6F2E069A50E787D131261E5CB25FC9E03F95B5E1_inline(L_1, L_2, NULL);
		return L_3;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// DungeonGenerator.Room[] DungeonGenerator.DungeonDesigner::getDungeon(DungeonGenerator.Dungeon)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ___0_dungeon, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_ToArray_mC3E937AF391FBD2071D29BE457FAFAB3BF5DD94F_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		// return dungeon.dungeon.ToArray();
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_0 = ___0_dungeon;
		NullCheck(L_0);
		List_1_t8BDDFB0F95802B2D4D77AF6307053B99A41F8DCE* L_1 = L_0->___dungeon_11;
		NullCheck(L_1);
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_2;
		L_2 = List_1_ToArray_mC3E937AF391FBD2071D29BE457FAFAB3BF5DD94F(L_1, List_1_ToArray_mC3E937AF391FBD2071D29BE457FAFAB3BF5DD94F_RuntimeMethod_var);
		return L_2;
	}
}
// DungeonGenerator.Model DungeonGenerator.DungeonDesigner::RoomToModel(DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* DungeonDesigner_RoomToModel_m7DF305BE8C449842BD12AC327A56C73CAA053B2D (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___0_r, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_AddComponent_TisModel_tC414155249EC7AAC88CDBA8448952AF9525DEC17_mD473FDD0F45F30E0908D9C09D6969E43F9CF0ACF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* V_0 = NULL;
	List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* V_1 = NULL;
	int32_t V_2 = 0;
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* V_3 = NULL;
	int32_t V_4 = 0;
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 V_5;
	memset((&V_5), 0, sizeof(V_5));
	{
		// int[] euclidean_links = new int[r.links.Length];
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_0 = ___0_r;
		NullCheck(L_0);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_1 = L_0->___links_4;
		NullCheck(L_1);
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_2 = (Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C*)SZArrayNew(Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C_il2cpp_TypeInfo_var, (uint32_t)((int32_t)(((RuntimeArray*)L_1)->max_length)));
		V_0 = L_2;
		// for (int i = 0; i < r.links.Length; ++i)
		V_2 = 0;
		goto IL_0032;
	}

IL_0012:
	{
		// euclidean_links[i] = Dungeon.Normalized(r.links[i].angle + r.GetActivationRotation());
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_3 = V_0;
		int32_t L_4 = V_2;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_5 = ___0_r;
		NullCheck(L_5);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_6 = L_5->___links_4;
		int32_t L_7 = V_2;
		NullCheck(L_6);
		int32_t L_8 = L_7;
		Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* L_9 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		NullCheck(L_9);
		int32_t L_10 = L_9->___angle_0;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_11 = ___0_r;
		NullCheck(L_11);
		int32_t L_12;
		L_12 = Room_GetActivationRotation_mD585EEAC58FCB6AB88F219D9E624038EF7C37D1C_inline(L_11, NULL);
		int32_t L_13;
		L_13 = Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA(((int32_t)il2cpp_codegen_add(L_10, L_12)), NULL);
		NullCheck(L_3);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(L_4), (int32_t)L_13);
		// for (int i = 0; i < r.links.Length; ++i)
		int32_t L_14 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_14, 1));
	}

IL_0032:
	{
		// for (int i = 0; i < r.links.Length; ++i)
		int32_t L_15 = V_2;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_16 = ___0_r;
		NullCheck(L_16);
		LinkU5BU5D_tEA971C6E9BD6A8A55819AF671098252FC5164C18* L_17 = L_16->___links_4;
		NullCheck(L_17);
		if ((((int32_t)L_15) < ((int32_t)((int32_t)(((RuntimeArray*)L_17)->max_length)))))
		{
			goto IL_0012;
		}
	}
	{
		// List<SpawnPoint> spawn_points = new List<SpawnPoint>();
		List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* L_18 = (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2*)il2cpp_codegen_object_new(List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2_il2cpp_TypeInfo_var);
		NullCheck(L_18);
		List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13(L_18, List_1__ctor_m039E1FC26668506C95211BB1DFC93CEEB8A1BD13_RuntimeMethod_var);
		V_1 = L_18;
		// foreach (SpawnPoint sp in model.spawnpoints)
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_19 = __this->___model_5;
		NullCheck(L_19);
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_20 = L_19->___spawnpoints_4;
		V_3 = L_20;
		V_4 = 0;
		goto IL_00b1;
	}

IL_0054:
	{
		// foreach (SpawnPoint sp in model.spawnpoints)
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_21 = V_3;
		int32_t L_22 = V_4;
		NullCheck(L_21);
		int32_t L_23 = L_22;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_24 = (L_21)->GetAt(static_cast<il2cpp_array_size_t>(L_23));
		V_5 = L_24;
		// if ((Contains(euclidean_links, (int)sp.location) && (sp.needs_wall == NeedsWall.No)) ||
		//    (!Contains(euclidean_links, (int)sp.location) && (sp.needs_wall == NeedsWall.Yes)) ||
		//    (sp.needs_wall == NeedsWall.DoesntMatter))
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_25 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_26 = V_5;
		int32_t L_27 = L_26.___location_2;
		int32_t L_28 = ((int32_t)L_27);
		RuntimeObject* L_29 = Box(Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var, &L_28);
		bool L_30;
		L_30 = DungeonDesigner_Contains_m159F5B7F3AD84DC9185747D461F7224A503E6040((RuntimeArray*)L_25, L_29, NULL);
		if (!L_30)
		{
			goto IL_007b;
		}
	}
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_31 = V_5;
		int32_t L_32 = L_31.___needs_wall_3;
		if (!L_32)
		{
			goto IL_00a3;
		}
	}

IL_007b:
	{
		Int32U5BU5D_t19C97395396A72ECAF310612F0760F165060314C* L_33 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_34 = V_5;
		int32_t L_35 = L_34.___location_2;
		int32_t L_36 = ((int32_t)L_35);
		RuntimeObject* L_37 = Box(Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_il2cpp_TypeInfo_var, &L_36);
		bool L_38;
		L_38 = DungeonDesigner_Contains_m159F5B7F3AD84DC9185747D461F7224A503E6040((RuntimeArray*)L_33, L_37, NULL);
		if (L_38)
		{
			goto IL_0099;
		}
	}
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_39 = V_5;
		int32_t L_40 = L_39.___needs_wall_3;
		if ((((int32_t)L_40) == ((int32_t)1)))
		{
			goto IL_00a3;
		}
	}

IL_0099:
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_41 = V_5;
		int32_t L_42 = L_41.___needs_wall_3;
		if ((!(((uint32_t)L_42) == ((uint32_t)(-1)))))
		{
			goto IL_00ab;
		}
	}

IL_00a3:
	{
		// spawn_points.Add(sp);
		List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* L_43 = V_1;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_44 = V_5;
		NullCheck(L_43);
		List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_inline(L_43, L_44, List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_RuntimeMethod_var);
	}

IL_00ab:
	{
		int32_t L_45 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_45, 1));
	}

IL_00b1:
	{
		// foreach (SpawnPoint sp in model.spawnpoints)
		int32_t L_46 = V_4;
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_47 = V_3;
		NullCheck(L_47);
		if ((((int32_t)L_46) < ((int32_t)((int32_t)(((RuntimeArray*)L_47)->max_length)))))
		{
			goto IL_0054;
		}
	}
	{
		// Model m = r.gameObject.AddComponent<Model>();
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_48 = ___0_r;
		NullCheck(L_48);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_49;
		L_49 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(L_48, NULL);
		NullCheck(L_49);
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_50;
		L_50 = GameObject_AddComponent_TisModel_tC414155249EC7AAC88CDBA8448952AF9525DEC17_mD473FDD0F45F30E0908D9C09D6969E43F9CF0ACF(L_49, GameObject_AddComponent_TisModel_tC414155249EC7AAC88CDBA8448952AF9525DEC17_mD473FDD0F45F30E0908D9C09D6969E43F9CF0ACF_RuntimeMethod_var);
		// m.spawnpoints = spawn_points.ToArray();
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_51 = L_50;
		List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* L_52 = V_1;
		NullCheck(L_52);
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_53;
		L_53 = List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557(L_52, List_1_ToArray_m4D951D4303B8F53ABDB10F2AE23F1FEACA680557_RuntimeMethod_var);
		NullCheck(L_51);
		L_51->___spawnpoints_4 = L_53;
		Il2CppCodeGenWriteBarrier((void**)(&L_51->___spawnpoints_4), (void*)L_53);
		// return m;
		return L_51;
	}
}
// System.Boolean DungeonGenerator.DungeonDesigner::Contains(System.Array,System.Object)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool DungeonDesigner_Contains_m159F5B7F3AD84DC9185747D461F7224A503E6040 (RuntimeArray* ___0_array, RuntimeObject* ___1_value, const RuntimeMethod* method) 
{
	{
		// return Array.IndexOf(array, value) != -1;
		RuntimeArray* L_0 = ___0_array;
		RuntimeObject* L_1 = ___1_value;
		int32_t L_2;
		L_2 = Array_IndexOf_m465D44BD098AF24A76CB69293F87849DEE7EBD5C(L_0, L_1, NULL);
		return (bool)((((int32_t)((((int32_t)L_2) == ((int32_t)(-1)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Void DungeonGenerator.DungeonDesigner::PopulateAll(DungeonGenerator.Dungeon)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_PopulateAll_m23406622813261B8262D4F608C2F6D078150FA62 (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ___0_d, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* V_0 = NULL;
	ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* V_1 = NULL;
	int32_t V_2 = 0;
	ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* V_3 = NULL;
	int32_t V_4 = 0;
	Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* V_5 = NULL;
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* V_6 = NULL;
	int32_t V_7 = 0;
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 V_8;
	memset((&V_8), 0, sizeof(V_8));
	{
		// Room[] dungeon_rooms = getDungeon(d);
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_0 = ___0_d;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_1;
		L_1 = DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F(__this, L_0, NULL);
		V_0 = L_1;
		// Model[] models = new Model[dungeon_rooms.Length];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_2 = V_0;
		NullCheck(L_2);
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_3 = (ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E*)(ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E*)SZArrayNew(ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E_il2cpp_TypeInfo_var, (uint32_t)((int32_t)(((RuntimeArray*)L_2)->max_length)));
		V_1 = L_3;
		// for (int i = 0; i < dungeon_rooms.Length; ++i)
		V_2 = 0;
		goto IL_0025;
	}

IL_0015:
	{
		// models[i] = RoomToModel(dungeon_rooms[i]);
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_4 = V_1;
		int32_t L_5 = V_2;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_6 = V_0;
		int32_t L_7 = V_2;
		NullCheck(L_6);
		int32_t L_8 = L_7;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_9 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_10;
		L_10 = DungeonDesigner_RoomToModel_m7DF305BE8C449842BD12AC327A56C73CAA053B2D(__this, L_9, NULL);
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, L_10);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(L_5), (Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17*)L_10);
		// for (int i = 0; i < dungeon_rooms.Length; ++i)
		int32_t L_11 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_11, 1));
	}

IL_0025:
	{
		// for (int i = 0; i < dungeon_rooms.Length; ++i)
		int32_t L_12 = V_2;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_13 = V_0;
		NullCheck(L_13);
		if ((((int32_t)L_12) < ((int32_t)((int32_t)(((RuntimeArray*)L_13)->max_length)))))
		{
			goto IL_0015;
		}
	}
	{
		// foreach (Model m in models)
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_14 = V_1;
		V_3 = L_14;
		V_4 = 0;
		goto IL_0074;
	}

IL_0032:
	{
		// foreach (Model m in models)
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_15 = V_3;
		int32_t L_16 = V_4;
		NullCheck(L_15);
		int32_t L_17 = L_16;
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_18 = (L_15)->GetAt(static_cast<il2cpp_array_size_t>(L_17));
		V_5 = L_18;
		// foreach (SpawnPoint sp in m.spawnpoints)
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_19 = V_5;
		NullCheck(L_19);
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_20 = L_19->___spawnpoints_4;
		V_6 = L_20;
		V_7 = 0;
		goto IL_0066;
	}

IL_0046:
	{
		// foreach (SpawnPoint sp in m.spawnpoints)
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_21 = V_6;
		int32_t L_22 = V_7;
		NullCheck(L_21);
		int32_t L_23 = L_22;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_24 = (L_21)->GetAt(static_cast<il2cpp_array_size_t>(L_23));
		V_8 = L_24;
		// Spawn(sp, m.GetComponent<Room>());
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_25 = V_8;
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_26 = V_5;
		NullCheck(L_26);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_27;
		L_27 = Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B(L_26, Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		DungeonDesigner_Spawn_mD5742B2869D433DCF9417BAD9C357B7A17E1E4F6(__this, L_25, L_27, NULL);
		int32_t L_28 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_add(L_28, 1));
	}

IL_0066:
	{
		// foreach (SpawnPoint sp in m.spawnpoints)
		int32_t L_29 = V_7;
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_30 = V_6;
		NullCheck(L_30);
		if ((((int32_t)L_29) < ((int32_t)((int32_t)(((RuntimeArray*)L_30)->max_length)))))
		{
			goto IL_0046;
		}
	}
	{
		int32_t L_31 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_31, 1));
	}

IL_0074:
	{
		// foreach (Model m in models)
		int32_t L_32 = V_4;
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_33 = V_3;
		NullCheck(L_33);
		if ((((int32_t)L_32) < ((int32_t)((int32_t)(((RuntimeArray*)L_33)->max_length)))))
		{
			goto IL_0032;
		}
	}
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.DungeonDesigner::Spawn(DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_Spawn_mD5742B2869D433DCF9417BAD9C357B7A17E1E4F6 (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_sp, Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* ___1_r, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CSpawnU3Eb__12_1_m60B3C71B30B827EA6AB771B0EF357E99EA96FE93_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CSpawnU3Eb__12_2_m240F5CF405EC66C270BCD4801ACF20066633CCBE_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CSpawnU3Eb__12_3_mBFB7BEB81624B39BF596D983CB6B71E91BC0C184_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_U3CSpawnU3Eb__12_4_m87F641E977858C2103703711151AF1C00AC926F9_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 V_0;
	memset((&V_0), 0, sizeof(V_0));
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_1;
	memset((&V_1), 0, sizeof(V_1));
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* V_2 = NULL;
	Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 V_3;
	memset((&V_3), 0, sizeof(V_3));
	bool V_4 = false;
	GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* V_5 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* V_6 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* V_7 = NULL;
	Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 V_8;
	memset((&V_8), 0, sizeof(V_8));
	bool V_9 = false;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* V_10 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* V_11 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B6_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B6_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B5_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B5_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B10_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B10_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B9_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B9_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B18_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B18_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B17_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B17_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B22_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B22_1 = NULL;
	Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* G_B21_0 = NULL;
	SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* G_B21_1 = NULL;
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_0 = ___0_sp;
		(&V_0)->___sp_0 = L_0;
		Il2CppCodeGenWriteBarrier((void**)&(((&(&V_0)->___sp_0))->___t_0), (void*)NULL);
		// Vector2 parent_pos = r.position;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_1 = ___1_r;
		NullCheck(L_1);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2;
		L_2 = Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F(L_1, NULL);
		V_1 = L_2;
		// if (sp.type == Type.Loot)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_3 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_4 = L_3.___sp_0;
		int32_t L_5 = L_4.___type_1;
		if ((!(((uint32_t)L_5) == ((uint32_t)1))))
		{
			goto IL_007b;
		}
	}
	{
		// Spawnable s = loot[Random.Range(0, loot.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_6 = __this->___loot_6;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_7 = __this->___loot_6;
		NullCheck(L_7);
		int32_t L_8;
		L_8 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_7)->max_length)), NULL);
		NullCheck(L_6);
		int32_t L_9 = L_8;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_10 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		// GameObject g = Instantiate(s.gameObject, sp.t.position + (Vector3)parent_pos, sp.t.rotation, r.transform);
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_11 = L_10;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_12 = L_11.___gameObject_0;
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_13 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_14 = L_13.___sp_0;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_15 = L_14.___t_0;
		NullCheck(L_15);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_16;
		L_16 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_15, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_17 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_18;
		L_18 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_17, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_19;
		L_19 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_16, L_18, NULL);
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_20 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_21 = L_20.___sp_0;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_22 = L_21.___t_0;
		NullCheck(L_22);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_23;
		L_23 = Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C(L_22, NULL);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_24 = ___1_r;
		NullCheck(L_24);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_25;
		L_25 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_24, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_26;
		L_26 = Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181(L_12, L_19, L_23, L_25, Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181_RuntimeMethod_var);
		V_2 = L_26;
		// FlipCheck(s, g);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_27 = V_2;
		DungeonDesigner_U3CSpawnU3Eg__FlipCheckU7C12_0_m0C267CF9CAE77F246C2E72B68168D4B86FE506F2(L_11, L_27, (&V_0), NULL);
	}

IL_007b:
	{
		// if (sp.type == Type.Decoration)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_28 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_29 = L_28.___sp_0;
		int32_t L_30 = L_29.___type_1;
		if ((!(((uint32_t)L_30) == ((uint32_t)2))))
		{
			goto IL_01a5;
		}
	}
	{
		// Spawnable s = new Spawnable();
		il2cpp_codegen_initobj((&V_3), sizeof(Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9));
		// bool check = false;
		V_4 = (bool)0;
		// if (Model.Orientation(sp) == Orientation.Horizontal)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_31 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_32 = L_31.___sp_0;
		int32_t L_33;
		L_33 = Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A(L_32, NULL);
		if ((!(((uint32_t)L_33) == ((uint32_t)1))))
		{
			goto IL_00eb;
		}
	}
	{
		// Spawnable[] h = decorations.Where(x => x.orientation == Orientation.Horizontal).ToArray();
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_34 = __this->___decorations_7;
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_35 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_1_1;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_36 = L_35;
		G_B5_0 = L_36;
		G_B5_1 = L_34;
		if (L_36)
		{
			G_B6_0 = L_36;
			G_B6_1 = L_34;
			goto IL_00ca;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* L_37 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9_0;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_38 = (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240*)il2cpp_codegen_object_new(Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240_il2cpp_TypeInfo_var);
		NullCheck(L_38);
		Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E(L_38, L_37, (intptr_t)((void*)U3CU3Ec_U3CSpawnU3Eb__12_1_m60B3C71B30B827EA6AB771B0EF357E99EA96FE93_RuntimeMethod_var), NULL);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_39 = L_38;
		((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_1_1 = L_39;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_1_1), (void*)L_39);
		G_B6_0 = L_39;
		G_B6_1 = G_B5_1;
	}

IL_00ca:
	{
		RuntimeObject* L_40;
		L_40 = Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043((RuntimeObject*)G_B6_1, G_B6_0, Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_RuntimeMethod_var);
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_41;
		L_41 = Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358(L_40, Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_RuntimeMethod_var);
		V_6 = L_41;
		// s = h[Random.Range(0, h.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_42 = V_6;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_43 = V_6;
		NullCheck(L_43);
		int32_t L_44;
		L_44 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_43)->max_length)), NULL);
		NullCheck(L_42);
		int32_t L_45 = L_44;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_46 = (L_42)->GetAt(static_cast<il2cpp_array_size_t>(L_45));
		V_3 = L_46;
		// check = true;
		V_4 = (bool)1;
	}

IL_00eb:
	{
		// if (Model.Orientation(sp) == Orientation.Vertical)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_47 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_48 = L_47.___sp_0;
		int32_t L_49;
		L_49 = Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A(L_48, NULL);
		if ((!(((uint32_t)L_49) == ((uint32_t)2))))
		{
			goto IL_013f;
		}
	}
	{
		// Spawnable[] v = decorations.Where(x => x.orientation == Orientation.Vertical).ToArray();
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_50 = __this->___decorations_7;
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_51 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_2_2;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_52 = L_51;
		G_B9_0 = L_52;
		G_B9_1 = L_50;
		if (L_52)
		{
			G_B10_0 = L_52;
			G_B10_1 = L_50;
			goto IL_011e;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* L_53 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9_0;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_54 = (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240*)il2cpp_codegen_object_new(Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240_il2cpp_TypeInfo_var);
		NullCheck(L_54);
		Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E(L_54, L_53, (intptr_t)((void*)U3CU3Ec_U3CSpawnU3Eb__12_2_m240F5CF405EC66C270BCD4801ACF20066633CCBE_RuntimeMethod_var), NULL);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_55 = L_54;
		((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_2_2 = L_55;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_2_2), (void*)L_55);
		G_B10_0 = L_55;
		G_B10_1 = G_B9_1;
	}

IL_011e:
	{
		RuntimeObject* L_56;
		L_56 = Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043((RuntimeObject*)G_B10_1, G_B10_0, Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_RuntimeMethod_var);
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_57;
		L_57 = Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358(L_56, Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_RuntimeMethod_var);
		V_7 = L_57;
		// s = v[Random.Range(0, v.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_58 = V_7;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_59 = V_7;
		NullCheck(L_59);
		int32_t L_60;
		L_60 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_59)->max_length)), NULL);
		NullCheck(L_58);
		int32_t L_61 = L_60;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_62 = (L_58)->GetAt(static_cast<il2cpp_array_size_t>(L_61));
		V_3 = L_62;
		// check = true;
		V_4 = (bool)1;
	}

IL_013f:
	{
		// if (check == false)
		bool L_63 = V_4;
		if (L_63)
		{
			goto IL_015d;
		}
	}
	{
		// s = decorations[Random.Range(0, decorations.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_64 = __this->___decorations_7;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_65 = __this->___decorations_7;
		NullCheck(L_65);
		int32_t L_66;
		L_66 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_65)->max_length)), NULL);
		NullCheck(L_64);
		int32_t L_67 = L_66;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_68 = (L_64)->GetAt(static_cast<il2cpp_array_size_t>(L_67));
		V_3 = L_68;
	}

IL_015d:
	{
		// GameObject g = Instantiate(s.gameObject, sp.t.position + (Vector3)parent_pos, sp.t.rotation, r.transform);
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_69 = V_3;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_70 = L_69.___gameObject_0;
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_71 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_72 = L_71.___sp_0;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_73 = L_72.___t_0;
		NullCheck(L_73);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_74;
		L_74 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_73, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_75 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_76;
		L_76 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_75, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_77;
		L_77 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_74, L_76, NULL);
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_78 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_79 = L_78.___sp_0;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_80 = L_79.___t_0;
		NullCheck(L_80);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_81;
		L_81 = Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C(L_80, NULL);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_82 = ___1_r;
		NullCheck(L_82);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_83;
		L_83 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_82, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_84;
		L_84 = Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181(L_70, L_77, L_81, L_83, Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181_RuntimeMethod_var);
		V_5 = L_84;
		// FlipCheck(s, g);
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_85 = V_3;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_86 = V_5;
		DungeonDesigner_U3CSpawnU3Eg__FlipCheckU7C12_0_m0C267CF9CAE77F246C2E72B68168D4B86FE506F2(L_85, L_86, (&V_0), NULL);
	}

IL_01a5:
	{
		// if (sp.type == Type.Trap)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_87 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_88 = L_87.___sp_0;
		int32_t L_89 = L_88.___type_1;
		if ((!(((uint32_t)L_89) == ((uint32_t)3))))
		{
			goto IL_02c8;
		}
	}
	{
		// Spawnable s = new Spawnable();
		il2cpp_codegen_initobj((&V_8), sizeof(Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9));
		// bool check = false;
		V_9 = (bool)0;
		// if (Model.Orientation(sp) == Orientation.Horizontal)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_90 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_91 = L_90.___sp_0;
		int32_t L_92;
		L_92 = Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A(L_91, NULL);
		if ((!(((uint32_t)L_92) == ((uint32_t)1))))
		{
			goto IL_0216;
		}
	}
	{
		// Spawnable[] h = traps.Where(x => x.orientation == Orientation.Horizontal).ToArray();
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_93 = __this->___traps_8;
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_94 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_3_3;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_95 = L_94;
		G_B17_0 = L_95;
		G_B17_1 = L_93;
		if (L_95)
		{
			G_B18_0 = L_95;
			G_B18_1 = L_93;
			goto IL_01f4;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* L_96 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9_0;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_97 = (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240*)il2cpp_codegen_object_new(Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240_il2cpp_TypeInfo_var);
		NullCheck(L_97);
		Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E(L_97, L_96, (intptr_t)((void*)U3CU3Ec_U3CSpawnU3Eb__12_3_mBFB7BEB81624B39BF596D983CB6B71E91BC0C184_RuntimeMethod_var), NULL);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_98 = L_97;
		((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_3_3 = L_98;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_3_3), (void*)L_98);
		G_B18_0 = L_98;
		G_B18_1 = G_B17_1;
	}

IL_01f4:
	{
		RuntimeObject* L_99;
		L_99 = Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043((RuntimeObject*)G_B18_1, G_B18_0, Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_RuntimeMethod_var);
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_100;
		L_100 = Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358(L_99, Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_RuntimeMethod_var);
		V_10 = L_100;
		// s = h[Random.Range(0, h.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_101 = V_10;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_102 = V_10;
		NullCheck(L_102);
		int32_t L_103;
		L_103 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_102)->max_length)), NULL);
		NullCheck(L_101);
		int32_t L_104 = L_103;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_105 = (L_101)->GetAt(static_cast<il2cpp_array_size_t>(L_104));
		V_8 = L_105;
		// check = true;
		V_9 = (bool)1;
	}

IL_0216:
	{
		// if (Model.Orientation(sp) == Orientation.Vertical)
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_106 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_107 = L_106.___sp_0;
		int32_t L_108;
		L_108 = Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A(L_107, NULL);
		if ((!(((uint32_t)L_108) == ((uint32_t)2))))
		{
			goto IL_026b;
		}
	}
	{
		// Spawnable[] v = traps.Where(x => x.orientation == Orientation.Vertical).ToArray();
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_109 = __this->___traps_8;
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_110 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_4_4;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_111 = L_110;
		G_B21_0 = L_111;
		G_B21_1 = L_109;
		if (L_111)
		{
			G_B22_0 = L_111;
			G_B22_1 = L_109;
			goto IL_0249;
		}
	}
	{
		il2cpp_codegen_runtime_class_init_inline(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* L_112 = ((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9_0;
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_113 = (Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240*)il2cpp_codegen_object_new(Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240_il2cpp_TypeInfo_var);
		NullCheck(L_113);
		Func_2__ctor_m2AE32AE2CC5CF1FEF0B3CC79A4192608B8CA400E(L_113, L_112, (intptr_t)((void*)U3CU3Ec_U3CSpawnU3Eb__12_4_m87F641E977858C2103703711151AF1C00AC926F9_RuntimeMethod_var), NULL);
		Func_2_t72F27487C8B686F0FD682BB3734E68C04DB1B240* L_114 = L_113;
		((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_4_4 = L_114;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9__12_4_4), (void*)L_114);
		G_B22_0 = L_114;
		G_B22_1 = G_B21_1;
	}

IL_0249:
	{
		RuntimeObject* L_115;
		L_115 = Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043((RuntimeObject*)G_B22_1, G_B22_0, Enumerable_Where_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_m69847501F759E2C02B8F7DA54CF19799066DB043_RuntimeMethod_var);
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_116;
		L_116 = Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358(L_115, Enumerable_ToArray_TisSpawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_mD3BACA23BE58C6696F75AB095D523421459AF358_RuntimeMethod_var);
		V_11 = L_116;
		// s = v[Random.Range(0, v.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_117 = V_11;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_118 = V_11;
		NullCheck(L_118);
		int32_t L_119;
		L_119 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_118)->max_length)), NULL);
		NullCheck(L_117);
		int32_t L_120 = L_119;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_121 = (L_117)->GetAt(static_cast<il2cpp_array_size_t>(L_120));
		V_8 = L_121;
		// check = true;
		V_9 = (bool)1;
	}

IL_026b:
	{
		// if (check == false)
		bool L_122 = V_9;
		if (L_122)
		{
			goto IL_028a;
		}
	}
	{
		// s = traps[Random.Range(0, decorations.Length)];
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_123 = __this->___traps_8;
		SpawnableU5BU5D_t01A010BEDB1DA8644AF91F5F3262C10ADD470DF8* L_124 = __this->___decorations_7;
		NullCheck(L_124);
		int32_t L_125;
		L_125 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, ((int32_t)(((RuntimeArray*)L_124)->max_length)), NULL);
		NullCheck(L_123);
		int32_t L_126 = L_125;
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_127 = (L_123)->GetAt(static_cast<il2cpp_array_size_t>(L_126));
		V_8 = L_127;
	}

IL_028a:
	{
		// Instantiate(s.gameObject, sp.t.position + (Vector3)parent_pos, sp.t.rotation, r.transform);
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_128 = V_8;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_129 = L_128.___gameObject_0;
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_130 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_131 = L_130.___sp_0;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_132 = L_131.___t_0;
		NullCheck(L_132);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_133;
		L_133 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_132, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_134 = V_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_135;
		L_135 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_134, NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_136;
		L_136 = Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline(L_133, L_135, NULL);
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4 L_137 = V_0;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_138 = L_137.___sp_0;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_139 = L_138.___t_0;
		NullCheck(L_139);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_140;
		L_140 = Transform_get_rotation_m32AF40CA0D50C797DA639A696F8EAEC7524C179C(L_139, NULL);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_141 = ___1_r;
		NullCheck(L_141);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_142;
		L_142 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(L_141, NULL);
		il2cpp_codegen_runtime_class_init_inline(Object_tC12DECB6760A7F2CBF65D9DCF18D044C2D97152C_il2cpp_TypeInfo_var);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_143;
		L_143 = Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181(L_129, L_136, L_140, L_142, Object_Instantiate_TisGameObject_t76FEDD663AB33C991A9C9A23129337651094216F_mD136E37F696C00A3A1D4F65724ACAE903E385181_RuntimeMethod_var);
	}

IL_02c8:
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.DungeonDesigner::SpawnRandomN(DungeonGenerator.Dungeon,System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_SpawnRandomN_m56C8F4BF0E57401469B33FCBAEFD04340BC89990 (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* ___0_d, int32_t ___1_n, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_Add_mDBE179845F4DD8F7DCD68FFE1AE177FD7E3ED070_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1__ctor_m36B74D51D7FC7F3FE3EC1EE076EAD4EB6DBD5FF1_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ValueTuple_2__ctor_m3315007AD2DBF3F7D006595F0F70623784E08499_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* V_0 = NULL;
	ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* V_1 = NULL;
	List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* V_2 = NULL;
	int32_t V_3 = 0;
	ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* V_4 = NULL;
	int32_t V_5 = 0;
	Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* V_6 = NULL;
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* V_7 = NULL;
	int32_t V_8 = 0;
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 V_9;
	memset((&V_9), 0, sizeof(V_9));
	int32_t V_10 = 0;
	ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE V_11;
	memset((&V_11), 0, sizeof(V_11));
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	{
		// Room[] dungeon_rooms = getDungeon(d);
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_0 = ___0_d;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_1;
		L_1 = DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F(__this, L_0, NULL);
		V_0 = L_1;
		// Model[] models = new Model[dungeon_rooms.Length];
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_2 = V_0;
		NullCheck(L_2);
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_3 = (ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E*)(ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E*)SZArrayNew(ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E_il2cpp_TypeInfo_var, (uint32_t)((int32_t)(((RuntimeArray*)L_2)->max_length)));
		V_1 = L_3;
		// for (int i = 0; i < dungeon_rooms.Length; ++i)
		V_3 = 0;
		goto IL_0025;
	}

IL_0015:
	{
		// models[i] = RoomToModel(dungeon_rooms[i]);
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_4 = V_1;
		int32_t L_5 = V_3;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_6 = V_0;
		int32_t L_7 = V_3;
		NullCheck(L_6);
		int32_t L_8 = L_7;
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_9 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_10;
		L_10 = DungeonDesigner_RoomToModel_m7DF305BE8C449842BD12AC327A56C73CAA053B2D(__this, L_9, NULL);
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, L_10);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(L_5), (Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17*)L_10);
		// for (int i = 0; i < dungeon_rooms.Length; ++i)
		int32_t L_11 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_11, 1));
	}

IL_0025:
	{
		// for (int i = 0; i < dungeon_rooms.Length; ++i)
		int32_t L_12 = V_3;
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_13 = V_0;
		NullCheck(L_13);
		if ((((int32_t)L_12) < ((int32_t)((int32_t)(((RuntimeArray*)L_13)->max_length)))))
		{
			goto IL_0015;
		}
	}
	{
		// List<(SpawnPoint, Room)> spawnPoints = new List<(SpawnPoint, Room)>();
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_14 = (List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F*)il2cpp_codegen_object_new(List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F_il2cpp_TypeInfo_var);
		NullCheck(L_14);
		List_1__ctor_m36B74D51D7FC7F3FE3EC1EE076EAD4EB6DBD5FF1(L_14, List_1__ctor_m36B74D51D7FC7F3FE3EC1EE076EAD4EB6DBD5FF1_RuntimeMethod_var);
		V_2 = L_14;
		// foreach (Model m in models)
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_15 = V_1;
		V_4 = L_15;
		V_5 = 0;
		goto IL_0081;
	}

IL_0039:
	{
		// foreach (Model m in models)
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_16 = V_4;
		int32_t L_17 = V_5;
		NullCheck(L_16);
		int32_t L_18 = L_17;
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_19 = (L_16)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		V_6 = L_19;
		// foreach (SpawnPoint sp in m.spawnpoints)
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_20 = V_6;
		NullCheck(L_20);
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_21 = L_20->___spawnpoints_4;
		V_7 = L_21;
		V_8 = 0;
		goto IL_0073;
	}

IL_004e:
	{
		// foreach (SpawnPoint sp in m.spawnpoints)
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_22 = V_7;
		int32_t L_23 = V_8;
		NullCheck(L_22);
		int32_t L_24 = L_23;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_25 = (L_22)->GetAt(static_cast<il2cpp_array_size_t>(L_24));
		V_9 = L_25;
		// spawnPoints.Add((sp, m.GetComponent<Room>()));
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_26 = V_2;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_27 = V_9;
		Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* L_28 = V_6;
		NullCheck(L_28);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_29;
		L_29 = Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B(L_28, Component_GetComponent_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_m59E87E48C5DA945FAB16E6A5817F4A2EEAED5C3B_RuntimeMethod_var);
		ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE L_30;
		memset((&L_30), 0, sizeof(L_30));
		ValueTuple_2__ctor_m3315007AD2DBF3F7D006595F0F70623784E08499((&L_30), L_27, L_29, /*hidden argument*/ValueTuple_2__ctor_m3315007AD2DBF3F7D006595F0F70623784E08499_RuntimeMethod_var);
		NullCheck(L_26);
		List_1_Add_mDBE179845F4DD8F7DCD68FFE1AE177FD7E3ED070_inline(L_26, L_30, List_1_Add_mDBE179845F4DD8F7DCD68FFE1AE177FD7E3ED070_RuntimeMethod_var);
		int32_t L_31 = V_8;
		V_8 = ((int32_t)il2cpp_codegen_add(L_31, 1));
	}

IL_0073:
	{
		// foreach (SpawnPoint sp in m.spawnpoints)
		int32_t L_32 = V_8;
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_33 = V_7;
		NullCheck(L_33);
		if ((((int32_t)L_32) < ((int32_t)((int32_t)(((RuntimeArray*)L_33)->max_length)))))
		{
			goto IL_004e;
		}
	}
	{
		int32_t L_34 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_34, 1));
	}

IL_0081:
	{
		// foreach (Model m in models)
		int32_t L_35 = V_5;
		ModelU5BU5D_tD9074E663AACB519490F8B5C66CA6D5BD012BB7E* L_36 = V_4;
		NullCheck(L_36);
		if ((((int32_t)L_35) < ((int32_t)((int32_t)(((RuntimeArray*)L_36)->max_length)))))
		{
			goto IL_0039;
		}
	}
	{
		// for (int i = 0; i < spawnPoints.Count(); ++i)
		V_10 = 0;
		goto IL_00c6;
	}

IL_008e:
	{
		// var temp = spawnPoints[i];
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_37 = V_2;
		int32_t L_38 = V_10;
		NullCheck(L_37);
		ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE L_39;
		L_39 = List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B(L_37, L_38, List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B_RuntimeMethod_var);
		V_11 = L_39;
		// int r = Random.Range(0, spawnPoints.Count());
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_40 = V_2;
		int32_t L_41;
		L_41 = Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01(L_40, Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01_RuntimeMethod_var);
		int32_t L_42;
		L_42 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(0, L_41, NULL);
		V_12 = L_42;
		// spawnPoints[i] = spawnPoints[r];
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_43 = V_2;
		int32_t L_44 = V_10;
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_45 = V_2;
		int32_t L_46 = V_12;
		NullCheck(L_45);
		ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE L_47;
		L_47 = List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B(L_45, L_46, List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B_RuntimeMethod_var);
		NullCheck(L_43);
		List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA(L_43, L_44, L_47, List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA_RuntimeMethod_var);
		// spawnPoints[r] = temp;
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_48 = V_2;
		int32_t L_49 = V_12;
		ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE L_50 = V_11;
		NullCheck(L_48);
		List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA(L_48, L_49, L_50, List_1_set_Item_m250E1C2F0E4EFB63DD9181554C9FBD3B9DB591CA_RuntimeMethod_var);
		// for (int i = 0; i < spawnPoints.Count(); ++i)
		int32_t L_51 = V_10;
		V_10 = ((int32_t)il2cpp_codegen_add(L_51, 1));
	}

IL_00c6:
	{
		// for (int i = 0; i < spawnPoints.Count(); ++i)
		int32_t L_52 = V_10;
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_53 = V_2;
		int32_t L_54;
		L_54 = Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01(L_53, Enumerable_Count_TisValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE_m4152E6F2AA97520608C4FD75F99ABF6DDB01FC01_RuntimeMethod_var);
		if ((((int32_t)L_52) < ((int32_t)L_54)))
		{
			goto IL_008e;
		}
	}
	{
		// for (int i = 0; i <= n; ++i)
		V_13 = 0;
		goto IL_00fb;
	}

IL_00d5:
	{
		// Spawn(spawnPoints[i].Item1, spawnPoints[i].Item2);
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_55 = V_2;
		int32_t L_56 = V_13;
		NullCheck(L_55);
		ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE L_57;
		L_57 = List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B(L_55, L_56, List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B_RuntimeMethod_var);
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_58 = L_57.___Item1_0;
		List_1_t7E5397359952F25EEDB1BE8236B8B474B593A78F* L_59 = V_2;
		int32_t L_60 = V_13;
		NullCheck(L_59);
		ValueTuple_2_t101177C367F07262B9C4D28A9A92A1ED137195CE L_61;
		L_61 = List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B(L_59, L_60, List_1_get_Item_m7DF0C479A0174E7CF34F9E1973060646307BF82B_RuntimeMethod_var);
		Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* L_62 = L_61.___Item2_1;
		DungeonDesigner_Spawn_mD5742B2869D433DCF9417BAD9C357B7A17E1E4F6(__this, L_58, L_62, NULL);
		// for (int i = 0; i <= n; ++i)
		int32_t L_63 = V_13;
		V_13 = ((int32_t)il2cpp_codegen_add(L_63, 1));
	}

IL_00fb:
	{
		// for (int i = 0; i <= n; ++i)
		int32_t L_64 = V_13;
		int32_t L_65 = ___1_n;
		if ((((int32_t)L_64) <= ((int32_t)L_65)))
		{
			goto IL_00d5;
		}
	}
	{
		// }
		return;
	}
}
// System.Void DungeonGenerator.DungeonDesigner::Awake()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_Awake_m590402CE7A4F6FBE0FE01C3138DBC10860169C0B (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteral121E3C04443BF8E117A53A4EA6445D0FAE0FDDF7);
		s_Il2CppMethodInitialized = true;
	}
	{
		// StartCoroutine("DecorateDungeon");
		Coroutine_t85EA685566A254C23F3FD77AB5BDFFFF8799596B* L_0;
		L_0 = MonoBehaviour_StartCoroutine_m10C4B693B96175C42B0FD00911E072701C220DB4(__this, _stringLiteral121E3C04443BF8E117A53A4EA6445D0FAE0FDDF7, NULL);
		// }
		return;
	}
}
// System.Collections.IEnumerator DungeonGenerator.DungeonDesigner::DecorateDungeon()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* DungeonDesigner_DecorateDungeon_m42A5ECCDE936DDB8A71B8ED2C604DFE2D068ED8D (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* L_0 = (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC*)il2cpp_codegen_object_new(U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		U3CDecorateDungeonU3Ed__17__ctor_m1ED48BFA78B792EC4E43CDA3E496583F5172F37B(L_0, 0, NULL);
		U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* L_1 = L_0;
		NullCheck(L_1);
		L_1->___U3CU3E4__this_2 = __this;
		Il2CppCodeGenWriteBarrier((void**)(&L_1->___U3CU3E4__this_2), (void*)__this);
		return L_1;
	}
}
// System.Void DungeonGenerator.DungeonDesigner::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner__ctor_m25B3DCC8CB97E0FA5AFCD8AD409262788EA7EA3A (DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* __this, const RuntimeMethod* method) 
{
	{
		// public float min_spawn_ratio = 1.5f;
		__this->___min_spawn_ratio_9 = (1.5f);
		// public float max_spawn_ratio = 4f;
		__this->___max_spawn_ratio_10 = (4.0f);
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
// System.Void DungeonGenerator.DungeonDesigner::<Spawn>g__FlipCheck|12_0(DungeonGenerator.DungeonDesigner/Spawnable,UnityEngine.GameObject,DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0&)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void DungeonDesigner_U3CSpawnU3Eg__FlipCheckU7C12_0_m0C267CF9CAE77F246C2E72B68168D4B86FE506F2 (Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 ___0_s, GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* ___1_g, U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4* ___2_p, const RuntimeMethod* method) 
{
	{
		// if (s.can_flip == CanFlip.Yes && sp.t.position.x > 0)
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_0 = ___0_s;
		int32_t L_1 = L_0.___can_flip_2;
		if ((!(((uint32_t)L_1) == ((uint32_t)1))))
		{
			goto IL_0066;
		}
	}
	{
		U3CU3Ec__DisplayClass12_0_t24582CA9185E5F266AC84BEFBE85C949E2C219D4* L_2 = ___2_p;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0* L_3 = (SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0*)(&L_2->___sp_0);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_4 = L_3->___t_0;
		NullCheck(L_4);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_5;
		L_5 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_4, NULL);
		float L_6 = L_5.___x_2;
		if ((!(((float)L_6) > ((float)(0.0f)))))
		{
			goto IL_0066;
		}
	}
	{
		// g.transform.localScale = new Vector3(-g.transform.localScale.x, g.transform.localScale.y, g.transform.localScale.z);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_7 = ___1_g;
		NullCheck(L_7);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_8;
		L_8 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_7, NULL);
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_9 = ___1_g;
		NullCheck(L_9);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_10;
		L_10 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_9, NULL);
		NullCheck(L_10);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_11;
		L_11 = Transform_get_localScale_m804A002A53A645CDFCD15BB0F37209162720363F(L_10, NULL);
		float L_12 = L_11.___x_2;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_13 = ___1_g;
		NullCheck(L_13);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_14;
		L_14 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_13, NULL);
		NullCheck(L_14);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_15;
		L_15 = Transform_get_localScale_m804A002A53A645CDFCD15BB0F37209162720363F(L_14, NULL);
		float L_16 = L_15.___y_3;
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_17 = ___1_g;
		NullCheck(L_17);
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_18;
		L_18 = GameObject_get_transform_m0BC10ADFA1632166AE5544BDF9038A2650C2AE56(L_17, NULL);
		NullCheck(L_18);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_19;
		L_19 = Transform_get_localScale_m804A002A53A645CDFCD15BB0F37209162720363F(L_18, NULL);
		float L_20 = L_19.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_21;
		memset((&L_21), 0, sizeof(L_21));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_21), ((-L_12)), L_16, L_20, /*hidden argument*/NULL);
		NullCheck(L_8);
		Transform_set_localScale_mBA79E811BAF6C47B80FF76414C12B47B3CD03633(L_8, L_21, NULL);
	}

IL_0066:
	{
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: DungeonGenerator.DungeonDesigner/Spawnable
IL2CPP_EXTERN_C void Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshal_pinvoke(const Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9& unmarshaled, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_pinvoke& marshaled)
{
	Exception_t* ___gameObject_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'gameObject' of type 'Spawnable': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___gameObject_0Exception, NULL);
}
IL2CPP_EXTERN_C void Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshal_pinvoke_back(const Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_pinvoke& marshaled, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9& unmarshaled)
{
	Exception_t* ___gameObject_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'gameObject' of type 'Spawnable': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___gameObject_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: DungeonGenerator.DungeonDesigner/Spawnable
IL2CPP_EXTERN_C void Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshal_pinvoke_cleanup(Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: DungeonGenerator.DungeonDesigner/Spawnable
IL2CPP_EXTERN_C void Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshal_com(const Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9& unmarshaled, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_com& marshaled)
{
	Exception_t* ___gameObject_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'gameObject' of type 'Spawnable': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___gameObject_0Exception, NULL);
}
IL2CPP_EXTERN_C void Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshal_com_back(const Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_com& marshaled, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9& unmarshaled)
{
	Exception_t* ___gameObject_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'gameObject' of type 'Spawnable': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___gameObject_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: DungeonGenerator.DungeonDesigner/Spawnable
IL2CPP_EXTERN_C void Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshal_com_cleanup(Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.DungeonDesigner/<>c::.cctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m6E63BFEAE3BAC3EB1B9B8CDE7A98A610C3499DBB (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* L_0 = (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655*)il2cpp_codegen_object_new(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var);
		NullCheck(L_0);
		U3CU3Ec__ctor_mD27026C1F9A45AA0C1D922C1165B4629D17494FC(L_0, NULL);
		((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9_0 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655_il2cpp_TypeInfo_var))->___U3CU3E9_0), (void*)L_0);
		return;
	}
}
// System.Void DungeonGenerator.DungeonDesigner/<>c::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_mD27026C1F9A45AA0C1D922C1165B4629D17494FC (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
// System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_1(DungeonGenerator.DungeonDesigner/Spawnable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSpawnU3Eb__12_1_m60B3C71B30B827EA6AB771B0EF357E99EA96FE93 (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* __this, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 ___0_x, const RuntimeMethod* method) 
{
	{
		// Spawnable[] h = decorations.Where(x => x.orientation == Orientation.Horizontal).ToArray();
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_0 = ___0_x;
		int32_t L_1 = L_0.___orientation_1;
		return (bool)((((int32_t)L_1) == ((int32_t)1))? 1 : 0);
	}
}
// System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_2(DungeonGenerator.DungeonDesigner/Spawnable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSpawnU3Eb__12_2_m240F5CF405EC66C270BCD4801ACF20066633CCBE (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* __this, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 ___0_x, const RuntimeMethod* method) 
{
	{
		// Spawnable[] v = decorations.Where(x => x.orientation == Orientation.Vertical).ToArray();
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_0 = ___0_x;
		int32_t L_1 = L_0.___orientation_1;
		return (bool)((((int32_t)L_1) == ((int32_t)2))? 1 : 0);
	}
}
// System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_3(DungeonGenerator.DungeonDesigner/Spawnable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSpawnU3Eb__12_3_mBFB7BEB81624B39BF596D983CB6B71E91BC0C184 (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* __this, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 ___0_x, const RuntimeMethod* method) 
{
	{
		// Spawnable[] h = traps.Where(x => x.orientation == Orientation.Horizontal).ToArray();
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_0 = ___0_x;
		int32_t L_1 = L_0.___orientation_1;
		return (bool)((((int32_t)L_1) == ((int32_t)1))? 1 : 0);
	}
}
// System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_4(DungeonGenerator.DungeonDesigner/Spawnable)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CU3Ec_U3CSpawnU3Eb__12_4_m87F641E977858C2103703711151AF1C00AC926F9 (U3CU3Ec_tA42E9FBAA0B02A84FCE5861C547781A39879E655* __this, Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 ___0_x, const RuntimeMethod* method) 
{
	{
		// Spawnable[] v = traps.Where(x => x.orientation == Orientation.Vertical).ToArray();
		Spawnable_t5D2F726B1AB725443F314DAB1386997015F3B3C9 L_0 = ___0_x;
		int32_t L_1 = L_0.___orientation_1;
		return (bool)((((int32_t)L_1) == ((int32_t)2))? 1 : 0);
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDecorateDungeonU3Ed__17__ctor_m1ED48BFA78B792EC4E43CDA3E496583F5172F37B (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, int32_t ___0_U3CU3E1__state, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		int32_t L_0 = ___0_U3CU3E1__state;
		__this->___U3CU3E1__state_0 = L_0;
		return;
	}
}
// System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.IDisposable.Dispose()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDecorateDungeonU3Ed__17_System_IDisposable_Dispose_m3776D2A1B0B1A3C045361C21C836F67290AAFDC9 (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, const RuntimeMethod* method) 
{
	{
		return;
	}
}
// System.Boolean DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::MoveNext()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool U3CDecorateDungeonU3Ed__17_MoveNext_m2B94D724615515BC2B269E525B22D5F530996294 (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Enumerable_Count_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_mB2A88D089B3CEC205E70A7BB7292844B04AD56D9_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* V_1 = NULL;
	int32_t V_2 = 0;
	{
		int32_t L_0 = __this->___U3CU3E1__state_0;
		V_0 = L_0;
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_1 = __this->___U3CU3E4__this_2;
		V_1 = L_1;
		int32_t L_2 = V_0;
		if (!L_2)
		{
			goto IL_0017;
		}
	}
	{
		int32_t L_3 = V_0;
		if ((((int32_t)L_3) == ((int32_t)1)))
		{
			goto IL_002e;
		}
	}
	{
		return (bool)0;
	}

IL_0017:
	{
		__this->___U3CU3E1__state_0 = (-1);
		// yield return null;
		__this->___U3CU3E2__current_1 = NULL;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___U3CU3E2__current_1), (void*)NULL);
		__this->___U3CU3E1__state_0 = 1;
		return (bool)1;
	}

IL_002e:
	{
		__this->___U3CU3E1__state_0 = (-1);
		// int multiplier = getDungeon(dungeon).Count();
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_4 = V_1;
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_5 = V_1;
		NullCheck(L_5);
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_6 = L_5->___dungeon_4;
		NullCheck(L_4);
		RoomU5BU5D_tB15C24679278F6C05B740B22E1A4BA86EE195AC3* L_7;
		L_7 = DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F(L_4, L_6, NULL);
		int32_t L_8;
		L_8 = Enumerable_Count_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_mB2A88D089B3CEC205E70A7BB7292844B04AD56D9((RuntimeObject*)L_7, Enumerable_Count_TisRoom_tD73D04FF0B9E743C836C5550CD2FCACD2183A404_mB2A88D089B3CEC205E70A7BB7292844B04AD56D9_RuntimeMethod_var);
		V_2 = L_8;
		// SpawnRandomN(dungeon, Random.Range((int)(multiplier * min_spawn_ratio), (int)(multiplier * max_spawn_ratio)));
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_9 = V_1;
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_10 = V_1;
		NullCheck(L_10);
		Dungeon_tB963FD4B60995FF36AB12F8E59810EC5BFE7E75B* L_11 = L_10->___dungeon_4;
		int32_t L_12 = V_2;
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_13 = V_1;
		NullCheck(L_13);
		float L_14 = L_13->___min_spawn_ratio_9;
		int32_t L_15 = V_2;
		DungeonDesigner_t43A7ACC3CDFCBF4F6E177B59375F1E06D6AF64D6* L_16 = V_1;
		NullCheck(L_16);
		float L_17 = L_16->___max_spawn_ratio_10;
		int32_t L_18;
		L_18 = Random_Range_m6763D9767F033357F88B6637F048F4ACA4123B68(il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_multiply(((float)L_12), L_14))), il2cpp_codegen_cast_double_to_int<int32_t>(((float)il2cpp_codegen_multiply(((float)L_15), L_17))), NULL);
		NullCheck(L_9);
		DungeonDesigner_SpawnRandomN_m56C8F4BF0E57401469B33FCBAEFD04340BC89990(L_9, L_11, L_18, NULL);
		// }
		return (bool)0;
	}
}
// System.Object DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CDecorateDungeonU3Ed__17_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m07B60834727E843AD189567EB9E4A49C4C64FC20 (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->___U3CU3E2__current_1;
		return L_0;
	}
}
// System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.Collections.IEnumerator.Reset()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_Reset_m5DA478BBBA8FEE33F186D61520F10B132227BED2 (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, const RuntimeMethod* method) 
{
	{
		NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A* L_0 = (NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A*)il2cpp_codegen_object_new(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&NotSupportedException_t1429765983D409BD2986508963C98D214E4EBF4A_il2cpp_TypeInfo_var)));
		NullCheck(L_0);
		NotSupportedException__ctor_m1398D0CDE19B36AA3DE9392879738C1EA2439CDF(L_0, NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0, ((RuntimeMethod*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_Reset_m5DA478BBBA8FEE33F186D61520F10B132227BED2_RuntimeMethod_var)));
	}
}
// System.Object DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.Collections.IEnumerator.get_Current()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RuntimeObject* U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_get_Current_m85BB93CF408EFB73A4F700B3DEA4472D8C89C793 (U3CDecorateDungeonU3Ed__17_t59E353095D8A48ABAD406B73EF646F99C65DC0EC* __this, const RuntimeMethod* method) 
{
	{
		RuntimeObject* L_0 = __this->___U3CU3E2__current_1;
		return L_0;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.Model::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Model__ctor_m0FB6FFD9DCAB32E41C0CC2FA501DB8963C0361EF (Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* __this, const RuntimeMethod* method) 
{
	{
		// public Model()
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		// }
		return;
	}
}
// System.Void DungeonGenerator.Model::.ctor(DungeonGenerator.Model/SpawnPoint[])
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Model__ctor_m05A1645191AA545C4412C449D4FF2444E42EFBAE (Model_tC414155249EC7AAC88CDBA8448952AF9525DEC17* __this, SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* ___0_spawnpoints, const RuntimeMethod* method) 
{
	{
		// public Model(SpawnPoint[] spawnpoints)
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		// this.spawnpoints = spawnpoints;
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_0 = ___0_spawnpoints;
		__this->___spawnpoints_4 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___spawnpoints_4), (void*)L_0);
		// }
		return;
	}
}
// DungeonGenerator.DungeonDesigner/Orientation DungeonGenerator.Model::Orientation(DungeonGenerator.Model/SpawnPoint)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A (SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_sp, const RuntimeMethod* method) 
{
	{
		// if (sp.location == Location.None)
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_0 = ___0_sp;
		int32_t L_1 = L_0.___location_2;
		if ((!(((uint32_t)L_1) == ((uint32_t)((int32_t)360)))))
		{
			goto IL_000f;
		}
	}
	{
		// return DungeonDesigner.Orientation.None;
		return (int32_t)(0);
	}

IL_000f:
	{
		// if ((sp.location == Location.Right) || (sp.location == Location.Left))
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_2 = ___0_sp;
		int32_t L_3 = L_2.___location_2;
		if (!L_3)
		{
			goto IL_0024;
		}
	}
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_4 = ___0_sp;
		int32_t L_5 = L_4.___location_2;
		if ((!(((uint32_t)L_5) == ((uint32_t)((int32_t)180)))))
		{
			goto IL_0026;
		}
	}

IL_0024:
	{
		// return DungeonDesigner.Orientation.Horizontal;
		return (int32_t)(1);
	}

IL_0026:
	{
		// if ((sp.location == Location.Top) || (sp.location == Location.Bottom))
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_6 = ___0_sp;
		int32_t L_7 = L_6.___location_2;
		if ((((int32_t)L_7) == ((int32_t)((int32_t)90))))
		{
			goto IL_003d;
		}
	}
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_8 = ___0_sp;
		int32_t L_9 = L_8.___location_2;
		if ((!(((uint32_t)L_9) == ((uint32_t)((int32_t)270)))))
		{
			goto IL_003f;
		}
	}

IL_003d:
	{
		// return DungeonDesigner.Orientation.Vertical;
		return (int32_t)(2);
	}

IL_003f:
	{
		// return DungeonDesigner.Orientation.None;
		return (int32_t)(0);
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: DungeonGenerator.Model/SpawnPoint
IL2CPP_EXTERN_C void SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshal_pinvoke(const SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0& unmarshaled, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_pinvoke& marshaled)
{
	Exception_t* ___t_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 't' of type 'SpawnPoint': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___t_0Exception, NULL);
}
IL2CPP_EXTERN_C void SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshal_pinvoke_back(const SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_pinvoke& marshaled, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0& unmarshaled)
{
	Exception_t* ___t_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 't' of type 'SpawnPoint': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___t_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: DungeonGenerator.Model/SpawnPoint
IL2CPP_EXTERN_C void SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshal_pinvoke_cleanup(SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: DungeonGenerator.Model/SpawnPoint
IL2CPP_EXTERN_C void SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshal_com(const SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0& unmarshaled, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_com& marshaled)
{
	Exception_t* ___t_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 't' of type 'SpawnPoint': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___t_0Exception, NULL);
}
IL2CPP_EXTERN_C void SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshal_com_back(const SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_com& marshaled, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0& unmarshaled)
{
	Exception_t* ___t_0Exception = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 't' of type 'SpawnPoint': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___t_0Exception, NULL);
}
// Conversion method for clean up from marshalling of: DungeonGenerator.Model/SpawnPoint
IL2CPP_EXTERN_C void SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshal_com_cleanup(SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0_marshaled_com& marshaled)
{
}
// System.Void DungeonGenerator.Model/SpawnPoint::.ctor(UnityEngine.Transform,DungeonGenerator.Model/Type,DungeonGenerator.Model/Location,DungeonGenerator.Model/NeedsWall)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22 (SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0* __this, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___0_t, int32_t ___1_type, int32_t ___2_location, int32_t ___3_needs_wall, const RuntimeMethod* method) 
{
	{
		// this.t = t;
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_0 = ___0_t;
		__this->___t_0 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&__this->___t_0), (void*)L_0);
		// this.type = type;
		int32_t L_1 = ___1_type;
		__this->___type_1 = L_1;
		// this.location = location;
		int32_t L_2 = ___2_location;
		__this->___location_2 = L_2;
		// this.needs_wall = needs_wall;
		int32_t L_3 = ___3_needs_wall;
		__this->___needs_wall_3 = L_3;
		// }
		return;
	}
}
IL2CPP_EXTERN_C  void SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22_AdjustorThunk (RuntimeObject* __this, Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___0_t, int32_t ___1_type, int32_t ___2_location, int32_t ___3_needs_wall, const RuntimeMethod* method)
{
	SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0*>(__this + _offset);
	SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22(_thisAdjusted, ___0_t, ___1_type, ___2_location, ___3_needs_wall, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 DungeonGenerator.Room::get_rotation()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) 
{
	{
		// public int rotation { get { return (int)transform.eulerAngles.z; } set { transform.eulerAngles = new Vector3(0, 0, value); } }
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_0;
		L_0 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		NullCheck(L_0);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1;
		L_1 = Transform_get_eulerAngles_mCAAF48EFCF628F1ED91C2FFE75A4FD19C039DD6A(L_0, NULL);
		float L_2 = L_1.___z_4;
		return il2cpp_codegen_cast_double_to_int<int32_t>(L_2);
	}
}
// System.Void DungeonGenerator.Room::set_rotation(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Room_set_rotation_m436F74FF610C99B98252E1DD84C68089F9FC46A9 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		// public int rotation { get { return (int)transform.eulerAngles.z; } set { transform.eulerAngles = new Vector3(0, 0, value); } }
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_0;
		L_0 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		int32_t L_1 = ___0_value;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2;
		memset((&L_2), 0, sizeof(L_2));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_2), (0.0f), (0.0f), ((float)L_1), /*hidden argument*/NULL);
		NullCheck(L_0);
		Transform_set_eulerAngles_m9F0BC484A7915A51FAB87230644229B75BACA004(L_0, L_2, NULL);
		// public int rotation { get { return (int)transform.eulerAngles.z; } set { transform.eulerAngles = new Vector3(0, 0, value); } }
		return;
	}
}
// UnityEngine.Vector2 DungeonGenerator.Room::get_position()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) 
{
	{
		// public Vector2 position { get { return transform.position; } set { transform.position = value; } }
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_0;
		L_0 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		NullCheck(L_0);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_1;
		L_1 = Transform_get_position_m69CD5FA214FDAE7BB701552943674846C220FDE1(L_0, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2;
		L_2 = Vector2_op_Implicit_mE8EBEE9291F11BB02F062D6E000F4798968CBD96_inline(L_1, NULL);
		return L_2;
	}
}
// System.Void DungeonGenerator.Room::set_position(UnityEngine.Vector2)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Room_set_position_m6AE5E1964F76BC88D453111FA7535ECB00AAF44D (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_value, const RuntimeMethod* method) 
{
	{
		// public Vector2 position { get { return transform.position; } set { transform.position = value; } }
		Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* L_0;
		L_0 = Component_get_transform_m2919A1D81931E6932C7F06D4C2F0AB8DDA9A5371(__this, NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1 = ___0_value;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2;
		L_2 = Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline(L_1, NULL);
		NullCheck(L_0);
		Transform_set_position_mA1A817124BB41B685043DED2A9BA48CDF37C4156(L_0, L_2, NULL);
		// public Vector2 position { get { return transform.position; } set { transform.position = value; } }
		return;
	}
}
// System.Void DungeonGenerator.Room::ActivateGraphics(System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Room_ActivateGraphics_mD775D2203F51E0CB69D089C1BFBDB85996B34BE4 (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, bool ___0_generate_skeleton, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&GameObject_AddComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_mDC33421D7DA59610EEC9A5E208A162DF9934C391_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* V_1 = NULL;
	int32_t V_2 = 0;
	{
		// int r = rotation / 90;
		int32_t L_0;
		L_0 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(__this, NULL);
		V_0 = ((int32_t)(L_0/((int32_t)90)));
		goto IL_0017;
	}

IL_000c:
	{
		// r -= graphics.Length;
		int32_t L_1 = V_0;
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_2 = __this->___graphics_5;
		NullCheck(L_2);
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_1, ((int32_t)(((RuntimeArray*)L_2)->max_length))));
	}

IL_0017:
	{
		// while (r >= graphics.Length)
		int32_t L_3 = V_0;
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_4 = __this->___graphics_5;
		NullCheck(L_4);
		if ((((int32_t)L_3) >= ((int32_t)((int32_t)(((RuntimeArray*)L_4)->max_length)))))
		{
			goto IL_000c;
		}
	}
	{
		// GetComponent<SpriteRenderer>().sprite = graphics[r].sprite;
		SpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B* L_5;
		L_5 = Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45(__this, Component_GetComponent_TisSpriteRenderer_t1DD7FE258F072E1FA87D6577BA27225892B8047B_m6181F10C09FC1650DAE0EF2308D344A2F170AA45_RuntimeMethod_var);
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_6 = __this->___graphics_5;
		int32_t L_7 = V_0;
		NullCheck(L_6);
		int32_t L_8 = L_7;
		Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* L_9 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		NullCheck(L_9);
		Sprite_tAFF74BC83CD68037494CB0B4F28CBDF8971CAB99* L_10 = L_9->___sprite_0;
		NullCheck(L_5);
		SpriteRenderer_set_sprite_m7B176E33955108C60CAE21DFC153A0FAC674CB53(L_5, L_10, NULL);
		// activation_rotation = rotation;
		int32_t L_11;
		L_11 = Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415(__this, NULL);
		__this->___activation_rotation_6 = L_11;
		// rotation = 0;
		Room_set_rotation_m436F74FF610C99B98252E1DD84C68089F9FC46A9(__this, 0, NULL);
		// if (!generate_skeleton)
		bool L_12 = ___0_generate_skeleton;
		if (L_12)
		{
			goto IL_0051;
		}
	}
	{
		// return;
		return;
	}

IL_0051:
	{
		// PolygonCollider2D poly = gameObject.AddComponent<PolygonCollider2D>();
		GameObject_t76FEDD663AB33C991A9C9A23129337651094216F* L_13;
		L_13 = Component_get_gameObject_m57AEFBB14DB39EC476F740BA000E170355DE691B(__this, NULL);
		NullCheck(L_13);
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_14;
		L_14 = GameObject_AddComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_mDC33421D7DA59610EEC9A5E208A162DF9934C391(L_13, GameObject_AddComponent_TisPolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E_mDC33421D7DA59610EEC9A5E208A162DF9934C391_RuntimeMethod_var);
		V_1 = L_14;
		// poly.pathCount = graphics[r].collider.pathCount;
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_15 = V_1;
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_16 = __this->___graphics_5;
		int32_t L_17 = V_0;
		NullCheck(L_16);
		int32_t L_18 = L_17;
		Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* L_19 = (L_16)->GetAt(static_cast<il2cpp_array_size_t>(L_18));
		NullCheck(L_19);
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_20 = L_19->___collider_1;
		NullCheck(L_20);
		int32_t L_21;
		L_21 = PolygonCollider2D_get_pathCount_m2F7EA6C9D0D7E579741DD3CB26BD1B2320570CC3(L_20, NULL);
		NullCheck(L_15);
		PolygonCollider2D_set_pathCount_m088370F58AC70DE6D28029AB0F2443D6A9B87721(L_15, L_21, NULL);
		// for (int i = 0; i < graphics[r].collider.pathCount; i++)
		V_2 = 0;
		goto IL_0097;
	}

IL_0079:
	{
		// poly.SetPath(i, graphics[r].collider.GetPath(i));
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_22 = V_1;
		int32_t L_23 = V_2;
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_24 = __this->___graphics_5;
		int32_t L_25 = V_0;
		NullCheck(L_24);
		int32_t L_26 = L_25;
		Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* L_27 = (L_24)->GetAt(static_cast<il2cpp_array_size_t>(L_26));
		NullCheck(L_27);
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_28 = L_27->___collider_1;
		int32_t L_29 = V_2;
		NullCheck(L_28);
		Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* L_30;
		L_30 = PolygonCollider2D_GetPath_mE9D53D83FBB110EAC748BA535A1659C262B50F50(L_28, L_29, NULL);
		NullCheck(L_22);
		PolygonCollider2D_SetPath_mDF03B6FDAE81E25C985F9BA6D372D949A6D9A1C1(L_22, L_23, L_30, NULL);
		// for (int i = 0; i < graphics[r].collider.pathCount; i++)
		int32_t L_31 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_31, 1));
	}

IL_0097:
	{
		// for (int i = 0; i < graphics[r].collider.pathCount; i++)
		int32_t L_32 = V_2;
		GraphicU5BU5D_t65BE07BE20EF82B33A9553CE9F40F700CADF69D2* L_33 = __this->___graphics_5;
		int32_t L_34 = V_0;
		NullCheck(L_33);
		int32_t L_35 = L_34;
		Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* L_36 = (L_33)->GetAt(static_cast<il2cpp_array_size_t>(L_35));
		NullCheck(L_36);
		PolygonCollider2D_t7CEFFFEE6522175436B408712B052D236889C89E* L_37 = L_36->___collider_1;
		NullCheck(L_37);
		int32_t L_38;
		L_38 = PolygonCollider2D_get_pathCount_m2F7EA6C9D0D7E579741DD3CB26BD1B2320570CC3(L_37, NULL);
		if ((((int32_t)L_32) < ((int32_t)L_38)))
		{
			goto IL_0079;
		}
	}
	{
		// }
		return;
	}
}
// System.Int32 DungeonGenerator.Room::GetActivationRotation()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Room_GetActivationRotation_mD585EEAC58FCB6AB88F219D9E624038EF7C37D1C (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) 
{
	{
		// return activation_rotation;
		int32_t L_0 = __this->___activation_rotation_6;
		return L_0;
	}
}
// System.Void DungeonGenerator.Room::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Room__ctor_m5AA1689F9308ACE3C097A309725BB48A0DD8D4CD (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) 
{
	{
		MonoBehaviour__ctor_m592DB0105CA0BC97AA1C5F4AD27B12D68A3B7C1E(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.Room/Link::.ctor(System.Int32,System.Boolean)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Link__ctor_m43A114F7E47CE536A887DE0ED6AC1832C119F7E7 (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* __this, int32_t ___0_angle, bool ___1_can_generate, const RuntimeMethod* method) 
{
	{
		// public bool can_generate = true;
		__this->___can_generate_1 = (bool)1;
		// public Link(int angle, bool can_generate)
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		// this.angle = angle;
		int32_t L_0 = ___0_angle;
		__this->___angle_0 = L_0;
		// this.can_generate = can_generate;
		bool L_1 = ___1_can_generate;
		__this->___can_generate_1 = L_1;
		// }
		return;
	}
}
// System.Void DungeonGenerator.Room/Link::.ctor(System.Int32)
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB (Link_t6F995E8CE4CD80D1BC8581B21135D7DE57CA04A4* __this, int32_t ___0_angle, const RuntimeMethod* method) 
{
	{
		// public bool can_generate = true;
		__this->___can_generate_1 = (bool)1;
		// public Link(int angle)
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		// this.angle = angle;
		int32_t L_0 = ___0_angle;
		__this->___angle_0 = L_0;
		// this.can_generate = true;
		__this->___can_generate_1 = (bool)1;
		// }
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void DungeonGenerator.Room/Graphic::.ctor()
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Graphic__ctor_m34E3C7ECA3E4289DA95D6D6C45683CB7D144E4B1 (Graphic_t466CF34EB04EE2A185AE74760B4AED5B648DC6AD* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Mathf_Clamp_mEB9AEA827D27D20FCC787F7375156AF46BB12BBF_inline (float ___0_value, float ___1_min, float ___2_max, const RuntimeMethod* method) 
{
	bool V_0 = false;
	bool V_1 = false;
	float V_2 = 0.0f;
	{
		float L_0 = ___0_value;
		float L_1 = ___1_min;
		V_0 = (bool)((((float)L_0) < ((float)L_1))? 1 : 0);
		bool L_2 = V_0;
		if (!L_2)
		{
			goto IL_000e;
		}
	}
	{
		float L_3 = ___1_min;
		___0_value = L_3;
		goto IL_0019;
	}

IL_000e:
	{
		float L_4 = ___0_value;
		float L_5 = ___2_max;
		V_1 = (bool)((((float)L_4) > ((float)L_5))? 1 : 0);
		bool L_6 = V_1;
		if (!L_6)
		{
			goto IL_0019;
		}
	}
	{
		float L_7 = ___2_max;
		___0_value = L_7;
	}

IL_0019:
	{
		float L_8 = ___0_value;
		V_2 = L_8;
		goto IL_001d;
	}

IL_001d:
	{
		float L_9 = V_2;
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2Int_op_Implicit_m5B9FB268943E6CAB6E40E13D30BA49A9AC7D2059_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_v, const RuntimeMethod* method) 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		int32_t L_0;
		L_0 = Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline((&___0_v), NULL);
		int32_t L_1;
		L_1 = Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline((&___0_v), NULL);
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2;
		memset((&L_2), 0, sizeof(L_2));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_2), ((float)L_0), ((float)L_1), /*hidden argument*/NULL);
		V_0 = L_2;
		goto IL_0019;
	}

IL_0019:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3 = V_0;
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Subtraction_m44475FCDAD2DA2F98D78A6625EC2DCDFE8803837_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___1_b, const RuntimeMethod* method) 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_a;
		float L_1 = L_0.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___1_b;
		float L_3 = L_2.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4 = ___0_a;
		float L_5 = L_4.___y_1;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_6 = ___1_b;
		float L_7 = L_6.___y_1;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_8;
		memset((&L_8), 0, sizeof(L_8));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_8), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), /*hidden argument*/NULL);
		V_0 = L_8;
		goto IL_0023;
	}

IL_0023:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_9 = V_0;
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Vector2Int_op_Equality_mD80F6ED22EA1200C4F408440D02FE61388C7D6BA_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_lhs, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___1_rhs, const RuntimeMethod* method) 
{
	bool V_0 = false;
	int32_t G_B3_0 = 0;
	{
		int32_t L_0;
		L_0 = Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline((&___0_lhs), NULL);
		int32_t L_1;
		L_1 = Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline((&___1_rhs), NULL);
		if ((!(((uint32_t)L_0) == ((uint32_t)L_1))))
		{
			goto IL_0023;
		}
	}
	{
		int32_t L_2;
		L_2 = Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline((&___0_lhs), NULL);
		int32_t L_3;
		L_3 = Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline((&___1_rhs), NULL);
		G_B3_0 = ((((int32_t)L_2) == ((int32_t)L_3))? 1 : 0);
		goto IL_0024;
	}

IL_0023:
	{
		G_B3_0 = 0;
	}

IL_0024:
	{
		V_0 = (bool)G_B3_0;
		goto IL_0027;
	}

IL_0027:
	{
		bool L_4 = V_0;
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float Vector2_get_magnitude_m5C59B4056420AEFDB291AD0914A3F675330A75CE_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		float L_0 = __this->___x_0;
		float L_1 = __this->___x_0;
		float L_2 = __this->___y_1;
		float L_3 = __this->___y_1;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_4;
		L_4 = sqrt(((double)((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_0, L_1)), ((float)il2cpp_codegen_multiply(L_2, L_3))))));
		V_0 = ((float)L_4);
		goto IL_0026;
	}

IL_0026:
	{
		float L_5 = V_0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Division_m57A2DCD71E0CE7420851D705D1951F9238902AAB_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_a;
		float L_1 = L_0.___x_0;
		float L_2 = ___1_d;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3 = ___0_a;
		float L_4 = L_3.___y_1;
		float L_5 = ___1_d;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_6;
		memset((&L_6), 0, sizeof(L_6));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_6), ((float)(L_1/L_2)), ((float)(L_4/L_5)), /*hidden argument*/NULL);
		V_0 = L_6;
		goto IL_0019;
	}

IL_0019:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_7 = V_0;
		return L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Vector2_op_Equality_m6F2E069A50E787D131261E5CB25FC9E03F95B5E1_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_lhs, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___1_rhs, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	bool V_2 = false;
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_lhs;
		float L_1 = L_0.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___1_rhs;
		float L_3 = L_2.___x_0;
		V_0 = ((float)il2cpp_codegen_subtract(L_1, L_3));
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4 = ___0_lhs;
		float L_5 = L_4.___y_1;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_6 = ___1_rhs;
		float L_7 = L_6.___y_1;
		V_1 = ((float)il2cpp_codegen_subtract(L_5, L_7));
		float L_8 = V_0;
		float L_9 = V_0;
		float L_10 = V_1;
		float L_11 = V_1;
		V_2 = (bool)((((float)((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_8, L_9)), ((float)il2cpp_codegen_multiply(L_10, L_11))))) < ((float)(9.99999944E-11f)))? 1 : 0);
		goto IL_002e;
	}

IL_002e:
	{
		bool L_12 = V_2;
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2Int__ctor_mC20D1312133EB8CB63EC11067088B043660F11CE_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		__this->___m_X_0 = L_0;
		int32_t L_1 = ___1_y;
		__this->___m_Y_1 = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Vector2Int_get_x_mA2CACB1B6E6B5AD0CCC32B2CD2EDCE3ECEB50576_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->___m_X_0;
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Vector2Int_get_y_m48454163ECF0B463FB5A16A0C4FC4B14DB0768B3_inline (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->___m_Y_1;
		V_0 = L_0;
		goto IL_000a;
	}

IL_000a:
	{
		int32_t L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_get_zero_m32506C40EC2EE7D5D4410BF40D3EE683A3D5F32C_inline (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ((Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_StaticFields*)il2cpp_codegen_static_fields_for(Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7_il2cpp_TypeInfo_var))->___zeroVector_2;
		V_0 = L_0;
		goto IL_0009;
	}

IL_0009:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_1 = V_0;
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector2_op_Implicit_m6D9CABB2C791A192867D7A4559D132BE86DD3EB7_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_v, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_v;
		float L_1 = L_0.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___0_v;
		float L_3 = L_2.___y_1;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4;
		memset((&L_4), 0, sizeof(L_4));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_4), L_1, L_3, (0.0f), /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_001a;
	}

IL_001a:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_5 = V_0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 Quaternion_Euler_m9262AB29E3E9CE94EF71051F38A28E82AEC73F90_inline (float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		float L_0 = ___0_x;
		float L_1 = ___1_y;
		float L_2 = ___2_z;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3;
		memset((&L_3), 0, sizeof(L_3));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_3), L_0, L_1, L_2, /*hidden argument*/NULL);
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4;
		L_4 = Vector3_op_Multiply_m87BA7C578F96C8E49BB07088DAAC4649F83B0353_inline(L_3, (0.0174532924f), NULL);
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_5;
		L_5 = Quaternion_Internal_FromEulerRad_m66D4475341F53949471E6870FB5C5E4A5E9BA93E(L_4, NULL);
		V_0 = L_5;
		goto IL_001b;
	}

IL_001b:
	{
		Quaternion_tDA59F214EF07D7700B26E40E562F267AF7306974 L_6 = V_0;
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x_0 = L_0;
		float L_1 = ___1_y;
		__this->___y_1 = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Multiply_m2D984B613020089BF5165BA4CA10988E2DC771FE_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_a;
		float L_1 = L_0.___x_0;
		float L_2 = ___1_d;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_3 = ___0_a;
		float L_4 = L_3.___y_1;
		float L_5 = ___1_d;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_6;
		memset((&L_6), 0, sizeof(L_6));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_6), ((float)il2cpp_codegen_multiply(L_1, L_2)), ((float)il2cpp_codegen_multiply(L_4, L_5)), /*hidden argument*/NULL);
		V_0 = L_6;
		goto IL_0019;
	}

IL_0019:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_7 = V_0;
		return L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Addition_m8136742CE6EE33BA4EB81C5F584678455917D2AE_inline (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_a, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___1_b, const RuntimeMethod* method) 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_0 = ___0_a;
		float L_1 = L_0.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_2 = ___1_b;
		float L_3 = L_2.___x_0;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4 = ___0_a;
		float L_5 = L_4.___y_1;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_6 = ___1_b;
		float L_7 = L_6.___y_1;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_8;
		memset((&L_8), 0, sizeof(L_8));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_8), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), /*hidden argument*/NULL);
		V_0 = L_8;
		goto IL_0023;
	}

IL_0023:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_9 = V_0;
		return L_9;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t Room_GetActivationRotation_mD585EEAC58FCB6AB88F219D9E624038EF7C37D1C_inline (Room_tD73D04FF0B9E743C836C5550CD2FCACD2183A404* __this, const RuntimeMethod* method) 
{
	{
		// return activation_rotation;
		int32_t L_0 = __this->___activation_rotation_6;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Addition_m78C0EC70CB66E8DCAC225743D82B268DAEE92067_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___1_b, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___1_b;
		float L_3 = L_2.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_4 = ___0_a;
		float L_5 = L_4.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___1_b;
		float L_7 = L_6.___y_3;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_8 = ___0_a;
		float L_9 = L_8.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = ___1_b;
		float L_11 = L_10.___z_4;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_12;
		memset((&L_12), 0, sizeof(L_12));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_12), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), ((float)il2cpp_codegen_add(L_9, L_11)), /*hidden argument*/NULL);
		V_0 = L_12;
		goto IL_0030;
	}

IL_0030:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_13 = V_0;
		return L_13;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x_2 = L_0;
		float L_1 = ___1_y;
		__this->___y_3 = L_1;
		float L_2 = ___2_z;
		__this->___z_4 = L_2;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 Vector2_op_Implicit_mE8EBEE9291F11BB02F062D6E000F4798968CBD96_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_v, const RuntimeMethod* method) 
{
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_v;
		float L_1 = L_0.___x_2;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_2 = ___0_v;
		float L_3 = L_2.___y_3;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_4;
		memset((&L_4), 0, sizeof(L_4));
		Vector2__ctor_m9525B79969AFFE3254B303A40997A56DEEB6F548_inline((&L_4), L_1, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		goto IL_0015;
	}

IL_0015:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_5 = V_0;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m4407E4C389F22B8CEC282C15D56516658746C383_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->____size_2;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_mB5FDF069171C4CB1778BFAC3B9015A22EA7DFBCD_gshared_inline (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B* __this, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___0_item, const RuntimeMethod* method) 
{
	Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->____version_3;
		__this->____version_3 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* L_1 = __this->____items_1;
		V_0 = L_1;
		int32_t L_2 = __this->____size_2;
		V_1 = L_2;
		int32_t L_3 = V_1;
		Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* L_4 = V_0;
		NullCheck(L_4);
		if ((!(((uint32_t)L_3) < ((uint32_t)((int32_t)(((RuntimeArray*)L_4)->max_length))))))
		{
			goto IL_0034;
		}
	}
	{
		int32_t L_5 = V_1;
		__this->____size_2 = ((int32_t)il2cpp_codegen_add(L_5, 1));
		Vector2U5BU5D_tFEBBC94BCC6C9C88277BA04047D2B3FDB6ED7FDA* L_6 = V_0;
		int32_t L_7 = V_1;
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_8 = ___0_item;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7)L_8);
		return;
	}

IL_0034:
	{
		Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 L_9 = ___0_item;
		((  void (*) (List_1_t8F3790B7F8C471B3A1336522C7415FB0AC36D47B*, Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7, const RuntimeMethod*))il2cpp_codegen_get_method_pointer(il2cpp_rgctx_method(method->klass->rgctx_data, 11)))(__this, L_9, il2cpp_rgctx_method(method->klass->rgctx_data, 11));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m7D6CB04952BDE74978E3DEB313A300913D805A76_gshared_inline (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->____size_2;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_mEBCF994CC3814631017F46A387B1A192ED6C85C7_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, RuntimeObject* ___0_item, const RuntimeMethod* method) 
{
	ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->____version_3;
		__this->____version_3 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_1 = __this->____items_1;
		V_0 = L_1;
		int32_t L_2 = __this->____size_2;
		V_1 = L_2;
		int32_t L_3 = V_1;
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_4 = V_0;
		NullCheck(L_4);
		if ((!(((uint32_t)L_3) < ((uint32_t)((int32_t)(((RuntimeArray*)L_4)->max_length))))))
		{
			goto IL_0034;
		}
	}
	{
		int32_t L_5 = V_1;
		__this->____size_2 = ((int32_t)il2cpp_codegen_add(L_5, 1));
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_6 = V_0;
		int32_t L_7 = V_1;
		RuntimeObject* L_8 = ___0_item;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (RuntimeObject*)L_8);
		return;
	}

IL_0034:
	{
		RuntimeObject* L_9 = ___0_item;
		((  void (*) (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D*, RuntimeObject*, const RuntimeMethod*))il2cpp_codegen_get_method_pointer(il2cpp_rgctx_method(method->klass->rgctx_data, 11)))(__this, L_9, il2cpp_rgctx_method(method->klass->rgctx_data, 11));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_m771AC7A01DFC931CCCFCCF949C1F4D56B5E98A1B_gshared_inline (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D* __this, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___0_item, const RuntimeMethod* method) 
{
	Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->____version_3;
		__this->____version_3 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534* L_1 = __this->____items_1;
		V_0 = L_1;
		int32_t L_2 = __this->____size_2;
		V_1 = L_2;
		int32_t L_3 = V_1;
		Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534* L_4 = V_0;
		NullCheck(L_4);
		if ((!(((uint32_t)L_3) < ((uint32_t)((int32_t)(((RuntimeArray*)L_4)->max_length))))))
		{
			goto IL_0034;
		}
	}
	{
		int32_t L_5 = V_1;
		__this->____size_2 = ((int32_t)il2cpp_codegen_add(L_5, 1));
		Vector2IntU5BU5D_tF9E2BDAC11B246DF7EEB9137B826A0CBEBD59534* L_6 = V_0;
		int32_t L_7 = V_1;
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_8 = ___0_item;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A)L_8);
		return;
	}

IL_0034:
	{
		Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A L_9 = ___0_item;
		((  void (*) (List_1_tB56F1028A724D2CE4E84861619D1CF68C68C983D*, Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A, const RuntimeMethod*))il2cpp_codegen_get_method_pointer(il2cpp_rgctx_method(method->klass->rgctx_data, 11)))(__this, L_9, il2cpp_rgctx_method(method->klass->rgctx_data, 11));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Clear_m16C1F2C61FED5955F10EB36BC1CB2DF34B128994_gshared_inline (List_1_tA239CB83DE5615F348BB0507E45F490F4F7C9A8D* __this, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = __this->____version_3;
		__this->____version_3 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		if (!true)
		{
			goto IL_0035;
		}
	}
	{
		int32_t L_1 = __this->____size_2;
		V_0 = L_1;
		__this->____size_2 = 0;
		int32_t L_2 = V_0;
		if ((((int32_t)L_2) <= ((int32_t)0)))
		{
			goto IL_003c;
		}
	}
	{
		ObjectU5BU5D_t8061030B0A12A55D5AD8652A20C922FE99450918* L_3 = __this->____items_1;
		int32_t L_4 = V_0;
		Array_Clear_m50BAA3751899858B097D3FF2ED31F284703FE5CB((RuntimeArray*)L_3, 0, L_4, NULL);
		return;
	}

IL_0035:
	{
		__this->____size_2 = 0;
	}

IL_003c:
	{
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_m2F8FBCD34E84D2440E635E6770BC3148AB83C3B2_gshared_inline (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2* __this, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 ___0_item, const RuntimeMethod* method) 
{
	SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->____version_3;
		__this->____version_3 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_1 = __this->____items_1;
		V_0 = L_1;
		int32_t L_2 = __this->____size_2;
		V_1 = L_2;
		int32_t L_3 = V_1;
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_4 = V_0;
		NullCheck(L_4);
		if ((!(((uint32_t)L_3) < ((uint32_t)((int32_t)(((RuntimeArray*)L_4)->max_length))))))
		{
			goto IL_0034;
		}
	}
	{
		int32_t L_5 = V_1;
		__this->____size_2 = ((int32_t)il2cpp_codegen_add(L_5, 1));
		SpawnPointU5BU5D_t2374AACB6C344EBFD506765642864D7DF6992F61* L_6 = V_0;
		int32_t L_7 = V_1;
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_8 = ___0_item;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0)L_8);
		return;
	}

IL_0034:
	{
		SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0 L_9 = ___0_item;
		((  void (*) (List_1_tA6D3CE2D18437FDE82DF33708D290FBEB00148E2*, SpawnPoint_t81F578AB52FA6AA9A38B09C695515C14A0FF54B0, const RuntimeMethod*))il2cpp_codegen_get_method_pointer(il2cpp_rgctx_method(method->klass->rgctx_data, 11)))(__this, L_9, il2cpp_rgctx_method(method->klass->rgctx_data, 11));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void List_1_Add_m9423514FF12E538E6D90B267B916270EDAD7F9B5_gshared_inline (List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E* __this, ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 ___0_item, const RuntimeMethod* method) 
{
	ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->____version_3;
		__this->____version_3 = ((int32_t)il2cpp_codegen_add(L_0, 1));
		ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E* L_1 = __this->____items_1;
		V_0 = L_1;
		int32_t L_2 = __this->____size_2;
		V_1 = L_2;
		int32_t L_3 = V_1;
		ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E* L_4 = V_0;
		NullCheck(L_4);
		if ((!(((uint32_t)L_3) < ((uint32_t)((int32_t)(((RuntimeArray*)L_4)->max_length))))))
		{
			goto IL_0034;
		}
	}
	{
		int32_t L_5 = V_1;
		__this->____size_2 = ((int32_t)il2cpp_codegen_add(L_5, 1));
		ValueTuple_2U5BU5D_t2DEFAAA5A976911B265E3208E07CE6C9933F621E* L_6 = V_0;
		int32_t L_7 = V_1;
		ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 L_8 = ___0_item;
		NullCheck(L_6);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13)L_8);
		return;
	}

IL_0034:
	{
		ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13 L_9 = ___0_item;
		((  void (*) (List_1_t829721D2CD727AD399BA15E086EBE65F1E543F0E*, ValueTuple_2_t67A521A0A5BCCACC03D97EF803CC4F18958F0F13, const RuntimeMethod*))il2cpp_codegen_get_method_pointer(il2cpp_rgctx_method(method->klass->rgctx_data, 11)))(__this, L_9, il2cpp_rgctx_method(method->klass->rgctx_data, 11));
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 Vector3_op_Multiply_m87BA7C578F96C8E49BB07088DAAC4649F83B0353_inline (Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___0_a, float ___1_d, const RuntimeMethod* method) 
{
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_0 = ___0_a;
		float L_1 = L_0.___x_2;
		float L_2 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_3 = ___0_a;
		float L_4 = L_3.___y_3;
		float L_5 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_6 = ___0_a;
		float L_7 = L_6.___z_4;
		float L_8 = ___1_d;
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_9;
		memset((&L_9), 0, sizeof(L_9));
		Vector3__ctor_m376936E6B999EF1ECBE57D990A386303E2283DE0_inline((&L_9), ((float)il2cpp_codegen_multiply(L_1, L_2)), ((float)il2cpp_codegen_multiply(L_4, L_5)), ((float)il2cpp_codegen_multiply(L_7, L_8)), /*hidden argument*/NULL);
		V_0 = L_9;
		goto IL_0021;
	}

IL_0021:
	{
		Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 L_10 = V_0;
		return L_10;
	}
}
