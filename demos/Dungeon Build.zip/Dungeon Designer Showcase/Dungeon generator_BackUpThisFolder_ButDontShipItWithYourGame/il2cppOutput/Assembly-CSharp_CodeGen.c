﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void Tester::Update()
extern void Tester_Update_mF75D641178A6BCCCEDA69064EB10CD4734438FF5 (void);
// 0x00000002 System.Collections.IEnumerator Tester::loop()
extern void Tester_loop_m1CD17E61D20BA2F286FA8B628BCF58B262C51DC6 (void);
// 0x00000003 System.Void Tester::Show()
extern void Tester_Show_m5C9B329A7906F6BC93BEB481C2B0CE8AEF697705 (void);
// 0x00000004 System.Void Tester::.ctor()
extern void Tester__ctor_mB83E1CEF76CEF9C95ADD9D1867EA55A7A9C8DDBB (void);
// 0x00000005 System.Void Tester/<loop>d__3::.ctor(System.Int32)
extern void U3CloopU3Ed__3__ctor_m0EB9D6D302D7F4E0EA0D8E38B1E447F471228941 (void);
// 0x00000006 System.Void Tester/<loop>d__3::System.IDisposable.Dispose()
extern void U3CloopU3Ed__3_System_IDisposable_Dispose_mB0C975BA31BBFB438C3091F78BD2E68FFE103B98 (void);
// 0x00000007 System.Boolean Tester/<loop>d__3::MoveNext()
extern void U3CloopU3Ed__3_MoveNext_m5BE2C670FB6FA809917DFE26C7954AA1A977131E (void);
// 0x00000008 System.Object Tester/<loop>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CloopU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m178C36F2562192D59739078AA03BBE78255D3BA9 (void);
// 0x00000009 System.Void Tester/<loop>d__3::System.Collections.IEnumerator.Reset()
extern void U3CloopU3Ed__3_System_Collections_IEnumerator_Reset_mDFBAFEB791DDF7FE317D9CAA3304254E9AA97A22 (void);
// 0x0000000A System.Object Tester/<loop>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CloopU3Ed__3_System_Collections_IEnumerator_get_Current_mBC9F1FE87350D677977D4968BB9B5183B4DFD414 (void);
// 0x0000000B System.Void PixelCollider.PixelCollider2D::Regenerate()
extern void PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7 (void);
// 0x0000000C System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2>> PixelCollider.PixelCollider2D::Finalize_Paths(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>,UnityEngine.Sprite)
extern void PixelCollider2D_Finalize_Paths_m88E0EA0CFBDE2DADE57268C1116A9E1E91D47ECF (void);
// 0x0000000D System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Simplify_Paths_Phase_1(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>)
extern void PixelCollider2D_Simplify_Paths_Phase_1_m3054733C750DC0318B29B2941CBE87C5AD6226C1 (void);
// 0x0000000E System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Simplify_Paths_Phase_2(System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>>)
extern void PixelCollider2D_Simplify_Paths_Phase_2_mDDF788D66579E9EBF363A083056902AC6DE3874A (void);
// 0x0000000F System.Collections.Generic.List`1<System.Collections.Generic.List`1<UnityEngine.Vector2Int>> PixelCollider.PixelCollider2D::Get_Unit_Paths(UnityEngine.Texture2D,System.Single)
extern void PixelCollider2D_Get_Unit_Paths_m6F6B4B95F9074198C788267EFF5D6405AB6A8EB4 (void);
// 0x00000010 System.Boolean PixelCollider.PixelCollider2D::pixelSolid(UnityEngine.Texture2D,UnityEngine.Vector2Int,System.Single)
extern void PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2 (void);
// 0x00000011 System.Void PixelCollider.PixelCollider2D::.ctor()
extern void PixelCollider2D__ctor_mFE9D9734480050BB89A63B0C1354C03F4299FB10 (void);
// 0x00000012 System.Void DungeonGenerator.Dungeon::Start()
extern void Dungeon_Start_m68463C9782D5BAAA0F983EB8A6FFA6EDDA1F1842 (void);
// 0x00000013 System.Void DungeonGenerator.Dungeon::GenerateDungeon()
extern void Dungeon_GenerateDungeon_m09621F7697AC301ECD310E1320E847D7EDFFB10D (void);
// 0x00000014 System.Void DungeonGenerator.Dungeon::GenerateFirst()
extern void Dungeon_GenerateFirst_m8715C4306C6ABCB9E478E73B12132CC2F7E0DD60 (void);
// 0x00000015 System.Void DungeonGenerator.Dungeon::DestroyDungeon()
extern void Dungeon_DestroyDungeon_m11ADC224AEEA4D854500F6D4A7564C2A906EA22F (void);
// 0x00000016 System.Void DungeonGenerator.Dungeon::GenerateFromRoom(DungeonGenerator.Room)
extern void Dungeon_GenerateFromRoom_m437D042CBB67DFF7F19FA8A4F8C9639D724EFBA8 (void);
// 0x00000017 System.Void DungeonGenerator.Dungeon::GenerateFromLink(DungeonGenerator.Room/Link,DungeonGenerator.Room)
extern void Dungeon_GenerateFromLink_m6E4C3BA491302C3D6132DA76D99E86AB1CF369C7 (void);
// 0x00000018 DungeonGenerator.Room DungeonGenerator.Dungeon::AddRooms(DungeonGenerator.Room,DungeonGenerator.Room)
extern void Dungeon_AddRooms_m3D3C97690BDF4618559AAC205FFAEB8D40320AFA (void);
// 0x00000019 DungeonGenerator.Room DungeonGenerator.Dungeon::RandomRoom()
extern void Dungeon_RandomRoom_mF59C744A7A66100F033CD9536DC5D2495AA8EC9B (void);
// 0x0000001A System.Int32 DungeonGenerator.Dungeon::Normalized(System.Int32)
extern void Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA (void);
// 0x0000001B System.Void DungeonGenerator.Dungeon::.ctor()
extern void Dungeon__ctor_mFE80CC90F277257724D6F229110BFDBAEFEACF05 (void);
// 0x0000001C System.Void DungeonGenerator.Dungeon::<AddRooms>g__Distinct|14_0(System.Collections.Generic.List`1<DungeonGenerator.Room/Link>)
extern void Dungeon_U3CAddRoomsU3Eg__DistinctU7C14_0_mC7B9629734C039FEAC834D902336C88F33E5307E (void);
// 0x0000001D System.Void DungeonGenerator.Dungeon::<AddRooms>g__Sort|14_1(System.Collections.Generic.IEnumerable`1<DungeonGenerator.Room/Link>)
extern void Dungeon_U3CAddRoomsU3Eg__SortU7C14_1_m037CC0569376A031A30912BC8E5F6787F98E06BA (void);
// 0x0000001E System.Boolean DungeonGenerator.Dungeon::<AddRooms>g__AngleMatch|14_2(DungeonGenerator.Room/Link[],DungeonGenerator.Room/Link[])
extern void Dungeon_U3CAddRoomsU3Eg__AngleMatchU7C14_2_m02B65223985DB827BB9659F00877C1409FF11A14 (void);
// 0x0000001F DungeonGenerator.Room/Link[] DungeonGenerator.Dungeon::<AddRooms>g__NormalizeAngles|14_3(DungeonGenerator.Room/Link[],System.Int32)
extern void Dungeon_U3CAddRoomsU3Eg__NormalizeAnglesU7C14_3_m39FB34A370A8930F673CA42078ED5E2E5B80414C (void);
// 0x00000020 System.Void DungeonGenerator.Dungeon::<AddRooms>g__DisableLinks|14_4(DungeonGenerator.Room,DungeonGenerator.Room)
extern void Dungeon_U3CAddRoomsU3Eg__DisableLinksU7C14_4_m1F011D4844CB48DEB66D6EC54EADEF34C784A3C9 (void);
// 0x00000021 System.Void DungeonGenerator.Dungeon/<>c__DisplayClass13_0::.ctor()
extern void U3CU3Ec__DisplayClass13_0__ctor_m06A2E9304E55E1226138916A1E18D697DA8DDB41 (void);
// 0x00000022 System.Boolean DungeonGenerator.Dungeon/<>c__DisplayClass13_0::<GenerateFromLink>b__0(DungeonGenerator.Room)
extern void U3CU3Ec__DisplayClass13_0_U3CGenerateFromLinkU3Eb__0_m267464DB7CBAE1AB6FFB27DCF39E3DD15D91C413 (void);
// 0x00000023 DungeonGenerator.Room[] DungeonGenerator.DungeonDesigner::getDungeon(DungeonGenerator.Dungeon)
extern void DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F (void);
// 0x00000024 DungeonGenerator.Model DungeonGenerator.DungeonDesigner::RoomToModel(DungeonGenerator.Room)
extern void DungeonDesigner_RoomToModel_m7DF305BE8C449842BD12AC327A56C73CAA053B2D (void);
// 0x00000025 System.Boolean DungeonGenerator.DungeonDesigner::Contains(System.Array,System.Object)
extern void DungeonDesigner_Contains_m159F5B7F3AD84DC9185747D461F7224A503E6040 (void);
// 0x00000026 System.Void DungeonGenerator.DungeonDesigner::PopulateAll(DungeonGenerator.Dungeon)
extern void DungeonDesigner_PopulateAll_m23406622813261B8262D4F608C2F6D078150FA62 (void);
// 0x00000027 System.Void DungeonGenerator.DungeonDesigner::Spawn(DungeonGenerator.Model/SpawnPoint,DungeonGenerator.Room)
extern void DungeonDesigner_Spawn_mD5742B2869D433DCF9417BAD9C357B7A17E1E4F6 (void);
// 0x00000028 System.Void DungeonGenerator.DungeonDesigner::SpawnRandomN(DungeonGenerator.Dungeon,System.Int32)
extern void DungeonDesigner_SpawnRandomN_m56C8F4BF0E57401469B33FCBAEFD04340BC89990 (void);
// 0x00000029 System.Void DungeonGenerator.DungeonDesigner::Awake()
extern void DungeonDesigner_Awake_m590402CE7A4F6FBE0FE01C3138DBC10860169C0B (void);
// 0x0000002A System.Collections.IEnumerator DungeonGenerator.DungeonDesigner::DecorateDungeon()
extern void DungeonDesigner_DecorateDungeon_m42A5ECCDE936DDB8A71B8ED2C604DFE2D068ED8D (void);
// 0x0000002B System.Void DungeonGenerator.DungeonDesigner::.ctor()
extern void DungeonDesigner__ctor_m25B3DCC8CB97E0FA5AFCD8AD409262788EA7EA3A (void);
// 0x0000002C System.Void DungeonGenerator.DungeonDesigner::<Spawn>g__FlipCheck|12_0(DungeonGenerator.DungeonDesigner/Spawnable,UnityEngine.GameObject,DungeonGenerator.DungeonDesigner/<>c__DisplayClass12_0&)
extern void DungeonDesigner_U3CSpawnU3Eg__FlipCheckU7C12_0_m0C267CF9CAE77F246C2E72B68168D4B86FE506F2 (void);
// 0x0000002D System.Void DungeonGenerator.DungeonDesigner/<>c::.cctor()
extern void U3CU3Ec__cctor_m6E63BFEAE3BAC3EB1B9B8CDE7A98A610C3499DBB (void);
// 0x0000002E System.Void DungeonGenerator.DungeonDesigner/<>c::.ctor()
extern void U3CU3Ec__ctor_mD27026C1F9A45AA0C1D922C1165B4629D17494FC (void);
// 0x0000002F System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_1(DungeonGenerator.DungeonDesigner/Spawnable)
extern void U3CU3Ec_U3CSpawnU3Eb__12_1_m60B3C71B30B827EA6AB771B0EF357E99EA96FE93 (void);
// 0x00000030 System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_2(DungeonGenerator.DungeonDesigner/Spawnable)
extern void U3CU3Ec_U3CSpawnU3Eb__12_2_m240F5CF405EC66C270BCD4801ACF20066633CCBE (void);
// 0x00000031 System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_3(DungeonGenerator.DungeonDesigner/Spawnable)
extern void U3CU3Ec_U3CSpawnU3Eb__12_3_mBFB7BEB81624B39BF596D983CB6B71E91BC0C184 (void);
// 0x00000032 System.Boolean DungeonGenerator.DungeonDesigner/<>c::<Spawn>b__12_4(DungeonGenerator.DungeonDesigner/Spawnable)
extern void U3CU3Ec_U3CSpawnU3Eb__12_4_m87F641E977858C2103703711151AF1C00AC926F9 (void);
// 0x00000033 System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::.ctor(System.Int32)
extern void U3CDecorateDungeonU3Ed__17__ctor_m1ED48BFA78B792EC4E43CDA3E496583F5172F37B (void);
// 0x00000034 System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.IDisposable.Dispose()
extern void U3CDecorateDungeonU3Ed__17_System_IDisposable_Dispose_m3776D2A1B0B1A3C045361C21C836F67290AAFDC9 (void);
// 0x00000035 System.Boolean DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::MoveNext()
extern void U3CDecorateDungeonU3Ed__17_MoveNext_m2B94D724615515BC2B269E525B22D5F530996294 (void);
// 0x00000036 System.Object DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDecorateDungeonU3Ed__17_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m07B60834727E843AD189567EB9E4A49C4C64FC20 (void);
// 0x00000037 System.Void DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.Collections.IEnumerator.Reset()
extern void U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_Reset_m5DA478BBBA8FEE33F186D61520F10B132227BED2 (void);
// 0x00000038 System.Object DungeonGenerator.DungeonDesigner/<DecorateDungeon>d__17::System.Collections.IEnumerator.get_Current()
extern void U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_get_Current_m85BB93CF408EFB73A4F700B3DEA4472D8C89C793 (void);
// 0x00000039 System.Void DungeonGenerator.Model::.ctor()
extern void Model__ctor_m0FB6FFD9DCAB32E41C0CC2FA501DB8963C0361EF (void);
// 0x0000003A System.Void DungeonGenerator.Model::.ctor(DungeonGenerator.Model/SpawnPoint[])
extern void Model__ctor_m05A1645191AA545C4412C449D4FF2444E42EFBAE (void);
// 0x0000003B DungeonGenerator.DungeonDesigner/Orientation DungeonGenerator.Model::Orientation(DungeonGenerator.Model/SpawnPoint)
extern void Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A (void);
// 0x0000003C System.Void DungeonGenerator.Model/SpawnPoint::.ctor(UnityEngine.Transform,DungeonGenerator.Model/Type,DungeonGenerator.Model/Location,DungeonGenerator.Model/NeedsWall)
extern void SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22 (void);
// 0x0000003D System.Int32 DungeonGenerator.Room::get_rotation()
extern void Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415 (void);
// 0x0000003E System.Void DungeonGenerator.Room::set_rotation(System.Int32)
extern void Room_set_rotation_m436F74FF610C99B98252E1DD84C68089F9FC46A9 (void);
// 0x0000003F UnityEngine.Vector2 DungeonGenerator.Room::get_position()
extern void Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F (void);
// 0x00000040 System.Void DungeonGenerator.Room::set_position(UnityEngine.Vector2)
extern void Room_set_position_m6AE5E1964F76BC88D453111FA7535ECB00AAF44D (void);
// 0x00000041 System.Void DungeonGenerator.Room::ActivateGraphics(System.Boolean)
extern void Room_ActivateGraphics_mD775D2203F51E0CB69D089C1BFBDB85996B34BE4 (void);
// 0x00000042 System.Int32 DungeonGenerator.Room::GetActivationRotation()
extern void Room_GetActivationRotation_mD585EEAC58FCB6AB88F219D9E624038EF7C37D1C (void);
// 0x00000043 System.Void DungeonGenerator.Room::.ctor()
extern void Room__ctor_m5AA1689F9308ACE3C097A309725BB48A0DD8D4CD (void);
// 0x00000044 System.Void DungeonGenerator.Room/Link::.ctor(System.Int32,System.Boolean)
extern void Link__ctor_m43A114F7E47CE536A887DE0ED6AC1832C119F7E7 (void);
// 0x00000045 System.Void DungeonGenerator.Room/Link::.ctor(System.Int32)
extern void Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB (void);
// 0x00000046 System.Void DungeonGenerator.Room/Graphic::.ctor()
extern void Graphic__ctor_m34E3C7ECA3E4289DA95D6D6C45683CB7D144E4B1 (void);
static Il2CppMethodPointer s_methodPointers[70] = 
{
	Tester_Update_mF75D641178A6BCCCEDA69064EB10CD4734438FF5,
	Tester_loop_m1CD17E61D20BA2F286FA8B628BCF58B262C51DC6,
	Tester_Show_m5C9B329A7906F6BC93BEB481C2B0CE8AEF697705,
	Tester__ctor_mB83E1CEF76CEF9C95ADD9D1867EA55A7A9C8DDBB,
	U3CloopU3Ed__3__ctor_m0EB9D6D302D7F4E0EA0D8E38B1E447F471228941,
	U3CloopU3Ed__3_System_IDisposable_Dispose_mB0C975BA31BBFB438C3091F78BD2E68FFE103B98,
	U3CloopU3Ed__3_MoveNext_m5BE2C670FB6FA809917DFE26C7954AA1A977131E,
	U3CloopU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m178C36F2562192D59739078AA03BBE78255D3BA9,
	U3CloopU3Ed__3_System_Collections_IEnumerator_Reset_mDFBAFEB791DDF7FE317D9CAA3304254E9AA97A22,
	U3CloopU3Ed__3_System_Collections_IEnumerator_get_Current_mBC9F1FE87350D677977D4968BB9B5183B4DFD414,
	PixelCollider2D_Regenerate_mF6B075DFD32A5093E5606E42204D68A5880086E7,
	PixelCollider2D_Finalize_Paths_m88E0EA0CFBDE2DADE57268C1116A9E1E91D47ECF,
	PixelCollider2D_Simplify_Paths_Phase_1_m3054733C750DC0318B29B2941CBE87C5AD6226C1,
	PixelCollider2D_Simplify_Paths_Phase_2_mDDF788D66579E9EBF363A083056902AC6DE3874A,
	PixelCollider2D_Get_Unit_Paths_m6F6B4B95F9074198C788267EFF5D6405AB6A8EB4,
	PixelCollider2D_pixelSolid_mD2C57A891CE7D7EB0BC3C6F6501F726AEBEB49E2,
	PixelCollider2D__ctor_mFE9D9734480050BB89A63B0C1354C03F4299FB10,
	Dungeon_Start_m68463C9782D5BAAA0F983EB8A6FFA6EDDA1F1842,
	Dungeon_GenerateDungeon_m09621F7697AC301ECD310E1320E847D7EDFFB10D,
	Dungeon_GenerateFirst_m8715C4306C6ABCB9E478E73B12132CC2F7E0DD60,
	Dungeon_DestroyDungeon_m11ADC224AEEA4D854500F6D4A7564C2A906EA22F,
	Dungeon_GenerateFromRoom_m437D042CBB67DFF7F19FA8A4F8C9639D724EFBA8,
	Dungeon_GenerateFromLink_m6E4C3BA491302C3D6132DA76D99E86AB1CF369C7,
	Dungeon_AddRooms_m3D3C97690BDF4618559AAC205FFAEB8D40320AFA,
	Dungeon_RandomRoom_mF59C744A7A66100F033CD9536DC5D2495AA8EC9B,
	Dungeon_Normalized_mD96B8A5B58E86B58633BC966621708ED493527EA,
	Dungeon__ctor_mFE80CC90F277257724D6F229110BFDBAEFEACF05,
	Dungeon_U3CAddRoomsU3Eg__DistinctU7C14_0_mC7B9629734C039FEAC834D902336C88F33E5307E,
	Dungeon_U3CAddRoomsU3Eg__SortU7C14_1_m037CC0569376A031A30912BC8E5F6787F98E06BA,
	Dungeon_U3CAddRoomsU3Eg__AngleMatchU7C14_2_m02B65223985DB827BB9659F00877C1409FF11A14,
	Dungeon_U3CAddRoomsU3Eg__NormalizeAnglesU7C14_3_m39FB34A370A8930F673CA42078ED5E2E5B80414C,
	Dungeon_U3CAddRoomsU3Eg__DisableLinksU7C14_4_m1F011D4844CB48DEB66D6EC54EADEF34C784A3C9,
	U3CU3Ec__DisplayClass13_0__ctor_m06A2E9304E55E1226138916A1E18D697DA8DDB41,
	U3CU3Ec__DisplayClass13_0_U3CGenerateFromLinkU3Eb__0_m267464DB7CBAE1AB6FFB27DCF39E3DD15D91C413,
	DungeonDesigner_getDungeon_m5093578C4E170E1019889A3883C1940F653EEA3F,
	DungeonDesigner_RoomToModel_m7DF305BE8C449842BD12AC327A56C73CAA053B2D,
	DungeonDesigner_Contains_m159F5B7F3AD84DC9185747D461F7224A503E6040,
	DungeonDesigner_PopulateAll_m23406622813261B8262D4F608C2F6D078150FA62,
	DungeonDesigner_Spawn_mD5742B2869D433DCF9417BAD9C357B7A17E1E4F6,
	DungeonDesigner_SpawnRandomN_m56C8F4BF0E57401469B33FCBAEFD04340BC89990,
	DungeonDesigner_Awake_m590402CE7A4F6FBE0FE01C3138DBC10860169C0B,
	DungeonDesigner_DecorateDungeon_m42A5ECCDE936DDB8A71B8ED2C604DFE2D068ED8D,
	DungeonDesigner__ctor_m25B3DCC8CB97E0FA5AFCD8AD409262788EA7EA3A,
	DungeonDesigner_U3CSpawnU3Eg__FlipCheckU7C12_0_m0C267CF9CAE77F246C2E72B68168D4B86FE506F2,
	U3CU3Ec__cctor_m6E63BFEAE3BAC3EB1B9B8CDE7A98A610C3499DBB,
	U3CU3Ec__ctor_mD27026C1F9A45AA0C1D922C1165B4629D17494FC,
	U3CU3Ec_U3CSpawnU3Eb__12_1_m60B3C71B30B827EA6AB771B0EF357E99EA96FE93,
	U3CU3Ec_U3CSpawnU3Eb__12_2_m240F5CF405EC66C270BCD4801ACF20066633CCBE,
	U3CU3Ec_U3CSpawnU3Eb__12_3_mBFB7BEB81624B39BF596D983CB6B71E91BC0C184,
	U3CU3Ec_U3CSpawnU3Eb__12_4_m87F641E977858C2103703711151AF1C00AC926F9,
	U3CDecorateDungeonU3Ed__17__ctor_m1ED48BFA78B792EC4E43CDA3E496583F5172F37B,
	U3CDecorateDungeonU3Ed__17_System_IDisposable_Dispose_m3776D2A1B0B1A3C045361C21C836F67290AAFDC9,
	U3CDecorateDungeonU3Ed__17_MoveNext_m2B94D724615515BC2B269E525B22D5F530996294,
	U3CDecorateDungeonU3Ed__17_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m07B60834727E843AD189567EB9E4A49C4C64FC20,
	U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_Reset_m5DA478BBBA8FEE33F186D61520F10B132227BED2,
	U3CDecorateDungeonU3Ed__17_System_Collections_IEnumerator_get_Current_m85BB93CF408EFB73A4F700B3DEA4472D8C89C793,
	Model__ctor_m0FB6FFD9DCAB32E41C0CC2FA501DB8963C0361EF,
	Model__ctor_m05A1645191AA545C4412C449D4FF2444E42EFBAE,
	Model_Orientation_m5D2D5A225E8F1690FE43EF504CED3943BDAE897A,
	SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22,
	Room_get_rotation_m5D6D8BAD530E8A71FE2E0847F6638A7879BEA415,
	Room_set_rotation_m436F74FF610C99B98252E1DD84C68089F9FC46A9,
	Room_get_position_mDC215A50A922B766FC88E87EE16E08BE6003A52F,
	Room_set_position_m6AE5E1964F76BC88D453111FA7535ECB00AAF44D,
	Room_ActivateGraphics_mD775D2203F51E0CB69D089C1BFBDB85996B34BE4,
	Room_GetActivationRotation_mD585EEAC58FCB6AB88F219D9E624038EF7C37D1C,
	Room__ctor_m5AA1689F9308ACE3C097A309725BB48A0DD8D4CD,
	Link__ctor_m43A114F7E47CE536A887DE0ED6AC1832C119F7E7,
	Link__ctor_m68D0FD468A19DD685EAF3EB8361435BB118855EB,
	Graphic__ctor_m34E3C7ECA3E4289DA95D6D6C45683CB7D144E4B1,
};
extern void SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[1] = 
{
	{ 0x0600003C, SpawnPoint__ctor_m66D186F055531F62A077A4DCC0D7DB4D219A5D22_AdjustorThunk },
};
static const int32_t s_InvokerIndices[70] = 
{
	3712,
	3613,
	3712,
	3712,
	2974,
	3712,
	3551,
	3613,
	3712,
	3613,
	3712,
	1275,
	5342,
	5342,
	4963,
	4441,
	3712,
	3712,
	3712,
	3712,
	3712,
	2993,
	1650,
	1275,
	3613,
	5280,
	3712,
	5484,
	5484,
	4808,
	4957,
	5108,
	3712,
	2113,
	2634,
	2634,
	4808,
	2993,
	1707,
	1646,
	3712,
	3613,
	3712,
	4726,
	5591,
	3712,
	2226,
	2226,
	2226,
	2226,
	2974,
	3712,
	3551,
	3613,
	3712,
	3613,
	3712,
	2993,
	5291,
	594,
	3592,
	2974,
	3701,
	3073,
	2927,
	3592,
	3712,
	1469,
	2974,
	3712,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharp_CodeGenModule = 
{
	"Assembly-CSharp.dll",
	70,
	s_methodPointers,
	1,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
