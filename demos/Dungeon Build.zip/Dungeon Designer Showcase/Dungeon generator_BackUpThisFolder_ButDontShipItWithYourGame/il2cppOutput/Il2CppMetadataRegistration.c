﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





extern Il2CppGenericClass* const g_Il2CppGenericTypes[];
extern const Il2CppGenericInst* const g_Il2CppGenericInstTable[];
extern const Il2CppGenericMethodFunctionsDefinitions g_Il2CppGenericMethodFunctions[];
extern const Il2CppType* const  g_Il2CppTypeTable[];
extern const Il2CppMethodSpec g_Il2CppMethodSpecTable[];
IL2CPP_EXTERN_C_CONST int32_t* g_FieldOffsetTable[];
IL2CPP_EXTERN_C_CONST Il2CppTypeDefinitionSizes* g_Il2CppTypeDefinitionSizesTable[];
IL2CPP_EXTERN_C const Il2CppMetadataRegistration g_MetadataRegistration;
const Il2CppMetadataRegistration g_MetadataRegistration = 
{
	2879,
	g_Il2CppGenericTypes,
	1747,
	g_Il2CppGenericInstTable,
	22128,
	g_Il2CppGenericMethodFunctions,
	10809,
	g_Il2CppTypeTable,
	26864,
	g_Il2CppMethodSpecTable,
	3719,
	g_FieldOffsetTable,
	3719,
	g_Il2CppTypeDefinitionSizesTable,
	0,
	NULL,
};
