'a' for generating a new dungeon
'q' for generating a new dungeon every 2 seconds
'p' for pause
'esc' to quit